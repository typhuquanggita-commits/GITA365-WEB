# Cơ sở nghiên cứu V27

Nguồn chính thức đã đọc:
- https://huggingface.co/docs/diffusers/v0.35.1/api/pipelines/ltx_video — LTXConditionPipeline nhận prompt_embeds/attention masks; khuyến nghị VAE tiling, guidance theo model, điều kiện tham chiếu.
- https://huggingface.co/docs/diffusers/v0.35.1/optimization/memory — model, sequential và group offload có đánh đổi RAM/tốc độ; group có giới hạn tương thích.
- https://huggingface.co/docs/transformers/v4.57.1/quantization/bitsandbytes — lượng tử hóa mô hình có Linear/Accelerate, T4 hỗ trợ LLM.int8.
- https://huggingface.co/docs/bitsandbytes/installation — LLM.int8 cần capability 7.5 trở lên, tương thích phụ thuộc PyTorch/CUDA.
- https://www.kaggle.com/discussions/product-announcements/735239 — thông báo nghỉ P100; phát hiện phần cứng thực tế thay vì cấu hình cố định theo bài hướng dẫn cũ.

Quyết định triển khai: tách encoder T5, không trộn quantized encoder với hook CPU offload của video; hai GPU phân vai khi có đủ bộ nhớ; cache embedding CPU giới hạn; dtype theo capability; giữ model 0.9.5; không bật torch.compile/FP8/group stream mặc định vì cold start, tương thích và RAM host chưa được benchmark.

Các ngưỡng VRAM, RAM và profile là lựa chọn kỹ thuật của bản code, không phải benchmark hoặc cam kết từ Kaggle/Hugging Face. Hiệu quả phải đo cùng model, prompt, seed, resolution, frames, QA và phiên bản thư viện. Chỉ so sánh các lượt khác cấu hình sẽ không chứng minh tốc độ cải thiện do engine.
