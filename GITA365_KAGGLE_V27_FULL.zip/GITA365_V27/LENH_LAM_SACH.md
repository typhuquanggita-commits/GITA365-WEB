# Lệnh làm sạch V27

Dùng bản full GITA365_KAGGLE_V27_CODE.txt thay V26.

1. Cancel Run và chờ cell worker dừng hoàn toàn.
2. Chạy cell xem trước:
```python
bao_cao = lam_sach_dia()
print(bao_cao)
```
3. Xóa những file được xác định an toàn:
```python
bao_cao = lam_sach_dia(thuc_hien=True)
print(bao_cao)
```
Phim có biên nhận cold được đối chiếu kho từ xa và kiểm tra toàn bộ SHA-256 trước khi dọn. ready/web_uploaded chưa có xác minh archive bị bỏ qua. Có thể hoàn tất lưu trữ từ V26 trước rồi dọn; không tự coi phản hồi upload cũ là bằng chứng lưu trữ an toàn.

Nếu đã tải phim về laptop, kiểm tra tải đủ và mở được phim, sau đó ghi xác nhận cho biên nhận đúng:
```python
xac_nhan_da_tai_laptop(
    '/kaggle/working/gita365-v24/TEN_PHIEN/jobs/MA_PHIM_delivery.json',
    da_kiem_tra=True
)
lam_sach_dia(thuc_hien=True)
```
Thay TEN_PHIEN và MA_PHIM theo đường dẫn thực tế. Đây là xác nhận của người dùng, không phải kiểm tra tự động laptop. Nếu file Kaggle thay đổi sau xác nhận, nó bị bỏ qua.

Giải phóng model LTX và bộ nhớ GPU có thể thu hồi:
```python
giai_phong_gpu()
```
Không đảm bảo giải phóng VRAM đang do biến hoặc thư viện khác giữ. Restart Session sẽ giải phóng tiến trình hiện tại, nhưng cần nạp lại code/model.

Lệnh dọn chỉ xét các phiên nằm trong GITA_WORKDIR hiện tại, không xóa toàn bộ /kaggle/working, dataset, cache model hay phim không có biên nhận. Giữ kịch bản, tiến độ, biên nhận, báo cáo nhỏ để truy vết. Chỉ dọn phim đầu ra và phụ phẩm được chỉ định/ghi trong báo cáo. Dữ liệu rất cũ không có biên nhận không tự bị xóa vì không thể chứng minh đã sao lưu.

Không chạy worker khác dùng chung thư mục trong lúc dọn. Sau Cancel Run, muốn chạy lại worker hãy Restart Session và Run All để khởi tạo lại stop event/model đúng trạng thái. Khi muốn chạy dọn ngay trong session mới mà không mở vòng worker, nạp full code bằng exec(code, {'__name__':'gita_commands'}) rồi gọi các hàm từ dict đó; dễ nhất vẫn dùng các cell của phiên hiện tại sau Cancel Run.

Đã qua 7 kiểm tra bổ sung: khóa dọn khi worker chạy, giữ phim chưa sao lưu, xem trước, phát hiện phim đổi, xóa đúng mã, giữ metadata, giải phóng GPU khi chưa nạp torch. Chưa kiểm tra trên Kaggle thật.
