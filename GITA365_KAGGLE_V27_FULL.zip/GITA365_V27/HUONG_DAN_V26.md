# GITA365 V26 — Kaggle và kho phim từ xa

## Cơ chế
Phim tạo xong được nộp qua endpoint web hiện có, rồi lưu thêm vào kho R2 và đọc lại toàn bộ để so sánh SHA-256/dung lượng. Chỉ sau khi xác minh thành công mới ghi trạng thái cold và xóa bản local cùng phụ phẩm được chỉ định. Khi không có lệnh, worker không tải phim từ xa xuống. Model cache vẫn chiếm đĩa để tránh tải lại model cho mỗi phim; cơ chế này không làm model hoặc phim từ xa biến mất.

Tải lại bằng mã phim lấy đúng bản đã lưu, không sinh lại phim bằng AI. Sinh lại bằng AI có thể cho kết quả khác và cần một việc film mới.

## Triển khai máy chủ trước
1. Tạo bucket R2, gắn binding STUDIO_ARCHIVE, đặt secret GITA_KHOA_XUONG_QUAY (ít nhất 32 ký tự).
2. Ghép archive-worker.mjs vào Worker hiện tại: gọi handleArchive(request, env) trước các route cũ, trả kết quả nếu khác null. Giữ nguyên các endpoint /quay/nhan, /quay/song, /quay/kq và các endpoint cũ khác.
3. archive-control.mjs là route cho nút lệnh web. Phải truyền hàm authorizeStudioAdmin thực tế của ứng dụng; thiếu hàm này sẽ trả 403. Chỉ máy chủ giữ secret, không đưa khóa xưởng ra trình duyệt.
4. Có thể triển khai archive-worker.mjs riêng và đặt GITA_ARCHIVE_SERVER trong Kaggle thành URL của nó. Các route web cũ vẫn ở GITA_MAY_CHU.
5. Đặt lifecycle hủy multipart chưa hoàn tất trên R2 để tránh lưu phần tải dang dở mãi. Nếu session đã bị hủy, part trả 404 sẽ xóa tiến độ local để lần thử sau bắt đầu phiên tải mới.

Gói không chứa mã web/Worker hiện tại nên chưa nối trực tiếp nút xem/tải lại của ứng dụng. Không thay toàn bộ Worker cũ bằng archive-worker.mjs: mô-đun này chỉ xử lý lưu trữ.

## Kaggle
Bật Internet. Đặt Secret GITA_KHOA_QUAY bằng đúng khóa máy chủ và bật quyền notebook đọc secret. Dán NỘI DUNG file GITA365_KAGGLE_V26_CODE.txt vào một cell Python rồi chạy. Không dán nội dung JSON notebook.

Chế độ tạo phim mặc định cần GPU. Đặt cấu hình ở cell trước nếu cần:
```python
import os
os.environ['GITA_MODE'] = 'render'
os.environ['GITA_WORKDIR'] = '/kaggle/working/gita365-v24'
# os.environ['GITA_ARCHIVE_SERVER'] = 'https://your-archive-worker.example'
```
Giữ GITA_WORKDIR ổn định qua các lần chạy để tìm lại tiến độ trong các thư mục phiên cũ còn tồn tại. Kaggle có thể xóa đĩa khi kết thúc session; tiến độ local không tồn tại sau khi đĩa thực sự bị xóa. Đừng xóa phim chưa lưu xong.

Chế độ chỉ tải lại / lưu tiếp, chọn Accelerator None và chạy cell cấu hình trước:
```python
import os
os.environ['GITA_MODE'] = 'archive'
os.environ['GITA_WORKDIR'] = '/kaggle/working/gita365-v24'
```
Chế độ này dùng thư viện chuẩn Python và ffprobe, không cài/nạp model video, không nhận việc tạo phim. Mã máy được in khi chạy; gửi lệnh tới đúng mã máy này.

## Lệnh
Route web /api/studio/archive-command (archive-control.mjs) nhận JSON gồm machine, action, filmMa, ttl. action: restore hoặc view tải phim về Kaggle; release dọn bản tải tạm. ttl giới hạn 60–3600 giây, mặc định 900. Hãy nối nút của web với route này qua cơ chế đăng nhập quản trị hiện có.

Nếu xem trên web bằng URL lưu trữ của ứng dụng, không cần gửi lệnh view về Kaggle. Tải về Kaggle chỉ khi thực sự cần xử lý bản local.

Tối đa một phim tải tạm. Worker đang chạy dọn phim mỗi 30 giây sau khi hết hạn. Khi dừng bình thường sẽ dọn ngay; bị kill có thể để lại file, được dọn khi chạy lại trên cùng thư mục. Không có tiến trình đang chạy thì không có bộ hẹn giờ tự xóa.

Chỉ chạy một worker trên cùng GITA_WORKDIR; không chạy đồng thời hai cell/phiên dùng chung thư mục. Lệnh chưa thành công không bị xác nhận xóa nên có thể được thử lại. Nếu phản hồi xác nhận mất, restore có thể chạy lại và gia hạn thời gian.

## Tối ưu và giới hạn
- Upload kho chia part 8 MiB, lưu tiến độ sau từng part. Mất mạng không hủy phiên upload; lần thử sau bỏ qua part đã xác nhận. Part có phản hồi bị mất có thể tải lại một lần.
- Phim trạng thái web_uploaded trong phiên cũ được thử lưu tiếp mỗi 5 phút khi lỗi. Phim trạng thái ready chưa nộp được web cần retry_upload(ma) ở đúng phiên để tránh tự nộp lại không rõ tính idempotent của server cũ.
- MP4 H.264 CRF 22 và AAC, cache model dùng chung, cảnh trung gian dọn theo pipeline. CRF thấp hơn tăng chất lượng nhưng tăng dung lượng; không thể vừa nén tối đa vừa giữ mọi chi tiết.
- Đang giữ tương thích với endpoint /quay/kq cũ nên một phim có thể có bản ở kho web cũ và bản archive. Muốn chỉ giữ một bản từ xa cần sửa handler web hiện tại để tham chiếu object archive. Endpoint nộp cũ vẫn có giới hạn request theo cấu hình máy chủ; upload archive chia nhỏ không sửa giới hạn endpoint cũ.
- Chưa triển khai khớp môi tự động; cần adapter bên ngoài. Chất lượng hình ảnh/nội dung phụ thuộc model, prompt, GPU; không đảm bảo nhân vật/hành động chính xác mọi chi tiết.
- Các đối tượng archive đã hoàn tất được giữ từ xa; thay phim cùng mã có thể để lại phiên bản object cũ. Cần chính sách lưu phiên bản phù hợp trước khi xóa trên máy chủ.

## Kiểm tra
11 kiểm tra Python cho checksum, restore, xóa đúng phim, giữ phim khi lỗi, hết hạn, resume upload, phục hồi phiên cũ và chế độ CPU. 5 kiểm tra Worker với R2 giả lập. Chưa kiểm tra GPU inference hoặc kết nối Cloudflare/Kaggle thật; chưa triển khai hệ thống của bạn.
