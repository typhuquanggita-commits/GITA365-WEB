# GITA V27 GPU engine: no third-party imports until GPU setup has completed.
from collections import OrderedDict
GPU_PROFILE = os.getenv('GITA_GPU_PROFILE', 'balanced')
TEXT_MODE = os.getenv('GITA_TEXT_MODE', 'int8')
OFFLOAD_MODE = os.getenv('GITA_OFFLOAD', 'model')
IDLE_EXIT_SECONDS = max(60, int(os.getenv('GITA_IDLE_EXIT_SECONDS', '300')))
_text_encoder = None
_tokenizer = None
_prompt_cache = OrderedDict()
_working_profile = None
_gpu_plan = None


def choose_gpu_plan(devices, profile='balanced'):
    if profile not in ('economy','balanced','quality'):
        raise ValueError('GITA_GPU_PROFILE: economy, balanced hoặc quality')
    if not devices: raise RuntimeError('Không có GPU')
    render = max(range(len(devices)), key=lambda i:devices[i]['free_bytes'])
    spare = [i for i in range(len(devices)) if i != render and tuple(devices[i]['capability'])>=(7,5)
             and devices[i]['free_bytes'] >= 7*2**30]
    text = max(spare,key=lambda i:devices[i]['free_bytes']) if spare else render
    free_gb = devices[render]['free_bytes']/2**30
    target = {'economy':(512,320,49), 'balanced':(640,384,73), 'quality':(768,448,97)}[profile]
    if free_gb < 8: target = (384,256,25)
    elif free_gb < 12 and profile != 'economy': target = (512,320,49)
    return dict(render_gpu=render,text_gpu=text,profile=profile,target=target,devices=devices)


def configure_gpu():
    global _gpu_plan
    if TEXT_MODE not in ('int8','cpu_fp32'): raise ValueError('GITA_TEXT_MODE: int8 hoặc cpu_fp32')
    if OFFLOAD_MODE not in ('model','group','sequential'): raise ValueError('GITA_OFFLOAD không hợp lệ')
    devices=[]
    for i in range(torch.cuda.device_count()):
        with torch.cuda.device(i):
            f,t=torch.cuda.mem_get_info()
        devices.append(dict(name=torch.cuda.get_device_name(i),free_bytes=f,total_bytes=t,
                            capability=list(torch.cuda.get_device_capability(i))))
    _gpu_plan = choose_gpu_plan(devices,GPU_PROFILE)
    render = _gpu_plan['render_gpu']
    torch.cuda.set_device(render)
    torch.backends.cuda.matmul.allow_tf32 = devices[render]['capability'][0]>=8
    CFG['width'],CFG['height'],CFG['frames'] = _gpu_plan['target']
    atomic_json(STUDIO/'gpu_plan.json',dict(version=VERSION,plan=_gpu_plan,text_mode=TEXT_MODE,offload=OFFLOAD_MODE))
    log('GPU plan: render=%d, T5=%d, %s, %s' % (render,_gpu_plan['text_gpu'],GPU_PROFILE,CFG))
    return _gpu_plan


def gpu_dtype():
    with torch.cuda.device(_gpu_plan['render_gpu']):
        return torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16


def release_text_encoder():
    global _text_encoder
    _text_encoder = None
    free()


def load_text_encoder():
    global _text_encoder, _tokenizer
    if _text_encoder is not None: return _text_encoder
    from transformers import T5EncoderModel, AutoTokenizer, BitsAndBytesConfig
    if _tokenizer is None:
        _tokenizer = AutoTokenizer.from_pretrained(MODEL_LTX,subfolder='tokenizer',cache_dir=str(HF_CACHE))
    if TEXT_MODE == 'int8':
        idx = _gpu_plan['text_gpu']
        if tuple(torch.cuda.get_device_capability(idx))<(7,5):
            raise RuntimeError('GPU này không hỗ trợ LLM.int8; chọn GITA_TEXT_MODE=cpu_fp32')
        # For a single GPU, text encoding and video generation have separate lifetimes.
        if idx == _gpu_plan['render_gpu']: unload_ltx()
        _text_encoder = T5EncoderModel.from_pretrained(MODEL_LTX,subfolder='text_encoder',
            cache_dir=str(HF_CACHE),low_cpu_mem_usage=True,torch_dtype=torch.float32,
            quantization_config=BitsAndBytesConfig(load_in_8bit=True),device_map={'':idx})
    else:
        # Explicit slow fallback, never silently allocate ~20 GB FP32 T5 RAM.
        import psutil
        if psutil.virtual_memory().available < 22*2**30:
            raise RuntimeError('T5 FP32 CPU cần dự phòng ít nhất 22 GiB RAM; chọn int8 hoặc restart session')
        _text_encoder = T5EncoderModel.from_pretrained(MODEL_LTX,subfolder='text_encoder',
            cache_dir=str(HF_CACHE),low_cpu_mem_usage=True,torch_dtype=torch.float32).to('cpu')
    _text_encoder.eval()
    return _text_encoder


def cache_prompt(key,value):
    _prompt_cache[key]=value
    _prompt_cache.move_to_end(key)
    while len(_prompt_cache)>16: _prompt_cache.popitem(last=False)


def prompt_tensors(prompt):
    def encode(text):
        key=(MODEL_LTX,TEXT_MODE,text)
        if key in _prompt_cache:
            _prompt_cache.move_to_end(key)
            return _prompt_cache[key]
        encoder=load_text_encoder()
        inputs=_tokenizer(text,padding='max_length',max_length=128,truncation=True,
                          add_special_tokens=True,return_tensors='pt')
        device = next(encoder.parameters()).device
        ids,mask=inputs.input_ids.to(device),inputs.attention_mask.to(device)
        with torch.inference_mode():
            emb=encoder(input_ids=ids,attention_mask=mask).last_hidden_state
        if not torch.isfinite(emb).all():
            raise RuntimeError('T5 sinh NaN/Inf; không dựng phim với embedding lỗi')
        result=(emb.detach().to(device='cpu',dtype=gpu_dtype()),mask.detach().cpu())
        cache_prompt(key,result)
        return result
    started=time.monotonic()
    try:
        positive=encode(prompt)
        negative=encode(NEG) if CFG['guidance']>1 else (None,None)
        return dict(prompt_embeds=positive[0],prompt_attention_mask=positive[1],
                    negative_prompt_embeds=negative[0],negative_prompt_attention_mask=negative[1])
    finally:
        if TEXT_MODE == 'cpu_fp32' or _gpu_plan['text_gpu']==_gpu_plan['render_gpu']:
            release_text_encoder()
        record_gpu_metric('text_encode',started)


def render_profiles():
    first = _working_profile or tuple(_gpu_plan['target'])
    alternatives = [first,(512,320,49),(384,256,25)]
    # Never increase token volume after an OOM or an economy request.
    result=[];budget=first[0]*first[1]*first[2]
    for item in alternatives:
        if item not in result and item[0]*item[1]*item[2]<=budget: result.append(item)
    return result


def record_gpu_metric(stage,started,**extra):
    if _gpu_plan is None: return
    row=dict(stage=stage,seconds=round(time.monotonic()-started,3),time=time.time(),**extra,gpus=[])
    for i in range(torch.cuda.device_count()):
        f,t=torch.cuda.mem_get_info(i)
        row['gpus'].append(dict(id=i,free_gb=round(f/2**30,3),
            allocated_gb=round(torch.cuda.memory_allocated(i)/2**30,3),
            peak_allocated_gb=round(torch.cuda.max_memory_allocated(i)/2**30,3)))
    (STUDIO/'metrics').mkdir(parents=True,exist_ok=True)
    with (STUDIO/'metrics/gpu.jsonl').open('a') as handle: handle.write(json.dumps(row)+'\n')


def render_step_callback(pipe,step,timestep,kwargs):
    if _stop.is_set(): raise InterruptedError('Dừng ở ranh giới bước denoise; giữ tiến độ cảnh đã xong')
    if step%10==0: log('Denoise bước %d' % step)
    return kwargs
