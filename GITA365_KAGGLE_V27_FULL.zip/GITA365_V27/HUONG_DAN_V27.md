# GITA365 V27 — tối ưu GPU theo phần cứng thực tế

## Chạy trên Kaggle
1. Restart Session, chọn GPU có sẵn và bật Internet. Đặt Secret GITA_KHOA_QUAY đúng khóa máy chủ. Archive Worker vẫn cần triển khai theo HUONG_DAN_V26.md; V27 không tự thay code máy chủ.
2. Upload GITA365_KAGGLE_V27.ipynb để mở notebook, hoặc dán NỘI DUNG GITA365_KAGGLE_V27_CODE.txt vào cell Python. Không dán JSON của file ipynb vào cell.
3. Cell cấu hình phải chạy trước code chính:
```python
import os
os.environ['GITA_MODE'] = 'render'
os.environ['GITA_GPU_PROFILE'] = 'balanced'
os.environ['GITA_TEXT_MODE'] = 'int8'
os.environ['GITA_OFFLOAD'] = 'model'
os.environ['GITA_IDLE_EXIT_SECONDS'] = '300'
os.environ['GITA_WORKDIR'] = '/kaggle/working/gita365-v24'
# os.environ['GITA_ARCHIVE_SERVER'] = 'https://your-archive-worker.example'
```
Code in thông tin GPU và chờ việc film/tts. Thiết lập GPU do Kaggle cấp thực tế quyết định; không giả định luôn có T4 x2. Đừng chạy hai worker cùng thư mục.

## Ba hồ sơ
| Hồ sơ | Kích thước mục tiêu | Frame / đoạn | Dùng khi |
|---|---|---|---|
| economy | 512×320 | 49 | Kiểm tra kịch bản, giảm lượng tính toán mỗi đoạn |
| balanced | 640×384 | 73 | Mặc định, cân bằng tài nguyên và chi tiết |
| quality | 768×448 | 97 | Ưu tiên chi tiết, chấp nhận chi phí tăng |

Các giá trị là điểm khởi đầu theo kinh nghiệm kỹ thuật, chưa phải cấu hình đã đo tối ưu trên mọi GPU. VRAM trống thấp sẽ hạ hồ sơ. Số frame theo 8n+1, kích thước chia hết cho 32. FPS 24. Đoạn ngắn hơn có thể cần nhiều lượt để phủ hết lời thoại nên economy không đảm bảo rẻ hơn cho mọi phim.

Profile mục tiêu khác độ phân giải thực tế sau OOM. Nếu phải dựng thấp hơn, bước ghép có thể scale lên mục tiêu; scale không phục hồi chi tiết thật. Báo cáo từng shot ghi native_profile để kiểm tra. Chưa xuất Full HD gốc hoặc tự làm super-resolution.

## Các thay đổi GPU
- T5 int8 độc lập, không nạp T5 FP32 bên trong pipeline video nữa. Pipeline nhận embedding và attention mask trực tiếp.
- Hai GPU đủ điều kiện: GPU trống nhiều hơn dựng video, GPU kia chạy T5. Hai GPU vẫn có VRAM riêng; không cộng thành một GPU 32 GB, không dùng hai GPU dựng song song cảnh.
- Một GPU: mã hóa prompt rồi giải phóng T5 trước khi nạp video. Với nhiều prompt khác nhau, việc đổi model có thể chậm; ưu tiên đo tổng thời gian thay vì chỉ VRAM.
- Cache tối đa 16 prompt trong RAM CPU; tránh chạy T5 lại cho prompt/negative prompt đã có. Không lưu pickle hay embeddings ra đĩa.
- T5 int8 có thể ảnh hưởng kết quả so với FP32; không khẳng định chất lượng y hệt. Nếu int8 không tương thích, có thể chọn cpu_fp32; cần ít nhất 22 GiB RAM trống theo ngưỡng bảo thủ của code và chậm hơn. Không tự tải/nạp FP32 âm thầm sau lỗi int8.
- VAE tiled/sliced, dtype dựa trên khả năng BF16 của GPU. model offload mặc định; sequential sau OOM; group là tùy chọn cần thử thực tế, không bật CUDA streams để tránh tăng RAM host do prefetch.
- Sau OOM, ghi nhớ cấu hình thấp hơn đã chạy thành công trong phiên. Không thử lại cấu hình lớn ở đầu mọi đoạn.
- LLM kịch bản vẫn bật khi cần, nhưng giải phóng video/T5 trước khi chạy. Nếu web đã gửi scenes đầy đủ, không cần tạo lại kịch bản. Có thể đặt GITA_LLM_ON=0 để dùng nội dung đã chuẩn bị và giảm thời gian LLM; fallback mẫu có thể kém phong phú hơn.
- Callback thông báo bước denoise và kiểm tra yêu cầu dừng. Hủy giữa một shot không giữ latent shot đó; chỉ cảnh/shot đã hoàn tất được checkpoint theo pipeline hiện có.

## Model và thư viện
Giữ Lightricks/LTX-Video-0.9.5 làm mặc định cho dung lượng vừa phải. Không mặc định chuyển sang 13B chỉ vì tên phiên bản mới hơn. Biến GITA_MODEL cũ vẫn hỗ trợ 0.9.7-distilled nhưng cần nhiều tài nguyên hơn và kiểm tra trước; 8 bước distilled không tương đương 40 bước của model khác.

Diffusers 0.35.1 và Transformers 4.57.1 được cố định để giảm thay đổi API. Accelerate/bitsandbytes có giới hạn phiên bản; phiên bản thực tế cần lưu trong môi trường chạy. PyTorch/CUDA Kaggle được giữ nguyên bằng constraints. Nếu dependencies yêu cầu torch khác, pip dừng thay vì âm thầm thay bản CUDA. Chưa kiểm tra đầy đủ tổ hợp thư viện trong Kaggle hiện tại.

Quantization giảm RAM/VRAM khi nạp, không làm các weights nguồn trên đĩa nhỏ đi. Cache model vẫn cần đủ đĩa; kiểm tra dung lượng trước khi quay giữ từ V26.

## Theo dõi và kết thúc
```python
# Sau Cancel Run, xem báo cáo phiên:
print(bao_cao_gpu())
```
Các log metrics/gpu.jsonl ghi thời gian encode, nạp video, tạo shot và bộ nhớ GPU. Peak allocated là bộ nhớ allocator PyTorch trong giai đoạn đo, không phải toàn bộ VRAM của mọi tiến trình. Không so trực tiếp peak của giai đoạn encode với peak đã reset ở giai đoạn generate. Log generate thành công chưa bao gồm encode video FFmpeg, QA, upload và mọi lần OOM; không coi đó là thời gian toàn phim.

Không có việc trong 300 giây sẽ kết thúc worker và giải phóng model. Cần End Session trên Kaggle để kết thúc phiên GPU và tránh tiếp tục tiêu quota phiên. Worker thoát không có nghĩa Kaggle đã kết thúc session. Khi có phim mới, chạy lại notebook trong phiên mới; không tự khởi động Kaggle bằng mã web.

Chỉ tải lại phim: đặt GITA_MODE=archive, chọn Accelerator None. Không nạp model video. Giữ cơ chế resume multipart, xác minh SHA-256, dọn bản local sau archive và tải lại có TTL của V26.

Lệnh dọn an toàn từ V26.1 vẫn có: lam_sach_dia(), lam_sach_dia(thuc_hien=True), xac_nhan_da_tai_laptop(...), giai_phong_gpu(). Xem LENH_LAM_SACH.md. Đĩa/RAM/VRAM/quota GPU là bốn tài nguyên khác nhau.

## Kiểm tra và giới hạn
9 kiểm tra planner/controller bằng giả lập, 8 kiểm tra integrity/restore/eviction, 7 kiểm tra cleanup, 5 kiểm tra Worker R2 giả lập. Chưa benchmark GPU thật, nạp T5 int8 thật, thử offload hoặc triển khai Cloudflare. Không đưa ra con số tốc độ tăng/%VRAM giảm khi chưa đo.

Chất lượng nhân vật, tương tác nhiều người, bàn tay, hành động và khớp môi vẫn phụ thuộc model/adapter; V27 tối ưu vận hành GPU, không đảm bảo bộ phim dài chuẩn mọi chi tiết. Adapter lipsync vẫn phải cấu hình riêng.
