from pathlib import Path
from types import SimpleNamespace,ModuleType
import tempfile,sys,contextlib,json
s=Path(__file__).with_name('gita365_kaggle.py').read_text();ns={'__name__':'test'};exec(compile(s,'v27','exec'),ns)
checks=[]
dev=lambda free,cc=(7,5):dict(free_bytes=free*2**30,total_bytes=16*2**30,capability=cc,name='mock')
p=ns['choose_gpu_plan']([dev(15),dev(14)]);assert p['render_gpu']==0 and p['text_gpu']==1;checks.append('separate text/render devices on dual T4')
p=ns['choose_gpu_plan']([dev(10)],'quality');assert p['target']==(512,320,49) and p['text_gpu']==0;checks.append('low free VRAM reduces token volume')
p=ns['choose_gpu_plan']([dev(15),dev(15,(7,0))]);assert p['text_gpu']==p['render_gpu'];checks.append('reject second GPU below int8 capability')
try:ns['choose_gpu_plan']([])
except RuntimeError:checks.append('missing GPU rejected')
ns['_gpu_plan']=ns['choose_gpu_plan']([dev(15)],'economy');assert ns['render_profiles']()[0]==(512,320,49);assert (768,448,97) not in ns['render_profiles']();checks.append('economy never escalates resolution')
for i in range(20):ns['cache_prompt'](i,i)
assert len(ns['_prompt_cache'])==16 and 0 not in ns['_prompt_cache'];checks.append('bounded CPU prompt LRU')
ns['_stop'].set()
try:ns['render_step_callback'](None,1,None,{})
except InterruptedError:checks.append('cancellation at denoise boundary')
ns['_stop'].clear()
# Exercise full rendering controller with fake pipeline throwing CUDA OOM once.
class OOM(Exception):pass
ns['torch']=SimpleNamespace(cuda=SimpleNamespace(OutOfMemoryError=OOM,device_count=lambda:1,reset_peak_memory_stats=lambda _:None),inference_mode=contextlib.nullcontext,Generator=lambda _:SimpleNamespace(manual_seed=lambda _:None))
mod=ModuleType('diffusers.pipelines.ltx.pipeline_ltx_condition');mod.LTXVideoCondition=lambda **kw:kw;sys.modules[mod.__name__]=mod
import numpy as np
calls=[];fail=True
class Pipeline:
 def __call__(self,**kw):
  global fail
  calls.append(kw)
  if fail:fail=False;raise OOM()
  return SimpleNamespace(frames=[[np.zeros((4,4,3),dtype=np.uint8)]])
ns.update(load_pipeline=lambda:Pipeline(),prompt_tensors=lambda _:dict(prompt_embeds='encoded',prompt_attention_mask='mask'),
 free=lambda:None,unload_ltx=lambda:None,record_gpu_metric=lambda *a,**kw:None,
 ensure_output_space=lambda:None,export_to_video=lambda frames,path,**kw:Path(path).write_bytes(b'video'),media_info=lambda *a,**kw:1.0,log=lambda _:None,QC_ON=False)
ns['_gpu_plan']=ns['choose_gpu_plan']([dev(15)],'quality');ns['_working_profile']=None
with tempfile.TemporaryDirectory() as td:
 ns['quay_canh'](None,'test',10,Path(td)/'one.mp4')
 assert len(calls)==2 and ns['_working_profile']==(512,320,49)
 assert 'prompt' not in calls[-1] and calls[-1]['prompt_embeds']=='encoded';checks.append('render consumes supplied embeddings without duplicate T5')
 ns['quay_canh'](None,'test',10,Path(td)/'two.mp4')
 assert len(calls)==3 and calls[-1]['width']==512;checks.append('learned OOM profile avoids repeated failed large attempt')
assert 'torch' not in {'__name__':'test'}
print('PASS',len(checks),'V27 planner/controller checks')
Path(__file__).with_name('gpu_verification.json').write_text(json.dumps(dict(checks=checks,limits=['No GPU hardware inference benchmark','Quantized T5 and dual GPU placement require live Kaggle verification','Mock pipeline only']),indent=2))
