import { handleArchive } from './archive-worker.mjs';
// Host app must supply its actual administrator-session verifier.
// Never expose the worker key in frontend JavaScript.
export async function handleArchiveControl(request, env, authorizeStudioAdmin) {
  if(new URL(request.url).pathname!=='/api/studio/archive-command')return null;
  if(request.method!=='POST')return Response.json({error:'Method not allowed'},{status:405});
  if(typeof authorizeStudioAdmin!=='function'||!await authorizeStudioAdmin(request,env))
    return Response.json({error:'Forbidden'},{status:403});
  const d=await request.json();
  if(typeof d.machine!=='string'||!/^[A-Za-z0-9_-]{1,120}$/.test(d.machine))
    return Response.json({error:'Invalid machine'},{status:400});
  const internal=new Request(new URL('/quay/archive/commands/'+d.machine,request.url),{
    method:'POST',headers:{'X-Khoa-Quay':env.GITA_KHOA_XUONG_QUAY,'Content-Type':'application/json'},
    body:JSON.stringify({action:d.action,filmMa:d.filmMa,ttl:d.ttl})});
  return await handleArchive(internal,env);
}
