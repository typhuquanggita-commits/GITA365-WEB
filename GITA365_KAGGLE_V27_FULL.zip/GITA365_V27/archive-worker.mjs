// Integrate this router BEFORE existing GITA Worker routes. Does not replace them.
// Binding: STUDIO_ARCHIVE (R2), secret: GITA_KHOA_XUONG_QUAY.
const PREFIX = '/quay/archive';
const PART = 8 * 1024 * 1024;
const validId = s => typeof s === 'string' && /^[A-Za-z0-9_-]{1,120}$/.test(s);
const validHash = s => typeof s === 'string' && /^[a-f0-9]{64}$/.test(s);
const json = (obj, status=200) => Response.json(obj,{status,headers:{'Cache-Control':'no-store'}});
async function authorized(req,env) {
  const expected=env.GITA_KHOA_XUONG_QUAY;
  if (!expected || expected.length<32) return false;
  const supplied=req.headers.get('X-Khoa-Quay') || '';
  const hash=async s=>new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)));
  const [a,b]=await Promise.all([hash(expected),hash(supplied)]);
  let difference=0; for(let i=0;i<a.length;i++)difference|=a[i]^b[i];
  return difference===0;
}
async function readJSON(bucket,key) { const o=await bucket.get(key);return o ? await o.json() : null; }
async function smallJSON(request) {
  const text=await request.text();if(text.length>200000)throw new Error('JSON too large');return JSON.parse(text);
}
export async function handleArchive(request,env) {
  const u=new URL(request.url);
  if (!u.pathname.startsWith(PREFIX+'/')) return null;
  if (!env.STUDIO_ARCHIVE) return json({error:'STUDIO_ARCHIVE R2 binding missing'},503);
  if (!await authorized(request,env)) return json({error:'Unauthorized'},401);
  const bucket=env.STUDIO_ARCHIVE;
  const rest=u.pathname.slice(PREFIX.length+1).split('/');
  const method=request.method;
  try {
    if(rest[0]==='health' && method==='GET')return json({ok:true,protocol:1,partBytes:PART});
    if(rest[0]==='commands') {
      const machine=rest[1];if(!validId(machine))return json({error:'Invalid machine'},400);
      const prefix=`studio-archive/commands/${machine}/`;
      if(method==='POST' && rest.length===2) {
        const d=await smallJSON(request);
        if(!['restore','view','release'].includes(d.action)||!validId(d.filmMa))return json({error:'Invalid command'},400);
        const id=crypto.randomUUID();const cmd={id,action:d.action,filmMa:d.filmMa,ttl:Math.max(60,Math.min(3600,Number(d.ttl)||900)),created:Date.now()};
        await bucket.put(prefix+id+'.json',JSON.stringify(cmd));return json({ok:true,id});
      }
      if(method==='GET' && rest.length===2) {
        const listing=await bucket.list({prefix,limit:20});const commands=[];
        for(const object of listing.objects){const c=await readJSON(bucket,object.key);if(c)commands.push(c);}
        commands.sort((a,b)=>a.created-b.created);return json({commands});
      }
      if(method==='DELETE' && /^[a-f0-9-]{36}$/.test(rest[2]||'')) {
        await bucket.delete(prefix+rest[2]+'.json');return json({ok:true});
      }
    }
    if(rest[0]==='start' && method==='POST') {
      const d=await smallJSON(request);
      if(!validId(d.ma)||!validHash(d.sha256)||!Number.isSafeInteger(d.size)||d.size<=0||d.size>80*1024**3)
        return json({error:'Invalid manifest'},400);
      if(!['video/mp4','audio/mpeg'].includes(d.mime))return json({error:'Invalid MIME'},400);
      const existing=await readJSON(bucket,`studio-archive/index/${d.ma}.json`);
      if(existing && existing.sha256===d.sha256 && existing.size===d.size) {
        const object=await bucket.head(existing.key);
        if(object && object.size===d.size)return json({existing:true,manifest:existing});
      }
      const session=crypto.randomUUID();
      const key=`studio-archive/objects/${d.ma}/${session}.${d.mime==='video/mp4'?'mp4':'mp3'}`;
      const upload=await bucket.createMultipartUpload(key,{httpMetadata:{contentType:d.mime}});
      const state={...d,key,session,uploadId:upload.uploadId,created:Date.now(),parts:Math.ceil(d.size/PART)};
      await bucket.put(`studio-archive/sessions/${session}.json`,JSON.stringify(state));
      return json({session,partBytes:PART});
    }
    if(['part','complete','abort'].includes(rest[0])) {
      const session=rest[1];if(!/^[a-f0-9-]{36}$/.test(session||''))return json({error:'Invalid session'},400);
      const sk=`studio-archive/sessions/${session}.json`;
      const state=await readJSON(bucket,sk);if(!state)return json({error:'Session missing'},404);
      const upload=bucket.resumeMultipartUpload(state.key,state.uploadId);
      if(rest[0]==='part' && method==='PUT') {
        const number=Number(rest[2]);
        if(!Number.isInteger(number)||number<1||number>state.parts)return json({error:'Invalid part number'},400);
        const expected=number===state.parts ? state.size-PART*(state.parts-1) : PART;
        if(Number(request.headers.get('Content-Length'))!==expected)return json({error:'Invalid part size'},400);
        const part=await upload.uploadPart(number,request.body);
        return json(part);
      }
      if(rest[0]==='complete' && method==='POST') {
        const d=await smallJSON(request);
        if(!Array.isArray(d.parts)||d.parts.length!==state.parts||d.parts.some((p,i)=>p.partNumber!==i+1||typeof p.etag!=='string'))
          return json({error:'Invalid parts'},400);
        const object=await upload.complete(d.parts);
        if(object.size!==state.size)return json({error:'Completed size mismatch'},409);
        const manifest={ma:state.ma,key:state.key,size:state.size,sha256:state.sha256,mime:state.mime,created:Date.now(),protocol:1};
        await bucket.put(`studio-archive/index/${state.ma}.json`,JSON.stringify(manifest));
        await bucket.delete(sk);
        return json(manifest);
      }
      if(rest[0]==='abort' && method==='POST') {
        await upload.abort();await bucket.delete(sk);return json({ok:true});
      }
    }
    if(['meta','file'].includes(rest[0]) && ['GET','HEAD'].includes(method)) {
      const ma=rest[1];if(!validId(ma))return json({error:'Invalid ID'},400);
      const m=await readJSON(bucket,`studio-archive/index/${ma}.json`);
      if(!m)return json({error:'Archive missing'},404);
      const h=await bucket.head(m.key);if(!h||h.size!==m.size)return json({error:'Archive invalid'},409);
      if(rest[0]==='meta')return json(m);
      const headers={'Content-Type':m.mime,'Content-Length':String(m.size),'X-Archive-SHA256':m.sha256,
        'Cache-Control':'private, no-store','Content-Disposition':`attachment; filename="${ma}.${m.mime==='video/mp4'?'mp4':'mp3'}"`};
      if(method==='HEAD')return new Response(null,{headers});
      const object=await bucket.get(m.key);if(!object)return json({error:'Archive missing'},404);
      return new Response(object.body,{headers});
    }
    return json({error:'Unknown archive route'},404);
  } catch(error) { return json({error:'Archive operation failed',type:error.name},500); }
}
// For deployment as a separate private archive Worker (requires GITA_ARCHIVE_SERVER on Kaggle):
export default {async fetch(request,env){return await handleArchive(request,env)||json({error:'Not found'},404);}};
