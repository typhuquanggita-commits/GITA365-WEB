# GITA365 KAGGLE V27 — resumable archive, CPU restore mode, verified local eviction.
# Restart Session before running. Secrets: GITA_KHOA_QUAY.
# Run directory is new by default; no old files or server jobs are deleted.
import os, sys, io, re, gc, json, time, math, hashlib, shutil, subprocess
import threading, urllib.request, urllib.error
from pathlib import Path
from urllib.parse import quote

VERSION = "27.0"
MAY_CHU = os.getenv("GITA_MAY_CHU", "https://gita365.typhuquanggita.workers.dev").rstrip("/")
RUN_ID = os.getenv("GITA_RUN_ID", time.strftime("v27-%Y%m%d-%H%M%S"))
if not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", RUN_ID):
    raise ValueError("GITA_RUN_ID phải là tên đơn giản, không chứa đường dẫn")
def choose_disk_path(env_name, folder, reserve_gb):
    override = os.getenv(env_name)
    if override:
        return Path(override)
    # Compare real free capacity; /tmp is not assumed to be a separate disk.
    candidates = [Path("/kaggle/working"), Path("/kaggle/temp"), Path("/tmp")]
    choices = []
    for base in candidates:
        try:
            base.mkdir(parents=True, exist_ok=True)
            free_bytes = shutil.disk_usage(base).free
            if os.access(base, os.W_OK):
                choices.append((free_bytes, base))
        except OSError:
            pass
    if not choices:
        raise RuntimeError("Không có thư mục ghi được cho GITA365")
    preferred = next((item for item in choices if item[1] == Path("/kaggle/working")
                      and item[0] >= reserve_gb * 2**30), None)
    base = preferred[1] if preferred else max(choices, key=lambda item: item[0])[1]
    return base / folder

STUDIO = choose_disk_path("GITA_WORKDIR", "gita365-v24", 3) / RUN_ID
HF_CACHE = choose_disk_path("GITA_HF_CACHE", "gita365-model-cache", 30)
ARCHIVE_SERVER = os.getenv("GITA_ARCHIVE_SERVER", MAY_CHU).rstrip("/")
RESTORE_TTL_SECONDS = 900
MAX_RESTORED_FILES = 1
_restore_lock = threading.Lock()
CLEAN_OLD_DATA_ONCE = False
VIDEO_CRF = 22
VIDEO_PRESET = "medium"
KEEP_INTERMEDIATES = False
MODEL_LTX = os.getenv("GITA_MODEL", "Lightricks/LTX-Video-0.9.5")
if MODEL_LTX not in {"Lightricks/LTX-Video-0.9.5", "Lightricks/LTX-Video-0.9.7-distilled"}:
    raise ValueError("Bản này hỗ trợ model 0.9.5 và 0.9.7-distilled")
DISTILLED = "distilled" in MODEL_LTX
TEN_MAY = "kaggle-" + RUN_ID
CFG = dict(width=768, height=448, fps=24, frames=97,
           steps=8 if DISTILLED else 40, guidance=1.0 if DISTILLED else 5.0)
QC_ON = True
QC_STRICT = os.getenv("GITA_QC_STRICT", "1") == "1"
QC = dict(blur_min=40.0, motion_min=0.3, motion_max=50.0, thu_lai=1)
LLM_ON = os.getenv("GITA_LLM_ON", "1") == "1"
REQUIRE_REFERENCE = os.getenv("GITA_REQUIRE_REFERENCE", "1") == "1"
MAX_SCENES = 100
MAX_SHOTS_PER_SCENE = 30
POLL_SECONDS = 30
MAX_SESSION_HOURS = float(os.getenv("GITA_SESSION_HOURS", "8"))
# Optional adapter: JSON argv array containing {video}, {audio}, {output}.
# No incomplete automatic MuseTalk/Wav2Lip install is executed.
LIPSYNC_ARGV = json.loads(os.getenv("GITA_LIPSYNC_ARGV", "[]"))
BRAND = {"ten": "GITA365", "slogan": "Đánh thức tiềm năng — Bứt phá giới hạn"}
NEG = "blurry, low quality, distorted face, watermark, text, glitch, deformed hands, frozen motion"
INTRO_SECONDS, OUTRO_SECONDS = 2.5, 3.0
_pipe = None
_memory_mode = "model_offload"
_stop = threading.Event()
_active_job = None
_heartbeat_thread = None
_last_heartbeat = None

def log(msg):
    print(msg, flush=True)

def safe_id(value):
    value = str(value)
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,120}", value):
        raise ValueError("Mã việc/nhân vật không hợp lệ")
    return value

def atomic_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)

def run_cmd(argv, timeout=600):
    r = subprocess.run([str(x) for x in argv], capture_output=True, timeout=timeout)
    if r.returncode:
        # Save diagnostic output locally. Never print dialogue or credentials.
        STUDIO.mkdir(parents=True, exist_ok=True)
        (STUDIO / "last-command-error.log").write_bytes(r.stderr or r.stdout)
        raise RuntimeError("Lệnh %s thất bại; xem last-command-error.log" % Path(str(argv[0])).name)
    return r

def chuan_hoa_khoa(value):
    if not isinstance(value, str):
        return None
    value = value.strip()
    if len(value) < 32 or any(c.isspace() or ord(c) < 32 or ord(c) > 126 for c in value):
        return None
    return value


def nhap_khoa_an():
    import getpass, warnings
    log("Kaggle sẽ hiện ô nhập khóa ẩn. Dán khóa xưởng Cloudflare vào ô đó, rồi Enter.")
    try:
        # Refuse getpass fallback that would echo credentials to public output.
        with warnings.catch_warnings():
            warnings.simplefilter("error", getpass.GetPassWarning)
            value = getpass.getpass("Khóa xưởng GITA (ẩn, không lưu vào code): ")
    except (EOFError, OSError, getpass.GetPassWarning):
        raise RuntimeError(
            "Phiên này không hỗ trợ nhập khóa ẩn. Chạy trong Kaggle editor tương tác; "
            "hoặc bật quyền notebook dùng Secret GITA_KHOA_QUAY. Save & Run All nền cần Secret.") from None
    result = chuan_hoa_khoa(value)
    value = None
    if result is None:
        raise RuntimeError("Khóa rỗng, ngắn hơn 32 ký tự hoặc chứa ký tự không hợp lệ; dùng khóa máy chủ hiện tại")
    return result


def lay_khoa_an_toan():
    names = ("GITA_KHOA_QUAY", "GITA_KHOA_XUONG_QUAY")
    for name in names:
        value = chuan_hoa_khoa(os.getenv(name))
        if value:
            log("Đã lấy khóa từ biến môi trường " + name + " (không hiển thị giá trị).")
            return value
    try:
        from kaggle_secrets import UserSecretsClient
        client = UserSecretsClient()
    except Exception as error:
        log("Không khởi tạo được Kaggle Secrets: " + type(error).__name__)
        client = None
    if client is not None:
        for name in names:
            for attempt in range(2):
                try:
                    value = chuan_hoa_khoa(client.get_secret(name))
                    if value:
                        log("Đã đọc Secret " + name + " (không hiển thị giá trị).")
                        return value
                    log("Secret " + name + " rỗng hoặc sai định dạng.")
                    break
                except Exception as error:
                    # Never expose raw provider exceptions, which may contain tokens.
                    log("Đọc Secret %s, lần %d: %s" % (name, attempt + 1, type(error).__name__))
    log("Không đọc được khóa hợp lệ từ Secrets; chuyển sang nhập ẩn ngay trong Kaggle.")
    return nhap_khoa_an()


def xac_thuc_ket_noi():
    global KHOA
    try:
        gui_heartbeat()
    except PermissionError:
        log("Cloudflare trả 401/403. Có thể khóa không khớp hoặc quy tắc truy cập chặn request.")
        log("Thử một lần bằng khóa máy chủ hiện tại qua ô nhập ẩn.")
        KHOA = nhap_khoa_an()
        try:
            gui_heartbeat()
        except PermissionError:
            raise RuntimeError(
                "Máy chủ vẫn trả 401/403 sau khi nhập khóa. Kiểm tra khóa và quy tắc Cloudflare cho /quay/*. "
                "Đã dừng trước khi tải model; không thể sửa quyền máy chủ bằng code Kaggle.") from None


def reset_old_data_once():
    if not CLEAN_OLD_DATA_ONCE:
        return
    root = Path("/kaggle/working")
    if not root.is_dir():
        raise RuntimeError("Bước reset chỉ được chạy trên Kaggle /kaggle/working")
    marker = root / ".gita_v24_reset_done"
    if marker.exists():
        log("V24 đã dọn lần đầu; giữ cache và phim mới cho lần quay tiếp theo.")
        return
    log("DỌN LẦN ĐẦU: xóa tất cả dữ liệu cũ trong /kaggle/working theo yêu cầu.")
    for item in list(root.iterdir()):
        if item.is_symlink() or item.is_file():
            item.unlink()
        elif item.is_dir():
            shutil.rmtree(item)
    # Only task-owned cache/run folders on transient volumes; do not erase arbitrary /tmp.
    for base in (Path("/kaggle/temp"), Path("/tmp")):
        for name in ("gita365-model-cache", "gita365-v23", "gita365-v24"):
            item = base / name
            if item.is_symlink():
                item.unlink()
            elif item.is_dir():
                shutil.rmtree(item)
    marker.write_text("V24 initial reset completed; preserve new work on subsequent runs\n")
    log("Dọn xong. /kaggle/working còn %.1f GB trống" % (shutil.disk_usage(root).free / 2**30))


def ensure_output_space(min_gb=1.0):
    free_bytes = shutil.disk_usage(STUDIO).free
    if free_bytes < min_gb * 2**30:
        raise RuntimeError("Ổ phim còn %.2f GB, dưới ngưỡng %.2f GB; tải phim cũ về rồi xóa chọn lọc." %
                           (free_bytes / 2**30, min_gb))


def delete_local_files(paths):
    if KEEP_INTERMEDIATES:
        return
    root = STUDIO.resolve()
    for path in paths:
        path = Path(path)
        if path.resolve().is_relative_to(root) and path.is_file():
            path.unlink()


def setup():
    global torch, Image, ImageOps, export_to_video, KHOA, _heartbeat_thread, _last_heartbeat, STUDIO, HF_CACHE
    reset_old_data_once()
    STUDIO = choose_disk_path("GITA_WORKDIR", "gita365-v24", 3) / RUN_ID
    HF_CACHE = choose_disk_path("GITA_HF_CACHE", "gita365-model-cache", 30)
    for d in ("jobs", "clips", "audio", "subs", "final", "assets/nvchuan"):
        (STUDIO / d).mkdir(parents=True, exist_ok=True)
    HF_CACHE.mkdir(parents=True, exist_ok=True)
    os.environ["HF_HOME"] = str(HF_CACHE)
    os.environ["HF_HUB_CACHE"] = str(HF_CACHE)
    os.environ["HF_XET_CHUNK_CACHE_SIZE_BYTES"] = "0"
    os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")
    KHOA = lay_khoa_an_toan()
    if not MAY_CHU.startswith("https://"):
        raise ValueError("Máy chủ phải dùng HTTPS")
    # Register before pip or downloading models; stop immediately on bad auth.
    # HTTP success is enough: the old endpoint may return an empty response.
    xac_thuc_ket_noi()
    _last_heartbeat = time.time()
    log("Máy chủ đã nhận heartbeat đầu tiên: " + TEN_MAY)
    _heartbeat_thread = threading.Thread(target=heartbeat, daemon=True)
    _heartbeat_thread.start()
    # Do not replace Kaggle's preinstalled CUDA torch build.
    # Check before pip: loaded ML packages cannot safely be upgraded in place.
    if any(m in sys.modules for m in ("diffusers", "transformers")):
        raise RuntimeError("Restart Session rồi Run All; session đang giữ thư viện/model cũ")
    log("Cài thư viện; giữ nguyên PyTorch/CUDA của Kaggle...")
    import importlib.metadata as package_metadata
    installed_torch = package_metadata.version("torch")
    constraints = STUDIO / "kaggle-torch-constraints.txt"
    constraints.write_text("torch==" + installed_torch + "\n")
    run_cmd([sys.executable, "-m", "pip", "install", "-q", "--no-cache-dir", "--constraint", str(constraints),
             "diffusers==0.35.1", "transformers==4.57.1", "accelerate>=1.2,<2",
             "bitsandbytes>=0.46,<1", "psutil",
             "safetensors", "sentencepiece", "huggingface_hub<1",
             "imageio[ffmpeg]", "edge-tts>=7,<8", "opencv-python-headless",
             "Pillow", "numpy<3"], timeout=900)
    import torch as torch_module
    torch = torch_module
    if not torch.cuda.is_available():
        raise RuntimeError("Kaggle Settings → Accelerator → GPU; Restart Session")
    configure_gpu()
    from PIL import Image as PILImage, ImageOps as PILImageOps
    from diffusers.utils import export_to_video as exporter
    Image, ImageOps, export_to_video = PILImage, PILImageOps, exporter
    for executable in ("ffmpeg", "ffprobe"):
        if not shutil.which(executable):
            raise RuntimeError("Môi trường thiếu " + executable)
    import importlib.metadata as md
    atomic_json(STUDIO / "environment.json", {
        "version": VERSION, "model": MODEL_LTX, "config": CFG,
        "python": sys.version, "gpu": torch.cuda.get_device_name(0),
        "packages": {n: md.version(n) for n in ("diffusers", "transformers", "torch", "accelerate")}})
    log("GITA365 V27 | GPU: %s | model: %s" % (torch.cuda.get_device_name(0), MODEL_LTX))
    log("Thư mục kết quả: %s" % STUDIO)
    log("Cache model: %s" % HF_CACHE)
    kiem_tra_dung_luong_model()
    if not LIPSYNC_ARGV:
        log("Chế độ thuyết minh: chưa cấu hình adapter khớp môi.")

def kiem_tra_dung_luong_model():
    from huggingface_hub import HfApi, try_to_load_from_cache
    try:
        info = HfApi().model_info(MODEL_LTX, files_metadata=True)
    except Exception as error:
        raise RuntimeError("Không lấy được metadata dung lượng model: " + type(error).__name__) from None
    missing_bytes = 0
    total_bytes = 0
    wanted = ("transformer/", "text_encoder/", "vae/", "tokenizer/", "scheduler/")
    for item in info.siblings:
        name = item.rfilename
        if not name.startswith(wanted) or not name.endswith((".safetensors", ".json", ".model", ".txt")):
            continue
        size = item.size
        if size is None:
            raise RuntimeError("Metadata thiếu kích thước tệp: " + name)
        total_bytes += size
        local = try_to_load_from_cache(MODEL_LTX, name, cache_dir=str(HF_CACHE))
        if not isinstance(local, str) or not Path(local).is_file() or Path(local).stat().st_size != size:
            missing_bytes += size
    if total_bytes <= 0:
        raise RuntimeError("Không xác định được kích thước weights; dừng trước khi nhận việc")
    # Downloads can resume, but reserve full missing file sizes conservatively.
    cache_free = shutil.disk_usage(HF_CACHE).free
    output_free = shutil.disk_usage(STUDIO).free
    same_disk = HF_CACHE.stat().st_dev == STUDIO.stat().st_dev
    required = missing_bytes + ((4 if same_disk else 2) + (4 if LLM_ON else 0)) * 2**30
    log("Model: %.1f GB | cần tải: %.1f GB | ổ cache trống: %.1f GB" %
        (total_bytes / 2**30, missing_bytes / 2**30, cache_free / 2**30))
    if cache_free < required:
        raise RuntimeError("Ổ cache không đủ: cần tối thiểu %.1f GB trống, hiện có %.1f GB. "
            "Dọn cache model cũ hoặc đặt GITA_HF_CACHE tới ổ đủ dung lượng; không tiếp tục tải khi ổ đầy." %
            (required / 2**30, cache_free / 2**30))
    if not same_disk and output_free < 2 * 2**30:
        raise RuntimeError("Ổ kết quả còn dưới 2 GB; đặt GITA_WORKDIR tới thư mục đủ dung lượng")
    return dict(total_bytes=total_bytes, missing_bytes=missing_bytes, free_bytes=cache_free)


def free():
    gc.collect()
    if "torch" in globals() and torch.cuda.is_available():
        for i in range(torch.cuda.device_count()):
            with torch.cuda.device(i): torch.cuda.empty_cache()

def unload_ltx():
    global _pipe
    _pipe = None
    free()

def vram():
    f,t = torch.cuda.mem_get_info(_gpu_plan['render_gpu'])
    return f/2**30,t/2**30

def load_pipeline():
    global _pipe
    if _pipe is not None: return _pipe
    from diffusers import LTXConditionPipeline
    started=time.monotonic()
    p=None
    try:
        # Embeddings are supplied explicitly; never load a second T5 inside this pipeline.
        p=LTXConditionPipeline.from_pretrained(MODEL_LTX,text_encoder=None,
            torch_dtype=gpu_dtype(),cache_dir=str(HF_CACHE),low_cpu_mem_usage=True)
        p.vae.enable_tiling()
        if hasattr(p.vae,'enable_slicing'): p.vae.enable_slicing()
        idx=_gpu_plan['render_gpu']
        mode='sequential' if _memory_mode=='sequential_offload' else OFFLOAD_MODE
        if mode=='group':
            # No CUDA streams: avoid doubling host memory through prefetch/pinned copies.
            from diffusers.hooks import apply_group_offloading
            p.transformer.enable_group_offload(onload_device=torch.device('cuda:%d'%idx),
                offload_device=torch.device('cpu'),offload_type='block_level',num_blocks_per_group=1)
            apply_group_offloading(p.vae,onload_device=torch.device('cuda:%d'%idx),
                offload_device=torch.device('cpu'),offload_type='leaf_level')
        elif mode=='sequential': p.enable_sequential_cpu_offload(gpu_id=idx)
        else: p.enable_model_cpu_offload(gpu_id=idx)
        _pipe=p
        return _pipe
    finally:
        p=None
        free()
        record_gpu_metric('load_video_model',started)

class RedirectSafe(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # Never forward the worker secret on redirects.
        raise RuntimeError("Máy chủ chuyển hướng; kiểm tra GITA_MAY_CHU")

def goi(path, method="GET", data=None, mime="application/json", retry=False):
    opener = urllib.request.build_opener(RedirectSafe())
    attempts = 3 if retry else 1
    for attempt in range(attempts):
        req = urllib.request.Request(MAY_CHU + path, data=data, method=method,
            headers={"X-Khoa-Quay": KHOA, "User-Agent": "Mozilla/5.0 GITA365-Studio/23",
                     "Content-Type": mime})
        try:
            with opener.open(req, timeout=300) as response:
                return response.status, response.read()
        except urllib.error.HTTPError as e:
            if e.code in (401, 403):
                raise PermissionError("Máy chủ trả HTTP %d: kiểm tra Secret và quyền worker" % e.code) from None
            if e.code not in (429, 500, 502, 503, 504) or attempt == attempts - 1:
                raise RuntimeError("API trả HTTP %d" % e.code) from None
        except (urllib.error.URLError, TimeoutError):
            if attempt == attempts - 1:
                raise RuntimeError("Không kết nối được máy chủ") from None
        _stop.wait(3 * (attempt + 1))

def api_json(path, payload=None, retry=False):
    _, body = goi(path, "POST" if payload is not None else "GET",
                  json.dumps(payload).encode() if payload is not None else None, retry=retry)
    return json.loads(body.decode("utf-8"))

def gui_heartbeat():
    status, body = goi("/quay/song", "POST", json.dumps({"may": TEN_MAY}).encode())
    if body.strip():
        try:
            response = json.loads(body.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            raise RuntimeError("Heartbeat trả nội dung không phải JSON; kiểm tra Worker") from None
        if isinstance(response, dict) and (response.get("ok") is False or response.get("success") is False):
            raise RuntimeError("Worker từ chối đăng ký heartbeat")
    return status

def heartbeat():
    global _last_heartbeat
    while not _stop.is_set():
        try:
            gui_heartbeat()
            _last_heartbeat = time.time()
        except Exception:
            log("Heartbeat chưa gửi được; sẽ thử lại.")
        _stop.wait(20)

def kiem_tra_ket_noi():
    """Run in another cell after Cancel Run to check the same server/secret."""
    global _last_heartbeat
    status = gui_heartbeat()
    _last_heartbeat = time.time()
    result = {"may": TEN_MAY, "http": status, "gui_luc": _last_heartbeat,
              "job": _active_job, "server": MAY_CHU}
    log("Heartbeat HTTP %d. Bấm Làm mới trên web; kiểm tra web dùng cùng Worker." % status)
    return result

def nop_ket_qua(ma, path, mime):
    # Stream the existing app's legacy PUT without loading the whole film into RAM.
    path = Path(path)
    for attempt in range(3):
        try:
            with path.open("rb") as source:
                req = urllib.request.Request(MAY_CHU + "/quay/kq/" + quote(safe_id(ma)),
                    data=source, method="PUT", headers={"X-Khoa-Quay": KHOA,
                    "User-Agent": "Mozilla/5.0 GITA365-Studio/27", "Content-Type": mime,
                    "Content-Length": str(path.stat().st_size)})
                with urllib.request.build_opener(RedirectSafe()).open(req, timeout=300) as response:
                    response.read()
                    return
        except urllib.error.HTTPError as error:
            if error.code not in (429, 500, 502, 503, 504) or attempt==2:
                raise RuntimeError("Upload web HTTP %d; giữ phim local để nộp lại" % error.code) from None
        except (urllib.error.URLError, TimeoutError):
            if attempt==2:
                raise RuntimeError("Upload web mất kết nối; giữ phim local") from None
        _stop.wait(3)


def tai_nhan_vat():
    ds = api_json("/quay/nvchuan", retry=True).get("ds", [])
    cast = {}
    for nv in ds:
        nid = safe_id(nv["id"])
        refs = []
        for i, ref in enumerate(nv.get("refs", [])):
            p = STUDIO / "assets/nvchuan" / (nid + "_%02d.png" % i)
            try:
                if not p.exists():
                    _, data = goi("/quay/nvchuan/" + quote(safe_id(ref["ma"])), retry=True)
                    with Image.open(io.BytesIO(data)) as im:
                        im.convert("RGB").save(p)
                with Image.open(p) as im:
                    im.verify()
                refs.append(p)
            except Exception:
                log("Không tải/đọc được ảnh nhân vật %s, ref %d" % (nid, i))
        if refs:
            cast[nid] = dict(ten=nv.get("ten", nid), giong=nv.get("giong", "vi-VN-NamMinhNeural"),
                            promptEn=nv.get("promptEn", ""), refs=refs)
    log("Nhân vật có ảnh tham chiếu: " + (", ".join(cast) or "chưa có"))
    return cast

TEMPLATES = {
    "dao_tao": ["Mở đầu: giới thiệu vấn đề", "Tại sao vấn đề này quan trọng",
                "Nội dung chính thứ nhất", "Nội dung chính thứ hai",
                "Ví dụ thực tế dễ hiểu", "Lỗi thường gặp cần tránh",
                "Tổng kết và lời kêu gọi hành động"],
    "huan_luyen": ["Chào mở và khởi động năng lượng", "Mục tiêu buổi huấn luyện",
                   "Hoạt động trải nghiệm chính", "Phân tích và rút ra bài học",
                   "Thực hành theo nhóm", "Cam kết hành động sau buổi học"],
    "hotro_khach": ["Chào hỏi và lắng nghe khách hàng", "Xác định đúng vấn đề",
                    "Giải pháp bước một", "Giải pháp bước hai",
                    "Kết luận và hẹn theo dõi", "Cảm ơn và kết thúc"],
    "gita_hanh_trinh": ["Tầng 1 · Thức tỉnh ý thức: nhìn nhận điểm đang đứng",
                        "Tầng 2 · Xây thói quen: một việc nhỏ làm đều mỗi ngày",
                        "Tầng 3 · Rèn kỷ luật: giữ nhịp khi không ai nhắc",
                        "Tầng 4 · Bứt phá giới hạn: dám làm điều chưa từng làm",
                        "Tầng 5 · Chiến thắng chính mình: đứng vững sau hành trình"],
}

VISUAL_MAP = {
    "mở đầu": "cinematic wide establishing shot, bright Vietnamese training hall, energetic hopeful mood",
    "chào mở": "trainer walking confidently onto a large stage, warm spotlights sweeping, audience clapping",
    "khởi động": "large group of Vietnamese adults doing energetic warm-up claps together, joyful atmosphere",
    "vấn đề": "thoughtful Vietnamese person at a desk, soft dramatic window light, reflective mood",
    "quan trọng": "medium shot of speaker gesturing strongly on stage, serious inspiring tone",
    "nội dung": "trainer presenting beside a large LED screen in a modern hall, professional corporate style",
    "ví dụ": "warm family living room scene, parents and children talking together, golden daylight",
    "lỗi": "person recognizing a mistake and nodding thoughtfully, documentary close-up",
    "hoạt động": "teams of Vietnamese adults in a big hall discussing around tables, dynamic teamwork energy",
    "nhóm": "small circle of people putting hands together in the center, celebrating teamwork",
    "thực hành": "participants writing goals on large boards, focused engaged faces",
    "cam kết": "close-up of hands signing a commitment card, determined mood, cinematic light",
    "tổng kết": "inspiring wide shot of the whole hall standing and applauding, confetti light",
    "hành động": "trainer raising a fist on stage edge, crowd raising fists in answer, epic energy",
    "lắng nghe": "close-up of a listener nodding with warm eye contact, soft light",
    "giải pháp": "step-by-step demonstration at a whiteboard, clean bright office",
    "cảm ơn": "warm grateful smile to camera, gentle applause behind, golden light",
    "thức tỉnh": "person standing at a window at dawn realizing a truth, cinematic silhouette",
    "thói quen": "person calmly repeating a small daily habit at a tidy desk, morning light",
    "kỷ luật": "person training alone with focus in a quiet room, determined expression",
    "bứt phá": "person breaking through a finish-line ribbon in a hall, triumphant slow motion",
    "chiến thắng": "hero low-angle shot of a person standing tall, arms raised, dramatic stage light",
    "kết luận": "inspiring wide shot of a team working together, sunset office light",
}

CAMS = ["medium, stable camera", "close-up, slow push in", "medium, slow pan right",
        "close-up, stable", "wide, stable", "medium, gentle handheld", "wide, slow pull back"]

def pick_visual(sect):
    s = sect.lower()
    for kw, v in VISUAL_MAP.items():
        if kw in s:
            return v
    return "corporate training video scene, clean professional Vietnamese setting, cinematic lighting"



def viet_kich_ban(job, cast):
    limit = max(1, min(MAX_SCENES, int(job.get("soCanhToiDa", 7))))
    nv = job.get("nhanVat", "trainer")
    person = cast.get(nv, {}).get("promptEn", "a Vietnamese trainer")
    source = job.get("scenes") or job.get("canh")
    if not source and LLM_ON:
        source = kich_ban_llm(job, limit)
    engine = "provided" if source else "mau-gita"
    if not source:
        sections = TEMPLATES.get(job.get("loaiPhim"), TEMPLATES["dao_tao"])[:limit]
        topic = str(job.get("chuDe", "")).strip()
        source = [{"muc_vi": section,
                   "thoai_vi": "%s. %s. Hãy chọn một hành động cụ thể để thực hiện hôm nay." % (topic, section),
                   "prompt_en": pick_visual(section) + ", " + person +
                       ", the trainer turns toward the participants, gestures with an open hand, "
                       "participants respond and take notes, realistic coordinated body motion"}
                  for section in sections]
        log("Dùng kịch bản mẫu. Muốn thoại cụ thể: gửi scenes hoặc bật GITA_LLM_ON.")
    scenes = []
    for i, s in enumerate(source[:limit]):
        if not isinstance(s, dict):
            raise ValueError("Mỗi scene phải là một object JSON")
        prompt = str(s.get("prompt_en") or s.get("visual_hint_en") or "").strip()
        if not prompt:
            raise ValueError("Scene %d thiếu prompt_en tiếng Anh" % (i + 1))
        dialogue = str(s.get("thoai_vi") or s.get("dialogue_vi") or "").strip()
        if len(dialogue) > 3000:
            raise ValueError("Thoại scene quá dài; hãy chia nhỏ")
        scenes.append(dict(index=i + 1, muc_vi=s.get("muc_vi", s.get("section_vi", "")),
            thoai_vi=dialogue, prompt_en=prompt, nhanVat=s.get("nhanVat", nv),
            camera=s.get("camera", CAMS[i % len(CAMS)]), seed=int(s.get("seed", 1000 + i)),
            duration=float(s.get("duration", 3.0)), ref_index=int(s.get("ref_index", 0))))
    if not scenes:
        raise ValueError("Kịch bản không có cảnh")
    return dict(job=job["ma"], dongCo=engine, scenes=scenes)

def kich_ban_llm(job, limit):
    unload_ltx()
    release_text_encoder()
    from transformers import AutoTokenizer, AutoModelForCausalLM
    model = tokenizer = inputs = output = None
    try:
        name = "Qwen/Qwen2.5-1.5B-Instruct"
        tokenizer = AutoTokenizer.from_pretrained(name, cache_dir=str(HF_CACHE))
        model = AutoModelForCausalLM.from_pretrained(name, torch_dtype=torch.float16,
                    cache_dir=str(HF_CACHE), low_cpu_mem_usage=True).to("cuda:%d" % _gpu_plan["render_gpu"])
        messages = [dict(role="system", content=
            'Write only JSON {"scenes":[{"muc_vi":"...","thoai_vi":"...","prompt_en":"..."}]}. '
            'Vietnamese dialogue, English detailed visual prompts with setting, characters and physical actions. '
            'Use concrete content, no generic filler. Maximum %d scenes.' % limit),
            dict(role="user", content=json.dumps({k: job.get(k) for k in
                 ("tieuDe", "chuDe", "loaiPhim", "ghiChu")}, ensure_ascii=False))]
        text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        inputs = tokenizer(text, return_tensors="pt").to(model.device)
        with torch.inference_mode():
            output = model.generate(**inputs, max_new_tokens=3000, do_sample=False)
        decoded = tokenizer.decode(output[0][inputs.input_ids.shape[1]:], skip_special_tokens=True)
        match = re.search(r"\{.*\}", decoded, re.S)
        result = json.loads(match.group(0) if match else decoded)
        if not isinstance(result.get("scenes"), list) or not result["scenes"]:
            raise ValueError("LLM không trả scenes hợp lệ")
        return result["scenes"]
    finally:
        model = tokenizer = inputs = output = None
        free()

def media_info(path, require_video=False, require_audio=False):
    path = Path(path)
    if not path.is_file() or path.stat().st_size == 0:
        raise RuntimeError("Tệp kết quả không tồn tại/rỗng: " + path.name)
    result = run_cmd(["ffprobe", "-v", "error", "-show_format", "-show_streams", "-of", "json", path])
    info = json.loads(result.stdout)
    duration = float(info.get("format", {}).get("duration", 0))
    types = {s.get("codec_type") for s in info.get("streams", [])}
    if duration <= 0 or (require_video and "video" not in types) or (require_audio and "audio" not in types):
        raise RuntimeError("Media không hợp lệ: " + path.name)
    return duration

def cham_diem_clip(path):
    import cv2, numpy as np
    cap = cv2.VideoCapture(str(path))
    sharp, motion, previous = [], [], None
    try:
        for _ in range(100):
            ok, frame = cap.read()
            if not ok:
                break
            gray = cv2.resize(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY), (256, 256))
            sharp.append(float(cv2.Laplacian(gray, cv2.CV_64F).var()))
            if previous is not None:
                motion.append(float(np.mean(cv2.absdiff(gray, previous))))
            previous = gray
    finally:
        cap.release()
    s, m = (float(np.median(sharp)) if sharp else 0), (float(np.mean(motion)) if motion else 0)
    return dict(net=round(s, 1), dong=round(m, 2),
                dat=bool(sharp) and s >= QC["blur_min"] and QC["motion_min"] <= m <= QC["motion_max"])

def quay_canh(image, prompt, seed, path):
    global _memory_mode, _working_profile
    from diffusers.pipelines.ltx.pipeline_ltx_condition import LTXVideoCondition
    path = Path(path)
    best = path.with_name(path.stem + "_best.mp4")
    best_score, best_attempt = None, 0
    encoded = prompt_tensors(prompt)
    profiles = render_profiles()
    try:
        for attempt in range(QC["thu_lai"] + 1 if QC_ON else 1):
            success = False
            for w, h, frames in profiles:
                ensure_output_space()
                p = out = rendered = None
                try:
                    p = load_pipeline()
                    kwargs = dict(width=w, height=h, **encoded, frame_rate=CFG["fps"],
                        callback_on_step_end=render_step_callback,
                        num_frames=frames, num_inference_steps=CFG["steps"],
                        guidance_scale=CFG["guidance"], decode_timestep=0.05,
                        decode_noise_scale=0.025, max_sequence_length=128,
                        generator=torch.Generator("cpu").manual_seed(seed + attempt * 777))
                    if image is not None:
                        ref = ImageOps.fit(image, (w, h), method=Image.Resampling.LANCZOS)
                        kwargs["conditions"] = [LTXVideoCondition(image=ref, frame_index=0)]
                        kwargs["image_cond_noise_scale"] = 0.025
                    if DISTILLED:
                        kwargs["timesteps"] = [1000, 993, 987, 981, 975, 909, 725, 0.03]
                    started = time.monotonic()
                    for idx in range(torch.cuda.device_count()): torch.cuda.reset_peak_memory_stats(idx)
                    with torch.inference_mode():
                        out = p(**kwargs)
                    record_gpu_metric("generate_shot", started, width=w, height=h, frames=frames)
                    rendered = out.frames[0]
                    if not rendered:
                        raise RuntimeError("LTX trả video rỗng")
                    import numpy as np
                    if not all(np.isfinite(np.asarray(f)).all() for f in rendered):
                        raise RuntimeError("LTX trả NaN; kiểm tra dtype/GPU")
                    export_to_video(rendered, str(path), fps=CFG["fps"])
                    media_info(path, require_video=True)
                    _working_profile = (w,h,frames)
                    success = True
                    break
                except torch.cuda.OutOfMemoryError:
                    log("OOM: giảm độ phân giải/frames và chuyển sequential offload")
                    _memory_mode = "sequential_offload"
                    p = out = rendered = None
                    unload_ltx()
                finally:
                    p = out = rendered = None
                    free()
            if not success:
                raise RuntimeError("OOM ở cả cấu hình tối thiểu; restart session hoặc GPU lớn hơn")
            score = cham_diem_clip(path) if QC_ON else dict(net=-1, dong=-1, dat=True)
            log("QC %d: nét=%s, chuyển động=%s, đạt=%s" % (attempt + 1, score["net"], score["dong"], score["dat"]))
            rank = (bool(score["dat"]), QC["motion_min"] <= score["dong"] <= QC["motion_max"], score["net"])
            old_rank = None if best_score is None else (bool(best_score["dat"]),
                QC["motion_min"] <= best_score["dong"] <= QC["motion_max"], best_score["net"])
            if old_rank is None or rank > old_rank:
                shutil.copyfile(path, best)
                best_score, best_attempt = score, attempt
            if score["dat"]:
                break
        if not best_score["dat"] and QC_STRICT:
            raise RuntimeError("QC chưa đạt; không nộp video vì GITA_QC_STRICT=1")
        if not best_score["dat"]:
            log("QC chưa đạt: giữ bản tốt nhất, ghi rõ trong báo cáo chất lượng.")
        shutil.copyfile(best, path)
        return media_info(path, require_video=True), best_score, best_attempt
    finally:
        best.unlink(missing_ok=True)

def doc_thoai(text, voice, path):
    if not str(text).strip():
        return None
    # Text file avoids command-line length limits and exposing dialogue in process arguments.
    textfile = Path(path).with_suffix(".tts.txt")
    textfile.write_text(str(text), encoding="utf-8")
    try:
        for attempt in range(3):
            try:
                run_cmd([sys.executable, "-m", "edge_tts", "--voice", voice,
                         "--file", textfile, "--write-media", path], timeout=180)
                return media_info(path, require_audio=True)
            except RuntimeError:
                Path(path).unlink(missing_ok=True)
                if attempt == 2:
                    raise RuntimeError("TTS thất bại; không tạo phim thiếu lời thoại") from None
                _stop.wait(3)
    finally:
        textfile.unlink(missing_ok=True)

def concat_file(paths, target):
    # Paths here are internally generated, with validated IDs and a fresh run directory.
    lines = []
    for p in paths:
        s = str(Path(p).resolve()).replace("'", "'\\''")
        lines.append("file '%s'" % s)
    Path(target).write_text("\n".join(lines) + "\n", encoding="utf-8")
    return target

def last_frame(path):
    import cv2
    cap = cv2.VideoCapture(str(path))
    frame = None
    try:
        while True:
            ok, current = cap.read()
            if not ok:
                break
            frame = current
    finally:
        cap.release()
    if frame is None:
        raise RuntimeError("Không đọc được frame cuối")
    return Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))

def normalize_video(src, dst):
    run_cmd(["ffmpeg", "-y", "-i", src, "-vf",
        "scale=%d:%d:force_original_aspect_ratio=decrease,pad=%d:%d:(ow-iw)/2:(oh-ih)/2,setsar=1,format=yuv420p" %
        (CFG["width"], CFG["height"], CFG["width"], CFG["height"]),
        "-r", CFG["fps"], "-an", "-c:v", "libx264", "-preset", VIDEO_PRESET, "-crf", str(VIDEO_CRF), dst])
    media_info(dst, require_video=True)

def mux_scene(video, audio, duration, out):
    inputs = ["-i", video] + (["-i", audio] if audio else
             ["-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo"])
    run_cmd(["ffmpeg", "-y", *inputs, "-map", "0:v:0", "-map", "1:a:0",
             "-t", "%.6f" % duration, "-c:v", "libx264", "-pix_fmt", "yuv420p",
             "-preset", VIDEO_PRESET, "-crf", str(VIDEO_CRF), "-c:a", "aac", "-ar", "48000",
             "-ac", "2", "-b:a", "96k", "-movflags", "+faststart", out])
    return media_info(out, require_video=True, require_audio=True)

def khop_moi(video, audio, output):
    if not isinstance(LIPSYNC_ARGV, list) or not all(isinstance(s, str) for s in LIPSYNC_ARGV):
        raise ValueError("GITA_LIPSYNC_ARGV phải là JSON array các chuỗi")
    joined = " ".join(LIPSYNC_ARGV)
    if any(token not in joined for token in ("{video}", "{audio}", "{output}")):
        raise ValueError("Adapter thiếu placeholder video/audio/output")
    unload_ltx()
    argv = [x.replace("{video}", str(video)).replace("{audio}", str(audio)).replace("{output}", str(output))
            for x in LIPSYNC_ARGV]
    run_cmd(argv, timeout=1200)
    d = media_info(output, require_video=True)
    if abs(d - media_info(video, require_video=True)) > 0.25:
        raise RuntimeError("Adapter khớp môi thay đổi thời lượng")
    return output

def render_scene(ma, sc, cast):
    ensure_output_space()
    sid = "%s_%03d" % (ma, sc["index"])
    nv = cast.get(sc["nhanVat"])
    if not nv and REQUIRE_REFERENCE:
        raise RuntimeError("Thiếu ảnh tham chiếu cho " + safe_id(sc["nhanVat"]))
    reference = None
    if nv:
        with Image.open(nv["refs"][sc["ref_index"] % len(nv["refs"])]) as im:
            reference = im.convert("RGB")
    audio = STUDIO / "audio" / (sid + ".mp3")
    if sc["thoai_vi"]:
        target = (media_info(audio, require_audio=True) if audio.exists() else
                  doc_thoai(sc["thoai_vi"], nv["giong"] if nv else "vi-VN-NamMinhNeural", audio))
    else:
        audio = None
        target = max(1.0, min(60.0, sc["duration"]))
    if target > 60:
        raise ValueError("Cảnh quá 60 giây; hãy chia nhỏ")
    parts, reports, total = [], [], 0.0
    raw_paths = []
    for shot in range(MAX_SHOTS_PER_SCENE):
        if total >= target:
            break
        ensure_output_space()
        raw = STUDIO / "clips" / (sid + "_shot%02d.mp4" % shot)
        normalized = raw.with_name(raw.stem + "_norm.mp4")
        report_path = raw.with_suffix(".json")
        if normalized.exists() and report_path.exists():
            duration = media_info(normalized, require_video=True)
            report = json.loads(report_path.read_text(encoding="utf-8"))
        else:
            duration, score, attempt = quay_canh(reference,
                sc["prompt_en"] + ", " + sc["camera"] + ", realistic coordinated natural body motion",
                sc["seed"] + shot * 101, raw)
            # Normalize once; delete source once the normalized clip is validated.
            normalize_video(raw, normalized)
            duration = media_info(normalized, require_video=True)
            report = dict(qc=score, retry=attempt, duration=duration, native_profile=_working_profile)
            atomic_json(report_path, report)
        reference = last_frame(normalized)
        parts.append(normalized)
        raw_paths.extend([raw, report_path])
        delete_local_files([raw])
        reports.append(report)
        total += duration
        log("Cảnh %d | đoạn %d | %.1f / %.1f giây" % (sc["index"], shot + 1, total, target))
    if total < target:
        raise RuntimeError("Không đủ đoạn cho thoại; tăng MAX_SHOTS_PER_SCENE")
    listing = concat_file(parts, STUDIO / "jobs" / (sid + "_shots.txt"))
    result = STUDIO / "clips" / (sid + "_complete.mp4")
    scratch = []
    if audio and LIPSYNC_ARGV:
        joined = STUDIO / "clips" / (sid + "_joined.mp4")
        run_cmd(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", listing,
                 "-t", target, "-c:v", "copy", joined])
        lipsynced = khop_moi(joined, audio, STUDIO / "clips" / (sid + "_lipsync.mp4"))
        duration = mux_scene(lipsynced, audio, target, result)
        scratch = [joined, lipsynced]
    else:
        audio_inputs = (["-i", audio] if audio else
                        ["-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo"])
        run_cmd(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", listing,
                 *audio_inputs, "-map", "0:v:0", "-map", "1:a:0", "-t", target,
                 "-c:v", "copy", "-c:a", "aac", "-ar", "48000", "-ac", "2",
                 "-b:a", "96k", "-movflags", "+faststart", result])
        duration = media_info(result, require_video=True, require_audio=True)
    # Crash recovery: commit complete scene before deleting its source segments/audio.
    receipt = dict(path=str(result), duration=duration, shots=reports,
                   lipsync=bool(audio and LIPSYNC_ARGV), narration=bool(audio))
    scene_receipt = STUDIO / "jobs" / (sid + "_complete.json")
    atomic_json(scene_receipt, receipt)
    delete_local_files(parts + raw_paths + scratch + [listing] + ([audio] if audio else []))
    return receipt

def clip_chu(ma, name, text, duration):
    import textwrap
    font = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")
    if not font.exists():
        raise RuntimeError("Thiếu font DejaVuSans-Bold.ttf")
    textfile = STUDIO / "jobs" / (ma + "_" + name + "_title.txt")
    textfile.write_text("\n".join(textwrap.wrap(text, width=30)), encoding="utf-8")
    output = STUDIO / "clips" / (ma + "_" + name + ".mp4")
    run_cmd(["ffmpeg", "-y", "-f", "lavfi", "-i",
        "color=c=0x0d2b45:s=%dx%d:r=%d" % (CFG["width"], CFG["height"], CFG["fps"]),
        "-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo", "-t", duration,
        "-vf", "drawtext=fontfile=%s:textfile=%s:expansion=none:fontcolor=white:fontsize=32:line_spacing=10:x=(w-text_w)/2:y=(h-text_h)/2" % (font, textfile),
        "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", VIDEO_PRESET, "-crf", str(VIDEO_CRF),
        "-c:a", "aac", "-ar", "48000", "-ac", "2", "-b:a", "96k", output])
    media_info(output, require_video=True, require_audio=True)
    return output

def srt_time(seconds):
    millis = round(seconds * 1000)
    hours, millis = divmod(millis, 3600000)
    minutes, millis = divmod(millis, 60000)
    secs, millis = divmod(millis, 1000)
    return "%02d:%02d:%02d,%03d" % (hours, minutes, secs, millis)

def lam_srt(scenes, results, output):
    import textwrap
    offset = INTRO_SECONDS
    entries = []
    for sc, result in zip(scenes, results):
        words = sc["thoai_vi"].split()
        groups = [words[i:i + 12] for i in range(0, len(words), 12)]
        elapsed = 0.0
        for group in groups:
            end = elapsed + result["duration"] * len(group) / len(words)
            content = "\n".join(textwrap.wrap(" ".join(group), width=42))
            entries.append("%d\n%s --> %s\n%s\n" % (len(entries) + 1,
                srt_time(offset + elapsed), srt_time(offset + end), content))
            elapsed = end
        offset += result["duration"]
    Path(output).write_text("\n".join(entries), encoding="utf-8")
    return output

def lam_phim(ma, job, cast):
    ma = safe_id(ma)
    storyboard_path = STUDIO / "jobs" / (ma + "_kichban.json")
    identity = {nid: [hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in v["refs"]]
                for nid, v in cast.items()}
    job_fingerprint = hashlib.sha256(json.dumps(
        dict(job=job, model=MODEL_LTX, cfg=CFG, text_mode=TEXT_MODE, references=identity,
             lipsync=LIPSYNC_ARGV, qc=QC, qc_strict=QC_STRICT),
        sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    if storyboard_path.exists():
        kb = json.loads(storyboard_path.read_text(encoding="utf-8"))
        if kb.get("job_fingerprint") != job_fingerprint:
            raise RuntimeError("Nội dung việc đã đổi; chọn GITA_RUN_ID mới")
    else:
        kb = viet_kich_ban(job, cast)
        kb["job_fingerprint"] = job_fingerprint
        atomic_json(storyboard_path, kb)
    checkpoint = STUDIO / "jobs" / (ma + "_tiendo.json")
    progress = json.loads(checkpoint.read_text(encoding="utf-8")) if checkpoint.exists() else {"scenes": {}}
    final = STUDIO / "final" / (ma + ".mp4")
    quality_path = STUDIO / "final" / (ma + "_quality.json")
    if final.exists() and quality_path.exists():
        media_info(final, require_video=True, require_audio=True)
        return final
    ensure_output_space()
    results = []
    for sc in kb["scenes"]:
        key = str(sc["index"])
        result = progress["scenes"].get(key)
        scene_receipt = STUDIO / "jobs" / ("%s_%03d_complete.json" % (ma, sc["index"]))
        if not result and scene_receipt.exists():
            result = json.loads(scene_receipt.read_text(encoding="utf-8"))
        if result:
            try:
                media_info(result["path"], require_video=True, require_audio=True)
            except RuntimeError:
                result = None
        if not result:
            result = render_scene(ma, sc, cast)
            progress["scenes"][key] = result
            atomic_json(checkpoint, progress)
        else:
            log("Bỏ qua cảnh hoàn tất %s" % key)
        results.append(result)
    intro = clip_chu(ma, "intro", BRAND["ten"], INTRO_SECONDS)
    outro = clip_chu(ma, "outro", BRAND["slogan"], OUTRO_SECONDS)
    listing = concat_file([intro] + [r["path"] for r in results] + [outro], STUDIO / "jobs" / (ma + "_film.txt"))
    body = STUDIO / "final" / (ma + "_body.mp4")
    run_cmd(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", listing,
        "-c:v", "copy", "-c:a", "copy", body], timeout=1800)
    srt = lam_srt(kb["scenes"], results, STUDIO / "subs" / (ma + ".srt"))
    final = STUDIO / "final" / (ma + ".mp4")
    subtitle_args = (["-i", srt, "-map", "0:v:0", "-map", "0:a:0", "-map", "1:0",
                      "-c:s", "mov_text", "-metadata:s:s:0", "language=vie"]
                     if Path(srt).stat().st_size else ["-map", "0:v:0", "-map", "0:a:0"])
    run_cmd(["ffmpeg", "-y", "-i", body, *subtitle_args, "-c:v", "copy", "-c:a", "copy",
             "-movflags", "+faststart", final])
    duration = media_info(final, require_video=True, require_audio=True)
    expected = sum(r["duration"] for r in results) + INTRO_SECONDS + OUTRO_SECONDS
    if abs(duration - expected) > 0.5:
        raise RuntimeError("Thời lượng phim không khớp các cảnh")
    atomic_json(STUDIO / "final" / (ma + "_quality.json"),
                dict(version=VERSION, model=MODEL_LTX, duration=duration, scenes=results,
                     qc_scope="sharpness and pixel change only; no face/hand/identity verification"))
    delete_local_files([body, intro, outro, listing] + [r["path"] for r in results])
    log("Hoàn tất phim: %s | %.1f giây" % (final.name, duration))
    return final

def lam_tts(ma):
    _, body = goi("/quay/tep/" + quote(safe_id(ma)) + "/loi", retry=True)
    text = body.decode("utf-8")
    voice = "vi-VN-NamMinhNeural"
    match = re.match(r"^#giong=([\w-]+)\r?\n", text)
    if match:
        voice, text = match.group(1), text[match.end():]
    if not text.strip():
        raise ValueError("Việc TTS không có nội dung")
    output = STUDIO / "audio" / (ma + ".mp3")
    doc_thoai(text, voice, output)
    return output

def main():
    if os.getenv("GITA_MODE", "render") == "archive":
        return main_archive()
    global _active_job
    try:
        setup()
        # Fail auth before any multi-GB model download.
        cast = tai_nhan_vat()
        archive_json("/health")  # Require deployed archive protocol before producing films.
        don_phim_tam(force=True)
        janitor = threading.Thread(target=restore_janitor, daemon=True)
        janitor.start()
        started = time.monotonic()
        idle_since = started
        log("Xưởng sẵn sàng; đang chờ film/tts. Cancel Run để dừng vòng chờ.")
        while not _stop.is_set() and time.monotonic() - started < MAX_SESSION_HOURS * 3600:
            try:
                # Do not retry claims automatically: response loss can claim another job.
                task = api_json("/quay/nhan", {"may": TEN_MAY, "loai": "film,tts"})
            except PermissionError:
                raise
            except Exception as error:
                log("Nhận việc thất bại (%s); thử sau %ds" % (type(error).__name__, POLL_SECONDS))
                _stop.wait(POLL_SECONDS)
                continue
            if not task.get("ma"):
                if time.monotonic()-idle_since >= IDLE_EXIT_SECONDS:
                    log("Không có việc; kết thúc worker. End Session trên Kaggle để ngừng tính quota GPU.")
                    break
                _stop.wait(POLL_SECONDS)
                continue
            idle_since = time.monotonic()
            ma = safe_id(task["ma"])
            _active_job = ma
            receipt = STUDIO / "jobs" / (ma + "_delivery.json")
            try:
                if task.get("loai") == "tts":
                    output, mime = lam_tts(ma), "audio/mpeg"
                elif task.get("loai") == "film":
                    _, data = goi("/quay/tep/" + quote(ma) + "/loi", retry=True)
                    job = json.loads(data.decode("utf-8"))
                    job["ma"] = ma
                    cast = tai_nhan_vat()
                    output, mime = lam_phim(ma, job, cast), "video/mp4"
                else:
                    raise ValueError("Loại việc không được hỗ trợ")
                atomic_json(receipt, dict(status="ready", path=str(output), mime=mime))
                # An upload failure retains local output and ready receipt for manual retry.
                nop_ket_qua(ma, output, mime)
                atomic_json(receipt, dict(status="web_uploaded", path=str(output), mime=mime))
                luu_tu_xa_va_don(ma, output, mime)
                log("Đã nộp web, xác minh lưu trữ và dọn bản Kaggle: " + ma)
            except Exception as error:
                log("Việc %s lỗi: %s" % (ma, str(error).replace(KHOA, "[secret]")[:250]))
                if not receipt.exists():
                    try:
                        api_json("/quay/loi/" + quote(ma), {"loi": str(error).replace(KHOA, "[secret]")[:180]})
                    except Exception:
                        pass
                else:
                    log("Giữ kết quả tại máy; chạy retry_upload(ma) để nộp lại.")
            finally:
                _active_job = None
                idle_since = time.monotonic()
                free()
    except KeyboardInterrupt:
        log("Đã dừng. Các cảnh hoàn tất được giữ trong thư mục phiên.")
    finally:
        _stop.set()
        don_phim_tam(force=True)
        if "torch" in globals():
            unload_ltx()
            release_text_encoder()
            _prompt_cache.clear()
        if _heartbeat_thread is not None:
            _heartbeat_thread.join(timeout=2)

def retry_upload(ma):
    ma = safe_id(ma)
    receipt = STUDIO / "jobs" / (ma + "_delivery.json")
    item = json.loads(receipt.read_text(encoding="utf-8"))
    media_info(item["path"])
    nop_ket_qua(ma, item["path"], item["mime"])
    item["status"] = "web_uploaded"
    atomic_json(receipt, item)
    luu_tu_xa_va_don(ma, item["path"], item["mime"])
    log("Đã nộp lại, lưu trữ và dọn " + ma)

# ── V25: verified remote archive + zero local film until explicitly restored ──
def archive_request(path, method="GET", data=None, mime="application/json"):
    if not ARCHIVE_SERVER.startswith("https://"):
        raise ValueError("GITA_ARCHIVE_SERVER phải dùng HTTPS")
    req = urllib.request.Request(ARCHIVE_SERVER + "/quay/archive" + path, data=data, method=method,
        headers={"X-Khoa-Quay": KHOA, "Content-Type": mime,
                 "User-Agent": "Mozilla/5.0 GITA365-Studio/27"})
    return urllib.request.build_opener(RedirectSafe()).open(req, timeout=300)


def archive_json(path, payload=None, method=None):
    data = json.dumps(payload).encode() if payload is not None else None
    try:
        with archive_request(path, method or ("POST" if payload is not None else "GET"), data) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as error:
        raise RuntimeError("Archive API HTTP %d; cần triển khai archive-worker.mjs và binding R2 trước khi chạy V27" % error.code) from None
    except urllib.error.URLError as error:
        raise RuntimeError("Kết nối kho phim thất bại: " + type(error.reason).__name__) from None


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(2 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_manifest(manifest, ma, size=None, digest=None):
    if (not isinstance(manifest, dict) or manifest.get("ma") != ma or
        not isinstance(manifest.get("size"), int) or manifest["size"] <= 0 or
        not re.fullmatch(r"[a-f0-9]{64}", str(manifest.get("sha256", ""))) or
        manifest.get("mime") not in ("video/mp4", "audio/mpeg")):
        raise RuntimeError("Manifest kho phim không hợp lệ")
    if size is not None and (manifest["size"] != size or manifest["sha256"] != digest):
        raise RuntimeError("Phim từ xa không khớp bản gốc; GIỮ bản Kaggle")
    return manifest


def read_verified_archive(ma, manifest, destination=None):
    # Verify actual bytes streamed from R2, not just a successful upload or ETag.
    digest, size = hashlib.sha256(), 0
    tmp = None if destination is None else Path(destination).with_suffix(".download")
    output = None
    try:
        if tmp is not None:
            tmp.parent.mkdir(parents=True, exist_ok=True)
            output = tmp.open("wb")
        with archive_request("/file/" + quote(safe_id(ma))) as response:
            for chunk in iter(lambda: response.read(2 * 1024 * 1024), b""):
                size += len(chunk)
                if size > manifest["size"]:
                    raise RuntimeError("Kho phim trả nhiều byte hơn manifest")
                digest.update(chunk)
                if output is not None:
                    output.write(chunk)
        if size != manifest["size"] or digest.hexdigest() != manifest["sha256"]:
            raise RuntimeError("Read-back SHA-256/size không khớp; GIỮ bản Kaggle")
        if output is not None:
            output.close()
            output = None
            tmp.replace(destination)
        return {"size": size, "sha256": digest.hexdigest(), "verified": True}
    finally:
        if output is not None:
            output.close()
        if tmp is not None:
            tmp.unlink(missing_ok=True)


def upload_archive(ma, path, mime):
    ma = safe_id(ma)
    path = Path(path)
    size, digest = path.stat().st_size, file_sha256(path)
    expected = {"ma": ma, "size": size, "sha256": digest, "mime": mime}
    state_path = STUDIO.parent / "transfer-state" / (ma + "-" + digest + ".json")
    state = json.loads(state_path.read_text()) if state_path.exists() else None
    # A lost complete response may already have published the canonical object.
    try:
        manifest = validate_manifest(archive_json("/meta/" + quote(ma)), ma, size, digest)
    except (urllib.error.HTTPError, RuntimeError):
        manifest = None
    if manifest is None:
        if state is None:
            start = archive_json("/start", expected)
            if start.get("existing"):
                manifest = validate_manifest(start["manifest"], ma, size, digest)
            else:
                state = dict(start, expected=expected, parts=[])
                atomic_json(state_path, state)
        if manifest is None:
            if state.get("expected") != expected:
                raise RuntimeError("Tiến độ tải lên không khớp phim")
            session, part_bytes = str(state["session"]), int(state["partBytes"])
            if not re.fullmatch(r"[a-f0-9-]{36}", session) or not 5*1024**2 <= part_bytes <= 16*1024**2:
                raise RuntimeError("Tiến độ upload không hợp lệ")
            parts = state["parts"]
            if not isinstance(parts, list) or any(p.get("partNumber") != i+1 or not isinstance(p.get("etag"), str) for i,p in enumerate(parts)):
                raise RuntimeError("Danh sách part không hợp lệ")
            with path.open("rb") as source:
                source.seek(len(parts)*part_bytes)
                while True:
                    chunk = source.read(part_bytes)
                    if not chunk: break
                    number = len(parts)+1
                    for attempt in range(3):
                        try:
                            with archive_request("/part/%s/%d" % (session, number), "PUT", chunk, "application/octet-stream") as response:
                                part = json.loads(response.read().decode())
                            if part.get("partNumber") != number or not isinstance(part.get("etag"), str):
                                raise RuntimeError("Part không hợp lệ")
                            parts.append(part)
                            atomic_json(state_path, state)
                            break
                        except urllib.error.HTTPError as error:
                            if error.code == 404:
                                state_path.unlink(missing_ok=True)
                            raise
                        except (urllib.error.URLError, TimeoutError):
                            if attempt == 2: raise
                            _stop.wait(2)
            try:
                manifest = archive_json("/complete/" + session, {"parts": parts})
            except Exception:
                manifest = archive_json("/meta/" + quote(ma))
            validate_manifest(manifest, ma, size, digest)
    # Retain progress and local source on every failure, including readback failure.
    read_verified_archive(ma, manifest)
    state_path.unlink(missing_ok=True)
    return manifest


def luu_tu_xa_va_don(ma, path, mime, receipt_path=None):
    ma = safe_id(ma)
    receipt = Path(receipt_path) if receipt_path else STUDIO / "jobs" / (ma + "_delivery.json")
    root = receipt.parent.parent
    if receipt.parent.name != "jobs" or not root.resolve().is_relative_to(STUDIO.parent.resolve()):
        raise RuntimeError("Biên nhận ngoài thư mục xưởng")
    item = json.loads(receipt.read_text(encoding="utf-8"))
    if item.get("status") not in ("web_uploaded", "cold"):
        raise RuntimeError("Chưa xác nhận upload web; không được xóa bản local")
    path = Path(path)
    if not path.resolve().is_relative_to(root.resolve()):
        raise RuntimeError("Phim ngoài thư mục phiên")
    manifest = upload_archive(ma, path, mime)
    # Commit durable reference first. Evict only files belonging to this exact job.
    item.update(status="cold", remote=manifest, verified_at=time.time())
    atomic_json(receipt, item)
    # Exact filenames only: IDs containing underscores must not collide with other jobs.
    exact_paths = [path, root / "final" / (ma + "_quality.json"),
                   root / "final" / (ma + "_body.mp4"), root / "subs" / (ma + ".srt")]
    for local in exact_paths:
        if local.resolve().is_relative_to(root.resolve()):
            local.unlink(missing_ok=True)
    log("Phim %s ở kho từ xa; Kaggle chỉ giữ mã tham chiếu nhỏ." % ma)
    return manifest


def hoan_tat_luu_tru(ma):
    ma = safe_id(ma)
    item = json.loads((STUDIO / "jobs" / (ma + "_delivery.json")).read_text())
    if item.get("status") == "cold" and not Path(item["path"]).exists():
        log("Phim đã ở kho từ xa; không cần tải lại.")
        return item["remote"]
    return luu_tu_xa_va_don(ma, item["path"], item["mime"])


def tai_lai_phim(ma, ttl=RESTORE_TTL_SECONDS):
    ma = safe_id(ma)
    ttl = max(60, min(3600, int(ttl)))
    with _restore_lock:
        don_phim_tam_unlocked(force=True)  # One local restored film at most.
        manifest = validate_manifest(archive_json("/meta/" + quote(ma)), ma)
        if shutil.disk_usage(STUDIO).free < manifest["size"] + 256 * 1024**2:
            raise RuntimeError("Không đủ đĩa tải tạm phim; xem trên web thay vì tải về Kaggle")
        ext = ".mp4" if manifest["mime"] == "video/mp4" else ".mp3"
        path = STUDIO.parent / "restore-cache" / (ma + ext)
        read_verified_archive(ma, manifest, path)
        try:
            media_info(path, require_video=ext == ".mp4", require_audio=True)
            atomic_json(path.with_suffix(".lease.json"), {"path": str(path), "expires": time.time() + ttl})
        except Exception:
            path.unlink(missing_ok=True)
            raise
        log("Tải tạm %s; tự dọn sau %d giây khi worker còn chạy." % (ma, ttl))
        return path


def don_phim_tam_unlocked(force=False):
    root = STUDIO.parent / "restore-cache"
    if not root.exists():
        return
    if force:
        for file in root.iterdir():
            if file.is_file() and file.suffix in (".mp4", ".mp3", ".download"):
                file.unlink()
    for lease in root.glob("*.lease.json"):
        data = json.loads(lease.read_text())
        path = Path(data["path"])
        if force or time.time() >= data["expires"]:
            if path.resolve().parent == root.resolve():
                path.unlink(missing_ok=True)
            lease.unlink(missing_ok=True)


def don_phim_tam(force=False):
    with _restore_lock:
        don_phim_tam_unlocked(force)


def restore_janitor():
    while not _stop.is_set():
        try:
            don_phim_tam()
            poll_archive_commands()
            retry_pending_archives()
        except Exception:
            log("Không dọn được phim tải tạm; sẽ thử lại.")
        _stop.wait(30)


def poll_archive_commands():
    result = archive_json("/commands/" + quote(TEN_MAY))
    for command in result.get("commands", [])[:5]:
        try:
            action = command["action"]
            ma = safe_id(command["filmMa"])
            if action in ("restore", "view"):
                tai_lai_phim(ma, int(command.get("ttl", RESTORE_TTL_SECONDS)))
            elif action == "release":
                don_phim_tam(force=True)
            else:
                raise ValueError("Lệnh archive không được hỗ trợ")
            log("Hoàn tất lệnh archive " + command["id"])
            archive_json("/commands/%s/%s" % (quote(TEN_MAY), quote(command["id"])), {}, method="DELETE")
        except Exception as error:
            log("Lệnh archive lỗi: " + type(error).__name__)
            # Preserve the command for inspection/retry; do not delete on failure.
            break


_archive_retry_after = {}
def retry_pending_archives():
    for receipt in STUDIO.parent.glob("*/jobs/*_delivery.json"):
        item = json.loads(receipt.read_text())
        ma = receipt.name[:-len("_delivery.json")]
        if ma == _active_job or time.time() < _archive_retry_after.get(str(receipt), 0):
            continue
        if item.get("status") == "web_uploaded" and Path(item["path"]).is_file():
            try:
                luu_tu_xa_va_don(ma, item["path"], item["mime"], receipt)
            except Exception:
                _archive_retry_after[str(receipt)] = time.time() + 300
                log("Lưu trữ chưa xong; giữ phim và thử lại sau 5 phút: " + ma)

def main_archive():
    global KHOA
    STUDIO.mkdir(parents=True, exist_ok=True)
    KHOA = lay_khoa_an_toan()
    if not ARCHIVE_SERVER.startswith("https://"):
        raise ValueError("Archive server phải dùng HTTPS")
    archive_json("/health")
    if not shutil.which("ffprobe"):
        raise RuntimeError("Thiếu ffprobe để kiểm tra phim tải lại")
    don_phim_tam(force=True)  # Remove leftovers from interrupted previous sessions.
    log("Chế độ lưu trữ CPU; mã máy: " + TEN_MAY)
    log("Chờ lệnh tải lại; không cài hoặc nạp model video.")
    started = time.monotonic()
    try:
        while not _stop.is_set() and time.monotonic()-started < MAX_SESSION_HOURS*3600:
            try:
                don_phim_tam()
                retry_pending_archives()
                poll_archive_commands()
            except Exception as error:
                log("Lưu trữ tạm gián đoạn: " + type(error).__name__)
            _stop.wait(POLL_SECONDS)
    except KeyboardInterrupt:
        log("Đã dừng chế độ lưu trữ.")
    finally:
        _stop.set()
        don_phim_tam(force=True)

# Load AFTER the full GITA code has been defined; stop the worker before cleanup.
def _cleanup_idle():
    if _active_job is not None or not _stop.is_set():
        raise RuntimeError('Hãy Cancel Run và chờ worker dừng trước khi dọn đĩa.')


def xac_nhan_da_tai_laptop(receipt_path, da_kiem_tra=False):
    """Explicit user attestation; Kaggle cannot inspect a laptop download."""
    _cleanup_idle()
    if da_kiem_tra is not True:
        raise ValueError('Cần kiểm tra phim mở được trên laptop rồi truyền da_kiem_tra=True.')
    receipt = Path(receipt_path)
    root = STUDIO.parent.resolve()
    if receipt.is_symlink() or receipt.parent.name != 'jobs' or not receipt.resolve().is_relative_to(root):
        raise ValueError('Biên nhận ngoài xưởng.')
    item = json.loads(receipt.read_text())
    film = Path(item['path'])
    if film.is_symlink() or not film.resolve().is_relative_to(receipt.parent.parent.resolve()):
        raise ValueError('Phim ngoài phiên.')
    item['laptop_backup'] = dict(size=film.stat().st_size, sha256=file_sha256(film), confirmed_at=time.time())
    atomic_json(receipt, item)
    return {'receipt':str(receipt),'confirmed':True}


def lam_sach_dia(thuc_hien=False):
    """Preview by default. Delete only job media with verified remote or attested laptop backup."""
    _cleanup_idle()
    base = STUDIO.parent.resolve()
    report = {'files':[], 'skipped':[], 'bytes_selected':0, 'bytes_deleted':0, 'errors':[]}
    for receipt in sorted(base.glob('*/jobs/*_delivery.json')):
        try:
            if receipt.is_symlink(): raise ValueError('Symlink receipt')
            run = receipt.parent.parent.resolve()
            if run.parent != base: raise ValueError('Run outside studio')
            ma = safe_id(receipt.name[:-len('_delivery.json')])
            item = json.loads(receipt.read_text())
            film = Path(item['path'])
            if film.is_symlink() or not film.resolve().is_relative_to(run):
                raise ValueError('Film outside run')
            backup = item.get('laptop_backup')
            approved = False
            if backup and film.is_file():
                approved = film.stat().st_size == backup['size'] and file_sha256(film) == backup['sha256']
            if not approved and item.get('status') == 'cold':
                remote = validate_manifest(archive_json('/meta/' + quote(ma)), ma)
                saved = item.get('remote', {})
                validate_manifest(saved, ma)
                validate_manifest(remote, ma, saved['size'], saved['sha256'])
                if film.is_file() and (film.stat().st_size != remote['size'] or file_sha256(film) != remote['sha256']):
                    raise ValueError('Local film changed since archive')
                read_verified_archive(ma, remote)
                approved = True
            if not approved:
                report['skipped'].append({'receipt':str(receipt),'reason':'Chưa xác minh bản sao an toàn'})
                continue
            # No broad prefix globs: abc and abc_other are distinct jobs.
            candidates = {film,run/'final'/(ma+'_body.mp4'),run/'subs'/(ma+'.srt'),run/'audio'/(ma+'.mp3'),
                          run/'clips'/(ma+'_intro.mp4'),run/'clips'/(ma+'_outro.mp4')}
            quality = run/'final'/(ma+'_quality.json')
            if quality.is_file() and not quality.is_symlink():
                for scene in json.loads(quality.read_text()).get('scenes',[]):
                    if scene.get('path'): candidates.add(Path(scene['path']))
            for candidate in sorted(candidates):
                if candidate.is_symlink() or not candidate.resolve().is_relative_to(run) or not candidate.is_file():
                    continue
                size = candidate.stat().st_size
                report['files'].append(str(candidate));report['bytes_selected'] += size
                if thuc_hien:
                    try:
                        candidate.unlink();report['bytes_deleted'] += size
                    except OSError as error: report['errors'].append({'file':str(candidate),'type':type(error).__name__})
            if thuc_hien:
                item['local_cleanup_at'] = time.time();atomic_json(receipt,item)
        except Exception as error:
            report['skipped'].append({'receipt':str(receipt),'reason':type(error).__name__})
    report['free_gb'] = shutil.disk_usage(base).free/2**30
    log('Đã chọn %.2f GB; đã xóa %.2f GB; ổ còn %.2f GB.' %
        (report['bytes_selected']/2**30,report['bytes_deleted']/2**30,report['free_gb']))
    return report


def giai_phong_gpu():
    _cleanup_idle()
    global _pipe
    _pipe = None
    release_text_encoder()
    _prompt_cache.clear()
    gc.collect()
    if 'torch' in globals() and torch.cuda.is_available():
        torch.cuda.empty_cache()
        return {'free_gb':torch.cuda.mem_get_info(0)[0]/2**30}
    return {'gpu':'Không có GPU hoặc chưa nạp torch'}

# GITA V27 GPU engine: no third-party imports until GPU setup has completed.
from collections import OrderedDict
GPU_PROFILE = os.getenv('GITA_GPU_PROFILE', 'balanced')
TEXT_MODE = os.getenv('GITA_TEXT_MODE', 'int8')
OFFLOAD_MODE = os.getenv('GITA_OFFLOAD', 'model')
IDLE_EXIT_SECONDS = max(60, int(os.getenv('GITA_IDLE_EXIT_SECONDS', '300')))
_text_encoder = None
_tokenizer = None
_prompt_cache = OrderedDict()
_working_profile = None
_gpu_plan = None


def choose_gpu_plan(devices, profile='balanced'):
    if profile not in ('economy','balanced','quality'):
        raise ValueError('GITA_GPU_PROFILE: economy, balanced hoặc quality')
    if not devices: raise RuntimeError('Không có GPU')
    render = max(range(len(devices)), key=lambda i:devices[i]['free_bytes'])
    spare = [i for i in range(len(devices)) if i != render and tuple(devices[i]['capability'])>=(7,5)
             and devices[i]['free_bytes'] >= 7*2**30]
    text = max(spare,key=lambda i:devices[i]['free_bytes']) if spare else render
    free_gb = devices[render]['free_bytes']/2**30
    target = {'economy':(512,320,49), 'balanced':(640,384,73), 'quality':(768,448,97)}[profile]
    if free_gb < 8: target = (384,256,25)
    elif free_gb < 12 and profile != 'economy': target = (512,320,49)
    return dict(render_gpu=render,text_gpu=text,profile=profile,target=target,devices=devices)


def configure_gpu():
    global _gpu_plan
    if TEXT_MODE not in ('int8','cpu_fp32'): raise ValueError('GITA_TEXT_MODE: int8 hoặc cpu_fp32')
    if OFFLOAD_MODE not in ('model','group','sequential'): raise ValueError('GITA_OFFLOAD không hợp lệ')
    devices=[]
    for i in range(torch.cuda.device_count()):
        with torch.cuda.device(i):
            f,t=torch.cuda.mem_get_info()
        devices.append(dict(name=torch.cuda.get_device_name(i),free_bytes=f,total_bytes=t,
                            capability=list(torch.cuda.get_device_capability(i))))
    _gpu_plan = choose_gpu_plan(devices,GPU_PROFILE)
    render = _gpu_plan['render_gpu']
    torch.cuda.set_device(render)
    torch.backends.cuda.matmul.allow_tf32 = devices[render]['capability'][0]>=8
    CFG['width'],CFG['height'],CFG['frames'] = _gpu_plan['target']
    atomic_json(STUDIO/'gpu_plan.json',dict(version=VERSION,plan=_gpu_plan,text_mode=TEXT_MODE,offload=OFFLOAD_MODE))
    log('GPU plan: render=%d, T5=%d, %s, %s' % (render,_gpu_plan['text_gpu'],GPU_PROFILE,CFG))
    return _gpu_plan


def gpu_dtype():
    with torch.cuda.device(_gpu_plan['render_gpu']):
        return torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16


def release_text_encoder():
    global _text_encoder
    _text_encoder = None
    free()


def load_text_encoder():
    global _text_encoder, _tokenizer
    if _text_encoder is not None: return _text_encoder
    from transformers import T5EncoderModel, AutoTokenizer, BitsAndBytesConfig
    if _tokenizer is None:
        _tokenizer = AutoTokenizer.from_pretrained(MODEL_LTX,subfolder='tokenizer',cache_dir=str(HF_CACHE))
    if TEXT_MODE == 'int8':
        idx = _gpu_plan['text_gpu']
        if tuple(torch.cuda.get_device_capability(idx))<(7,5):
            raise RuntimeError('GPU này không hỗ trợ LLM.int8; chọn GITA_TEXT_MODE=cpu_fp32')
        # For a single GPU, text encoding and video generation have separate lifetimes.
        if idx == _gpu_plan['render_gpu']: unload_ltx()
        _text_encoder = T5EncoderModel.from_pretrained(MODEL_LTX,subfolder='text_encoder',
            cache_dir=str(HF_CACHE),low_cpu_mem_usage=True,torch_dtype=torch.float32,
            quantization_config=BitsAndBytesConfig(load_in_8bit=True),device_map={'':idx})
    else:
        # Explicit slow fallback, never silently allocate ~20 GB FP32 T5 RAM.
        import psutil
        if psutil.virtual_memory().available < 22*2**30:
            raise RuntimeError('T5 FP32 CPU cần dự phòng ít nhất 22 GiB RAM; chọn int8 hoặc restart session')
        _text_encoder = T5EncoderModel.from_pretrained(MODEL_LTX,subfolder='text_encoder',
            cache_dir=str(HF_CACHE),low_cpu_mem_usage=True,torch_dtype=torch.float32).to('cpu')
    _text_encoder.eval()
    return _text_encoder


def cache_prompt(key,value):
    _prompt_cache[key]=value
    _prompt_cache.move_to_end(key)
    while len(_prompt_cache)>16: _prompt_cache.popitem(last=False)


def prompt_tensors(prompt):
    def encode(text):
        key=(MODEL_LTX,TEXT_MODE,text)
        if key in _prompt_cache:
            _prompt_cache.move_to_end(key)
            return _prompt_cache[key]
        encoder=load_text_encoder()
        inputs=_tokenizer(text,padding='max_length',max_length=128,truncation=True,
                          add_special_tokens=True,return_tensors='pt')
        device = next(encoder.parameters()).device
        ids,mask=inputs.input_ids.to(device),inputs.attention_mask.to(device)
        with torch.inference_mode():
            emb=encoder(input_ids=ids,attention_mask=mask).last_hidden_state
        if not torch.isfinite(emb).all():
            raise RuntimeError('T5 sinh NaN/Inf; không dựng phim với embedding lỗi')
        result=(emb.detach().to(device='cpu',dtype=gpu_dtype()),mask.detach().cpu())
        cache_prompt(key,result)
        return result
    started=time.monotonic()
    try:
        positive=encode(prompt)
        negative=encode(NEG) if CFG['guidance']>1 else (None,None)
        return dict(prompt_embeds=positive[0],prompt_attention_mask=positive[1],
                    negative_prompt_embeds=negative[0],negative_prompt_attention_mask=negative[1])
    finally:
        if TEXT_MODE == 'cpu_fp32' or _gpu_plan['text_gpu']==_gpu_plan['render_gpu']:
            release_text_encoder()
        record_gpu_metric('text_encode',started)


def render_profiles():
    first = _working_profile or tuple(_gpu_plan['target'])
    alternatives = [first,(512,320,49),(384,256,25)]
    # Never increase token volume after an OOM or an economy request.
    result=[];budget=first[0]*first[1]*first[2]
    for item in alternatives:
        if item not in result and item[0]*item[1]*item[2]<=budget: result.append(item)
    return result


def record_gpu_metric(stage,started,**extra):
    if _gpu_plan is None: return
    row=dict(stage=stage,seconds=round(time.monotonic()-started,3),time=time.time(),**extra,gpus=[])
    for i in range(torch.cuda.device_count()):
        f,t=torch.cuda.mem_get_info(i)
        row['gpus'].append(dict(id=i,free_gb=round(f/2**30,3),
            allocated_gb=round(torch.cuda.memory_allocated(i)/2**30,3),
            peak_allocated_gb=round(torch.cuda.max_memory_allocated(i)/2**30,3)))
    (STUDIO/'metrics').mkdir(parents=True,exist_ok=True)
    with (STUDIO/'metrics/gpu.jsonl').open('a') as handle: handle.write(json.dumps(row)+'\n')


def render_step_callback(pipe,step,timestep,kwargs):
    if _stop.is_set(): raise InterruptedError('Dừng ở ranh giới bước denoise; giữ tiến độ cảnh đã xong')
    if step%10==0: log('Denoise bước %d' % step)
    return kwargs

def bao_cao_gpu():
    file = STUDIO / "metrics/gpu.jsonl"
    stages = {}
    if file.exists():
        for line in file.read_text().splitlines():
            row = json.loads(line)
            item = stages.setdefault(row["stage"], {"count":0,"seconds":0.0,"peak_allocated_gb":0.0})
            item["count"] += 1
            item["seconds"] += row["seconds"]
            item["peak_allocated_gb"] = max(item["peak_allocated_gb"], max((g["peak_allocated_gb"] for g in row["gpus"]),default=0))
    return {"gpu_plan":_gpu_plan,"stages":stages,"working_profile":_working_profile,
            "prompt_cache_entries":len(_prompt_cache),"metrics_file":str(file)}

if __name__ == "__main__":
    main()
