import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut as fbSignOut,
  onAuthStateChanged,
  User,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  getDocs,
  setDoc,
  collection,
  query,
  where,
  onSnapshot,
  getDocFromServer,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { FilmProject } from '../types';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Test connection on boot
export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase Firestore is offline. Check configuration.');
    }
    // Return false instead of throwing if test doc doesn't exist
    return false;
  }
}

// Google Sign-In Provider
const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

export async function loginWithGoogle(): Promise<User | null> {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    if (result.user) {
      await syncUserProfile(result.user);
    }
    return result.user;
  } catch (error) {
    console.error('Google Sign-In Error:', error);
    throw error;
  }
}

export async function logoutUser(): Promise<void> {
  await fbSignOut(auth);
}

export interface UserProfileData {
  id: string;
  email: string;
  displayName: string;
  photoURL: string;
  gitaPoints: number;
  role: 'user' | 'filmmaker' | 'director' | 'admin';
  createdAt: string;
  updatedAt: string;
}

export async function syncUserProfile(user: User, additionalPoints = 0): Promise<UserProfileData> {
  const userRef = doc(db, 'users', user.uid);
  try {
    const snap = await getDoc(userRef);
    if (snap.exists()) {
      const data = snap.data() as UserProfileData;
      if (additionalPoints !== 0) {
        const updated = {
          ...data,
          gitaPoints: (data.gitaPoints || 0) + additionalPoints,
          updatedAt: new Date().toISOString(),
        };
        await setDoc(userRef, updated, { merge: true });
        return updated;
      }
      return data;
    } else {
      const isInitialAdmin = user.email === 'typhuquanggita@gmail.com';
      const newProfile: UserProfileData = {
        id: user.uid,
        email: user.email || 'user@gita365.ai',
        displayName: user.displayName || 'Nhà Làm Phim GITA365',
        photoURL: user.photoURL || '',
        gitaPoints: 5000 + additionalPoints,
        role: isInitialAdmin ? 'admin' : 'filmmaker',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      await setDoc(userRef, newProfile);
      return newProfile;
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
  }
}

export async function saveProjectToFirestore(project: FilmProject, userId: string): Promise<void> {
  const docRef = doc(db, 'projects', project.id);
  const payload = {
    ...project,
    userId,
    updatedAt: new Date().toISOString(),
  };
  try {
    await setDoc(docRef, payload, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `projects/${project.id}`);
  }
}

export async function loadUserProjects(userId: string): Promise<FilmProject[]> {
  try {
    const q = query(collection(db, 'projects'), where('userId', '==', userId));
    const snapshot = await getDocs(q);
    const projects: FilmProject[] = [];
    snapshot.forEach((doc) => {
      projects.push(doc.data() as FilmProject);
    });
    return projects;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'projects');
  }
}

export async function saveTranscription(
  id: string,
  userId: string,
  transcript: string,
  projectId?: string
): Promise<void> {
  const docRef = doc(db, 'audioTranscriptions', id);
  try {
    await setDoc(docRef, {
      id,
      userId,
      transcript,
      projectId: projectId || '',
      createdAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `audioTranscriptions/${id}`);
  }
}

export interface CustomerAccount {
  id: string;
  email: string;
  displayName: string;
  photoURL: string;
  gitaPoints: number;
  role: 'user' | 'filmmaker' | 'director' | 'admin';
  subscriptionTier: 'Free' | 'Creator Pro' | 'Studio VIP' | 'Enterprise 4K';
  status: 'active' | 'suspended' | 'trial' | 'pending';
  videoRenderQuota: number;
  videoRendersUsed: number;
  storageUsedGB: number;
  phone?: string;
  company?: string;
  lastActiveAt?: string;
  createdAt: string;
  updatedAt: string;
}

export const INITIAL_DEMO_CUSTOMERS: CustomerAccount[] = [
  {
    id: 'cust_01',
    email: 'nguyen.anh@vfilmstudio.vn',
    displayName: 'Nguyễn Tuấn Anh',
    photoURL: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
    gitaPoints: 18500,
    role: 'director',
    subscriptionTier: 'Enterprise 4K',
    status: 'active',
    videoRenderQuota: 100,
    videoRendersUsed: 64,
    storageUsedGB: 38.4,
    phone: '0912 888 999',
    company: 'V-Film Studio Hà Nội',
    lastActiveAt: 'Vừa xong',
    createdAt: '2026-08-15T08:30:00Z',
    updatedAt: '2026-10-10T02:15:00Z',
  },
  {
    id: 'cust_02',
    email: 'mai.linh@kinhteai.com',
    displayName: 'Trần Mai Linh',
    photoURL: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=150&q=80',
    gitaPoints: 8200,
    role: 'filmmaker',
    subscriptionTier: 'Studio VIP',
    status: 'active',
    videoRenderQuota: 50,
    videoRendersUsed: 31,
    storageUsedGB: 18.2,
    phone: '0988 776 554',
    company: 'Sách Nói Kinh Tế & Video AI',
    lastActiveAt: '15 phút trước',
    createdAt: '2026-09-01T10:00:00Z',
    updatedAt: '2026-10-09T22:40:00Z',
  },
  {
    id: 'cust_03',
    email: 'quoc.bao@saigondigital.vn',
    displayName: 'Lê Quốc Bảo',
    photoURL: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
    gitaPoints: 4200,
    role: 'filmmaker',
    subscriptionTier: 'Creator Pro',
    status: 'active',
    videoRenderQuota: 25,
    videoRendersUsed: 19,
    storageUsedGB: 9.5,
    phone: '0903 112 334',
    company: 'Saigon Creative Labs',
    lastActiveAt: '1 giờ trước',
    createdAt: '2026-09-12T14:20:00Z',
    updatedAt: '2026-10-09T18:05:00Z',
  },
  {
    id: 'cust_04',
    email: 'thanh.tam@vietcreator.com',
    displayName: 'Vũ Thanh Tâm',
    photoURL: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80',
    gitaPoints: 1200,
    role: 'user',
    subscriptionTier: 'Free',
    status: 'trial',
    videoRenderQuota: 5,
    videoRendersUsed: 4,
    storageUsedGB: 2.1,
    phone: '0977 445 667',
    company: 'Kênh TikTok Lịch Sử Việt',
    lastActiveAt: 'Hôm qua',
    createdAt: '2026-10-01T09:10:00Z',
    updatedAt: '2026-10-08T11:22:00Z',
  },
  {
    id: 'cust_05',
    email: 'hoang.minh@cineproduction.com',
    displayName: 'Phạm Hoàng Minh',
    photoURL: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80',
    gitaPoints: 35000,
    role: 'director',
    subscriptionTier: 'Enterprise 4K',
    status: 'active',
    videoRenderQuota: 200,
    videoRendersUsed: 142,
    storageUsedGB: 85.0,
    phone: '0933 667 889',
    company: 'CineX Media Group',
    lastActiveAt: '3 giờ trước',
    createdAt: '2026-07-20T11:00:00Z',
    updatedAt: '2026-10-09T23:00:00Z',
  },
  {
    id: 'cust_06',
    email: 'ngoc.diep@phimtruyen.vn',
    displayName: 'Đoàn Ngọc Diệp',
    photoURL: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80',
    gitaPoints: 200,
    role: 'user',
    subscriptionTier: 'Free',
    status: 'pending',
    videoRenderQuota: 5,
    videoRendersUsed: 1,
    storageUsedGB: 0.6,
    phone: '0919 223 344',
    company: 'Cá nhân tự do',
    lastActiveAt: '3 ngày trước',
    createdAt: '2026-10-06T16:45:00Z',
    updatedAt: '2026-10-06T17:00:00Z',
  },
  {
    id: 'cust_07',
    email: 'violation.acc@spamdomain.net',
    displayName: 'Tài Khoản Tạm Khóa Vi Phạm',
    photoURL: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&q=80',
    gitaPoints: 0,
    role: 'user',
    subscriptionTier: 'Free',
    status: 'suspended',
    videoRenderQuota: 0,
    videoRendersUsed: 0,
    storageUsedGB: 0.1,
    phone: '0900 000 000',
    company: 'Không xác định',
    lastActiveAt: '1 tuần trước',
    createdAt: '2026-09-25T08:00:00Z',
    updatedAt: '2026-10-02T09:00:00Z',
  },
];

export async function fetchAllCustomers(): Promise<CustomerAccount[]> {
  try {
    const snap = await getDocs(collection(db, 'users'));
    if (!snap.empty) {
      const customers: CustomerAccount[] = [];
      snap.forEach((docSnap) => {
        const data = docSnap.data();
        customers.push({
          id: docSnap.id,
          email: data.email || 'user@gita365.ai',
          displayName: data.displayName || 'Nhà làm phim',
          photoURL: data.photoURL || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
          gitaPoints: data.gitaPoints ?? 5000,
          role: data.role || 'user',
          subscriptionTier: data.subscriptionTier || 'Free',
          status: data.status || 'active',
          videoRenderQuota: data.videoRenderQuota ?? 10,
          videoRendersUsed: data.videoRendersUsed ?? 0,
          storageUsedGB: data.storageUsedGB ?? 1.5,
          phone: data.phone || '',
          company: data.company || '',
          lastActiveAt: data.lastActiveAt || 'Vừa xong',
          createdAt: data.createdAt || new Date().toISOString(),
          updatedAt: data.updatedAt || new Date().toISOString(),
        });
      });
      return customers;
    }
  } catch (error) {
    console.warn('Could not fetch from Firestore, returning mock customers for admin view:', error);
  }
  return INITIAL_DEMO_CUSTOMERS;
}

export async function updateCustomerInFirestore(userId: string, updates: Partial<CustomerAccount>): Promise<void> {
  const userRef = doc(db, 'users', userId);
  try {
    await setDoc(userRef, { ...updates, updatedAt: new Date().toISOString() }, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `users/${userId}`);
  }
}

export { onAuthStateChanged };
