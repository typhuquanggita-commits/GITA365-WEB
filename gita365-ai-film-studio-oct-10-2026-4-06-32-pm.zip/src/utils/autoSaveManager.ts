import { FilmProject } from '../types';
import { saveProjectToFirestore } from '../lib/firebase';

export const DRAFT_STORAGE_KEY = 'gita365_film_project_draft_v2';
export const DRAFT_HISTORY_KEY = 'gita365_project_history_v2';
export const DRAFT_AUTOSAVE_TIME_KEY = 'gita365_last_autosave_time_v2';

export interface DraftSnapshot {
  id: string;
  timestamp: string;
  readableTime: string;
  title: string;
  episodesCount: number;
  scenesCount: number;
  charactersCount: number;
  reason: string;
  project: FilmProject;
}

/**
 * Load the active auto-saved draft from localStorage if available
 */
export function getSavedDraft(): FilmProject | null {
  try {
    const raw = localStorage.getItem(DRAFT_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (parsed && parsed.id && parsed.title && parsed.episodes) {
      return parsed as FilmProject;
    }
  } catch (err) {
    console.error('Lỗi khi đọc bản nháp tự động:', err);
  }
  return null;
}

/**
 * Save draft into localStorage and maintain snapshot history
 */
export function saveDraftLocally(project: FilmProject, reason: string = 'Tự động lưu nháp'): void {
  try {
    const serialized = JSON.stringify(project);
    localStorage.setItem(DRAFT_STORAGE_KEY, serialized);
    const now = new Date();
    localStorage.setItem(DRAFT_AUTOSAVE_TIME_KEY, now.toISOString());

    // Record snapshot into history (keep max 10 latest snapshots)
    const history = getDraftHistory();
    const scenesCount = project.episodes.reduce(
      (acc, ep) => acc + ep.acts.reduce((aAcc, act) => aAcc + act.scenes.length, 0),
      0
    );

    // Only add a new snapshot if history is empty or last snapshot was over 2 minutes ago or different major reason
    const lastSnapshot = history[0];
    const isMajorReason = reason.includes('Chuyển thể') || reason.includes('Tạo nhân vật') || reason.includes('Thủ công');
    const timeDiffMs = lastSnapshot ? now.getTime() - new Date(lastSnapshot.timestamp).getTime() : Infinity;

    if (!lastSnapshot || timeDiffMs > 120000 || isMajorReason) {
      const newSnapshot: DraftSnapshot = {
        id: `snap-${Date.now()}`,
        timestamp: now.toISOString(),
        readableTime: now.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        title: project.title,
        episodesCount: project.episodes.length,
        scenesCount,
        charactersCount: project.characters.length,
        reason,
        project,
      };

      const updatedHistory = [newSnapshot, ...history.slice(0, 9)];
      localStorage.setItem(DRAFT_HISTORY_KEY, JSON.stringify(updatedHistory));
    }
  } catch (err) {
    console.error('Lỗi khi lưu bản nháp tự động:', err);
  }
}

/**
 * Get all snapshot history
 */
export function getDraftHistory(): DraftSnapshot[] {
  try {
    const raw = localStorage.getItem(DRAFT_HISTORY_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as DraftSnapshot[];
  } catch {
    return [];
  }
}

/**
 * Clear the local auto-saved draft
 */
export function clearSavedDraft(): void {
  try {
    localStorage.removeItem(DRAFT_STORAGE_KEY);
    localStorage.removeItem(DRAFT_AUTOSAVE_TIME_KEY);
  } catch (err) {
    console.error('Lỗi khi xóa bản nháp:', err);
  }
}

/**
 * Get last saved timestamp formatted
 */
export function getLastSavedTimeFormatted(): string {
  try {
    const raw = localStorage.getItem(DRAFT_AUTOSAVE_TIME_KEY);
    if (!raw) return 'Chưa lưu';
    const date = new Date(raw);
    return date.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  } catch {
    return 'Vừa xong';
  }
}
