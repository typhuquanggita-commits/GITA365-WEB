// Web Audio API cinematic music & sound effects synthesizer
// + Google Gemini Studio 24kHz Vietnamese Text-to-Speech Engine
let audioCtx: AudioContext | null = null;
let currentBgmNodes: { stop: () => void } | null = null;
let currentAudioElement: HTMLAudioElement | null = null;

// Client-side cache for instant playback of generated Vietnamese audio
const clientVoiceCache = new Map<string, string>();

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

export function playBgmSynth(category: string, durationSec = 15): { stop: () => void } {
  if (currentBgmNodes) {
    currentBgmNodes.stop();
    currentBgmNodes = null;
  }

  const ctx = getAudioContext();
  const masterGain = ctx.createGain();
  masterGain.gain.setValueAtTime(0.001, ctx.currentTime);
  masterGain.gain.exponentialRampToValueAtTime(0.3, ctx.currentTime + 1.5);
  masterGain.connect(ctx.destination);

  const oscillators: OscillatorNode[] = [];
  const intervals: number[] = [];

  // Determine root chord frequencies based on category
  let freqs = [130.81, 164.81, 196.0, 246.94]; // C-E-G-B
  let waveType: OscillatorType = 'sine';

  if (category.includes('Asian') || category.includes('Traditional')) {
    // Tibetan / Asian pentatonic scale: D, F, G, A, C
    freqs = [146.83, 174.61, 196.0, 220.0, 261.63];
    waveType = 'sine';
  } else if (category.includes('Epic') || category.includes('Warrior')) {
    // Dramatic D minor chords: D, F, A, D
    freqs = [110.0, 146.83, 174.61, 220.0];
    waveType = 'sawtooth';
  } else if (category.includes('Suspense') || category.includes('Mystery')) {
    // E diminished / suspended
    freqs = [82.41, 123.47, 155.56, 174.61];
    waveType = 'triangle';
  } else if (category.includes('Emotional') || category.includes('Drama')) {
    // A minor melancholic
    freqs = [110.0, 130.81, 164.81, 220.0];
    waveType = 'sine';
  } else if (category.includes('Sci-Fi')) {
    // Cyberpunk synth
    freqs = [98.0, 146.83, 196.0, 293.66];
    waveType = 'sawtooth';
  }

  // Create drone chord
  freqs.forEach((freq, idx) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = waveType;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);

    // slight detune for warmth
    osc.detune.setValueAtTime((idx - 1.5) * 8, ctx.currentTime);

    // lowpass filter for warmth
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(800 + idx * 200, ctx.currentTime);

    gain.gain.setValueAtTime(0.15 / freqs.length, ctx.currentTime);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(masterGain);
    osc.start();
    oscillators.push(osc);
  });

  // Schedule slow arpeggio bell/harp notes
  let noteIndex = 0;
  const arpTimer = window.setInterval(() => {
    if (!audioCtx || audioCtx.state === 'closed') return;
    const now = ctx.currentTime;
    const noteOsc = ctx.createOscillator();
    const noteGain = ctx.createGain();
    const noteFreq = freqs[noteIndex % freqs.length] * 2; // octave up
    noteOsc.type = 'triangle';
    noteOsc.frequency.setValueAtTime(noteFreq, now);

    noteGain.gain.setValueAtTime(0.12, now);
    noteGain.gain.exponentialRampToValueAtTime(0.0001, now + 2.0);

    noteOsc.connect(noteGain);
    noteGain.connect(masterGain);
    noteOsc.start(now);
    noteOsc.stop(now + 2.1);

    noteIndex++;
  }, 1200);

  intervals.push(arpTimer);

  let stopped = false;
  const stop = () => {
    if (stopped) return;
    stopped = true;
    intervals.forEach(clearInterval);
    try {
      const now = ctx.currentTime;
      masterGain.gain.cancelScheduledValues(now);
      masterGain.gain.setValueAtTime(masterGain.gain.value, now);
      masterGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.8);
      setTimeout(() => {
        oscillators.forEach(o => {
          try { o.stop(); } catch {}
        });
      }, 900);
    } catch {}
  };

  currentBgmNodes = { stop };

  // Auto stop when duration expires
  setTimeout(() => {
    if (!stopped) stop();
  }, durationSec * 1000);

  return { stop };
}

export function stopBgmSynth() {
  if (currentBgmNodes) {
    currentBgmNodes.stop();
    currentBgmNodes = null;
  }
}

// Stop any currently playing speech or voiceover
export function stopSpeaking() {
  if (currentAudioElement) {
    try {
      currentAudioElement.pause();
      currentAudioElement.currentTime = 0;
    } catch {}
    currentAudioElement = null;
  }
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

export interface AITTSOptions {
  gender?: 'Nam' | 'Nữ';
  voiceName?: 'Fenrir' | 'Kore' | 'Charon' | 'Zephyr' | 'Puck' | string;
  speakerName?: string;
  style?: string;
  emotion?: string;
  speed?: number;
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (err: any) => void;
}

/**
 * High-Fidelity Studio Vietnamese Text-to-Speech (V-TTS).
 * Calls Gemini TTS server-side engine (gemini-3.8-flash-lite-tts) for 24kHz crystal clear audio.
 * Never uses broken English fallback to pronounce Vietnamese text.
 */
export async function speakText(
  text: string,
  voiceGender: 'Nam' | 'Nữ' | string = 'Nam',
  lang = 'vi-VN',
  onEnd?: () => void
): Promise<void> {
  const gender: 'Nam' | 'Nữ' = voiceGender === 'Nữ' ? 'Nữ' : 'Nam';
  return speakWithGeminiTTS(text, { gender, onEnd });
}

export async function generateDialogueAudio(
  text: string,
  options: {
    voiceName?: string;
    gender?: 'Nam' | 'Nữ';
    speakerName?: string;
    emotion?: string;
    speed?: number;
    style?: string;
  } = {}
): Promise<{ success: boolean; audioUrl?: string; audioBase64?: string; error?: string }> {
  const {
    gender = 'Nam',
    voiceName,
    speakerName,
    emotion,
    speed = 1.0,
    style,
  } = options;

  if (!text || !text.trim()) {
    return { success: false, error: 'Văn bản trống' };
  }

  let resolvedVoice = voiceName;
  if (!resolvedVoice) {
    if (gender === 'Nữ' || speakerName?.includes('Nữ') || speakerName?.includes('MC')) {
      resolvedVoice = speakerName?.includes('Vy') || speakerName?.includes('Linh') ? 'Zephyr' : 'Kore';
    } else {
      resolvedVoice = speakerName?.includes('Spalding') || speakerName?.includes('Chơn') ? 'Charon' : 'Fenrir';
    }
  }

  const cacheKey = `${text.trim()}__${resolvedVoice}__${emotion || 'normal'}__${speed || 1}__${style || 'default'}`;

  if (clientVoiceCache.has(cacheKey)) {
    const audioDataUrl = clientVoiceCache.get(cacheKey)!;
    return { success: true, audioUrl: audioDataUrl };
  }

  try {
    const response = await fetch('/api/tts', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        text: text.trim(),
        voiceName: resolvedVoice,
        gender,
        speakerName,
        style,
        emotion,
        speed,
      }),
    });

    const data = await response.json();
    if (data.success && data.audioBase64) {
      const audioDataUrl = `data:audio/wav;base64,${data.audioBase64}`;
      clientVoiceCache.set(cacheKey, audioDataUrl);
      return { success: true, audioUrl: audioDataUrl, audioBase64: data.audioBase64 };
    }
    return { success: false, error: data.error || 'Không tạo được âm thanh' };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

export async function speakWithGeminiTTS(
  text: string,
  options: AITTSOptions = {}
): Promise<void> {
  const {
    gender = 'Nam',
    voiceName,
    speakerName,
    style,
    emotion,
    speed = 1.0,
    onStart,
    onEnd,
    onError,
  } = options;

  if (!text || !text.trim()) {
    if (onEnd) onEnd();
    return;
  }

  stopSpeaking();
  if (onStart) onStart();

  // Determine Gemini prebuilt voice
  let resolvedVoice = voiceName;
  if (!resolvedVoice) {
    if (gender === 'Nữ' || speakerName?.includes('Nữ') || speakerName?.includes('MC')) {
      resolvedVoice = speakerName?.includes('Vy') || speakerName?.includes('Linh') ? 'Zephyr' : 'Kore';
    } else {
      resolvedVoice = speakerName?.includes('Spalding') || speakerName?.includes('Chơn') ? 'Charon' : 'Fenrir';
    }
  }

  const cacheKey = `${text.trim()}__${resolvedVoice}__${emotion || 'normal'}__${speed || 1}__${style || 'default'}`;

  // 1. Play from client cache if already generated
  if (clientVoiceCache.has(cacheKey)) {
    const audioDataUrl = clientVoiceCache.get(cacheKey)!;
    playAudioUrl(audioDataUrl, onEnd, onError);
    return;
  }

  // 2. Fetch from Gemini TTS Server API
  try {
    const response = await fetch('/api/tts', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        text: text.trim(),
        voiceName: resolvedVoice,
        gender,
        speakerName,
        style,
        emotion,
        speed,
      }),
    });

    const data = await response.json();

    if (data.success && data.audioBase64) {
      const audioDataUrl = `data:audio/wav;base64,${data.audioBase64}`;
      clientVoiceCache.set(cacheKey, audioDataUrl);
      playAudioUrl(audioDataUrl, onEnd, onError);
      return;
    }
  } catch (err: any) {
    console.warn('Server TTS fetch notice, checking local voice options:', err.message);
  }

  // 3. Fallback: ONLY use window.speechSynthesis IF a genuine Vietnamese voice exists in the browser!
  // If no Vietnamese voice is installed (e.g. only English voices exist), DO NOT speak,
  // because English pronouncing Vietnamese produces 100% broken phonetic gibberish.
  if ('speechSynthesis' in window) {
    const voices = window.speechSynthesis.getVoices();
    const trueVietnameseVoice = voices.find(
      (v) => v.lang.toLowerCase().startsWith('vi') || v.name.toLowerCase().includes('vietnam')
    );

    if (trueVietnameseVoice) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.voice = trueVietnameseVoice;
      utterance.lang = 'vi-VN';
      utterance.rate = 1.0;
      utterance.pitch = gender === 'Nam' ? 0.95 : 1.1;

      utterance.onend = () => {
        if (onEnd) onEnd();
      };
      utterance.onerror = () => {
        if (onEnd) onEnd();
      };
      window.speechSynthesis.speak(utterance);
      return;
    }
  }

  // If no genuine Vietnamese voice is available, safely complete
  if (onEnd) onEnd();
}

export function playAudioUrl(url: string, onEnd?: () => void, onError?: (err: any) => void) {
  try {
    const audio = new Audio(url);
    currentAudioElement = audio;

    audio.onended = () => {
      currentAudioElement = null;
      if (onEnd) onEnd();
    };

    audio.onerror = (e) => {
      currentAudioElement = null;
      if (onError) onError(e);
      if (onEnd) onEnd();
    };

    audio.play().catch((err) => {
      console.warn('Audio play request notice:', err.message);
      if (onEnd) onEnd();
    });
  } catch (err) {
    if (onEnd) onEnd();
  }
}

export function playSpeechSample(text: string, voiceName?: string, onEnd?: () => void) {
  const isFemale = voiceName && (
    voiceName.includes('Nữ') ||
    voiceName.includes('MC') ||
    voiceName.includes('Vy') ||
    voiceName.includes('Linh') ||
    voiceName.includes('Thảo') ||
    voiceName.includes('My') ||
    voiceName.includes('Trinh') ||
    voiceName.includes('Hằng') ||
    voiceName.includes('Phương') ||
    voiceName.includes('Uyên') ||
    voiceName.includes('Anh') ||
    voiceName.includes('Kore') ||
    voiceName.includes('Zephyr')
  );

  const gender: 'Nam' | 'Nữ' = isFemale ? 'Nữ' : 'Nam';
  const prebuilt = isFemale ? 'Kore' : 'Fenrir';

  speakWithGeminiTTS(text, {
    gender,
    voiceName: prebuilt,
    speakerName: voiceName,
    onEnd,
  });
}
