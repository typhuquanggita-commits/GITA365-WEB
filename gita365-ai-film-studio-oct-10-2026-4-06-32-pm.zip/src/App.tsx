import React, { useState } from 'react';
import { FilmProject } from './types';
import { SAMPLE_PROJECT } from './data/initialData';
import { Navbar } from './components/Navbar';
import { BookToScriptView } from './components/BookToScriptView';
import { CharacterConsistencyView } from './components/CharacterConsistencyView';
import { VideoStudioView } from './components/VideoStudioView';
import { AudioVoiceView } from './components/AudioVoiceView';
import { ThumbnailSubtitleView } from './components/ThumbnailSubtitleView';
import { SchedulerView } from './components/SchedulerView';
import { AnalyticsTrendsView } from './components/AnalyticsTrendsView';
import { WebToVideoView } from './components/WebToVideoView';
import { TeamLeaderboardView } from './components/TeamLeaderboardView';
import { PricingLoyaltyView } from './components/PricingLoyaltyView';
import { PresentersAndCastView } from './components/PresentersAndCastView';
import { CustomerAdminView } from './components/CustomerAdminView';
import { PhotoToVideoStudioView } from './components/PhotoToVideoStudioView';
import { RenderModal } from './components/RenderModal';
import { AICopilotDrawer } from './components/AICopilotDrawer';
import { Bot, Sparkles, Film, Heart } from 'lucide-react';
import {
  auth,
  loginWithGoogle,
  logoutUser,
  onAuthStateChanged,
  testConnection,
  saveProjectToFirestore,
} from './lib/firebase';
import { useEffect, useRef } from 'react';
import { DraftHistoryModal } from './components/DraftHistoryModal';
import {
  getSavedDraft,
  saveDraftLocally,
  clearSavedDraft,
  getLastSavedTimeFormatted,
} from './utils/autoSaveManager';

export default function App() {
  const [project, setProject] = useState<FilmProject>(() => {
    const saved = getSavedDraft();
    if (saved) return saved;
    return SAMPLE_PROJECT;
  });
  const [activeTab, setActiveTab] = useState<string>('script');
  const [isRenderModalOpen, setIsRenderModalOpen] = useState(false);
  const [isCopilotOpen, setIsCopilotOpen] = useState(false);
  const [isDraftModalOpen, setIsDraftModalOpen] = useState(false);
  const [gitaPoints, setGitaPoints] = useState(5420);
  const [currentUser, setCurrentUser] = useState<any>(null);

  // Auto-Save Real-time Status
  const [autoSaveStatus, setAutoSaveStatus] = useState<'saved' | 'saving' | 'synced_cloud'>('saved');
  const [lastSavedTime, setLastSavedTime] = useState<string>(() => getLastSavedTimeFormatted());
  const [draftToast, setDraftToast] = useState<string | null>(null);
  const isFirstRender = useRef(true);

  useEffect(() => {
    // Validate Firestore connection on boot per Firebase skill guidelines
    testConnection().catch((err) => console.warn('Firestore boot test note:', err));

    // Listen to Firebase auth
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
    });

    // Check if auto-saved draft was loaded from previous session
    const saved = getSavedDraft();
    if (saved && saved.updatedAt) {
      setDraftToast(`Đã tự động khôi phục bản nháp kịch bản gần nhất (Auto-Save) lúc ${getLastSavedTimeFormatted()}! Dữ liệu của bạn được bảo toàn.`);
      setTimeout(() => setDraftToast(null), 5000);
    }

    return () => unsubscribe();
  }, []);

  // Debounced Auto-Save effect whenever project or user changes
  useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false;
      return;
    }

    setAutoSaveStatus('saving');
    const timer = setTimeout(async () => {
      saveDraftLocally(project, 'Tự động lưu nháp thay đổi kịch bản / phân cảnh');
      const timeStr = getLastSavedTimeFormatted();
      setLastSavedTime(timeStr);
      setAutoSaveStatus('saved');

      // If user is logged into Firebase, sync to Firestore in background
      if (currentUser?.uid) {
        try {
          await saveProjectToFirestore(project, currentUser.uid);
          setAutoSaveStatus('synced_cloud');
        } catch (err) {
          console.warn('Firestore background auto-sync note:', err);
        }
      }
    }, 800);

    return () => clearTimeout(timer);
  }, [project, currentUser]);

  const handleLogin = async () => {
    try {
      const user = await loginWithGoogle();
      setCurrentUser(user);
    } catch (e: any) {
      console.error('Login error:', e);
    }
  };

  const handleLogout = async () => {
    try {
      await logoutUser();
      setCurrentUser(null);
    } catch (e: any) {
      console.error('Logout error:', e);
    }
  };

  const handleAddPoints = (pts: number) => {
    setGitaPoints((prev) => prev + pts);
  };

  const handleManualSaveFirestore = async () => {
    if (!currentUser?.uid) {
      handleLogin();
      return;
    }
    setAutoSaveStatus('saving');
    try {
      await saveProjectToFirestore(project, currentUser.uid);
      setAutoSaveStatus('synced_cloud');
      setDraftToast('Đã lưu thành công dự án lên Đám mây Firestore!');
      setTimeout(() => setDraftToast(null), 3500);
    } catch (e) {
      console.error(e);
      setAutoSaveStatus('saved');
    }
  };

  const handleResetToSample = () => {
    clearSavedDraft();
    setProject(SAMPLE_PROJECT);
    setLastSavedTime('Vừa xong');
    setAutoSaveStatus('saved');
    setDraftToast('Đã đặt lại dự án về kịch bản mẫu ban đầu.');
    setTimeout(() => setDraftToast(null), 3500);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* Top Auto-Save Notification Toast */}
      {draftToast && (
        <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white px-4 py-2.5 text-xs font-bold flex items-center justify-between border-b border-emerald-400/30 animate-in fade-in">
          <div className="max-w-7xl mx-auto w-full flex items-center justify-between">
            <span className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-300 animate-ping" />
              {draftToast}
            </span>
            <button
              onClick={() => setDraftToast(null)}
              className="text-white/80 hover:text-white text-xs font-bold ml-4"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Top Navbar */}
      <Navbar
        currentProject={project}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenRenderModal={() => setIsRenderModalOpen(true)}
        onToggleCopilot={() => setIsCopilotOpen(!isCopilotOpen)}
        isCopilotOpen={isCopilotOpen}
        gitaPoints={gitaPoints}
        currentUser={currentUser}
        onLogin={handleLogin}
        onLogout={handleLogout}
        autoSaveStatus={autoSaveStatus}
        lastSavedTime={lastSavedTime}
        onOpenDraftModal={() => setIsDraftModalOpen(true)}
        onManualSaveFirestore={handleManualSaveFirestore}
      />

      {/* Main Content View Switcher */}
      <main className="flex-1 pb-16">
        {activeTab === 'script' && (
          <BookToScriptView
            project={project}
            onUpdateProject={setProject}
            onNavigateToStudio={() => setActiveTab('studio')}
          />
        )}

        {activeTab === 'character' && (
          <CharacterConsistencyView project={project} onUpdateProject={setProject} />
        )}

        {activeTab === 'studio' && (
          <VideoStudioView
            project={project}
            onUpdateProject={setProject}
            onOpenRenderModal={() => setIsRenderModalOpen(true)}
          />
        )}

        {activeTab === 'audio' && (
          <AudioVoiceView project={project} onUpdateProject={setProject} />
        )}

        {activeTab === 'thumbnail' && (
          <ThumbnailSubtitleView project={project} onUpdateProject={setProject} />
        )}

        {activeTab === 'scheduler' && (
          <SchedulerView project={project} onUpdateProject={setProject} />
        )}

        {activeTab === 'analytics' && <AnalyticsTrendsView project={project} />}

        {activeTab === 'webtovideo' && (
          <WebToVideoView
            project={project}
            onNavigateToStudio={() => setActiveTab('studio')}
          />
        )}

        {activeTab === 'team' && <TeamLeaderboardView project={project} />}

        {activeTab === 'pricing' && (
          <PricingLoyaltyView currentPoints={gitaPoints} onAddPoints={handleAddPoints} />
        )}

        {activeTab === 'presenters' && (
          <PresentersAndCastView
            project={project}
            onUpdateProject={setProject}
            onNavigateToStudio={() => setActiveTab('studio')}
          />
        )}

        {activeTab === 'admin' && (
          <CustomerAdminView
            currentAdminEmail={currentUser?.email || 'typhuquanggita@gmail.com'}
          />
        )}

        {activeTab === 'photo2video' && (
          <PhotoToVideoStudioView
            project={project}
            onUpdateProject={setProject}
            onNavigateToStudio={() => setActiveTab('studio')}
          />
        )}
      </main>

      {/* 4K Render Engine Modal */}
      <RenderModal
        isOpen={isRenderModalOpen}
        onClose={() => setIsRenderModalOpen(false)}
        project={project}
        onNavigateToScheduler={() => {
          setIsRenderModalOpen(false);
          setActiveTab('scheduler');
        }}
      />

      {/* Auto-Save Draft & Version History Modal */}
      <DraftHistoryModal
        isOpen={isDraftModalOpen}
        onClose={() => setIsDraftModalOpen(false)}
        currentProject={project}
        onRestoreProject={(restored) => {
          setProject(restored);
          setDraftToast(`Đã khôi phục thành công dự án: ${restored.title}`);
          setTimeout(() => setDraftToast(null), 3500);
        }}
        onResetToSample={handleResetToSample}
        currentUser={currentUser}
        lastSavedTime={lastSavedTime}
      />

      {/* Floating AI Studio Copilot Chatbot */}
      <AICopilotDrawer
        isOpen={isCopilotOpen}
        onClose={() => setIsCopilotOpen(false)}
        project={project}
      />

      {/* Floating Action Button for Copilot when closed */}
      {!isCopilotOpen && (
        <button
          onClick={() => setIsCopilotOpen(true)}
          className="fixed bottom-6 right-6 z-40 p-3.5 rounded-full bg-gradient-to-r from-purple-600 to-amber-500 hover:brightness-110 text-white shadow-2xl shadow-purple-600/40 flex items-center gap-2 group transition-all transform hover:scale-105"
          title="Mở Trợ lý AI Xưởng Phim GITA365"
        >
          <Bot className="w-5 h-5" />
          <span className="text-xs font-bold pr-1 hidden sm:inline">Hỏi AI Studio</span>
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping absolute -top-0.5 -right-0.5" />
        </button>
      )}

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/90 py-8 px-4 text-center text-xs text-slate-500 space-y-2">
        <div className="flex items-center justify-center gap-2 text-slate-400 font-semibold">
          <Film className="w-4 h-4 text-amber-400" />
          <span>Hệ Thống Xưởng Phim Điện Ảnh AI GITA365</span>
          <span>•</span>
          <span className="text-amber-400">GITA365 Cinematic Cloud Suite</span>
        </div>
        <p className="max-w-xl mx-auto text-[11px] text-slate-500">
          Nền tảng chuyển thể kịch bản sách thành phim tập 10-30 phút, đồng bộ nhân vật nhất quán,
          lồng tiếng AI đa ngôn ngữ, render 4K siêu tốc và tự động hóa xuất bản đa nền tảng.
        </p>
        <div className="text-[10px] text-slate-600 pt-2">
          © 2026 GITA365 Ecosystem. All Rights Reserved. Bảo lưu mọi quyền thương mại.
        </div>
      </footer>
    </div>
  );
}
