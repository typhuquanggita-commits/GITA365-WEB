export type VideoFormat = '16:9' | '9:16' | '1:1';

export interface DialogueItem {
  id: string;
  speaker: string;
  emotion: string;
  text: string;
  audioUrl?: string;
  durationSeconds?: number;
  speed?: number; // e.g., 0.75 to 1.5
  voiceName?: string; // e.g., 'Fenrir' | 'Kore' | 'Zephyr' | 'Charon'
  pitch?: number;
  isSynthesized?: boolean;
}

export interface Scene {
  id: string;
  sceneNumber: number;
  title?: string;
  location: string;
  timeOfDay: string;
  lighting: string;
  cameraAngle: string;
  description: string;
  visualPrompt: string;
  dialogue: DialogueItem[];
  sfx: string;
  bgmMood: string;
  durationSeconds: number;
  imageUrl?: string;
  videoPreviewUrl?: string;
  transition?: 'cut' | 'fade' | 'dissolve' | 'wipe' | 'zoom';
}

export interface Act {
  actNumber: number;
  name: string;
  scenes: Scene[];
}

export interface Episode {
  id: string;
  episodeNumber: number;
  title: string;
  durationMinutes: number;
  synopsis: string;
  acts: Act[];
  thumbnailUrl?: string;
}

export interface CharacterVoiceProfile {
  gender: 'Nam' | 'Nữ';
  accent: string;
  tone: string;
  speed: number;
  pitch?: number;
  voiceName?: string;
}

export interface CharacterPhysicalTraits {
  face: string;
  hair: string;
  eyes: string;
  attire: string;
  distinguishingMarks: string;
}

export interface Character {
  id: string;
  name: string;
  role: 'Protagonist' | 'Antagonist' | 'Mentor' | 'Supporting' | 'Narrator';
  age: string;
  archetype: string;
  physicalTraits: CharacterPhysicalTraits;
  voiceProfile: CharacterVoiceProfile;
  consistencyKeyPrompt: string;
  scenePromptVariations?: { sceneType: string; prompt: string }[];
  avatarUrl: string;
  consistencyScore: number;
}

export interface FilmProject {
  id: string;
  title: string;
  originalBook: string;
  author: string;
  genre: string;
  targetAudience: string;
  visualStyle: string;
  aspectRatio: VideoFormat;
  resolution: '1080p' | '4K UHD' | '720p';
  episodeCount: number;
  episodeDurationMinutes: number;
  episodes: Episode[];
  characters: Character[];
  createdAt: string;
  updatedAt: string;
}

export interface BgmTrack {
  id: string;
  title: string;
  category: 'Cinematic Epic' | 'Emotional Drama' | 'Suspense Mystery' | 'Inspirational' | 'Traditional Asian' | 'Cyberpunk Sci-Fi';
  duration: string;
  durationSec: number;
  bpm: number;
  license: string;
  audioPreviewNote: string;
}

export interface VoicePreset {
  id: string;
  name: string;
  lang: string;
  accent: string;
  gender: 'Nam' | 'Nữ';
  sampleText: string;
  tag: string;
  avatar: string;
}

export interface ScheduledPost {
  id: string;
  episodeId: string;
  videoTitle: string;
  thumbnail: string;
  platforms: ('youtube' | 'tiktok' | 'facebook')[];
  scheduledDate: string; // ISO string or format
  scheduledTime: string; // HH:mm
  status: 'draft' | 'scheduled' | 'published';
  tags: string[];
  description: string;
  stats?: {
    views: number;
    likes: number;
    comments: number;
    shares: number;
  };
}

export interface TeamMember {
  id: string;
  name: string;
  role: 'Tổng Đạo Diễn' | 'Biên Kịch Trưởng' | 'Họa Sĩ Concept' | 'Kỹ Sư Âm Thanh' | 'Dựng Phim';
  avatar: string;
  status: 'online' | 'editing' | 'idle';
  currentActivity: string;
}

export interface PricingPlan {
  id: string;
  name: string;
  badge?: string;
  priceMonthly: number;
  priceYearly: number;
  description: string;
  features: string[];
  recommended?: boolean;
  renderSpeed: string;
  cloudStorage: string;
  maxResolution: string;
}

export interface LoyaltyTier {
  id: string;
  name: string;
  minPoints: number;
  badgeColor: string;
  discountRender: string;
  perks: string[];
}

export interface LeaderboardFilm {
  rank: number;
  id: string;
  title: string;
  director: string;
  basedOnBook: string;
  views: number;
  likes: number;
  episodes: number;
  badge: string;
  award: string;
  posterUrl: string;
}

export interface VideoAnalytics {
  totalViews: number;
  watchTimeHours: number;
  retentionRate: number;
  ctr: number;
  estimatedRevenueVND: number;
  dailyGrowth: { date: string; views: number; watchHours: number }[];
  platformDistribution: { platform: string; share: number; views: number; color: string }[];
  topRetentionMoments: { timestamp: string; label: string; retention: number }[];
}

export interface SubtitleLine {
  id: string;
  startTime: string; // 00:00:05,000
  endTime: string;
  text: string;
  speaker?: string;
  language: string;
}

export interface TrainerPose {
  id: string;
  title: string;
  setting: string;
  attire: string;
  description: string;
  tag: string;
  screenContent: string;
  imageUrl: string;
  aiPrompt: string;
  hasInteractiveScreen?: boolean;
}

export interface GitaMC {
  id: string;
  name: string;
  suitColor: string;
  suitHex: string;
  role: string;
  category: string;
  voiceStyle: string;
  description: string;
  studioPose: string;
  imageUrl: string;
  aiPrompt: string;
  badge?: string;
}

export type VIPTierLevel = 'standard' | 'pro' | 'vip_cinema' | 'vip_hollywood';

export interface VIPTierConfig {
  id: VIPTierLevel;
  name: string;
  badge: string;
  resolution: string;
  fps: number;
  description: string;
  visualFidelity: string;
  voiceQuality: string;
  motionFlow: string;
  recommendedDuration: number; // 1, 2, or 3 min
  rawComputeCostUSD: number;
  gitaMarginUSD: number; // strictly 0.10 USD
  finalPriceUSD: number;
  finalPriceVND: number;
  features: string[];
}

export interface IndustryPromptTemplate {
  id: string;
  name: string;
  icon: string;
  category: string;
  recommendedDuration: 1 | 2 | 3;
  suggestedAudience: string;
  hookTemplate: string;
  coreMessagePlaceholder: string;
  ctaTemplate: string;
  samplePhotoUrl: string;
  samplePhotoDesc: string;
  defaultDirectorSettings: {
    cameraMotion: string;
    lightingVibe: string;
    colorGrading: string;
    pacing: string;
    storyFormula: string;
    voiceTone: string;
  };
}

export interface PhotoToVideoRequest {
  photoUrl: string;
  photoTitle?: string;
  industryId: string;
  userSkillLevel: 'beginner' | 'director_pro';
  targetAudience: string;
  coreMessage: string;
  callToAction: string;
  durationMinutes: 1 | 2 | 3;
  aspectRatio: VideoFormat;
  vipTier: VIPTierLevel;
  directorSettings?: {
    cameraMotion: string;
    lightingVibe: string;
    colorGrading: string;
    pacing: string;
    storyFormula: string;
    voiceTone: string;
  };
}

export interface PhotoToVideoProductionResult {
  title: string;
  synopsis: string;
  hookScript: string;
  durationMinutes: number;
  totalDurationSeconds: number;
  industryName: string;
  vipTier: VIPTierLevel;
  vipTierName: string;
  aspectRatio: VideoFormat;
  anchorPhotoUrl: string;
  scenes: Scene[];
  recommendedBgm: string;
  voiceTone: string;
  pricingBreakdown: {
    rawComputeCostUSD: number;
    gitaMarginUSD: number; // fixed 0.1 USD
    finalPriceUSD: number;
    finalPriceVND: number;
    costItems: Array<{
      label: string;
      amountUSD: number;
      desc: string;
    }>;
  };
}

export type MVTierLevel = 'mv_indie_2k' | 'mv_pro_4k' | 'mv_hollywood_cinema';

export interface MVTierConfig {
  id: MVTierLevel;
  name: string;
  badge: string;
  resolution: string;
  durationMinutes: number;
  scenesCount: number;
  fps: number;
  description: string;
  stageLocationsCount: number;
  hasDancerCrowd: boolean;
  hasLiveBand: boolean;
  lipSyncFidelity: string;
  rawComputeCostUSD: number;
  gitaMarginUSD: number; // strictly 0.50 USD
  finalPriceUSD: number;
  finalPriceVND: number;
  features: string[];
}

export interface MVStageSettings {
  hasBackupDancers: boolean;
  dancersChoreography: 'kpop_synchronized' | 'circle_singer' | 'freestyle_hype' | 'backing_vocal_group';
  hasLiveBand: boolean;
  bandType: 'rock_pop_ensemble' | 'acoustic_trio' | 'philharmonic_orchestra' | 'electronic_dj_decks';
  lipSyncAccuracy: 'standard' | 'high_precision_phoneme';
  spaceLocations: string[];
}

export interface MVProductionRequest {
  songTitle: string;
  artistName: string;
  singerPhotoUrl: string;
  lyrics: string;
  musicMode: 'upload' | 'ai_generate';
  audioUrl?: string;
  genre: 'vpop' | 'kpop' | 'ballad' | 'edm' | 'rnb' | 'hiphop' | 'bolero' | 'rock';
  stageSettings: MVStageSettings;
  vipTier: MVTierLevel;
}

export interface MVProductionResult {
  id: string;
  title: string;
  artistName: string;
  genreName: string;
  durationMinutes: number;
  totalDurationSeconds: number;
  audioTrackUrl: string;
  anchorSingerPhoto: string;
  stageLocations: string[];
  scenes: Scene[];
  stageChoreographyNotes: string;
  lipSyncReport: {
    phonemeSyncRate: number; // e.g. 98.7%
    tempoBPM: number;
    beatDropCount: number;
  };
  pricingBreakdown: {
    rawComputeCostUSD: number;
    gitaMarginUSD: number; // strictly 0.50 USD
    finalPriceUSD: number;
    finalPriceVND: number;
    costItems: Array<{
      label: string;
      amountUSD: number;
      desc: string;
    }>;
  };
  commercialRights: {
    youtubeMonetizationReady: boolean;
    tiktokCommercialLicense: boolean;
    contentIdProtected: boolean;
    licenseCode: string;
  };
}

export interface MVRevenueAnalytics {
  totalActiveMVs: number;
  netEarningsUSD: number;
  netEarningsVND: number;
  activeCreatorUsers: number;
  predictedMonthlyRevenueUSD: number;
  predictedMonthlyRevenueVND: number;
  growthRatePercent: number;
  monthlyHistory: Array<{
    month: string;
    projectsCount: number;
    netProfitUSD: number;
    activeUsers: number;
  }>;
  genreBreakdown: Array<{
    genre: string;
    count: number;
    share: number;
    color: string;
  }>;
  recentMVs: Array<{
    id: string;
    title: string;
    artist: string;
    genre: string;
    date: string;
    vipTier: string;
    feeUSD: number;
    netProfitUSD: number; // 0.50 USD
    viewsEst: number;
    status: 'monetized' | 'rendering' | 'ready';
  }>;
}


