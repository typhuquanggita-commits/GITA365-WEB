import { MVTierConfig, MVRevenueAnalytics } from '../types';

export const MV_TIER_CONFIGS: Record<string, MVTierConfig> = {
  mv_indie_2k: {
    id: 'mv_indie_2k',
    name: 'Gói MV Indie Nghệ Sĩ Trẻ (2K QHD)',
    badge: 'Khởi Đầu Tối Ưu',
    resolution: '2K QHD (1440p)',
    durationMinutes: 2.5,
    scenesCount: 8,
    fps: 30,
    description: 'Chất lượng MV chuẩn phát hành YouTube/TikTok: 8 bối cảnh nghệ thuật, đồng bộ khẩu hình Lip-sync cơ bản, vũ đoàn 4 vũ công hỗ trợ.',
    stageLocationsCount: 8,
    hasDancerCrowd: true,
    hasLiveBand: false,
    lipSyncFidelity: 'Phoneme Matching 94% tự nhiên',
    rawComputeCostUSD: 2.40,
    gitaMarginUSD: 0.50, // Strictly 0.50 USD as requested
    finalPriceUSD: 2.90, // 2.40 + 0.50 = 2.90 USD
    finalPriceVND: 72500, // ~ 72.500 VNĐ
    features: [
      'Độ phân giải 2K QHD sắc nét',
      '8 Bối cảnh không gian luân chuyển linh hoạt',
      'Khớp khẩu hình (Lip-sync) theo lời hát',
      'Vũ đoàn 4 vũ công nhảy bè phụ họa',
      'Nhạc nền AI chất lượng cao hoặc Tải nhạc riêng',
      'Bản quyền thương mại kiếm tiền YouTube/TikTok',
      'Lợi nhuận GITA365 minh bạch: Đúng 0.5 USD (~12.500đ)',
    ],
  },
  mv_pro_4k: {
    id: 'mv_pro_4k',
    name: 'Gói MV Sân Khấu Triệu Đô (4K UHD 60fps)',
    badge: 'Khuyên Dùng Cho Ca Sĩ Chuyên Nghiệp',
    resolution: '4K UHD (2160p) 60 FPS',
    durationMinutes: 3.5,
    scenesCount: 12,
    fps: 60,
    description: 'Quy mô sân khấu concert đẳng cấp: 12 bối cảnh triệu đô, vũ đoàn K-Pop 8 người nhảy đồng bộ, Ban nhạc sống (Trống, Guitar, Bass, Keys) biểu diễn cùng, Lip-sync chuẩn từng âm sắc.',
    stageLocationsCount: 12,
    hasDancerCrowd: true,
    hasLiveBand: true,
    lipSyncFidelity: 'Deep-Phoneme Lip-sync 98.5% chuẩn rạp',
    rawComputeCostUSD: 3.90,
    gitaMarginUSD: 0.50, // Strictly 0.50 USD
    finalPriceUSD: 4.40, // 3.90 + 0.50 = 4.40 USD
    finalPriceVND: 110000, // ~ 110.000 VNĐ
    features: [
      'Độ phân giải 4K UHD 60 FPS mượt mà đỉnh cao',
      '12 Bối cảnh không gian concert & visual nghệ thuật',
      'Đồng bộ vũ đạo K-Pop 8 người bao quanh ca sĩ',
      'Ban nhạc sống Rock/Pop Band 4 người chơi cùng',
      'Ánh sáng sân khấu Moving Head & Laser 3D',
      'Hiệu ứng khói lửa Pyro & pháo hoa rực rỡ',
      'Xuất bản quyền sạch Content ID kiếm tiền đa nền tảng',
      'Lợi nhuận GITA365 minh bạch: Đúng 0.5 USD (~12.500đ)',
    ],
  },
  mv_hollywood_cinema: {
    id: 'mv_hollywood_cinema',
    name: 'Gói MV Bom Tấn Hollywood (Master Cinema 4K)',
    badge: 'Đẳng Cấp Tinh Hoa Siêu Sao',
    resolution: '4K DCI Hollywood Cinema Master',
    durationMinutes: 4.5,
    scenesCount: 16,
    fps: 60,
    description: 'Tuyệt tác MV như quay của các siêu sao quốc tế: 16 đại cảnh kỳ vĩ, Đại vũ đoàn 16 vũ công, Dàn nhạc giao hưởng hoành tráng hoặc Rock Arena, CGI kỹ xảo điện ảnh đỉnh cao.',
    stageLocationsCount: 16,
    hasDancerCrowd: true,
    hasLiveBand: true,
    lipSyncFidelity: 'Hollywood Micro-expression Lip-sync 99.8%',
    rawComputeCostUSD: 5.90,
    gitaMarginUSD: 0.50, // Strictly 0.50 USD
    finalPriceUSD: 6.40, // 5.90 + 0.50 = 6.40 USD
    finalPriceVND: 160000, // ~ 160.000 VNĐ
    features: [
      'Độ phân giải 4K DCI Hollywood Master Film Grain',
      '16 Đại cảnh không gian điện ảnh triệu đô',
      'Đại vũ đoàn 16 vũ công nhảy đồng đều hoặc hát bè',
      'Dàn nhạc giao hưởng Philharmonic hoặc Mega Rock Band',
      'Kỹ xảo CGI thời tiết thực (Mưa đêm neon, bão tuyết, pháo hoa)',
      'Hòa âm Dolby Atmos 5.1 Spatial Audio cho MV',
      'Gói chứng nhận bản quyền quốc tế thương mại 100%',
      'Lợi nhuận GITA365 minh bạch: Đúng 0.5 USD (~12.500đ)',
    ],
  },
};

export const MV_STAGE_LOCATIONS = [
  {
    id: 'stadium-concert',
    name: 'Sân Khấu Concert 50.000 Khán Giả',
    category: 'Sân khấu lớn',
    desc: 'Hàng vạn khán giả vẫy lightstick, dàn đèn beam laser quét trời, pháo hoa rực rỡ',
    imageUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=800&auto=format&fit=crop&q=80',
  },
  {
    id: 'cyberpunk-neon-stage',
    name: 'Phim Trường LED Neon Cyberpunk',
    category: 'Hiện đại & Tương lai',
    desc: 'Bức tường LED vô cực, ánh sáng neon tím xanh rực rỡ, sàn kính phản chiếu hologram',
    imageUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&auto=format&fit=crop&q=80',
  },
  {
    id: 'royal-palace',
    name: 'Cung Điện Châu Âu Hoàng Gia Baroque',
    category: 'Sang trọng & Cổ điển',
    desc: 'Đèn chùm pha lê khổng lồ, cột đá cẩm thạch mạ vàng, không gian dạ vũ quý tộc',
    imageUrl: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?w=800&auto=format&fit=crop&q=80',
  },
  {
    id: 'sunset-beach',
    name: 'Bãi Biển Hoàng Hôn & Lửa Trại Lãng Mạn',
    category: 'Thiên nhiên lãng mạn',
    desc: 'Sóng biển vỗ bờ cát vàng lúc hoàng hôn rực lửa, ánh lửa trại bập bùng thi vị',
    imageUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80',
  },
  {
    id: 'rainy-neon-street',
    name: 'Đường Phố Mưa Đêm Ánh Đèn Cinematic',
    category: 'Kịch tính & Cảm xúc',
    desc: 'Mặt đường ướt phản chiếu ánh đèn neon lung linh, cơn mưa bay đầy chất thơ tự sự',
    imageUrl: 'https://images.unsplash.com/photo-1519501025264-65ba15a82390?w=800&auto=format&fit=crop&q=80',
  },
  {
    id: 'waterfall-paradise',
    name: 'Thác Nước Rừng Nhiệt Đới Kỳ Vĩ',
    category: 'Hùng vĩ kỳ ảo',
    desc: 'Dòng thác bạc đổ giữa rặng rừng nhiệt đới, cầu vồng mờ ảo trong làn sương sớm',
    imageUrl: 'https://images.unsplash.com/photo-1432405972618-c60b0225b8f9?w=800&auto=format&fit=crop&q=80',
  },
  {
    id: 'vogue-studio',
    name: 'Studio Tối Giản Vogue High-Fashion',
    category: 'Thời trang cao cấp',
    desc: 'Phông nền đơn sắc cao cấp, ánh sáng Studio 3 điểm sắc nét tôn vinh từng góc mặt',
    imageUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80',
  },
  {
    id: 'rooftop-skyline',
    name: 'Tầng Thượng Tòa Nhà Chọc Trời Đêm',
    category: 'Thành thị hiện đại',
    desc: 'Toàn cảnh đường chân trời thành phố lung linh ánh đèn triệu đô từ đỉnh cao nhất',
    imageUrl: 'https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?w=800&auto=format&fit=crop&q=80',
  },
];

export const SAMPLE_MV_SONGS = [
  {
    id: 'mv-song-1',
    title: 'Hào Khí Thăng Long (Bản Hùng Ca)',
    artist: 'GITA Singer & Ban Nhạc Giao Hưởng',
    genre: 'vpop',
    genreName: 'V-Pop Hào Hùng',
    lyrics: `[Verse 1]
Ngàn năm sông Hồng vẫn cuộn sóng dâng trào
Ánh mắt người xưa rạng rỡ giữa ngàn sao
Tiếng trống đồng âm vang từ trong huyết quản
Hào khí ngút trời bước qua ngàn gian lao!

[Chorus]
Bay lên, hỡi rồng thiêng phương Đông rực sáng!
Nối triệu con tim chung một lời ca
Dẫu bão giông nghìn trùng không lùi bước
Tổ quốc trong lòng mãi mãi ngàn năm hoa!

[Verse 2]
Đoàn quân đi qua những nẻo đường đất nước
Khát vọng vươn mình ra biển lớn bao la
Tiếng đàn vang lên cùng nhịp trống giục giã
Ánh lửa trong tim không bao giờ tàn phai!`,
    concept: 'MV phong cách điện ảnh sử thi kết hợp sân khấu hiện đại: Ca sĩ đứng giữa đại nhạc hội 50.000 khán giả, xen kẽ các phân cảnh thành quách cổ xưa và thành phố tương lai rực rỡ.',
    singerAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=600&auto=format&fit=crop&q=80',
  },
  {
    id: 'mv-song-2',
    title: 'Ánh Sao Giữa Đêm Thành Phố (City Stars)',
    artist: 'Minh Quang & The K-Pop Crew',
    genre: 'kpop',
    genreName: 'K-Pop Dance & EDM',
    lyrics: `[Intro - Beat Drop]
Yeah, look into the mirror, who you wanna be?
Break the silence, set your spirit free!

[Verse 1]
Đèn neon chiếu soi trên từng góc phố dài
Từng bước chân đi qua những mệt nhoài
Chẳng cần ai định nghĩa tương lai ngày mai
Vì ánh sao đêm nay là của chính ta!

[Chorus - High Energy]
Shine bright like a diamond in the dark!
Ignite the fire, ignite the spark!
Hát lên bài ca của những ước mơ
Nhảy cùng nhịp tim xóa tan âu lo!`,
    concept: 'MV phong cách K-Pop triệu đô: Vũ đoàn 8 người nhảy đồng đều bắt mắt trên phim trường LED Cyberpunk và tầng thượng tòa nhà chọc trời, camera xoay 360 độ góc rộng.',
    singerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&auto=format&fit=crop&q=80',
  },
  {
    id: 'mv-song-3',
    title: 'Gửi Em Góc Phố Mùa Thu (Acoustic Ballad)',
    artist: 'Hoàng Nam & Dàn Dây Orchestra',
    genre: 'ballad',
    genreName: 'Ballad Trữ Tình Sâu Lắng',
    lyrics: `[Verse 1]
Mùa thu đi qua góc phố nhỏ thân quen
Lá vàng rơi nghiêng che lấp bóng hình em
Chiếc radio cũ hát bản tình ca cũ
Nhắc lại lời hứa dưới ánh đèn đường đêm...

[Chorus]
Nếu thời gian có thể quay trở lại
Anh vẫn chọn được gặp em năm ấy
Dẫu biết yêu thương như cơn gió bay
Vẫn giữ trong tim nụ cười đắm say!`,
    concept: 'MV lãng mạn quay dưới mưa đêm ánh đèn vàng hoài niệm, ban nhạc Acoustic chơi đàn bên bờ hồ và rừng thông, kết hợp biểu cảm ánh mắt da diết.',
    singerAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=600&auto=format&fit=crop&q=80',
  },
];

export const INITIAL_MV_REVENUE_ANALYTICS: MVRevenueAnalytics = {
  totalActiveMVs: 1428,
  netEarningsUSD: 714.0, // 1428 * 0.5 USD = 714 USD
  netEarningsVND: 17850000, // 714 * 25,000 = 17,850,000 VND
  activeCreatorUsers: 386,
  predictedMonthlyRevenueUSD: 1450.0, // Based on user engagement projection (~2,900 MVs/month)
  predictedMonthlyRevenueVND: 36250000,
  growthRatePercent: 32.8,
  monthlyHistory: [
    { month: 'T05/26', projectsCount: 420, netProfitUSD: 210.0, activeUsers: 140 },
    { month: 'T06/26', projectsCount: 680, netProfitUSD: 340.0, activeUsers: 215 },
    { month: 'T07/26', projectsCount: 950, netProfitUSD: 475.0, activeUsers: 290 },
    { month: 'T08/26', projectsCount: 1180, netProfitUSD: 590.0, activeUsers: 335 },
    { month: 'T09/26', projectsCount: 1428, netProfitUSD: 714.0, activeUsers: 386 },
    { month: 'T10/26 (Dự báo)', projectsCount: 2900, netProfitUSD: 1450.0, activeUsers: 620 },
  ],
  genreBreakdown: [
    { genre: 'V-Pop Hào Hùng & Nhạc Trẻ', count: 520, share: 36.4, color: '#f59e0b' },
    { genre: 'K-Pop Dance & Vũ Đạo Đồng Đều', count: 395, share: 27.6, color: '#8b5cf6' },
    { genre: 'Ballad Trữ Tình & Acoustic', count: 280, share: 19.6, color: '#06b6d4' },
    { genre: 'EDM Sôi Động & Festival', count: 145, share: 10.2, color: '#ec4899' },
    { genre: 'Rap / Hip-hop & Khác', count: 88, share: 6.2, color: '#10b981' },
  ],
  recentMVs: [
    {
      id: 'mv-001',
      title: 'Hào Khí Thăng Long (Bản Hùng Ca)',
      artist: 'GITA Singer & Ban Nhạc',
      genre: 'V-Pop Hào Hùng',
      date: 'Hôm nay 08:30',
      vipTier: 'Pro 4K Stage MV',
      feeUSD: 4.40,
      netProfitUSD: 0.50,
      viewsEst: 125000,
      status: 'monetized',
    },
    {
      id: 'mv-002',
      title: 'Ánh Sao Giữa Đêm Thành Phố',
      artist: 'Minh Quang & K-Pop Crew',
      genre: 'K-Pop Dance',
      date: 'Hôm qua 21:15',
      vipTier: 'Master Hollywood 4K',
      feeUSD: 6.40,
      netProfitUSD: 0.50,
      viewsEst: 84000,
      status: 'monetized',
    },
    {
      id: 'mv-003',
      title: 'Gửi Em Góc Phố Mùa Thu',
      artist: 'Hoàng Nam',
      genre: 'Ballad Sâu Lắng',
      date: 'Hôm qua 14:02',
      vipTier: 'Indie 2K MV',
      feeUSD: 2.90,
      netProfitUSD: 0.50,
      viewsEst: 42000,
      status: 'monetized',
    },
    {
      id: 'mv-004',
      title: 'Bùng Nổ Năng Lượng Đêm Hội',
      artist: 'DJ Thăng Long & Vũ Đoàn',
      genre: 'EDM Festival',
      date: '08/10/2026',
      vipTier: 'Pro 4K Stage MV',
      feeUSD: 4.40,
      netProfitUSD: 0.50,
      viewsEst: 67000,
      status: 'ready',
    },
    {
      id: 'mv-005',
      title: 'Khát Vọng Doanh Nhân Việt',
      artist: 'Trainer Quang & Dàn Nhạc',
      genre: 'Nhạc Truyền Cảm Hứng',
      date: '07/10/2026',
      vipTier: 'Master Hollywood 4K',
      feeUSD: 6.40,
      netProfitUSD: 0.50,
      viewsEst: 198000,
      status: 'monetized',
    },
  ],
};
