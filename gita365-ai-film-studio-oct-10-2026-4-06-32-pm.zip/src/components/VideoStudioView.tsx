import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  SkipForward,
  SkipBack,
  Volume2,
  VolumeX,
  Maximize2,
  Sparkles,
  Download,
  Film,
  Music,
  Mic,
  Subtitles,
  Layers,
  Settings,
  Share2,
  CheckCircle2,
  Cpu,
  Clock,
  Check,
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  X,
  ArrowRight,
  AlertCircle,
} from 'lucide-react';
import { FilmProject, Scene, VideoFormat } from '../types';
import { playBgmSynth, stopBgmSynth, speakText, stopSpeaking } from '../utils/audioSynth';
import { ImageStudioModal } from './ImageStudioModal';
import { ContentModerationModal } from './ContentModerationModal';

interface VideoStudioViewProps {
  project: FilmProject;
  onUpdateProject: (updated: FilmProject) => void;
  onOpenRenderModal: () => void;
}

export const VideoStudioView: React.FC<VideoStudioViewProps> = ({
  project,
  onUpdateProject,
  onOpenRenderModal,
}) => {
  const [currentEpisodeIdx, setCurrentEpisodeIdx] = useState(0);
  const currentEpisode = project.episodes[currentEpisodeIdx] || project.episodes[0];

  // Flatten all scenes in this episode for timeline
  const scenes: Scene[] = currentEpisode?.acts.flatMap((a) => a.scenes) || [];
  const [currentSceneIdx, setCurrentSceneIdx] = useState(0);
  const activeScene = scenes[currentSceneIdx] || scenes[0];

  // Playback state
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackTime, setPlaybackTime] = useState(0); // in seconds
  const [isMuted, setIsMuted] = useState(false);
  const [aspectRatio, setAspectRatio] = useState<VideoFormat>(project.aspectRatio || '16:9');
  const [resolution, setResolution] = useState<'1080p' | '4K UHD' | '720p'>(project.resolution || '4K UHD');
  const [subtitleStyle, setSubtitleStyle] = useState<'yellow' | 'karaoke' | 'minimal'>('yellow');
  const [isSubtitleVisible, setIsSubtitleVisible] = useState(true);
  const [isImageStudioOpen, setIsImageStudioOpen] = useState(false);
  const [isModerationModalOpen, setIsModerationModalOpen] = useState(false);
  const [showPreRenderWarning, setShowPreRenderWarning] = useState(false);

  // Helper to detect sensitive scenes
  const isSceneSensitive = (sc: Scene) => {
    if (!sc) return false;
    const text = `${sc.title || ''} ${sc.description || ''} ${sc.visualPrompt || ''} ${(sc.dialogue || []).map((d) => d.text).join(' ')}`.toLowerCase();
    const sensitiveWords = ['giết', 'máu', 'chém', 'súng', 'bắn', 'tự tử', 'chết tiệt', 'nguyền rủa', 'khỏa thân', 'sex', 'đập phá', 'bạo lực'];
    return sensitiveWords.some((w) => text.includes(w));
  };

  const flaggedScenesCount = scenes.filter(isSceneSensitive).length;

  const handleInitiateRender = () => {
    if (flaggedScenesCount > 0) {
      setShowPreRenderWarning(true);
    } else {
      onOpenRenderModal();
    }
  };

  // Helper to update active scene and trigger Auto-Save immediately
  const updateActiveScene = (updates: Partial<Scene>) => {
    if (!activeScene) return;
    const updatedEpisodes = project.episodes.map((ep, eIdx) => {
      if (eIdx !== currentEpisodeIdx) return ep;
      return {
        ...ep,
        acts: ep.acts.map((act) => ({
          ...act,
          scenes: act.scenes.map((sc) => {
            if (sc.id === activeScene.id) {
              return { ...sc, ...updates };
            }
            return sc;
          }),
        })),
      };
    });
    onUpdateProject({
      ...project,
      episodes: updatedEpisodes,
      updatedAt: new Date().toISOString(),
    });
  };

  // Animation and timeline timer
  const playTimerRef = useRef<number | null>(null);

  // Total duration of current episode scenes
  const totalDuration = scenes.reduce((acc, s) => acc + (s.durationSeconds || 15), 0) || 60;

  // Handle play / pause toggle
  const togglePlay = () => {
    if (isPlaying) {
      setIsPlaying(false);
      stopBgmSynth();
      stopSpeaking();
      if (playTimerRef.current) clearInterval(playTimerRef.current);
    } else {
      setIsPlaying(true);
      // Trigger background ambient synth if not muted
      if (!isMuted && activeScene) {
        playBgmSynth(activeScene.bgmMood || 'Cinematic Epic', activeScene.durationSeconds || 15);
        // If scene has dialogue, speak the first line
        if (activeScene.dialogue && activeScene.dialogue.length > 0) {
          const firstLine = activeScene.dialogue[0];
          speakText(firstLine.text, firstLine.speaker.includes('Nữ') ? 'Nữ' : 'Nam');
        }
      }
    }
  };

  // Playback progression ticker
  useEffect(() => {
    if (isPlaying) {
      playTimerRef.current = window.setInterval(() => {
        setPlaybackTime((prev) => {
          const next = prev + 1;
          if (next >= totalDuration) {
            setIsPlaying(false);
            stopBgmSynth();
            stopSpeaking();
            return 0;
          }

          // Check if we should advance to the next scene
          let accumulated = 0;
          for (let i = 0; i < scenes.length; i++) {
            accumulated += scenes[i].durationSeconds || 15;
            if (next < accumulated) {
              if (i !== currentSceneIdx) {
                setCurrentSceneIdx(i);
                // Trigger next scene audio & speech
                if (!isMuted && scenes[i]) {
                  playBgmSynth(scenes[i].bgmMood || 'Cinematic', scenes[i].durationSeconds || 15);
                  if (scenes[i].dialogue && scenes[i].dialogue.length > 0) {
                    const line = scenes[i].dialogue[0];
                    speakText(line.text, line.speaker.includes('Nữ') ? 'Nữ' : 'Nam');
                  }
                }
              }
              break;
            }
          }
          return next;
        });
      }, 1000);
    } else {
      if (playTimerRef.current) clearInterval(playTimerRef.current);
    }

    return () => {
      if (playTimerRef.current) clearInterval(playTimerRef.current);
    };
  }, [isPlaying, scenes, currentSceneIdx, isMuted, totalDuration]);

  // Jump to specific scene
  const selectScene = (idx: number) => {
    setCurrentSceneIdx(idx);
    let offset = 0;
    for (let i = 0; i < idx; i++) {
      offset += scenes[i]?.durationSeconds || 15;
    }
    setPlaybackTime(offset);

    if (isPlaying && !isMuted && scenes[idx]) {
      playBgmSynth(scenes[idx].bgmMood || 'Cinematic', scenes[idx].durationSeconds || 15);
      if (scenes[idx].dialogue && scenes[idx].dialogue.length > 0) {
        speakText(scenes[idx].dialogue[0].text, scenes[idx].dialogue[0].speaker.includes('Nữ') ? 'Nữ' : 'Nam');
      }
    }
  };

  // Format seconds to mm:ss
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Top Bar with Project Status & Format toggles */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/90 p-4 rounded-2xl border border-slate-800 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Film className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-white">Xưởng Dựng & Render Phim AI (Studio Timeline)</h2>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 font-mono font-bold">
                Tập {currentEpisode?.episodeNumber || 1}
              </span>
            </div>
            <p className="text-xs text-slate-400">
              {currentEpisode?.title} • Tổng thời lượng: {formatTime(totalDuration)}
            </p>
          </div>
        </div>

        {/* Studio Controls: Format, Resolution, Render */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Aspect Ratio Switch */}
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setAspectRatio('16:9')}
              className={`px-2.5 py-1 rounded-lg font-semibold transition-all ${
                aspectRatio === '16:9' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              16:9 Cinema
            </button>
            <button
              onClick={() => setAspectRatio('9:16')}
              className={`px-2.5 py-1 rounded-lg font-semibold transition-all ${
                aspectRatio === '9:16' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              9:16 TikTok
            </button>
            <button
              onClick={() => setAspectRatio('1:1')}
              className={`px-2.5 py-1 rounded-lg font-semibold transition-all ${
                aspectRatio === '1:1' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              1:1 Vuông
            </button>
          </div>

          {/* Resolution Selector */}
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-mono">
            <button
              onClick={() => setResolution('1080p')}
              className={`px-2 py-1 rounded-lg ${
                resolution === '1080p' ? 'bg-slate-800 text-cyan-300 font-bold' : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              1080p
            </button>
            <button
              onClick={() => setResolution('4K UHD')}
              className={`px-2.5 py-1 rounded-lg ${
                resolution === '4K UHD'
                  ? 'bg-gradient-to-r from-amber-500/20 to-yellow-500/20 text-yellow-300 font-bold border border-yellow-500/40'
                  : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              4K UHD
            </button>
          </div>

          {/* Pre-render Content Moderation Filter Button */}
          <button
            onClick={() => setIsModerationModalOpen(true)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold border shadow-md transition-all group ${
              flaggedScenesCount > 0
                ? 'bg-amber-950/40 border-amber-500/60 text-amber-300 hover:bg-amber-900/50'
                : 'bg-slate-950 hover:bg-slate-850 text-slate-200 border-slate-750 hover:border-emerald-500/50'
            }`}
            title="Quét bộ lọc kiểm duyệt tiêu chuẩn cộng đồng trước khi render"
          >
            {flaggedScenesCount > 0 ? (
              <ShieldAlert className="w-3.5 h-3.5 text-amber-400 group-hover:scale-110 transition-transform animate-pulse" />
            ) : (
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 group-hover:scale-110 transition-transform" />
            )}
            <span className="hidden sm:inline">Bộ Lọc Kiểm Duyệt</span>
            {flaggedScenesCount > 0 ? (
              <span className="px-1.5 py-0.5 rounded-full bg-amber-500 text-slate-950 text-[10px] font-extrabold">
                {flaggedScenesCount}
              </span>
            ) : (
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
            )}
          </button>

          {/* Render 4K CTA with Pre-render safety hook */}
          <button
            onClick={handleInitiateRender}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 text-xs font-bold shadow-lg shadow-amber-500/20 transition-all transform hover:scale-105"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Xuất Phim 4K</span>
          </button>
        </div>
      </div>

      {/* Main Studio Viewport (Canvas / Video Screen) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Player Stage (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          <div
            className={`relative mx-auto rounded-3xl overflow-hidden bg-black border-2 border-slate-800 shadow-2xl flex items-center justify-center transition-all ${
              aspectRatio === '16:9'
                ? 'aspect-video w-full'
                : aspectRatio === '9:16'
                ? 'w-full max-w-sm aspect-[9/16]'
                : 'w-full max-w-md aspect-square'
            }`}
          >
            {/* Visual Screen Layer with smooth Ken Burns zoom animation */}
            {activeScene?.imageUrl ? (
              <img
                src={activeScene.imageUrl}
                alt={activeScene.title}
                className={`w-full h-full object-cover transition-all duration-1000 ${
                  isPlaying ? 'scale-110 filter brightness-105' : 'scale-100'
                }`}
              />
            ) : (
              <div className="text-slate-600 text-xs text-center p-4">
                Chưa có hình ảnh phân cảnh
              </div>
            )}

            {/* Cinematic Letterbox Bars */}
            <div className="absolute top-0 inset-x-0 h-6 bg-gradient-to-b from-black/80 to-transparent pointer-events-none" />
            <div className="absolute bottom-0 inset-x-0 h-20 bg-gradient-to-t from-black/90 via-black/40 to-transparent pointer-events-none" />

            {/* Overlays: Scene Metadata & Watermark */}
            <div className="absolute top-3 left-3 flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-md text-[10px] text-amber-300 font-mono border border-amber-500/30">
                SCENE #{activeScene?.sceneNumber || 1} • {activeScene?.cameraAngle}
              </span>
              <span className="px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-md text-[10px] text-emerald-400 font-mono">
                {resolution} 60FPS
              </span>
            </div>

            <div className="absolute top-3 right-3 flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-black/60 backdrop-blur-md text-[10px] text-slate-300 font-bold tracking-wider">
              <span className="text-amber-400">GITA365</span> CINEMA
            </div>

            {/* Dynamic Subtitle Overlay with styling */}
            {isSubtitleVisible && activeScene?.dialogue && activeScene.dialogue.length > 0 && (
              <div className="absolute bottom-6 inset-x-4 text-center px-4 pointer-events-none z-20">
                {subtitleStyle === 'yellow' && (
                  <div className="inline-block bg-black/75 backdrop-blur-sm px-4 py-1.5 rounded-xl border border-yellow-500/30 shadow-2xl">
                    <span className="text-yellow-300 font-bold text-xs sm:text-sm drop-shadow-md tracking-wide">
                      {activeScene.dialogue[0].speaker}: "{activeScene.dialogue[0].text}"
                    </span>
                  </div>
                )}
                {subtitleStyle === 'karaoke' && (
                  <div className="inline-block bg-indigo-950/80 backdrop-blur-md px-4 py-1.5 rounded-xl border border-indigo-400/50 shadow-2xl animate-pulse">
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-pink-400 to-cyan-300 font-extrabold text-xs sm:text-sm drop-shadow-lg">
                      ✦ {activeScene.dialogue[0].text} ✦
                    </span>
                  </div>
                )}
                {subtitleStyle === 'minimal' && (
                  <div className="inline-block text-white font-medium text-xs sm:text-sm drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
                    {activeScene.dialogue[0].text}
                  </div>
                )}
              </div>
            )}

            {/* Play Button Overlay on Pause */}
            {!isPlaying && (
              <button
                onClick={togglePlay}
                className="absolute inset-0 flex items-center justify-center bg-black/30 hover:bg-black/40 transition-colors group cursor-pointer"
              >
                <div className="w-16 h-16 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center shadow-2xl shadow-amber-500/50 group-hover:scale-110 transition-transform">
                  <Play className="w-8 h-8 fill-slate-950 translate-x-0.5" />
                </div>
              </button>
            )}
          </div>

          {/* Transport Controls Bar */}
          <div className="bg-slate-900/95 p-3.5 rounded-2xl border border-slate-800 flex items-center justify-between gap-3 shadow-lg">
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  if (currentSceneIdx > 0) selectScene(currentSceneIdx - 1);
                }}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                title="Cảnh trước"
              >
                <SkipBack className="w-4 h-4" />
              </button>
              <button
                onClick={togglePlay}
                className="p-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold transition-all shadow-md"
                title={isPlaying ? 'Tạm dừng' : 'Phát'}
              >
                {isPlaying ? <Pause className="w-4 h-4 fill-slate-950" /> : <Play className="w-4 h-4 fill-slate-950" />}
              </button>
              <button
                onClick={() => {
                  if (currentSceneIdx < scenes.length - 1) selectScene(currentSceneIdx + 1);
                }}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                title="Cảnh tiếp theo"
              >
                <SkipForward className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  setPlaybackTime(0);
                  selectScene(0);
                }}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                title="Quay lại đầu"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Time Indicator & Progress Bar */}
            <div className="flex-1 flex items-center gap-3 px-2">
              <span className="text-xs font-mono text-amber-300 font-semibold min-w-[40px]">
                {formatTime(playbackTime)}
              </span>
              <div
                onClick={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const ratio = (e.clientX - rect.left) / rect.width;
                  const newTime = Math.floor(ratio * totalDuration);
                  setPlaybackTime(newTime);
                }}
                className="flex-1 h-2 bg-slate-950 rounded-full cursor-pointer relative overflow-hidden group"
              >
                <div
                  className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 rounded-full transition-all"
                  style={{ width: `${(playbackTime / totalDuration) * 100}%` }}
                />
              </div>
              <span className="text-xs font-mono text-slate-400 min-w-[40px]">
                {formatTime(totalDuration)}
              </span>
            </div>

            {/* Audio & Subtitle toggles */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsMuted(!isMuted)}
                className={`p-2 rounded-xl text-xs transition-colors ${
                  isMuted ? 'text-rose-400 bg-rose-500/10' : 'text-slate-300 hover:bg-slate-800'
                }`}
                title={isMuted ? 'Bật âm thanh' : 'Tắt âm thanh'}
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>

              <button
                onClick={() => setIsSubtitleVisible(!isSubtitleVisible)}
                className={`p-2 rounded-xl text-xs transition-colors ${
                  isSubtitleVisible ? 'text-amber-300 bg-amber-500/10' : 'text-slate-500 hover:bg-slate-800'
                }`}
                title="Bật/tắt phụ đề"
              >
                <Subtitles className="w-4 h-4" />
              </button>

              {/* Subtitle style switch */}
              <select
                value={subtitleStyle}
                onChange={(e) => setSubtitleStyle(e.target.value as any)}
                className="bg-slate-950 border border-slate-800 rounded-xl px-2 py-1 text-[11px] text-slate-300 focus:outline-none"
              >
                <option value="yellow">Vàng Điện Ảnh</option>
                <option value="karaoke">Karaoke Glow</option>
                <option value="minimal">Tối Giản Trắng</option>
              </select>
            </div>
          </div>
        </div>

        {/* Right: Scene Details & Inspector (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-amber-400" /> Chi Tiết Phân Cảnh Hiện Tại
              </h3>
              <span className="text-[10px] text-amber-400 font-mono">
                Cảnh {currentSceneIdx + 1} / {scenes.length}
              </span>
            </div>

            {activeScene && (
              <div className="space-y-3 text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block mb-0.5">
                    Địa điểm & Thời gian:
                  </span>
                  <div className="text-slate-200 font-medium bg-slate-950 p-2 rounded-xl border border-slate-800">
                    📍 {activeScene.location} ({activeScene.timeOfDay})
                  </div>
                </div>

                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block mb-0.5">
                    Góc máy & Chuyển động:
                  </span>
                  <div className="text-slate-200 font-medium bg-slate-950 p-2 rounded-xl border border-slate-800">
                    🎥 {activeScene.cameraAngle}
                  </div>
                </div>

                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block mb-0.5">
                    Hiệu ứng chuyển cảnh (Transition):
                  </span>
                  <select
                    value={activeScene.transition || 'fade'}
                    onChange={(e) => {
                      updateActiveScene({ transition: e.target.value as any });
                    }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none"
                  >
                    <option value="fade">Fade In/Out (Chuyển đen mượt)</option>
                    <option value="dissolve">Cross Dissolve (Hòa tan hình ảnh)</option>
                    <option value="wipe">Wipe Right (Quét ngang điện ảnh)</option>
                    <option value="zoom">Crash Zoom (Phóng to kịch tính)</option>
                    <option value="cut">Hard Cut (Cắt trực diện)</option>
                  </select>
                </div>

                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block mb-0.5">
                    Tâm trạng Nhạc nền (BGM):
                  </span>
                  <div className="flex items-center justify-between bg-slate-950 p-2 rounded-xl border border-slate-800">
                    <span className="text-amber-300 font-medium">🎵 {activeScene.bgmMood}</span>
                    <button
                      onClick={() => playBgmSynth(activeScene.bgmMood, 8)}
                      className="text-[10px] text-amber-400 hover:text-amber-300 font-semibold"
                    >
                      Nghe thử
                    </button>
                  </div>
                </div>

                {activeScene.dialogue && activeScene.dialogue.length > 0 && (
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-semibold block mb-0.5">
                      Lời thoại AI lồng tiếng:
                    </span>
                    <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 space-y-1.5">
                      <div className="flex items-center justify-between text-[10px]">
                        <span className="font-bold text-amber-400">{activeScene.dialogue[0].speaker}</span>
                        <span className="text-slate-500 italic">({activeScene.dialogue[0].emotion})</span>
                      </div>
                      <textarea
                        rows={2}
                        value={activeScene.dialogue[0].text}
                        onChange={(e) => {
                          const updatedDialogue = activeScene.dialogue ? [...activeScene.dialogue] : [];
                          if (updatedDialogue[0]) {
                            updatedDialogue[0] = { ...updatedDialogue[0], text: e.target.value };
                            updateActiveScene({ dialogue: updatedDialogue });
                          }
                        }}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-slate-100 text-xs italic focus:outline-none focus:border-amber-500/50"
                      />
                    </div>
                  </div>
                )}

                {/* Auto-Save Reassurance Badge */}
                <div className="flex items-center justify-between text-[11px] text-emerald-400 bg-emerald-500/10 px-2.5 py-1.5 rounded-xl border border-emerald-500/20 font-medium">
                  <span className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Lưu Nháp Tự Động: Đã Bảo Toàn</span>
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">Real-time</span>
                </div>

                {/* AI Image Creation / Editing Button with gemini-nano-banana-2.1 */}
                <div className="pt-2 border-t border-slate-800">
                  <button
                    onClick={() => setIsImageStudioOpen(true)}
                    className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-amber-500 hover:brightness-110 text-white font-bold text-xs shadow-lg shadow-purple-600/20 transition-all"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Tạo & Sửa Ảnh AI (gemini-nano-banana-2.1)</span>
                  </button>
                </div>

                {/* Pre-render Content Moderation Card for Active Scene */}
                <div className="pt-3 border-t border-slate-800 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-200 flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                      Bộ Lọc Tiêu Chuẩn (Policy Check)
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                      An Toàn
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Tự động quét kịch bản & hình ảnh để phòng tránh vi phạm chính sách cộng đồng YouTube/TikTok trước khi render 4K.
                  </p>
                  <button
                    onClick={() => setIsModerationModalOpen(true)}
                    className="w-full flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/50 text-xs text-amber-300 font-semibold transition-all shadow-sm"
                  >
                    <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                    <span>Quét Tiêu Chuẩn & Sửa Tự Động</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Non-Linear Video Editor Timeline (Multi-track) */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Film className="w-4 h-4 text-amber-400" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Dòng Thời Gian Dựng Phim Đa Lớp (Multi-Track Timeline)
            </h3>
          </div>
          <div className="flex items-center gap-2 text-[11px] text-slate-400">
            <span>{scenes.length} phân cảnh</span>
            <span>•</span>
            <span className="text-amber-400 font-mono">{formatTime(totalDuration)} tổng</span>
          </div>
        </div>

        {/* Track 1: Video Scene Clips Track */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-semibold">
            <span className="flex items-center gap-1.5">
              <Film className="w-3.5 h-3.5 text-amber-400" /> Lớp Video (Scene Clips)
            </span>
            <span className="text-[10px] text-slate-500">Kéo / chọn phân cảnh để xem</span>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
            {scenes.map((sc, idx) => {
              const isCurrent = idx === currentSceneIdx;
              return (
                <div
                  key={sc.id}
                  onClick={() => selectScene(idx)}
                  className={`relative flex-shrink-0 w-36 h-20 rounded-xl overflow-hidden border-2 cursor-pointer transition-all group ${
                    isCurrent
                      ? 'border-amber-400 shadow-lg shadow-amber-500/20 ring-2 ring-amber-400/30'
                      : 'border-slate-800 hover:border-slate-600 opacity-70 hover:opacity-100'
                  }`}
                >
                  {sc.imageUrl ? (
                    <img src={sc.imageUrl} alt={sc.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full bg-slate-950 flex items-center justify-center text-[10px] text-slate-600">
                      Cảnh {sc.sceneNumber}
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-transparent to-transparent" />
                  {/* Content moderation badge per scene */}
                  {isSceneSensitive(sc) ? (
                    <div
                      className="absolute top-1 left-1 px-1.5 py-0.5 rounded-md bg-amber-950/90 border border-amber-500/80 text-[9px] text-amber-300 font-bold flex items-center gap-1 z-10 shadow"
                      title="Có từ ngữ nhạy cảm cần rà soát"
                    >
                      <ShieldAlert className="w-2.5 h-2.5 text-amber-400" />
                      <span>Cần duyệt</span>
                    </div>
                  ) : (
                    <div
                      className="absolute top-1 left-1 p-0.5 rounded bg-slate-950/70 border border-emerald-500/30 text-[9px] text-emerald-400 flex items-center z-10"
                      title="Đã qua kiểm duyệt an toàn"
                    >
                      <ShieldCheck className="w-2.5 h-2.5 text-emerald-400" />
                    </div>
                  )}
                  <div className="absolute bottom-1.5 left-1.5 right-1.5 flex items-center justify-between text-[10px]">
                    <span className="font-bold text-white font-mono">#{sc.sceneNumber}</span>
                    <span className="text-amber-300 font-mono">{sc.durationSeconds}s</span>
                  </div>
                  {sc.transition && (
                    <div className="absolute top-1 right-1 px-1 rounded bg-black/70 text-[9px] text-slate-300 uppercase">
                      {sc.transition}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Track 2: Dialogue & Voiceover Track */}
        <div className="space-y-1">
          <div className="text-[11px] text-slate-400 font-semibold flex items-center gap-1.5">
            <Mic className="w-3.5 h-3.5 text-indigo-400" /> Lớp Lồng Tiếng AI (Voiceover Track)
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
            {scenes.map((sc, idx) => (
              <div
                key={`voice-${sc.id}`}
                className="flex-shrink-0 w-36 h-7 rounded-lg bg-indigo-950/70 border border-indigo-800/60 px-2 flex items-center justify-between text-[10px] text-indigo-200"
              >
                <span className="truncate">{sc.dialogue?.[0]?.speaker || 'Nhạc cảnh'}</span>
                <span className="text-[9px] font-mono text-indigo-400">{sc.durationSeconds}s</span>
              </div>
            ))}
          </div>
        </div>

        {/* Track 3: Background Music & SFX Waveform Track */}
        <div className="space-y-1">
          <div className="text-[11px] text-slate-400 font-semibold flex items-center gap-1.5">
            <Music className="w-3.5 h-3.5 text-emerald-400" /> Lớp Nhạc Nền Bản Quyền (BGM & SFX Waveform)
          </div>
          <div className="h-10 bg-slate-950 rounded-xl border border-slate-800/90 flex items-center px-4 overflow-hidden relative">
            {/* Visualizer simulated bars */}
            <div className="flex items-center gap-1 w-full opacity-60">
              {Array.from({ length: 48 }).map((_, i) => (
                <div
                  key={i}
                  className={`w-1.5 rounded-full transition-all ${
                    isPlaying ? 'animate-pulse bg-emerald-400' : 'bg-slate-700'
                  }`}
                  style={{
                    height: `${Math.max(6, Math.sin(i * 0.4) * 24 + 10)}px`,
                  }}
                />
              ))}
            </div>
            <div className="absolute right-3 text-[10px] text-emerald-400 font-mono">
              Dolby Atmos 5.1
            </div>
          </div>
        </div>
      </div>

      {/* 4K Image Generation & Editing Modal with gemini-nano-banana-2.1 */}
      {isImageStudioOpen && (
        <ImageStudioModal
          isOpen={isImageStudioOpen}
          onClose={() => setIsImageStudioOpen(false)}
          initialPrompt={activeScene?.visualPrompt || `Cinematic film still, ${activeScene?.title || ''}, 8K photorealistic`}
          initialImage={activeScene?.imageUrl}
          sceneTitle={activeScene?.title || `Phân cảnh #${activeScene?.sceneNumber || 1}`}
          onApplyImage={(newImageUrl) => {
            if (!activeScene) return;
            const updatedEpisodes = project.episodes.map((ep, eIdx) => {
              if (eIdx !== currentEpisodeIdx) return ep;
              return {
                ...ep,
                acts: ep.acts.map((act) => ({
                  ...act,
                  scenes: act.scenes.map((sc) => {
                    if (sc.id === activeScene.id) {
                      return { ...sc, imageUrl: newImageUrl };
                    }
                    return sc;
                  }),
                })),
              };
            });
            onUpdateProject({
              ...project,
              episodes: updatedEpisodes,
              updatedAt: new Date().toISOString(),
            });
          }}
        />
      )}

      {/* Content Moderation Filter Modal (Pre-render Community Guidelines Audit) */}
      {isModerationModalOpen && (
        <ContentModerationModal
          isOpen={isModerationModalOpen}
          onClose={() => setIsModerationModalOpen(false)}
          scenes={scenes}
          currentSceneIdx={currentSceneIdx}
          onSelectScene={(idx) => selectScene(idx)}
          onApplySanitizedScene={(sceneId, sanitized) => {
            const updatedEpisodes = project.episodes.map((ep, eIdx) => {
              if (eIdx !== currentEpisodeIdx) return ep;
              return {
                ...ep,
                acts: ep.acts.map((act) => ({
                  ...act,
                  scenes: act.scenes.map((sc) => {
                    if (sc.id === sceneId) {
                      return {
                        ...sc,
                        ...sanitized,
                      };
                    }
                    return sc;
                  }),
                })),
              };
            });
            onUpdateProject({
              ...project,
              episodes: updatedEpisodes,
              updatedAt: new Date().toISOString(),
            });
          }}
          onProceedToRender={() => {
            setIsModerationModalOpen(false);
            onOpenRenderModal();
          }}
        />
      )}

      {/* Pre-render Moderation Safety Alert Dialog */}
      {showPreRenderWarning && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-lg bg-slate-900 border border-amber-500/50 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-400 flex items-center justify-center border border-amber-500/30">
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-sm">
                    Cảnh Báo Tiêu Chuẩn Cộng Đồng Trước Khi Render
                  </h3>
                  <span className="text-[11px] text-amber-400 font-mono">
                    Phát hiện {flaggedScenesCount} phân cảnh cần rà soát
                  </span>
                </div>
              </div>
              <button
                onClick={() => setShowPreRenderWarning(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Kịch bản chứa một số phân cảnh có từ ngữ hoặc mô tả hình ảnh có rủi ro vi phạm chính sách cộng đồng (bạo lực, nhạy cảm) của <strong className="text-white">YouTube, TikTok, Facebook</strong>.
            </p>

            <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-2">
              <span className="text-[11px] font-bold text-slate-400 block uppercase">
                Khuyến nghị của hệ thống GITA365:
              </span>
              <p className="text-xs text-emerald-400 flex items-start gap-1.5">
                <Check className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <span>Nên mở <strong>Bộ Lọc Kiểm Duyệt</strong> để AI tự động tinh chỉnh sang ngôn ngữ điện ảnh giàu tính nghệ thuật và an toàn 100%.</span>
              </p>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row items-center gap-2 justify-end">
              <button
                type="button"
                onClick={() => {
                  setShowPreRenderWarning(false);
                  onOpenRenderModal();
                }}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl text-slate-400 hover:text-slate-200 text-xs font-semibold"
              >
                Bỏ qua & Vẫn Xuất Phim 4K
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowPreRenderWarning(false);
                  setIsModerationModalOpen(true);
                }}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:brightness-110 text-slate-950 font-bold text-xs shadow-lg flex items-center justify-center gap-2"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Mở Bộ Lọc & Sửa Tự Động</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
