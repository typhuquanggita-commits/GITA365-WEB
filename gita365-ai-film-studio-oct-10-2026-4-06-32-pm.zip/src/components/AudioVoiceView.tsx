import React, { useState, useMemo } from 'react';
import {
  Mic,
  Music,
  Volume2,
  VolumeX,
  Play,
  Square,
  Sparkles,
  Sliders,
  CheckCircle2,
  Check,
  Headphones,
  Award,
  Download,
  Filter,
  Search,
  RefreshCw,
  FastForward,
  Clock,
  Layers,
  Film,
  User,
  Flame,
  Smile,
  Frown,
  Zap,
  BookOpen,
  Volume1,
  Save,
  Radio,
  Share2,
} from 'lucide-react';
import { FilmProject, BgmTrack, VoicePreset, DialogueItem } from '../types';
import { BGM_TRACKS, VOICE_PRESETS, GITA_MC_LIST } from '../data/initialData';
import {
  playBgmSynth,
  stopBgmSynth,
  speakWithGeminiTTS,
  generateDialogueAudio,
  playAudioUrl,
  stopSpeaking,
} from '../utils/audioSynth';

interface AudioVoiceViewProps {
  project: FilmProject;
  onUpdateProject: (updated: FilmProject) => void;
}

// Emotion presets mapped to natural Vietnamese speech instructions
const EMOTION_PRESETS = [
  {
    id: 'joyful',
    label: 'Vui tươi / Hân hoan',
    icon: Smile,
    color: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
    activeColor: 'bg-amber-500 text-slate-950 border-amber-400',
    prompt: 'cảm xúc vui tươi, phấn khởi, rạng rỡ và tràn đầy nụ cười',
  },
  {
    id: 'sad',
    label: 'U buồn / Xúc động',
    icon: Frown,
    color: 'text-blue-400 bg-blue-500/10 border-blue-500/30',
    activeColor: 'bg-blue-500 text-slate-950 border-blue-400',
    prompt: 'cảm xúc u buồn, nghẹn ngào, da diết và trầm lắng lay động',
  },
  {
    id: 'dramatic',
    label: 'Kịch tính / Gay cấn',
    icon: Flame,
    color: 'text-rose-400 bg-rose-500/10 border-rose-500/30',
    activeColor: 'bg-rose-500 text-slate-950 border-rose-400',
    prompt: 'cảm xúc kịch tính dồn dập, căng thẳng, gay cấn và uy lực điện ảnh',
  },
  {
    id: 'philosophical',
    label: 'Trầm ấm / Triết lý',
    icon: BookOpen,
    color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
    activeColor: 'bg-emerald-500 text-slate-950 border-emerald-400',
    prompt: 'cảm xúc trầm ấm, sâu sắc, điềm đạm và thông tuệ',
  },
  {
    id: 'heroic',
    label: 'Hào hùng / Quyết liệt',
    icon: Zap,
    color: 'text-purple-400 bg-purple-500/10 border-purple-500/30',
    activeColor: 'bg-purple-500 text-slate-950 border-purple-400',
    prompt: 'giọng điệu đanh thép, nghiêm nghị, quyết liệt và dứt khoát',
  },
  {
    id: 'anchor',
    label: 'Chuẩn phát thanh viên',
    icon: Radio,
    color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30',
    activeColor: 'bg-cyan-500 text-slate-950 border-cyan-400',
    prompt: 'chuẩn phát thanh viên truyền hình, rõ chữ, truyền cảm',
  },
];

const SPEED_PRESETS = [
  { value: 0.8, label: '0.8x Chậm rãi' },
  { value: 0.9, label: '0.9x Khoan thai' },
  { value: 1.0, label: '1.0x Chuẩn' },
  { value: 1.15, label: '1.15x Khẩn trương' },
  { value: 1.25, label: '1.25x Dồn dập' },
];

export const AudioVoiceView: React.FC<AudioVoiceViewProps> = ({
  project,
  onUpdateProject,
}) => {
  // Main view tab: 'screenplay' | 'studio' | 'bgm'
  const [activeTab, setActiveTab] = useState<'screenplay' | 'studio' | 'bgm'>('screenplay');

  // Filter controls for screenplay
  const [selectedEpisodeId, setSelectedEpisodeId] = useState<string>('all');
  const [selectedSceneId, setSelectedSceneId] = useState<string>('all');
  const [speakerFilter, setSpeakerFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'synthesized' | 'pending'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Per-dialogue loading/playing state
  const [loadingDialogueId, setLoadingDialogueId] = useState<string | null>(null);
  const [playingDialogueId, setPlayingDialogueId] = useState<string | null>(null);

  // Scene continuous playback
  const [isPlayingScene, setIsPlayingScene] = useState(false);
  const [activeSceneIndex, setActiveSceneIndex] = useState<number>(0);

  // Batch synthesis state
  const [isSynthesizingAll, setIsSynthesizingAll] = useState(false);
  const [batchProgress, setBatchProgress] = useState<{ current: number; total: number } | null>(null);
  const [batchSuccess, setBatchSuccess] = useState(false);

  // Free test studio state
  const [selectedVoiceId, setSelectedVoiceId] = useState<string>(VOICE_PRESETS[0].id);
  const [customSpeechText, setCustomSpeechText] = useState(
    'Chào mừng quý vị khán giả và các bạn đến với xưởng phim điện ảnh AI GITA365. Hệ thống V-TTS 24kHz sẵn sàng lồng tiếng chân thực với đầy đủ cảm xúc cho từng câu thoại.'
  );
  const [customEmotion, setCustomEmotion] = useState<string>('cảm xúc trầm ấm, sâu sắc, điềm đạm và thông tuệ');
  const [customSpeed, setCustomSpeed] = useState<number>(1.0);
  const [isLoadingTestVoice, setIsLoadingTestVoice] = useState(false);
  const [isPlayingTestVoice, setIsPlayingTestVoice] = useState(false);

  // BGM preview
  const [activeBgmId, setActiveBgmId] = useState<string | null>(null);

  // Extract all dialogue items flattened with scene metadata
  const flattenedDialogues = useMemo(() => {
    const list: Array<{
      episodeId: string;
      episodeNumber: number;
      episodeTitle: string;
      actNumber: number;
      actName: string;
      sceneId: string;
      sceneNumber: number;
      sceneTitle: string;
      sceneLocation: string;
      dialogue: DialogueItem;
    }> = [];

    project.episodes.forEach((ep) => {
      ep.acts.forEach((act) => {
        act.scenes.forEach((sc) => {
          if (sc.dialogue && sc.dialogue.length > 0) {
            sc.dialogue.forEach((d) => {
              list.push({
                episodeId: ep.id,
                episodeNumber: ep.episodeNumber,
                episodeTitle: ep.title,
                actNumber: act.actNumber,
                actName: act.name,
                sceneId: sc.id,
                sceneNumber: sc.sceneNumber,
                sceneTitle: sc.title || `Cảnh ${sc.sceneNumber}`,
                sceneLocation: sc.location,
                dialogue: d,
              });
            });
          }
        });
      });
    });

    return list;
  }, [project]);

  // Unique speakers across all dialogues
  const allSpeakers = useMemo(() => {
    const set = new Set<string>();
    flattenedDialogues.forEach((item) => {
      if (item.dialogue.speaker) set.add(item.dialogue.speaker);
    });
    return Array.from(set);
  }, [flattenedDialogues]);

  // Filtered dialogues
  const filteredDialogues = useMemo(() => {
    return flattenedDialogues.filter((item) => {
      if (selectedEpisodeId !== 'all' && item.episodeId !== selectedEpisodeId) return false;
      if (selectedSceneId !== 'all' && item.sceneId !== selectedSceneId) return false;
      if (speakerFilter !== 'all' && item.dialogue.speaker !== speakerFilter) return false;
      if (statusFilter === 'synthesized' && !item.dialogue.audioUrl) return false;
      if (statusFilter === 'pending' && item.dialogue.audioUrl) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchText = item.dialogue.text.toLowerCase().includes(q);
        const matchSpeaker = item.dialogue.speaker.toLowerCase().includes(q);
        const matchScene = item.sceneTitle.toLowerCase().includes(q);
        if (!matchText && !matchSpeaker && !matchScene) return false;
      }
      return true;
    });
  }, [flattenedDialogues, selectedEpisodeId, selectedSceneId, speakerFilter, statusFilter, searchQuery]);

  // Dialogue counts
  const totalDialogues = flattenedDialogues.length;
  const synthesizedCount = flattenedDialogues.filter((d) => Boolean(d.dialogue.audioUrl)).length;
  const progressPercent = totalDialogues > 0 ? Math.round((synthesizedCount / totalDialogues) * 100) : 0;

  // Selected voice for studio
  const selectedVoice =
    VOICE_PRESETS.find((v) => v.id === selectedVoiceId) || VOICE_PRESETS[0];

  // Helper to update a specific dialogue in the film project state
  const handleUpdateDialogue = (
    sceneId: string,
    dialogueId: string,
    updates: Partial<DialogueItem>
  ) => {
    const updatedProject: FilmProject = {
      ...project,
      episodes: project.episodes.map((ep) => ({
        ...ep,
        acts: ep.acts.map((act) => ({
          ...act,
          scenes: act.scenes.map((sc) => {
            if (sc.id !== sceneId) return sc;
            return {
              ...sc,
              dialogue: sc.dialogue.map((d) => {
                if (d.id !== dialogueId) return d;
                return { ...d, ...updates };
              }),
            };
          }),
        })),
      })),
    };
    onUpdateProject(updatedProject);
  };

  // Play dialogue single line with V-TTS API
  const handlePlayDialogue = async (item: (typeof flattenedDialogues)[0]) => {
    const { dialogue, sceneId } = item;

    // If currently playing, stop it
    if (playingDialogueId === dialogue.id) {
      stopSpeaking();
      setPlayingDialogueId(null);
      return;
    }

    stopSpeaking();
    setLoadingDialogueId(dialogue.id);

    // If audioUrl already exists, play directly
    if (dialogue.audioUrl) {
      setLoadingDialogueId(null);
      setPlayingDialogueId(dialogue.id);
      playAudioUrl(
        dialogue.audioUrl,
        () => setPlayingDialogueId(null),
        () => setPlayingDialogueId(null)
      );
      return;
    }

    // Call V-TTS API to generate 24kHz audio
    const isFemale =
      dialogue.speaker.includes('Nữ') ||
      dialogue.speaker.includes('Ananya') ||
      dialogue.speaker.includes('MC') ||
      dialogue.speaker.includes('Hương') ||
      dialogue.speaker.includes('Vy') ||
      dialogue.speaker.includes('Linh');

    const gender = isFemale ? 'Nữ' : 'Nam';
    const voiceName = dialogue.voiceName || (isFemale ? 'Kore' : 'Fenrir');
    const speed = dialogue.speed || 1.0;
    const emotion = dialogue.emotion || 'cảm xúc truyền cảm tự nhiên, rõ chữ';

    try {
      const res = await generateDialogueAudio(dialogue.text, {
        gender,
        voiceName,
        speakerName: dialogue.speaker,
        emotion,
        speed,
      });

      setLoadingDialogueId(null);

      if (res.success && res.audioUrl) {
        // Save audioUrl to project state
        handleUpdateDialogue(sceneId, dialogue.id, {
          audioUrl: res.audioUrl,
          isSynthesized: true,
        });

        setPlayingDialogueId(dialogue.id);
        playAudioUrl(
          res.audioUrl,
          () => setPlayingDialogueId(null),
          () => setPlayingDialogueId(null)
        );
      } else {
        alert(res.error || 'Không thể tạo âm thanh giọng đọc');
      }
    } catch (err: any) {
      setLoadingDialogueId(null);
      console.error('Play dialogue error:', err);
    }
  };

  // Play entire scene sequentially
  const handlePlayFullScene = async () => {
    if (isPlayingScene) {
      stopSpeaking();
      setIsPlayingScene(false);
      return;
    }

    if (filteredDialogues.length === 0) return;

    setIsPlayingScene(true);
    let index = 0;

    const playNext = async () => {
      if (index >= filteredDialogues.length) {
        setIsPlayingScene(false);
        setPlayingDialogueId(null);
        return;
      }

      const item = filteredDialogues[index];
      setActiveSceneIndex(index);
      setPlayingDialogueId(item.dialogue.id);

      const isFemale =
        item.dialogue.speaker.includes('Nữ') ||
        item.dialogue.speaker.includes('Ananya') ||
        item.dialogue.speaker.includes('MC');
      const voiceName = item.dialogue.voiceName || (isFemale ? 'Kore' : 'Fenrir');

      let audioUrl = item.dialogue.audioUrl;
      if (!audioUrl) {
        const res = await generateDialogueAudio(item.dialogue.text, {
          gender: isFemale ? 'Nữ' : 'Nam',
          voiceName,
          speakerName: item.dialogue.speaker,
          emotion: item.dialogue.emotion || 'cảm xúc điện ảnh tự nhiên',
          speed: item.dialogue.speed || 1.0,
        });
        if (res.success && res.audioUrl) {
          audioUrl = res.audioUrl;
          handleUpdateDialogue(item.sceneId, item.dialogue.id, {
            audioUrl: res.audioUrl,
            isSynthesized: true,
          });
        }
      }

      if (audioUrl) {
        playAudioUrl(
          audioUrl,
          () => {
            index++;
            setTimeout(playNext, 450); // slight pause between lines
          },
          () => {
            index++;
            setTimeout(playNext, 450);
          }
        );
      } else {
        index++;
        setTimeout(playNext, 450);
      }
    };

    playNext();
  };

  // Batch synthesize all lines in kịch bản
  const handleBatchSynthesizeAll = async () => {
    if (flattenedDialogues.length === 0) return;

    setIsSynthesizingAll(true);
    setBatchProgress({ current: 0, total: flattenedDialogues.length });

    try {
      const itemsToSynth = flattenedDialogues.map((item) => {
        const isFemale =
          item.dialogue.speaker.includes('Nữ') ||
          item.dialogue.speaker.includes('Ananya') ||
          item.dialogue.speaker.includes('MC');
        return {
          id: item.dialogue.id,
          sceneId: item.sceneId,
          text: item.dialogue.text,
          speaker: item.dialogue.speaker,
          voiceName: item.dialogue.voiceName || (isFemale ? 'Kore' : 'Fenrir'),
          emotion: item.dialogue.emotion || 'cảm xúc điện ảnh truyền cảm',
          speed: item.dialogue.speed || 1.0,
        };
      });

      const response = await fetch('/api/tts/batch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items: itemsToSynth }),
      });

      const data = await response.json();

      if (data.success && data.items) {
        const resultMap = new Map<string, string>();
        data.items.forEach((it: any) => {
          if (it.audioUrl) {
            resultMap.set(it.id, it.audioUrl);
          } else if (it.audioBase64) {
            resultMap.set(it.id, `data:audio/wav;base64,${it.audioBase64}`);
          }
        });

        // Apply all results to project
        const updatedProject: FilmProject = {
          ...project,
          episodes: project.episodes.map((ep) => ({
            ...ep,
            acts: ep.acts.map((act) => ({
              ...act,
              scenes: act.scenes.map((sc) => ({
                ...sc,
                dialogue: sc.dialogue.map((d) => {
                  const newUrl = resultMap.get(d.id);
                  if (newUrl) {
                    return { ...d, audioUrl: newUrl, isSynthesized: true };
                  }
                  return d;
                }),
              })),
            })),
          })),
        };

        onUpdateProject(updatedProject);
        setBatchSuccess(true);
        setTimeout(() => setBatchSuccess(false), 5000);
      }
    } catch (err) {
      console.error('Batch synthesis error:', err);
    } finally {
      setIsSynthesizingAll(false);
      setBatchProgress(null);
    }
  };

  // Play BGM preview
  const handlePlayBgm = (track: BgmTrack) => {
    if (activeBgmId === track.id) {
      stopBgmSynth();
      setActiveBgmId(null);
    } else {
      setActiveBgmId(track.id);
      playBgmSynth(track.category, 25);
    }
  };

  // Free test voice
  const handleTestFreeVoice = async () => {
    if (!customSpeechText.trim()) return;
    setIsLoadingTestVoice(true);
    setIsPlayingTestVoice(false);

    let voiceName = 'Fenrir';
    if (selectedVoice.gender === 'Nữ') {
      voiceName = selectedVoice.name.includes('Chi') || selectedVoice.name.includes('Linh') ? 'Zephyr' : 'Kore';
    } else {
      voiceName = selectedVoice.name.includes('Morgan') || selectedVoice.name.includes('Spalding') ? 'Charon' : 'Fenrir';
    }

    try {
      await speakWithGeminiTTS(customSpeechText, {
        gender: selectedVoice.gender,
        voiceName,
        speakerName: selectedVoice.name,
        emotion: customEmotion,
        speed: customSpeed,
        onStart: () => {
          setIsLoadingTestVoice(false);
          setIsPlayingTestVoice(true);
        },
        onEnd: () => {
          setIsLoadingTestVoice(false);
          setIsPlayingTestVoice(false);
        },
        onError: () => {
          setIsLoadingTestVoice(false);
          setIsPlayingTestVoice(false);
        },
      });
    } catch {
      setIsLoadingTestVoice(false);
      setIsPlayingTestVoice(false);
    }
  };

  const handleStopAll = () => {
    stopSpeaking();
    stopBgmSynth();
    setPlayingDialogueId(null);
    setLoadingDialogueId(null);
    setIsPlayingScene(false);
    setIsPlayingTestVoice(false);
    setIsLoadingTestVoice(false);
    setActiveBgmId(null);
  };

  // Download dialogue WAV file
  const handleDownloadWav = (item: (typeof flattenedDialogues)[0]) => {
    if (!item.dialogue.audioUrl) return;
    const a = document.createElement('a');
    a.href = item.dialogue.audioUrl;
    a.download = `V-TTS_${item.sceneNumber}_${item.dialogue.speaker.replace(/\s+/g, '_')}_${item.dialogue.id}.wav`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in">
      {/* Top Banner: V-TTS Studio Engine */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-slate-900 to-emerald-950/40 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 rounded-full bg-emerald-500/10 blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold uppercase tracking-wider">
              <Headphones className="w-3.5 h-3.5" /> GITA365 Studio V-TTS 24kHz Engine
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight">
              Phòng Thu Âm Lồng Tiếng AI Tiếng Việt Cao Cấp (V-TTS)
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              Tích hợp công nghệ <strong className="text-emerald-400">Gemini 3.8 Flash TTS</strong> chất lượng 24kHz.
              Tùy biến <span className="text-amber-400 font-semibold">Cảm Xúc</span> (vui tươi, u buồn, kịch tính, triết lý...) và{' '}
              <span className="text-cyan-400 font-semibold">Tốc Độ</span> (0.75x - 1.35x) trực tiếp cho từng câu thoại trong kịch bản.
            </p>

            {/* Quick Metrics Bar */}
            <div className="flex flex-wrap items-center gap-4 pt-2 text-xs">
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-950/80 border border-slate-800 text-slate-300">
                <Film className="w-3.5 h-3.5 text-emerald-400" />
                <span>Kịch bản: <strong>{totalDialogues} câu thoại</strong></span>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-950/80 border border-slate-800 text-emerald-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Đã lồng tiếng: <strong>{synthesizedCount}/{totalDialogues} ({progressPercent}%)</strong></span>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-950/80 border border-slate-800 text-amber-300">
                <Radio className="w-3.5 h-3.5 text-amber-400" />
                <span>Chuẩn âm thanh: <strong>24kHz WAV Studio</strong></span>
              </div>
            </div>
          </div>

          {/* Global Action Buttons */}
          <div className="flex flex-col sm:flex-row lg:flex-col gap-3 flex-shrink-0">
            <button
              onClick={handleBatchSynthesizeAll}
              disabled={isSynthesizingAll || totalDialogues === 0}
              className="flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/20 transition-all transform hover:scale-105 disabled:opacity-50"
            >
              {isSynthesizingAll ? (
                <>
                  <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                  <span>Đang Lồng Tiếng Toàn Bộ ({batchProgress?.current || 0}/{batchProgress?.total || totalDialogues})...</span>
                </>
              ) : batchSuccess ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Đã Hoàn Tất Lồng Tiếng 100%!</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Lồng Tiếng Toàn Bộ Kịch Bản (Batch V-TTS)</span>
                </>
              )}
            </button>

            <div className="flex items-center gap-2">
              <button
                onClick={handlePlayFullScene}
                disabled={filteredDialogues.length === 0}
                className={`flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold border transition-all ${
                  isPlayingScene
                    ? 'bg-rose-500/20 border-rose-500/60 text-rose-300'
                    : 'bg-slate-950 hover:bg-slate-800 border-slate-800 text-slate-200'
                }`}
              >
                {isPlayingScene ? (
                  <>
                    <Square className="w-3.5 h-3.5 fill-current" />
                    <span>Dừng Phát Phân Cảnh ({activeSceneIndex + 1}/{filteredDialogues.length})</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Nghe Toàn Bộ Đoạn Lọc ({filteredDialogues.length} câu)</span>
                  </>
                )}
              </button>

              <button
                onClick={handleStopAll}
                title="Dừng toàn bộ âm thanh"
                className="p-2.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white transition-all"
              >
                <VolumeX className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Studio Navigation Tabs */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('screenplay')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'screenplay'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Film className="w-4 h-4" />
            <span>1. Tùy Chỉnh Từng Câu Thoại Kịch Bản ({totalDialogues})</span>
          </button>
          <button
            onClick={() => setActiveTab('studio')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'studio'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Mic className="w-4 h-4" />
            <span>2. Bộ Giọng Đọc V-TTS & Thử Tự Do</span>
          </button>
          <button
            onClick={() => setActiveTab('bgm')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'bgm'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Music className="w-4 h-4" />
            <span>3. Kho Nhạc Bản Quyền BGM ({BGM_TRACKS.length})</span>
          </button>
        </div>

        <div className="hidden sm:flex items-center gap-1.5 text-xs text-slate-400">
          <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
          <span>V-TTS Vietnamese Neural Voice</span>
        </div>
      </div>

      {/* TAB 1: Kịch Bản & Lồng Tiếng Từng Câu Thoại */}
      {activeTab === 'screenplay' && (
        <div className="space-y-6">
          {/* Filter Bar */}
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 shadow-xl space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex flex-wrap items-center gap-3 flex-1 min-w-[280px]">
                {/* Search Box */}
                <div className="relative flex-1 min-w-[200px]">
                  <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Tìm theo nội dung thoại, nhân vật, phân cảnh..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                {/* Episode Selector */}
                <select
                  value={selectedEpisodeId}
                  onChange={(e) => {
                    setSelectedEpisodeId(e.target.value);
                    setSelectedSceneId('all');
                  }}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-emerald-500"
                >
                  <option value="all">Tất cả tập phim</option>
                  {project.episodes.map((ep) => (
                    <option key={ep.id} value={ep.id}>
                      Tập {ep.episodeNumber}: {ep.title}
                    </option>
                  ))}
                </select>

                {/* Speaker Selector */}
                <select
                  value={speakerFilter}
                  onChange={(e) => setSpeakerFilter(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-emerald-500"
                >
                  <option value="all">Tất cả nhân vật</option>
                  {allSpeakers.map((spk) => (
                    <option key={spk} value={spk}>
                      {spk}
                    </option>
                  ))}
                </select>

                {/* Status Filter */}
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value as any)}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-emerald-500"
                >
                  <option value="all">Tất cả trạng thái</option>
                  <option value="synthesized">Đã lồng tiếng ({synthesizedCount})</option>
                  <option value="pending">Chưa lồng tiếng ({totalDialogues - synthesizedCount})</option>
                </select>
              </div>

              <div className="text-xs text-slate-400">
                Hiển thị: <strong className="text-white">{filteredDialogues.length}</strong> / {totalDialogues} câu thoại
              </div>
            </div>
          </div>

          {/* Dialogue Cards List */}
          {filteredDialogues.length === 0 ? (
            <div className="bg-slate-900/60 rounded-2xl border border-slate-800 p-12 text-center space-y-3">
              <Film className="w-12 h-12 text-slate-600 mx-auto" />
              <h3 className="text-base font-bold text-white">Không tìm thấy câu thoại phù hợp</h3>
              <p className="text-xs text-slate-400">
                Thử đổi bộ lọc tập phim, nhân vật hoặc từ khóa tìm kiếm.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredDialogues.map((item, idx) => {
                const { dialogue, sceneId, sceneTitle, sceneNumber, actNumber, episodeNumber } = item;
                const isCurrentlyPlaying = playingDialogueId === dialogue.id;
                const isCurrentlyLoading = loadingDialogueId === dialogue.id;
                const currentSpeed = dialogue.speed || 1.0;
                const currentEmotion = dialogue.emotion || 'cảm xúc truyền cảm tự nhiên, rõ chữ';
                const hasAudio = Boolean(dialogue.audioUrl);

                return (
                  <div
                    key={`${sceneId}-${dialogue.id}-${idx}`}
                    className={`bg-slate-900/90 rounded-2xl border transition-all p-5 shadow-xl space-y-4 ${
                      isCurrentlyPlaying
                        ? 'border-emerald-500 ring-1 ring-emerald-500/50 shadow-emerald-500/10'
                        : 'border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    {/* Header Row: Scene Badge, Speaker, and Status */}
                    <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-[11px] font-mono text-slate-400">
                          Tập {episodeNumber} • Hồi {actNumber} • Cảnh {sceneNumber}
                        </span>
                        <span className="text-xs font-semibold text-slate-300">
                          {sceneTitle}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        {hasAudio ? (
                          <span className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[11px] font-medium">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Đã thu âm 24kHz
                          </span>
                        ) : (
                          <span className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[11px] font-medium">
                            <Clock className="w-3.5 h-3.5" /> Chưa thu âm
                          </span>
                        )}

                        {hasAudio && (
                          <button
                            onClick={() => handleDownloadWav(item)}
                            title="Tải file WAV 24kHz"
                            className="p-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-emerald-300 transition-all text-[11px]"
                          >
                            <Download className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Middle Row: Speaker Profile & Dialogue Text */}
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
                      {/* Left: Speaker & Voice Selector (4 cols) */}
                      <div className="lg:col-span-4 space-y-2">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-300 font-bold text-xs flex-shrink-0">
                            <User className="w-4 h-4" />
                          </div>
                          <div className="min-w-0">
                            <div className="text-xs font-bold text-white truncate">
                              {dialogue.speaker}
                            </div>
                            <div className="text-[10px] text-slate-400 truncate">
                              Giọng V-TTS: {dialogue.voiceName || (dialogue.speaker.includes('Nữ') ? 'Kore (Nữ)' : 'Fenrir (Nam)')}
                            </div>
                          </div>
                        </div>

                        {/* Voice Preset Selection for this line */}
                        <div>
                          <label className="text-[10px] font-semibold text-slate-400 block mb-1">
                            Chọn diễn viên giọng đọc:
                          </label>
                          <select
                            value={dialogue.voiceName || (dialogue.speaker.includes('Nữ') ? 'Kore' : 'Fenrir')}
                            onChange={(e) =>
                              handleUpdateDialogue(sceneId, dialogue.id, {
                                voiceName: e.target.value,
                                audioUrl: undefined, // invalidate previous audio when voice changes
                              })
                            }
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                          >
                            <optgroup label="Giọng Nam Chuẩn V-TTS">
                              <option value="Fenrir">Fenrir • Nam Điện Ảnh Trầm Ấm (Hà Nội)</option>
                              <option value="Charon">Charon • Nam Sâu Lắng, Cổ Phong Triết Lý</option>
                              <option value="Puck">Puck • Nam Trẻ Trung, Năng Động (Sài Gòn)</option>
                            </optgroup>
                            <optgroup label="Giọng Nữ Chuẩn V-TTS">
                              <option value="Kore">Kore • Nữ Truyền Cảm, Trong Trẻo (Hà Nội)</option>
                              <option value="Zephyr">Zephyr • Nữ Thanh Lịch, Nhẹ Nhàng (Miền Nam)</option>
                            </optgroup>
                          </select>
                        </div>
                      </div>

                      {/* Right: Dialogue Text Input (8 cols) */}
                      <div className="lg:col-span-8 space-y-1.5">
                        <label className="text-[10px] font-semibold text-slate-400 block">
                          Lời thoại nhân vật:
                        </label>
                        <textarea
                          rows={2}
                          value={dialogue.text}
                          onChange={(e) =>
                            handleUpdateDialogue(sceneId, dialogue.id, {
                              text: e.target.value,
                              audioUrl: undefined, // invalidate audio if text is edited
                            })
                          }
                          placeholder="Nhập nội dung câu thoại tiếng Việt..."
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-emerald-500 leading-relaxed font-sans"
                        />
                      </div>
                    </div>

                    {/* Bottom Controls: Emotion & Speed Tuning (User's Core Request) */}
                    <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800/80 space-y-3">
                      {/* Emotion Section */}
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                            <Sliders className="w-3.5 h-3.5 text-emerald-400" /> Sắc Thái & Cảm Xúc (Vui, Buồn, Kịch Tính...)
                          </span>
                          <span className="text-[10px] text-slate-500 italic">
                            {currentEmotion}
                          </span>
                        </div>

                        {/* Emotion Preset Chips */}
                        <div className="flex flex-wrap gap-1.5">
                          {EMOTION_PRESETS.map((ep) => {
                            const isMatch = currentEmotion.toLowerCase().includes(ep.id) || currentEmotion.toLowerCase().includes(ep.label.toLowerCase().split('/')[0].trim());
                            const EpIcon = ep.icon;
                            return (
                              <button
                                key={ep.id}
                                onClick={() =>
                                  handleUpdateDialogue(sceneId, dialogue.id, {
                                    emotion: ep.prompt,
                                    audioUrl: undefined, // reset cache so next play regenerates with new emotion
                                  })
                                }
                                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-medium border transition-all ${
                                  isMatch ? ep.activeColor : ep.color
                                }`}
                              >
                                <EpIcon className="w-3 h-3" />
                                <span>{ep.label}</span>
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* Speed Tuning Section */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1 border-t border-slate-900">
                        <div className="flex items-center gap-3 flex-1">
                          <span className="text-[11px] font-semibold text-slate-300 flex items-center gap-1 flex-shrink-0">
                            <FastForward className="w-3 h-3 text-cyan-400" /> Tốc độ đọc:
                          </span>
                          <input
                            type="range"
                            min="0.75"
                            max="1.35"
                            step="0.05"
                            value={currentSpeed}
                            onChange={(e) =>
                              handleUpdateDialogue(sceneId, dialogue.id, {
                                speed: parseFloat(e.target.value),
                                audioUrl: undefined,
                              })
                            }
                            className="flex-1 accent-emerald-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                          />
                          <span className="text-xs font-mono font-bold text-emerald-400 w-12 text-right">
                            {currentSpeed.toFixed(2)}x
                          </span>
                        </div>

                        {/* Quick Speed Pills */}
                        <div className="flex items-center gap-1">
                          {SPEED_PRESETS.map((sp) => (
                            <button
                              key={sp.value}
                              onClick={() =>
                                handleUpdateDialogue(sceneId, dialogue.id, {
                                  speed: sp.value,
                                  audioUrl: undefined,
                                })
                              }
                              className={`px-2 py-0.5 rounded text-[10px] font-mono transition-all ${
                                currentSpeed === sp.value
                                  ? 'bg-emerald-500 text-slate-950 font-bold'
                                  : 'bg-slate-900 hover:bg-slate-850 text-slate-400 hover:text-white border border-slate-800'
                              }`}
                            >
                              {sp.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Action Bar for this Dialogue */}
                    <div className="flex items-center justify-between pt-1">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handlePlayDialogue(item)}
                          disabled={isCurrentlyLoading}
                          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md ${
                            isCurrentlyPlaying
                              ? 'bg-rose-500 text-slate-950 hover:bg-rose-400 shadow-rose-500/20'
                              : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/20'
                          }`}
                        >
                          {isCurrentlyLoading ? (
                            <>
                              <div className="w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                              <span>Đang Tạo V-TTS 24kHz...</span>
                            </>
                          ) : isCurrentlyPlaying ? (
                            <>
                              <Square className="w-3.5 h-3.5 fill-current" />
                              <span>Dừng Đọc</span>
                            </>
                          ) : (
                            <>
                              <Volume2 className="w-3.5 h-3.5" />
                              <span>{hasAudio ? 'Nghe Lại Thoại' : 'Phát V-TTS Ngay'}</span>
                            </>
                          )}
                        </button>

                        {isCurrentlyPlaying && (
                          <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-[11px] font-mono">
                            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                            <span>Đang phát 24kHz...</span>
                          </div>
                        )}
                      </div>

                      <div className="flex items-center gap-2 text-[10px] text-slate-400">
                        <span>Gemini 3.8 Flash Studio</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: Thử Giọng Nhanh & Bộ Sưu Tập Giọng Đọc V-TTS */}
      {activeTab === 'studio' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column: Voice Presets Grid (6 cols) */}
          <div className="lg:col-span-6 space-y-6">
            <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-5">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <Mic className="w-4 h-4 text-emerald-400" /> Tuyển Tập Giọng Đọc V-TTS Tiếng Việt Chuẩn
                </h2>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 font-mono font-bold">
                  Gemini Studio 24kHz
                </span>
              </div>

              <div className="space-y-3">
                <label className="text-xs font-semibold text-slate-300 block">
                  Chọn nhân vật thử giọng:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {VOICE_PRESETS.map((v) => {
                    const isSelected = v.id === selectedVoice.id;
                    return (
                      <div
                        key={v.id}
                        onClick={() => setSelectedVoiceId(v.id)}
                        className={`p-3.5 rounded-2xl border cursor-pointer transition-all flex items-center gap-3 relative ${
                          isSelected
                            ? 'bg-slate-950 border-emerald-500/90 shadow-lg shadow-emerald-500/10 ring-1 ring-emerald-500/50'
                            : 'bg-slate-950/60 border-slate-800 hover:bg-slate-950 hover:border-slate-700'
                        }`}
                      >
                        <div className="relative">
                          <img
                            src={v.avatar}
                            alt={v.name}
                            className="w-12 h-12 rounded-xl object-cover border border-slate-700 flex-shrink-0"
                          />
                          {isSelected && (
                            <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-slate-950 flex items-center justify-center text-[8px] text-slate-950 font-bold">
                              ✓
                            </span>
                          )}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="text-xs font-bold text-white truncate flex items-center justify-between">
                            <span>{v.name}</span>
                            <span className="text-[10px] px-1.5 py-0.2 rounded font-mono text-emerald-400 bg-emerald-500/10">
                              {v.gender}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-400 truncate mt-0.5">{v.accent}</div>
                          <div className="text-[10px] text-emerald-300/90 font-medium truncate mt-0.5">
                            {v.tag}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* MCs Highlight Note */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 space-y-1">
                <div className="font-semibold text-emerald-400 flex items-center gap-1.5">
                  <Award className="w-3.5 h-3.5" /> Đồng bộ Dàn 11 Nữ MC & Trainer Trương Nhật Quang
                </div>
                <p className="text-[11px] text-slate-400">
                  Hệ thống tự động liên kết phong thái của Trainer Quang và 11 MC truyền hình GITA365 sang giọng V-TTS chuẩn ngữ điệu Bắc - Nam.
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Custom Testing Box with Emotion & Speed (6 cols) */}
          <div className="lg:col-span-6 space-y-6">
            <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-5">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-emerald-400" /> Thử Nghiệm Ngữ Điệu & Cảm Xúc Tự Do
                </h2>
                <span className="text-[10px] text-slate-500 font-mono">Trực tiếp qua API V-TTS</span>
              </div>

              {/* Text Input */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 block">
                  Văn bản kiểm tra phát âm tiếng Việt:
                </label>
                <textarea
                  rows={4}
                  value={customSpeechText}
                  onChange={(e) => setCustomSpeechText(e.target.value)}
                  placeholder="Nhập bất kỳ đoạn văn tiếng Việt nào để AI phát âm chuẩn 24kHz..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-emerald-500 leading-relaxed font-sans"
                />
              </div>

              {/* Emotion Tuning */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-300 block">
                  Cảm xúc diễn xuất (Emotion):
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {EMOTION_PRESETS.map((ep) => {
                    const isSelected = customEmotion === ep.prompt;
                    const EpIcon = ep.icon;
                    return (
                      <button
                        key={ep.id}
                        onClick={() => setCustomEmotion(ep.prompt)}
                        className={`flex items-center gap-1.5 p-2 rounded-xl text-left text-xs font-medium border transition-all ${
                          isSelected ? ep.activeColor : ep.color
                        }`}
                      >
                        <EpIcon className="w-3.5 h-3.5 flex-shrink-0" />
                        <span className="truncate">{ep.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Speed Tuning */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-300">Tốc độ đọc (Speed):</span>
                  <span className="font-mono text-emerald-400 font-bold">{customSpeed.toFixed(2)}x</span>
                </div>
                <input
                  type="range"
                  min="0.75"
                  max="1.35"
                  step="0.05"
                  value={customSpeed}
                  onChange={(e) => setCustomSpeed(parseFloat(e.target.value))}
                  className="w-full accent-emerald-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between gap-3 pt-2">
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleTestFreeVoice}
                    disabled={isLoadingTestVoice}
                    className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 text-xs font-bold shadow-lg shadow-emerald-500/20 transition-all transform hover:scale-105 disabled:opacity-50"
                  >
                    {isLoadingTestVoice ? (
                      <>
                        <div className="w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                        <span>Đang Tạo Giọng Chuẩn...</span>
                      </>
                    ) : isPlayingTestVoice ? (
                      <>
                        <span className="w-2.5 h-2.5 rounded-full bg-slate-950 animate-ping" />
                        <span>Đang Đọc Diễn Xuất...</span>
                      </>
                    ) : (
                      <>
                        <Volume2 className="w-4 h-4" />
                        <span>Nghe Thử Giọng Tiếng Việt Thật</span>
                      </>
                    )}
                  </button>

                  {(isPlayingTestVoice || isLoadingTestVoice) && (
                    <button
                      onClick={handleStopAll}
                      className="px-3 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-all"
                    >
                      Dừng đọc
                    </button>
                  )}
                </div>

                <div className="text-[11px] text-emerald-400 font-mono flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>24kHz WAV Studio</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: Kho Nhạc Bản Quyền BGM */}
      {activeTab === 'bgm' && (
        <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Music className="w-4 h-4 text-amber-400" /> Kho Nhạc Bản Quyền GITA365 Studio (BGM Studio)
            </h2>
            <span className="text-xs text-amber-400/90 font-mono">100% Miễn Phí Bản Quyền Thương Mại</span>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed max-w-3xl">
            Tất cả các bản nhạc được sáng tác và sản xuất bởi GITA365 Studio. Bạn có thể an tâm bật kiếm tiền trên YouTube AdSense, TikTok Shop và Facebook Reels mà không lo bị gậy bản quyền âm nhạc.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {BGM_TRACKS.map((track) => {
              const isPlaying = activeBgmId === track.id;
              return (
                <div
                  key={track.id}
                  className={`p-4 rounded-2xl border transition-all space-y-3 ${
                    isPlaying
                      ? 'bg-slate-950 border-amber-500/80 shadow-md ring-1 ring-amber-500/40'
                      : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between gap-3">
                    <button
                      onClick={() => handlePlayBgm(track)}
                      className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors flex-shrink-0 ${
                        isPlaying
                          ? 'bg-amber-500 text-slate-950 shadow-md'
                          : 'bg-slate-800 text-amber-400 hover:bg-slate-700'
                      }`}
                    >
                      {isPlaying ? (
                        <Square className="w-4 h-4 fill-current" />
                      ) : (
                        <Play className="w-4 h-4 fill-current ml-0.5" />
                      )}
                    </button>
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-bold text-white truncate">{track.title}</div>
                      <div className="text-[10px] text-slate-400 truncate mt-0.5">{track.category}</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-900">
                    <span className="text-amber-400 font-mono font-semibold">{track.duration}</span>
                    <span className="font-mono text-slate-500">{track.bpm} BPM</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
