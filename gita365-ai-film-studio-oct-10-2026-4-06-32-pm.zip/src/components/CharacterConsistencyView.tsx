import React, { useState, useEffect, useRef } from 'react';
import {
  Users,
  Sparkles,
  Lock,
  Volume2,
  Copy,
  Check,
  Plus,
  Trash2,
  Edit2,
  Sliders,
  ShieldCheck,
  UserCheck,
  Camera,
  Layers,
  Wand2,
  Upload,
  Image as ImageIcon,
  FolderOpen,
  CheckCircle2,
  X,
  UploadCloud,
  FolderHeart,
  Link2,
  Search,
  SlidersHorizontal,
  RefreshCw,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';
import { FilmProject, Character } from '../types';
import { speakText } from '../utils/audioSynth';

export interface VaultImageItem {
  id: string;
  name: string;
  url: string;
  category?: string;
  createdAt: string;
}

export const CHARACTER_STOCK_PHOTOS = [
  {
    id: 'stock-1',
    name: 'Quang GITA (Lãnh Đạo Tầm Nhìn)',
    category: 'Doanh Nhân & Diễn Giả',
    url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&auto=format&fit=crop&q=80',
    description: 'Phong thái đĩnh đạc, vest đen may đo, ánh mắt sắc bén, thần thái triệu đô',
  },
  {
    id: 'stock-2',
    name: 'Trần Mai Linh (Biên Kịch & Giám Đốc Sáng Tạo)',
    category: 'Doanh Nhân & Diễn Giả',
    url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=600&auto=format&fit=crop&q=80',
    description: 'Thanh lịch, hiện đại, phong cách nữ doanh nhân tự tin, sắc sảo',
  },
  {
    id: 'stock-3',
    name: 'Elena Vance (Nhà Khoa Học Tương Lai)',
    category: 'Điện Ảnh Hiện Đại & Hành Động',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=600&auto=format&fit=crop&q=80',
    description: 'Tóc búi cá tính, ánh nhìn tập trung, trang phục công nghệ tiên tiến',
  },
  {
    id: 'stock-4',
    name: 'Đại Sư Chơn Không (Bậc Giác Ngộ)',
    category: 'Cổ Trang & Huyền Huyễn',
    url: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=600&auto=format&fit=crop&q=80',
    description: 'Râu tóc bạc phơ, phong thái thiền định, áo tràng xám, ánh mắt từ bi',
  },
  {
    id: 'stock-5',
    name: 'Marcus Thorne (Chỉ Huy Hạm Đội)',
    category: 'Điện Ảnh Hiện Đại & Hành Động',
    url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=600&auto=format&fit=crop&q=80',
    description: 'Khuôn mặt phong trần, ánh mắt quyết đoán, áo da cổ đứng quân đội',
  },
  {
    id: 'stock-6',
    name: 'Lê Thảo My (Chiến Binh Mật Thám)',
    category: 'Điện Ảnh Hiện Đại & Hành Động',
    url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=600&auto=format&fit=crop&q=80',
    description: 'Nhanh nhẹn, trang phục tác chiến ngụy trang đêm, ánh mắt cảnh giác',
  },
  {
    id: 'stock-7',
    name: 'Võ Tướng Tây Sơn (Hùng Khí Non Sông)',
    category: 'Cổ Trang & Huyền Huyễn',
    url: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=600&auto=format&fit=crop&q=80',
    description: 'Giáp đồng cổ điển, tóc búi cao, khí phách kiên cường, ánh mắt rực lửa',
  },
  {
    id: 'stock-8',
    name: 'Công Chúa Ngọc Hân (Đoan Trang Diễm Lệ)',
    category: 'Cổ Trang & Huyền Huyễn',
    url: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=600&auto=format&fit=crop&q=80',
    description: 'Áo nhật bình cung đình, trâm ngọc cài tóc, thần thái quý phái đài các',
  },
  {
    id: 'stock-9',
    name: 'Hacker Cyberpunk K-09 (Tương Lai 2088)',
    category: 'Cyberpunk & Tương Lai',
    url: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=600&auto=format&fit=crop&q=80',
    description: 'Ánh sáng neon xanh tím, áo khoác hoodie công nghệ cao, ánh nhìn bí ẩn',
  },
  {
    id: 'stock-10',
    name: 'Giáo Sư David Spalding (Học Giả Khảo Cổ)',
    category: 'Doanh Nhân & Diễn Giả',
    url: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=600&auto=format&fit=crop&q=80',
    description: 'Mắt kính tri thức, áo vest len tweed cổ điển Anh Quốc, nụ cười thông thái',
  },
  {
    id: 'stock-11',
    name: 'Ananya (Thiếu Nữ Bản Địa Bí Ẩn)',
    category: 'Cổ Trang & Huyền Huyễn',
    url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=600&auto=format&fit=crop&q=80',
    description: 'Vòng hoa trên tóc, ánh mắt chứa đựng bí mật cổ xưa của rừng đại ngàn',
  },
  {
    id: 'stock-12',
    name: 'Đạo Diễn Trẻ Tuấn Kiệt (Gen Z Creator)',
    category: 'Tuổi Trẻ & Sáng Tạo',
    url: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=600&auto=format&fit=crop&q=80',
    description: 'Sơ mi mở cúc, tai nghe kiểm âm, phong cách đạo diễn trẻ nhiệt huyết',
  },
  {
    id: 'stock-13',
    name: 'Tiến Sĩ Vũ Minh (Chuyên Gia AI & Robot)',
    category: 'Cyberpunk & Tương Lai',
    url: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=600&auto=format&fit=crop&q=80',
    description: 'Áo blouse phòng lab công nghệ, kính hiển vi thực tế ảo holo-lens',
  },
  {
    id: 'stock-14',
    name: 'Hà Trang (MC Talkshow & Vlogger)',
    category: 'Tuổi Trẻ & Sáng Tạo',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=600&auto=format&fit=crop&q=80',
    description: 'Năng động, tươi tắn, tai nghe không dây, phong cách vlogger triệu view',
  },
];

const VAULT_STORAGE_KEY = 'gita365_character_vault_v1';

interface CharacterConsistencyViewProps {
  project: FilmProject;
  onUpdateProject: (updated: FilmProject) => void;
}

export const CharacterConsistencyView: React.FC<CharacterConsistencyViewProps> = ({
  project,
  onUpdateProject,
}) => {
  const [selectedCharacterId, setSelectedCharacterId] = useState<string>(
    project.characters[0]?.id || ''
  );
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newCharName, setNewCharName] = useState('');
  const [newCharRole, setNewCharRole] = useState<'Protagonist' | 'Antagonist' | 'Mentor' | 'Supporting' | 'Narrator'>('Protagonist');
  const [newCharContext, setNewCharContext] = useState('');
  const [newCharAvatar, setNewCharAvatar] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedToken, setCopiedToken] = useState<string | null>(null);

  // Gallery / Media Vault Modal State
  const [isGalleryModalOpen, setIsGalleryModalOpen] = useState(false);
  const [galleryTab, setGalleryTab] = useState<'stock' | 'upload' | 'vault' | 'url'>('stock');
  const [stockCategoryFilter, setStockCategoryFilter] = useState<string>('all');
  const [stockSearchQuery, setStockSearchQuery] = useState<string>('');
  const [targetCharIdForModal, setTargetCharIdForModal] = useState<string>(
    project.characters[0]?.id || ''
  );

  // User personal vault saved photos (persisted in localStorage)
  const [userVault, setUserVault] = useState<VaultImageItem[]>(() => {
    try {
      const stored = localStorage.getItem(VAULT_STORAGE_KEY);
      if (stored) return JSON.parse(stored);
    } catch (e) {
      console.error('Lỗi đọc kho ảnh cá nhân:', e);
    }
    // Default seed items if empty
    return [
      {
        id: 'vault-seed-1',
        name: 'Quang GITA - Chân dung studio 4K',
        url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&auto=format&fit=crop&q=80',
        category: 'Doanh Nhân',
        createdAt: '2026-10-09',
      },
      {
        id: 'vault-seed-2',
        name: 'Trần Mai Linh - Executive Portrait',
        url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=600&auto=format&fit=crop&q=80',
        category: 'Biên Kịch',
        createdAt: '2026-10-09',
      },
    ];
  });

  // Upload tab states
  const [uploadPreview, setUploadPreview] = useState<string | null>(null);
  const [uploadTitle, setUploadTitle] = useState<string>('');
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // URL tab states
  const [directUrlInput, setDirectUrlInput] = useState<string>('');
  const [directUrlPreview, setDirectUrlPreview] = useState<string | null>(null);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Sync selected character when target changes
  useEffect(() => {
    if (selectedCharacterId) {
      setTargetCharIdForModal(selectedCharacterId);
    }
  }, [selectedCharacterId]);

  // Persist user vault
  useEffect(() => {
    try {
      localStorage.setItem(VAULT_STORAGE_KEY, JSON.stringify(userVault));
    } catch (e) {
      console.error('Lỗi lưu kho ảnh cá nhân:', e);
    }
  }, [userVault]);

  const selectedCharacter =
    project.characters.find((c) => c.id === selectedCharacterId) || project.characters[0];

  const handleCopyPrompt = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedToken(id);
    setTimeout(() => setCopiedToken(null), 2000);
  };

  // Open Gallery for a specific character
  const openGalleryForCharacter = (charId: string, initialTab: 'stock' | 'upload' | 'vault' = 'stock') => {
    setTargetCharIdForModal(charId);
    setSelectedCharacterId(charId);
    setGalleryTab(initialTab);
    setUploadPreview(null);
    setUploadTitle('');
    setDirectUrlInput('');
    setDirectUrlPreview(null);
    setIsGalleryModalOpen(true);
  };

  // Apply chosen photo URL to the target character
  const applyPhotoToCharacter = (photoUrl: string, photoTitle: string) => {
    const charToUpdate = project.characters.find((c) => c.id === targetCharIdForModal) || selectedCharacter;
    if (!charToUpdate) return;

    const updatedChars = project.characters.map((c) =>
      c.id === charToUpdate.id ? { ...c, avatarUrl: photoUrl } : c
    );

    onUpdateProject({
      ...project,
      characters: updatedChars,
      updatedAt: new Date().toISOString(),
    });

    showToast(`Đã cập nhật diện mạo nhất quán từ kho ảnh cho nhân vật: ${charToUpdate.name}!`);
    setIsGalleryModalOpen(false);
  };

  // Handle file selection from local device
  const handleFileChange = (file: File) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      alert('Vui lòng chọn file hình ảnh hợp lệ (PNG, JPG, WebP)!');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setUploadPreview(result);
      if (!uploadTitle) {
        const cleanName = file.name.replace(/\.[^/.]+$/, '');
        setUploadTitle(cleanName);
      }
    };
    reader.readAsDataURL(file);
  };

  // Save uploaded photo to vault and optionally apply to character
  const handleSaveUploadToVaultAndApply = (applyImmediately: boolean = true) => {
    if (!uploadPreview) return;

    const newVaultItem: VaultImageItem = {
      id: `vault-${Date.now()}`,
      name: uploadTitle.trim() || `Ảnh tải lên ${new Date().toLocaleTimeString('vi-VN')}`,
      url: uploadPreview,
      category: 'Tự Tải Lên',
      createdAt: new Date().toISOString().split('T')[0],
    };

    setUserVault((prev) => [newVaultItem, ...prev]);

    if (applyImmediately) {
      applyPhotoToCharacter(uploadPreview, newVaultItem.name);
    } else {
      showToast(`Đã lưu "${newVaultItem.name}" vào Kho Ảnh Cá Nhân thành công!`);
      setUploadPreview(null);
      setUploadTitle('');
      setGalleryTab('vault');
    }
  };

  // Save direct URL to vault and apply
  const handleApplyDirectUrl = (applyImmediately: boolean = true) => {
    if (!directUrlInput.trim()) return;

    const newVaultItem: VaultImageItem = {
      id: `vault-url-${Date.now()}`,
      name: `Ảnh Link Web ${new Date().toLocaleTimeString('vi-VN')}`,
      url: directUrlInput.trim(),
      category: 'Đường Dẫn Web',
      createdAt: new Date().toISOString().split('T')[0],
    };

    setUserVault((prev) => [newVaultItem, ...prev]);

    if (applyImmediately) {
      applyPhotoToCharacter(directUrlInput.trim(), newVaultItem.name);
    } else {
      showToast('Đã lưu ảnh từ đường dẫn vào Kho Ảnh Cá Nhân!');
      setDirectUrlInput('');
      setDirectUrlPreview(null);
      setGalleryTab('vault');
    }
  };

  // Delete an item from personal vault
  const handleDeleteVaultItem = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setUserVault((prev) => prev.filter((item) => item.id !== id));
    showToast('Đã xóa ảnh khỏi Kho Ảnh Cá Nhân.');
  };

  // Generate new character via AI
  const handleGenerateCharacter = async () => {
    if (!newCharName.trim()) return;
    setIsGenerating(true);
    try {
      const response = await fetch('/api/character/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          characterName: newCharName,
          role: newCharRole,
          storyContext: newCharContext || project.title,
          visualStyle: project.visualStyle,
        }),
      });

      const data = await response.json();
      const generated = data.character;

      const newChar: Character = {
        id: `char-${Date.now()}`,
        name: generated?.name || newCharName,
        role: (generated?.role as any) || newCharRole,
        age: generated?.age || '30 tuổi',
        archetype: generated?.archetype || 'Nhân vật trung tâm',
        physicalTraits: generated?.physicalTraits || {
          face: 'Đường nét thanh tú, ánh mắt kiên định',
          hair: 'Tóc đen cắt tỉa gọn gàng',
          eyes: 'Đôi mắt nâu sâu thẳm',
          attire: 'Áo măng tô dạ sẫm màu cao cấp',
          distinguishingMarks: 'Huy hiệu cài áo đặc trưng GITA365',
        },
        voiceProfile: generated?.voiceProfile || {
          gender: 'Nam',
          accent: 'Bắc Bộ chuẩn',
          tone: 'Trầm ấm, nội lực',
          speed: 1.0,
        },
        consistencyKeyPrompt: generated?.consistencyKeyPrompt || `consistent character ${newCharName}, sharp detailed face, 8k cinematic masterpiece, 35mm photograph`,
        scenePromptVariations: generated?.scenePromptVariations || [
          {
            sceneType: 'Cận cảnh chân dung',
            prompt: `cinematic close-up portrait of ${newCharName}, natural light, 85mm lens, 8k`,
          },
          {
            sceneType: 'Toàn cảnh hành động',
            prompt: `wide action shot of ${newCharName} moving with determination, dramatic cinematic atmosphere, 8k`,
          },
        ],
        avatarUrl: newCharAvatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&auto=format&fit=crop&q=80',
        consistencyScore: 99,
      };

      const updated = {
        ...project,
        characters: [...project.characters, newChar],
      };
      onUpdateProject(updated);
      setSelectedCharacterId(newChar.id);
      setShowCreateModal(false);
      setNewCharName('');
      setNewCharContext('');
      setNewCharAvatar('');
      showToast(`Đã tạo thành công nhân vật: ${newChar.name}!`);
    } catch (err) {
      console.error('Lỗi tạo nhân vật:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDeleteCharacter = (charId: string) => {
    if (project.characters.length <= 1) return;
    const updated = {
      ...project,
      characters: project.characters.filter((c) => c.id !== charId),
    };
    onUpdateProject(updated);
    setSelectedCharacterId(updated.characters[0].id);
  };

  // Filtered Stock photos
  const filteredStockPhotos = CHARACTER_STOCK_PHOTOS.filter((photo) => {
    const matchesCategory =
      stockCategoryFilter === 'all' || photo.category.toLowerCase().includes(stockCategoryFilter.toLowerCase());
    const matchesSearch =
      !stockSearchQuery.trim() ||
      photo.name.toLowerCase().includes(stockSearchQuery.toLowerCase()) ||
      photo.description.toLowerCase().includes(stockSearchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 animate-in fade-in slide-in-from-bottom-5">
          <div className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-2.5 border border-emerald-400/40 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4 text-emerald-200" />
            <span>{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950/40 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/15 border border-indigo-500/30 text-indigo-300 text-xs font-bold uppercase tracking-wider">
              <ShieldCheck className="w-3.5 h-3.5" /> GITA365 Character Identity Lock & Face Vault
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight">
              Thiết Kế Nhân Vật Nhất Quán (Character Consistency Bible)
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              Khóa khuôn mặt, kiểu tóc, trang phục và phụ kiện của từng nhân vật qua hàng trăm phân cảnh khác nhau.
              Tải ảnh từ thiết bị hoặc chọn từ Kho Ảnh Mẫu Điện Ảnh để AI giữ đồng nhất 100% diện mạo khi render video.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => openGalleryForCharacter(selectedCharacter?.id || project.characters[0]?.id, 'stock')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-xs border border-amber-500/30 shadow-lg transition-all"
            >
              <FolderOpen className="w-4 h-4 text-amber-400" />
              <span>Mở Kho Ảnh Nhân Vật ({CHARACTER_STOCK_PHOTOS.length + userVault.length})</span>
            </button>
            <button
              onClick={() => setShowCreateModal(true)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-amber-500 hover:from-indigo-400 hover:to-amber-400 text-slate-950 font-bold text-xs shadow-lg shadow-indigo-500/20 transition-all transform hover:scale-105"
            >
              <Plus className="w-4 h-4" />
              <span>Thêm Nhân Vật Mới</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Layout: Character Selector Grid + Detail Bible */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Character List Cards (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
              <Users className="w-4 h-4 text-indigo-400" /> Danh Sách Nhân Vật ({project.characters.length})
            </h3>
            <span className="text-[11px] text-emerald-400 font-mono">Đã khóa Seed 100%</span>
          </div>

          <div className="space-y-3">
            {project.characters.map((char) => {
              const isSelected = char.id === selectedCharacter?.id;
              return (
                <div
                  key={char.id}
                  onClick={() => setSelectedCharacterId(char.id)}
                  className={`group relative p-3.5 rounded-2xl border cursor-pointer transition-all flex items-center gap-3.5 ${
                    isSelected
                      ? 'bg-slate-900/90 border-indigo-500/80 shadow-xl shadow-indigo-500/10 ring-1 ring-indigo-500/50'
                      : 'bg-slate-950/70 border-slate-800/80 hover:bg-slate-900/50 hover:border-slate-700'
                  }`}
                >
                  {/* Avatar with quick change on hover */}
                  <div className="relative w-14 h-14 rounded-xl overflow-hidden bg-slate-800 border border-slate-700 flex-shrink-0 group/av">
                    <img
                      src={char.avatarUrl}
                      alt={char.name}
                      className="w-full h-full object-cover group-hover/av:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute bottom-0 right-0 bg-slate-950/90 p-0.5 rounded-tl text-[9px] text-amber-400">
                      <Lock className="w-2.5 h-2.5" />
                    </div>
                    {/* Hover quick-change button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        openGalleryForCharacter(char.id, 'stock');
                      }}
                      className="absolute inset-0 bg-slate-950/80 opacity-0 group-hover/av:opacity-100 flex items-center justify-center transition-opacity text-amber-300"
                      title="Đổi ảnh từ kho cho nhân vật này"
                    >
                      <Camera className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <h4 className="text-xs font-bold text-white truncate">{char.name}</h4>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/15 text-indigo-300 font-medium whitespace-nowrap">
                        {char.role}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 truncate mt-0.5">{char.archetype}</p>
                    <div className="flex items-center gap-2 mt-1.5 text-[10px]">
                      <span className="text-emerald-400 font-mono flex items-center gap-1">
                        <UserCheck className="w-3 h-3" /> Độ khớp: {char.consistencyScore}%
                      </span>
                      <span className="text-slate-500">•</span>
                      <span className="text-slate-400">{char.age}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick upload card in left column */}
          <div
            onClick={() => openGalleryForCharacter(selectedCharacter?.id || project.characters[0]?.id, 'upload')}
            className="p-4 rounded-2xl border-2 border-dashed border-slate-800 hover:border-indigo-500/60 bg-slate-950/40 hover:bg-slate-900/40 transition-all cursor-pointer text-center space-y-2 group"
          >
            <div className="w-9 h-9 rounded-full bg-indigo-500/10 text-indigo-400 mx-auto flex items-center justify-center group-hover:scale-110 transition-transform">
              <UploadCloud className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-200 group-hover:text-amber-300 transition-colors block">
                Tải Ảnh Từ Kho / Máy Tính Lên
              </span>
              <span className="text-[11px] text-slate-500 block">
                PNG, JPG hoặc chọn từ kho mẫu có sẵn
              </span>
            </div>
          </div>
        </div>

        {/* Right: Detailed Character Bible (8 cols) */}
        {selectedCharacter && (
          <div className="lg:col-span-8 space-y-6">
            <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-6">
              {/* Profile Top Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
                <div className="flex items-center gap-4">
                  <div className="relative w-20 h-20 rounded-2xl overflow-hidden border-2 border-indigo-500/50 shadow-lg group flex-shrink-0">
                    <img
                      src={selectedCharacter.avatarUrl}
                      alt={selectedCharacter.name}
                      className="w-full h-full object-cover transition-transform group-hover:scale-105"
                    />
                    <div className="absolute top-1 right-1 bg-emerald-500 text-slate-950 p-0.5 rounded-full z-10">
                      <Check className="w-3 h-3" />
                    </div>
                    {/* Hover Overlay to change avatar from storage */}
                    <button
                      onClick={() => openGalleryForCharacter(selectedCharacter.id, 'stock')}
                      className="absolute inset-0 bg-slate-950/80 opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center transition-opacity text-white text-[10px] font-bold gap-1 z-20 cursor-pointer"
                      title="Tải ảnh lên hoặc chọn trong kho ảnh"
                    >
                      <Camera className="w-4 h-4 text-amber-400" />
                      <span>Đổi ảnh</span>
                    </button>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h2 className="text-xl font-bold text-white">{selectedCharacter.name}</h2>
                      <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 font-semibold">
                        {selectedCharacter.role}
                      </span>
                    </div>
                    <p className="text-xs text-amber-400 font-medium mt-0.5">
                      {selectedCharacter.archetype} • {selectedCharacter.age}
                    </p>
                    <p className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
                      <Lock className="w-3 h-3 text-emerald-400" />
                      <span>Được bảo vệ bởi GITA Seed Consistency Algorithm v3.8</span>
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {/* Tải ảnh trong kho lên Button */}
                  <button
                    onClick={() => openGalleryForCharacter(selectedCharacter.id, 'stock')}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-amber-500 hover:brightness-110 text-white text-xs font-bold border border-indigo-400/40 shadow-lg shadow-purple-600/20 transition-all transform hover:scale-[1.02]"
                    title="Mở kho ảnh hoặc tải file ảnh từ thiết bị lên"
                  >
                    <FolderOpen className="w-3.5 h-3.5 text-amber-300" />
                    <span>Tải Ảnh Trong Kho / Đổi Ảnh</span>
                  </button>

                  <button
                    onClick={() =>
                      speakText(
                        `Tôi là ${selectedCharacter.name}. Tôi đã sẵn sàng cho mọi phân cảnh của bộ phim.`,
                        selectedCharacter.voiceProfile.gender
                      )
                    }
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-all"
                  >
                    <Volume2 className="w-3.5 h-3.5 text-amber-400" />
                    <span>Thử Giọng Đọc</span>
                  </button>
                  {project.characters.length > 1 && (
                    <button
                      onClick={() => handleDeleteCharacter(selectedCharacter.id)}
                      className="p-2 rounded-xl bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 border border-rose-500/30 transition-all"
                      title="Xóa nhân vật"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Physical Identity DNA Grid */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                  <Camera className="w-4 h-4 text-indigo-400" /> Đặc Điểm Nhận Dạng Cố Định (Visual DNA)
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80">
                    <span className="text-slate-400 text-[11px] block font-semibold mb-0.5">Khuôn mặt & Biểu cảm:</span>
                    <span className="text-slate-200 font-medium">{selectedCharacter.physicalTraits.face}</span>
                  </div>
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80">
                    <span className="text-slate-400 text-[11px] block font-semibold mb-0.5">Kiểu tóc & Màu tóc:</span>
                    <span className="text-slate-200 font-medium">{selectedCharacter.physicalTraits.hair}</span>
                  </div>
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80">
                    <span className="text-slate-400 text-[11px] block font-semibold mb-0.5">Trang phục đặc trưng (Cố định):</span>
                    <span className="text-slate-200 font-medium">{selectedCharacter.physicalTraits.attire}</span>
                  </div>
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80">
                    <span className="text-slate-400 text-[11px] block font-semibold mb-0.5">Dấu hiệu nhận diện độc nhất:</span>
                    <span className="text-amber-300 font-medium">{selectedCharacter.physicalTraits.distinguishingMarks}</span>
                  </div>
                </div>
              </div>

              {/* Voice Profile Card */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-300 flex items-center gap-1.5">
                    <Volume2 className="w-4 h-4 text-amber-400" /> Hồ Sơ Giọng Nói AI (Voice Profile)
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono">Tự động lồng tiếng</span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-xs text-slate-300 pt-1">
                  <div>
                    <span className="text-slate-500 text-[10px] block">Giới tính:</span>
                    <span className="font-semibold text-white">{selectedCharacter.voiceProfile.gender}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 text-[10px] block">Giọng vùng miền:</span>
                    <span className="font-semibold text-white">{selectedCharacter.voiceProfile.accent}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 text-[10px] block">Sắc thái:</span>
                    <span className="font-semibold text-amber-300">{selectedCharacter.voiceProfile.tone}</span>
                  </div>
                </div>
              </div>

              {/* Consistency Master Prompt Box */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-300 flex items-center gap-1.5">
                    <Lock className="w-4 h-4 text-emerald-400" /> Master Consistency Prompt (Khóa Nhân Vật):
                  </span>
                  <button
                    onClick={() => handleCopyPrompt(selectedCharacter.consistencyKeyPrompt, 'master')}
                    className="flex items-center gap-1 text-xs text-amber-400 hover:text-amber-300 font-medium"
                  >
                    {copiedToken === 'master' ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Đã sao chép</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Sao chép Prompt</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 text-xs font-mono text-emerald-300/90 leading-relaxed break-words">
                  {selectedCharacter.consistencyKeyPrompt}
                </div>
                <p className="text-[11px] text-slate-500 italic">
                  💡 Prompt này được tự động chèn vào mọi phân cảnh có sự xuất hiện của {selectedCharacter.name} để AI vẽ chính xác 100%.
                </p>
              </div>

              {/* Multi-angle & Scenario Variations */}
              {selectedCharacter.scenePromptVariations && (
                <div className="space-y-3 pt-2 border-t border-slate-800">
                  <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                    <Layers className="w-4 h-4 text-indigo-400" /> Các Biến Thể Góc Máy & Tình Huống
                  </h3>
                  <div className="space-y-2">
                    {selectedCharacter.scenePromptVariations.map((v, i) => (
                      <div
                        key={i}
                        className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 flex items-start justify-between gap-3"
                      >
                        <div className="space-y-1">
                          <span className="text-xs font-bold text-indigo-300">{v.sceneType}</span>
                          <p className="text-[11px] font-mono text-slate-400 leading-tight">{v.prompt}</p>
                        </div>
                        <button
                          onClick={() => handleCopyPrompt(v.prompt, `var-${i}`)}
                          className="p-1.5 rounded-lg bg-slate-900 text-slate-400 hover:text-amber-300 transition-colors flex-shrink-0"
                          title="Sao chép"
                        >
                          {copiedToken === `var-${i}` ? (
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* ========================================================= */}
      {/* FULL-FEATURED KHO ẢNH & TẢI ẢNH MODAL (MEDIA VAULT) */}
      {/* ========================================================= */}
      {isGalleryModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-4xl bg-slate-900 border border-slate-700 rounded-3xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
            {/* Modal Header */}
            <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-indigo-600 flex items-center justify-center text-slate-950 shadow-lg shadow-indigo-500/20">
                  <FolderOpen className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-base flex items-center gap-2">
                    Kho Ảnh Nhân Vật & Tải Ảnh Lên (Face Vault)
                  </h3>
                  <p className="text-xs text-slate-400">
                    Cập nhật diện mạo nhất quán cho: <strong className="text-amber-400">{project.characters.find((c) => c.id === targetCharIdForModal)?.name || selectedCharacter?.name}</strong>
                  </p>
                </div>
              </div>

              {/* Close Button */}
              <button
                onClick={() => setIsGalleryModalOpen(false)}
                className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Target Character Quick Selector */}
            <div className="px-5 py-3 bg-slate-950/80 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-xs">
                <span className="text-slate-400 font-medium">Áp dụng cho nhân vật:</span>
                <select
                  value={targetCharIdForModal}
                  onChange={(e) => setTargetCharIdForModal(e.target.value)}
                  className="bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1 text-white font-semibold focus:outline-none focus:border-amber-500"
                >
                  {project.characters.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.role})
                    </option>
                  ))}
                </select>
              </div>

              {/* Tab Navigation */}
              <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs font-semibold">
                <button
                  onClick={() => setGalleryTab('stock')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                    galleryTab === 'stock'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <ImageIcon className="w-3.5 h-3.5" />
                  <span>Kho Mẫu Điện Ảnh ({CHARACTER_STOCK_PHOTOS.length})</span>
                </button>
                <button
                  onClick={() => setGalleryTab('upload')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                    galleryTab === 'upload'
                      ? 'bg-amber-500 text-slate-950 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <UploadCloud className="w-3.5 h-3.5" />
                  <span>Tải File Từ Máy</span>
                </button>
                <button
                  onClick={() => setGalleryTab('vault')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                    galleryTab === 'vault'
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <FolderHeart className="w-3.5 h-3.5" />
                  <span>Kho Của Tôi ({userVault.length})</span>
                </button>
                <button
                  onClick={() => setGalleryTab('url')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                    galleryTab === 'url'
                      ? 'bg-slate-800 text-cyan-300 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Link2 className="w-3.5 h-3.5" />
                  <span>Link Ảnh Web</span>
                </button>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-5 flex-1 overflow-y-auto space-y-4">
              {/* TAB 1: STOCK GALLERY */}
              {galleryTab === 'stock' && (
                <div className="space-y-4">
                  {/* Filter & Search Bar */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    {/* Category Filter Pills */}
                    <div className="flex flex-wrap items-center gap-1.5 text-xs">
                      {[
                        { id: 'all', label: 'Tất Cả' },
                        { id: 'Doanh Nhân', label: 'Doanh Nhân & Diễn Giả' },
                        { id: 'Hiện Đại', label: 'Điện Ảnh Hiện Đại' },
                        { id: 'Cổ Trang', label: 'Cổ Trang & Huyền Huyễn' },
                        { id: 'Cyberpunk', label: 'Cyberpunk & Sci-Fi' },
                        { id: 'Sáng Tạo', label: 'Tuổi Trẻ & Sáng Tạo' },
                      ].map((cat) => (
                        <button
                          key={cat.id}
                          onClick={() => setStockCategoryFilter(cat.id)}
                          className={`px-3 py-1 rounded-full border transition-all ${
                            stockCategoryFilter === cat.id
                              ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500 font-bold'
                              : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          {cat.label}
                        </button>
                      ))}
                    </div>

                    {/* Search */}
                    <div className="relative sm:w-64">
                      <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500" />
                      <input
                        type="text"
                        value={stockSearchQuery}
                        onChange={(e) => setStockSearchQuery(e.target.value)}
                        placeholder="Tìm nhân vật, phong thái..."
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                      />
                    </div>
                  </div>

                  {/* Stock Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                    {filteredStockPhotos.map((item) => (
                      <div
                        key={item.id}
                        className="group relative bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden hover:border-indigo-500/80 hover:shadow-xl hover:shadow-indigo-500/10 transition-all flex flex-col"
                      >
                        <div className="aspect-square relative overflow-hidden bg-slate-900">
                          <img
                            src={item.url}
                            alt={item.name}
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                            loading="lazy"
                          />
                          <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-md text-[9px] text-amber-300 font-medium">
                            {item.category}
                          </div>
                          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-2.5">
                            <button
                              onClick={() => applyPhotoToCharacter(item.url, item.name)}
                              className="w-full py-1.5 px-2 bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-bold text-[11px] rounded-lg shadow-lg flex items-center justify-center gap-1"
                            >
                              <Check className="w-3 h-3" />
                              <span>Chọn Nhân Vật Này</span>
                            </button>
                          </div>
                        </div>

                        <div className="p-3 flex-1 flex flex-col justify-between">
                          <div>
                            <h4 className="text-xs font-bold text-white group-hover:text-amber-300 transition-colors line-clamp-1">
                              {item.name}
                            </h4>
                            <p className="text-[10px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                              {item.description}
                            </p>
                          </div>

                          <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px]">
                            <span className="text-emerald-400 font-mono">Đã khóa 8K</span>
                            <button
                              onClick={() => applyPhotoToCharacter(item.url, item.name)}
                              className="text-indigo-400 hover:text-indigo-300 font-semibold"
                            >
                              Áp dụng →
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {filteredStockPhotos.length === 0 && (
                    <div className="py-12 text-center text-slate-500 text-xs">
                      Không tìm thấy ảnh mẫu phù hợp với từ khóa "{stockSearchQuery}".
                    </div>
                  )}
                </div>
              )}

              {/* TAB 2: UPLOAD FILE FROM LOCAL DEVICE */}
              {galleryTab === 'upload' && (
                <div className="space-y-5 max-w-xl mx-auto py-2">
                  <div
                    onDragOver={(e) => {
                      e.preventDefault();
                      setIsDragging(true);
                    }}
                    onDragLeave={() => setIsDragging(false)}
                    onDrop={(e) => {
                      e.preventDefault();
                      setIsDragging(false);
                      if (e.dataTransfer.files?.[0]) {
                        handleFileChange(e.dataTransfer.files[0]);
                      }
                    }}
                    onClick={() => fileInputRef.current?.click()}
                    className={`border-2 border-dashed rounded-3xl p-8 text-center cursor-pointer transition-all ${
                      isDragging
                        ? 'border-amber-400 bg-amber-500/10 scale-[1.01]'
                        : uploadPreview
                        ? 'border-emerald-500/50 bg-slate-950'
                        : 'border-slate-700 hover:border-amber-500/60 bg-slate-950/60 hover:bg-slate-950'
                    }`}
                  >
                    <input
                      type="file"
                      ref={fileInputRef}
                      className="hidden"
                      accept="image/png,image/jpeg,image/webp,image/jpg"
                      onChange={(e) => {
                        if (e.target.files?.[0]) {
                          handleFileChange(e.target.files[0]);
                        }
                      }}
                    />

                    {uploadPreview ? (
                      <div className="space-y-3">
                        <div className="w-36 h-36 rounded-2xl mx-auto overflow-hidden border-2 border-emerald-500 shadow-xl relative group">
                          <img
                            src={uploadPreview}
                            alt="Preview"
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="text-xs text-emerald-400 font-bold flex items-center justify-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Đã tải ảnh lên thành công. Bấm để chọn ảnh khác!</span>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        <div className="w-16 h-16 rounded-2xl bg-amber-500/10 text-amber-400 mx-auto flex items-center justify-center shadow-lg">
                          <UploadCloud className="w-8 h-8" />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-white">
                            Kéo thả ảnh chân dung vào đây hoặc nhấp để chọn file
                          </p>
                          <p className="text-xs text-slate-400 mt-1">
                            Hỗ trợ PNG, JPG, WebP. Nên dùng ảnh cận cảnh rõ nét khuôn mặt để AI nhận diện tốt nhất.
                          </p>
                        </div>
                      </div>
                    )}
                  </div>

                  {uploadPreview && (
                    <div className="space-y-3 bg-slate-950 p-4 rounded-2xl border border-slate-800">
                      <div>
                        <label className="text-slate-300 font-semibold text-xs mb-1 block">
                          Tên nhận diện hình ảnh (để lưu vào kho):
                        </label>
                        <input
                          type="text"
                          value={uploadTitle}
                          onChange={(e) => setUploadTitle(e.target.value)}
                          placeholder="Ví dụ: Quang GITA - Vest Đen 4K"
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                        />
                      </div>

                      <div className="pt-2 flex flex-col sm:flex-row items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleSaveUploadToVaultAndApply(true)}
                          className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-bold text-xs shadow-lg flex items-center justify-center gap-2 hover:scale-[1.01] transition-transform"
                        >
                          <Check className="w-4 h-4" />
                          <span>Lưu Vào Kho & Áp Dụng Ngay Cho Nhân Vật</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSaveUploadToVaultAndApply(false)}
                          className="w-full sm:w-auto py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700 flex items-center justify-center gap-2"
                        >
                          <FolderHeart className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Chỉ Lưu Kho</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* TAB 3: USER PERSONAL VAULT */}
              {galleryTab === 'vault' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-white flex items-center gap-2">
                        <FolderHeart className="w-4 h-4 text-emerald-400" /> Kho Ảnh Cá Nhân Của Bạn ({userVault.length})
                      </h4>
                      <p className="text-[11px] text-slate-400">
                        Những hình ảnh bạn đã tải lên hoặc thêm từ link, được lưu trữ an toàn để tái sử dụng mọi lúc.
                      </p>
                    </div>
                    <button
                      onClick={() => setGalleryTab('upload')}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs shadow-md"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Tải Ảnh Mới</span>
                    </button>
                  </div>

                  {userVault.length === 0 ? (
                    <div className="py-12 text-center space-y-3 bg-slate-950 rounded-2xl border border-slate-800">
                      <div className="w-12 h-12 rounded-full bg-slate-800 text-slate-500 mx-auto flex items-center justify-center">
                        <FolderOpen className="w-6 h-6" />
                      </div>
                      <p className="text-xs text-slate-400">Kho ảnh cá nhân đang trống.</p>
                      <button
                        onClick={() => setGalleryTab('upload')}
                        className="px-4 py-2 bg-indigo-600 text-white text-xs font-bold rounded-xl"
                      >
                        Tải ảnh đầu tiên lên ngay
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                      {userVault.map((item) => (
                        <div
                          key={item.id}
                          className="group relative bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden hover:border-emerald-500 transition-all flex flex-col"
                        >
                          <div className="aspect-square relative overflow-hidden bg-slate-900">
                            <img
                              src={item.url}
                              alt={item.name}
                              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                            />
                            {/* Delete button */}
                            <button
                              onClick={(e) => handleDeleteVaultItem(item.id, e)}
                              className="absolute top-2 right-2 p-1.5 rounded-lg bg-black/70 hover:bg-rose-600 text-slate-400 hover:text-white transition-colors"
                              title="Xóa khỏi kho"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>

                            {/* Select button overlay */}
                            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-2.5">
                              <button
                                onClick={() => applyPhotoToCharacter(item.url, item.name)}
                                className="w-full py-1.5 px-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-[11px] rounded-lg shadow-lg flex items-center justify-center gap-1"
                              >
                                <Check className="w-3 h-3" />
                                <span>Áp Dụng Cho Nhân Vật</span>
                              </button>
                            </div>
                          </div>

                          <div className="p-2.5">
                            <h5 className="text-xs font-bold text-white truncate">{item.name}</h5>
                            <span className="text-[10px] text-slate-500 block mt-0.5">{item.createdAt}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 4: DIRECT URL */}
              {galleryTab === 'url' && (
                <div className="space-y-4 max-w-lg mx-auto py-2">
                  <div className="space-y-2">
                    <label className="text-slate-300 font-semibold text-xs block">
                      Dán link hình ảnh trực tiếp (HTTPS):
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="url"
                        value={directUrlInput}
                        onChange={(e) => {
                          setDirectUrlInput(e.target.value);
                          setDirectUrlPreview(e.target.value);
                        }}
                        placeholder="https://images.unsplash.com/... hoặc link ảnh CDN"
                        className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                      />
                    </div>
                  </div>

                  {directUrlPreview && (
                    <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
                      <div className="w-36 h-36 rounded-2xl mx-auto overflow-hidden border border-cyan-500/50 shadow-md">
                        <img
                          src={directUrlPreview}
                          alt="URL Preview"
                          className="w-full h-full object-cover"
                          onError={() => {
                            // Invalid URL preview fallback
                          }}
                        />
                      </div>
                      <div className="flex items-center gap-2 justify-center">
                        <button
                          type="button"
                          onClick={() => handleApplyDirectUrl(true)}
                          className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs"
                        >
                          Áp Dụng Ngay Cho Nhân Vật
                        </button>
                        <button
                          type="button"
                          onClick={() => handleApplyDirectUrl(false)}
                          className="px-4 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-semibold"
                        >
                          Lưu Vào Kho
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between text-xs text-slate-400">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Mọi ảnh tải lên được tự động bảo toàn tỷ lệ khuôn mặt 8K trong kịch bản.</span>
              </span>
              <button
                type="button"
                onClick={() => setIsGalleryModalOpen(false)}
                className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: CREATE CHARACTER WITH AI & PHOTO PICKER */}
      {/* ========================================================= */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-lg bg-slate-900 rounded-3xl border border-slate-800 p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-400" /> Tạo Nhân Vật Nhất Quán Mới
              </h3>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3.5 text-xs">
              <div>
                <label className="text-slate-300 font-semibold mb-1 block">Tên nhân vật:</label>
                <input
                  type="text"
                  value={newCharName}
                  onChange={(e) => setNewCharName(e.target.value)}
                  placeholder="Ví dụ: Quang GITA, Elena, Đại Sư, Thảo My..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold mb-1 block">Vai trò trong kịch bản:</label>
                <select
                  value={newCharRole}
                  onChange={(e) => setNewCharRole(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                >
                  <option value="Protagonist">Nhân vật chính (Protagonist)</option>
                  <option value="Antagonist">Nhân vật phản diện / Đối trọng (Antagonist)</option>
                  <option value="Mentor">Người thầy / Bậc giác ngộ (Mentor)</option>
                  <option value="Supporting">Nhân vật phụ quan trọng (Supporting)</option>
                  <option value="Narrator">Người kể chuyện (Narrator)</option>
                </select>
              </div>

              {/* Photo selection for new character */}
              <div>
                <label className="text-slate-300 font-semibold mb-1 block flex items-center justify-between">
                  <span>Ảnh đại diện ban đầu (Chọn mẫu từ kho hoặc giữ mặc định):</span>
                  {newCharAvatar && (
                    <span className="text-[10px] text-emerald-400 font-mono">Đã chọn ảnh mẫu</span>
                  )}
                </label>
                <div className="grid grid-cols-4 gap-2 pt-1">
                  {CHARACTER_STOCK_PHOTOS.slice(0, 4).map((item) => (
                    <div
                      key={item.id}
                      onClick={() => setNewCharAvatar(item.url)}
                      className={`relative aspect-square rounded-xl overflow-hidden border-2 cursor-pointer transition-all ${
                        newCharAvatar === item.url
                          ? 'border-amber-400 ring-2 ring-amber-400/50 scale-105'
                          : 'border-slate-800 hover:border-slate-600'
                      }`}
                    >
                      <img src={item.url} alt={item.name} className="w-full h-full object-cover" />
                      {newCharAvatar === item.url && (
                        <div className="absolute top-1 right-1 bg-amber-400 text-slate-950 p-0.5 rounded-full">
                          <Check className="w-2.5 h-2.5" />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-semibold mb-1 block">Bối cảnh / Mô tả sơ bộ:</label>
                <textarea
                  rows={2}
                  value={newCharContext}
                  onChange={(e) => setNewCharContext(e.target.value)}
                  placeholder="Mô tả tuổi tác, nghề nghiệp, tính cách hoặc mong muốn của bạn..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-xs"
              >
                Hủy
              </button>
              <button
                type="button"
                onClick={handleGenerateCharacter}
                disabled={isGenerating || !newCharName.trim()}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-bold text-xs shadow-lg flex items-center gap-2 disabled:opacity-50"
              >
                {isGenerating ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                    <span>Đang Tạo Nhân Vật...</span>
                  </>
                ) : (
                  <>
                    <Wand2 className="w-3.5 h-3.5" />
                    <span>Khởi Tạo Bằng AI</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
