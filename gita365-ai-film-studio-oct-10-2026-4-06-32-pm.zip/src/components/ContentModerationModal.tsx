import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  X,
  Sparkles,
  RefreshCw,
  ExternalLink,
  ChevronRight,
  Wand2,
  Film,
  Layers,
  ArrowRight,
  Check,
  Youtube,
  Share2,
} from 'lucide-react';
import { Scene, FilmProject } from '../types';

export interface ModerationFlag {
  category: string;
  severity: 'low' | 'medium' | 'high';
  reason: string;
  flaggedText: string;
  suggestedFix: string;
}

export interface SceneModerationResult {
  sceneId: string;
  sceneNumber: number;
  status: 'safe' | 'warning' | 'violation';
  safetyScore: number;
  summary: string;
  flags: ModerationFlag[];
  platformSuitability: {
    youtube: string;
    tiktok: string;
    facebook: string;
  };
}

interface ContentModerationModalProps {
  isOpen: boolean;
  onClose: () => void;
  scenes: Scene[];
  currentSceneIdx: number;
  onSelectScene: (idx: number) => void;
  onApplySanitizedScene: (sceneId: string, sanitized: Partial<Scene>) => void;
  onProceedToRender?: () => void;
}

export const ContentModerationModal: React.FC<ContentModerationModalProps> = ({
  isOpen,
  onClose,
  scenes,
  currentSceneIdx,
  onSelectScene,
  onApplySanitizedScene,
  onProceedToRender,
}) => {
  const [isScanning, setIsScanning] = useState(false);
  const [overallStatus, setOverallStatus] = useState<'safe' | 'warning' | 'violation'>('safe');
  const [overallScore, setOverallScore] = useState<number>(95);
  const [results, setResults] = useState<SceneModerationResult[]>([]);
  const [activeTabSceneId, setActiveTabSceneId] = useState<string>(scenes[currentSceneIdx]?.id || scenes[0]?.id || '');
  const [sanitizingSceneId, setSanitizingSceneId] = useState<string | null>(null);
  const [appliedSceneIds, setAppliedSceneIds] = useState<Set<string>>(new Set());

  // Run moderation scan
  const runScan = async () => {
    setIsScanning(true);
    try {
      const response = await fetch('/api/moderation/check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scenes }),
      });
      const data = await response.json();
      if (data.success && data.results) {
        setResults(data.results);
        setOverallStatus(data.overallStatus || 'safe');
        setOverallScore(data.overallScore ?? 95);
      }
    } catch (err) {
      console.error('Moderation scan error:', err);
    } finally {
      setIsScanning(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      runScan();
    }
  }, [isOpen, scenes]);

  if (!isOpen) return null;

  const currentResult = results.find((r) => r.sceneId === activeTabSceneId) || results[0];
  const flaggedCount = results.filter((r) => r.status !== 'safe').length;
  const violationCount = results.filter((r) => r.status === 'violation').length;

  // Auto-sanitize scene
  const handleAutoSanitize = async (sceneId: string) => {
    const sceneToSanitize = scenes.find((s) => s.id === sceneId);
    if (!sceneToSanitize) return;

    setSanitizingSceneId(sceneId);
    try {
      const response = await fetch('/api/moderation/sanitize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scene: sceneToSanitize }),
      });
      const data = await response.json();
      if (data.success && data.sanitizedScene) {
        onApplySanitizedScene(sceneId, data.sanitizedScene);
        setAppliedSceneIds((prev) => new Set(prev).add(sceneId));

        // Optimistically update the result to safe
        setResults((prev) =>
          prev.map((r) =>
            r.sceneId === sceneId
              ? {
                  ...r,
                  status: 'safe',
                  safetyScore: 98,
                  summary: 'Đã áp dụng phương án viết lại điện ảnh an toàn 100%.',
                  flags: [],
                }
              : r
          )
        );
      }
    } catch (err) {
      console.error('Auto sanitize error:', err);
    } finally {
      setSanitizingSceneId(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-800 bg-slate-950/70 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-2xl flex items-center justify-center shadow-lg ${
                overallStatus === 'safe'
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-emerald-500/10'
                  : overallStatus === 'warning'
                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40 shadow-amber-500/10'
                  : 'bg-rose-500/20 text-rose-400 border border-rose-500/40 shadow-rose-500/10'
              }`}
            >
              {overallStatus === 'safe' ? (
                <ShieldCheck className="w-5 h-5" />
              ) : (
                <ShieldAlert className="w-5 h-5" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base text-white">
                  Bộ Lọc Kiểm Duyệt & Tiêu Chuẩn Cộng Đồng (Content Moderation Filter)
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                  Pre-Render Gate
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Đối chiếu kịch bản, lời thoại và visual prompt với chính sách xuất bản của YouTube, TikTok và Facebook.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={runScan}
              disabled={isScanning}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
              title="Quét lại toàn bộ phim"
            >
              <RefreshCw className={`w-4 h-4 ${isScanning ? 'animate-spin text-amber-400' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Executive Safety Summary Bar */}
        <div className="px-6 py-4 bg-slate-950/40 border-b border-slate-800 grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
          <div className="bg-slate-900/80 p-3 rounded-2xl border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-bold">Chỉ Số An Toàn</span>
              <div className="text-xl font-black text-white mt-0.5 flex items-center gap-1.5">
                <span
                  className={
                    overallScore >= 85
                      ? 'text-emerald-400'
                      : overallScore >= 65
                      ? 'text-amber-400'
                      : 'text-rose-400'
                  }
                >
                  {overallScore}/100
                </span>
              </div>
            </div>
            <span
              className={`px-2.5 py-1 rounded-xl text-[10px] font-bold ${
                overallStatus === 'safe'
                  ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                  : overallStatus === 'warning'
                  ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                  : 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
              }`}
            >
              {overallStatus === 'safe'
                ? 'Đạt Chuẩn'
                : overallStatus === 'warning'
                ? 'Cần Chú Ý'
                : 'Nguy Cơ Cao'}
            </span>
          </div>

          <div className="bg-slate-900/80 p-3 rounded-2xl border border-slate-800">
            <span className="text-[10px] text-slate-500 uppercase font-bold">Cảnh Báo / Rủi Ro</span>
            <div className="text-xl font-black text-white mt-0.5">
              <span className={flaggedCount > 0 ? 'text-amber-400' : 'text-slate-300'}>
                {flaggedCount}
              </span>
              <span className="text-slate-500 text-xs font-normal"> / {scenes.length} cảnh</span>
            </div>
          </div>

          <div className="bg-slate-900/80 p-3 rounded-2xl border border-slate-800 sm:col-span-2 flex flex-col justify-between">
            <span className="text-[10px] text-slate-500 uppercase font-bold">Trạng Thái Sẵn Sàng Xuất Bản</span>
            <div className="flex items-center gap-3 text-[11px] text-slate-300 mt-1">
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-red-500" />
                YouTube: <strong className="text-slate-200">Bật Kiếm Tiền</strong>
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-cyan-400" />
                TikTok: <strong className="text-slate-200">Đạt Chuẩn FYP</strong>
              </span>
            </div>
          </div>
        </div>

        {/* Content Body: Left scene navigation, Right scene report */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 flex flex-col md:flex-row gap-6">
          {/* Left: Scenes List with status badges */}
          <div className="w-full md:w-72 space-y-2 shrink-0">
            <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
              <span>Danh Sách Phân Cảnh ({scenes.length})</span>
              {isScanning && <span className="text-amber-400 font-normal animate-pulse">Đang quét AI...</span>}
            </h4>

            <div className="space-y-1.5 max-h-96 overflow-y-auto pr-1">
              {scenes.map((sc, sIdx) => {
                const res = results.find((r) => r.sceneId === sc.id);
                const isSelected = activeTabSceneId === sc.id;
                const status = res?.status || 'safe';
                const hasApplied = appliedSceneIds.has(sc.id);

                return (
                  <button
                    key={sc.id}
                    onClick={() => {
                      setActiveTabSceneId(sc.id);
                      onSelectScene(sIdx);
                    }}
                    className={`w-full text-left p-2.5 rounded-2xl border transition-all text-xs flex items-center justify-between gap-2 ${
                      isSelected
                        ? 'bg-slate-800 border-amber-500/60 shadow-md ring-1 ring-amber-500/30'
                        : 'bg-slate-950/60 border-slate-800/80 hover:bg-slate-850'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span className="w-6 h-6 rounded-lg bg-slate-900 border border-slate-700 flex items-center justify-center font-mono text-[10px] text-slate-300 shrink-0">
                        #{sc.sceneNumber}
                      </span>
                      <span className="font-semibold text-slate-200 truncate">
                        {sc.title || `Cảnh ${sc.sceneNumber}`}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {hasApplied && (
                        <span className="w-2 h-2 rounded-full bg-emerald-400" title="Đã sửa an toàn" />
                      )}
                      <span
                        className={`w-2.5 h-2.5 rounded-full ${
                          status === 'safe'
                            ? 'bg-emerald-400'
                            : status === 'warning'
                            ? 'bg-amber-400 animate-pulse'
                            : 'bg-rose-500 animate-ping'
                        }`}
                      />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right: Detailed report of currently viewed scene */}
          <div className="flex-1 space-y-4">
            {currentResult ? (
              <div className="space-y-4">
                {/* Scene title & score */}
                <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 flex items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs text-amber-400 font-bold">
                        PHÂN CẢNH #{currentResult.sceneNumber}
                      </span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          currentResult.status === 'safe'
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : currentResult.status === 'warning'
                            ? 'bg-amber-500/20 text-amber-300'
                            : 'bg-rose-500/20 text-rose-300'
                        }`}
                      >
                        {currentResult.status === 'safe'
                          ? 'An Toàn 100%'
                          : currentResult.status === 'warning'
                          ? 'Cần Thận Trọng'
                          : 'Cảnh Báo Vi Phạm'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                      {currentResult.summary}
                    </p>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-[10px] text-slate-500 uppercase block font-semibold">Điểm An Toàn</span>
                    <span
                      className={`text-2xl font-black font-mono ${
                        currentResult.safetyScore >= 85
                          ? 'text-emerald-400'
                          : currentResult.safetyScore >= 65
                          ? 'text-amber-400'
                          : 'text-rose-400'
                      }`}
                    >
                      {currentResult.safetyScore}
                    </span>
                  </div>
                </div>

                {/* Flags list */}
                {currentResult.flags.length > 0 ? (
                  <div className="space-y-3">
                    <h5 className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                      Yếu Tố Cần Lưu Ý & Khuyến Nghị Tinh Chỉnh ({currentResult.flags.length})
                    </h5>

                    {currentResult.flags.map((flag, idx) => (
                      <div
                        key={idx}
                        className="bg-slate-950/80 p-4 rounded-2xl border border-amber-500/30 space-y-2.5"
                      >
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-amber-300 flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-amber-400" />
                            {flag.category}
                          </span>
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 text-slate-400">
                            Mức độ: {flag.severity === 'high' ? 'Nghiêm trọng' : flag.severity === 'medium' ? 'Trung bình' : 'Nhẹ'}
                          </span>
                        </div>

                        <p className="text-xs text-slate-300">{flag.reason}</p>

                        <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800 text-[11px] space-y-1">
                          <div className="text-rose-400 font-mono">
                            ✕ Từ ngữ/chi tiết nhạy cảm: <strong className="underline">{flag.flaggedText}</strong>
                          </div>
                          <div className="text-emerald-400 flex items-center gap-1">
                            <Check className="w-3 h-3" />
                            <span>Gợi ý thay thế: <strong>{flag.suggestedFix}</strong></span>
                          </div>
                        </div>
                      </div>
                    ))}

                    {/* Auto-Sanitize button */}
                    <div className="pt-1">
                      <button
                        onClick={() => handleAutoSanitize(currentResult.sceneId)}
                        disabled={sanitizingSceneId === currentResult.sceneId}
                        className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:brightness-110 text-white font-bold text-xs shadow-lg shadow-emerald-600/20 transition-all"
                      >
                        {sanitizingSceneId === currentResult.sceneId ? (
                          <>
                            <RefreshCw className="w-4 h-4 animate-spin" />
                            <span>Đang tinh chỉnh kịch bản bằng AI...</span>
                          </>
                        ) : (
                          <>
                            <Wand2 className="w-4 h-4" />
                            <span>1-Click Tự Động Sửa Kịch Bản Chuẩn Điện Ảnh An Toàn</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="bg-emerald-950/20 border border-emerald-500/30 rounded-2xl p-6 text-center space-y-2">
                    <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
                    <h5 className="font-bold text-white text-sm">Phân cảnh hoàn hảo!</h5>
                    <p className="text-xs text-slate-400 max-w-md mx-auto">
                      Không phát hiện từ ngữ thô tục, bạo lực máu me hoặc hình ảnh vi phạm chính sách cộng đồng.
                    </p>
                  </div>
                )}

                {/* Platform suitability details */}
                <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2 text-xs">
                  <h5 className="font-bold text-slate-300 text-xs">Đánh Giá Phân Phối Đa Nền Tảng:</h5>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px]">
                    <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800/80">
                      <span className="font-bold text-red-400 block mb-1">YouTube</span>
                      <span className="text-slate-300">{currentResult.platformSuitability.youtube}</span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800/80">
                      <span className="font-bold text-cyan-400 block mb-1">TikTok</span>
                      <span className="text-slate-300">{currentResult.platformSuitability.tiktok}</span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800/80">
                      <span className="font-bold text-blue-400 block mb-1">Facebook Reels</span>
                      <span className="text-slate-300">{currentResult.platformSuitability.facebook}</span>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-12 text-center text-slate-500">
                <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-2 text-amber-400" />
                <span>Đang phân tích dữ liệu kiểm duyệt...</span>
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between gap-3">
          <div className="text-xs text-slate-400">
            {violationCount > 0 ? (
              <span className="text-rose-400 font-semibold flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5" />
                Có {violationCount} phân cảnh nguy cơ cao trước khi render
              </span>
            ) : (
              <span className="text-emerald-400 font-semibold flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Toàn bộ kịch bản đã sẵn sàng render chuẩn quốc tế
              </span>
            )}
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              Đóng
            </button>
            {onProceedToRender && (
              <button
                onClick={() => {
                  onClose();
                  onProceedToRender();
                }}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:brightness-110 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/20 transition-all"
              >
                <Sparkles className="w-4 h-4 stroke-[3]" />
                <span>Tiến Hành Render 4K</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
