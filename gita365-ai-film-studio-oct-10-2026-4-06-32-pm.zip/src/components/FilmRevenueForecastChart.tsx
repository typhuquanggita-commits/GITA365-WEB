import React, { useState, useMemo } from 'react';
import {
  TrendingUp,
  DollarSign,
  PieChart,
  BarChart3,
  Calendar,
  Sparkles,
  Sliders,
  CheckCircle2,
  Clock,
  ArrowUpRight,
  ShieldAlert,
  Percent,
  Download,
  Copy,
  Check,
  RefreshCw,
  Film,
  Zap,
  Info,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { FilmProject } from '../types';

interface FilmRevenueForecastChartProps {
  project: FilmProject;
}

export const FilmRevenueForecastChart: React.FC<FilmRevenueForecastChartProps> = ({ project }) => {
  // Configurable Project & Market Parameters
  const [episodeCount, setEpisodeCount] = useState<number>(project.episodeCount || 3);
  const [episodeDuration, setEpisodeDuration] = useState<number>(project.episodeDurationMinutes || 15);
  const [resolutionTier, setResolutionTier] = useState<'1080p' | '4K' | '8K'>('4K');
  const [targetViewsPerEp, setTargetViewsPerEp] = useState<number>(350000);
  const [avgCpmVND, setAvgCpmVND] = useState<number>(55000); // 55,000 VND / 1,000 views
  const [sponsorDeals, setSponsorDeals] = useState<number>(2); // 2 brand sponsor placements
  const [sponsorDealValueVND, setSponsorDealValueVND] = useState<number>(45000000); // 45,000,000 VND / deal
  const [enableCrossSell, setEnableCrossSell] = useState<boolean>(true); // GITA courses & books
  const [costPerEpisodeVND, setCostPerEpisodeVND] = useState<number>(8500000); // AI prompt & GPU render cost per episode

  // Display modes
  const [chartViewMode, setChartViewMode] = useState<'monthly' | 'cumulative'>('monthly');
  const [selectedScenario, setSelectedScenario] = useState<'all' | 'realistic' | 'conservative' | 'optimistic'>('all');
  const [hoveredMonthIndex, setHoveredMonthIndex] = useState<number | null>(null);
  const [showDataTable, setShowDataTable] = useState<boolean>(false);
  const [copiedData, setCopiedData] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);

  // Dynamic calculations based on user input and project config
  const calculations = useMemo(() => {
    // Quality RPM multiplier (4K and 8K command higher ad rates and brand prestige)
    const qualityMultiplier = resolutionTier === '8K' ? 1.6 : resolutionTier === '4K' ? 1.35 : 1.0;
    
    // Duration engagement multiplier (10-30m mini-series have optimal mid-roll ad slots)
    const durationMultiplier = episodeDuration >= 20 ? 1.3 : episodeDuration >= 12 ? 1.15 : 1.0;

    // Total projected views across season
    const totalProjectedViews = episodeCount * targetViewsPerEp;

    // Stream 1: Ad Revenue (YouTube AdSense 4K, Premium, TikTok Creator Rewards)
    const baseAdRevenueVND = (totalProjectedViews / 1000) * avgCpmVND * qualityMultiplier * durationMultiplier;
    const youtubeShareVND = baseAdRevenueVND * 0.65;
    const tiktokShareVND = baseAdRevenueVND * 0.35;

    // Stream 2: Brand Placement / Sponsorship Deals
    const totalSponsorRevenueVND = sponsorDeals * sponsorDealValueVND;

    // Stream 3: Cross-sell GITA books, audiobooks, masterclasses (0.15% conversion @ 290,000 VND)
    const crossSellRevenueVND = enableCrossSell ? totalProjectedViews * 0.0015 * 290000 : 0;

    // Total Projected 1-Year Revenue (Realistic Scenario)
    const totalProjectedRevenueRealistic = Math.round(
      youtubeShareVND + tiktokShareVND + totalSponsorRevenueVND + crossSellRevenueVND
    );

    // Conservative (58% of realistic) & Optimistic (185% of realistic)
    const totalProjectedRevenueConservative = Math.round(totalProjectedRevenueRealistic * 0.58);
    const totalProjectedRevenueOptimistic = Math.round(totalProjectedRevenueRealistic * 1.85);

    // Total production cost (AI tools, render tokens, human polishing)
    const totalProductionCost = episodeCount * costPerEpisodeVND;

    // Net Profit & ROI
    const netProfitRealistic = totalProjectedRevenueRealistic - totalProductionCost;
    const roiRealistic = totalProductionCost > 0 ? Math.round((netProfitRealistic / totalProductionCost) * 100) : 0;

    // Monthly Distribution Ramping Curve (T1 to T12)
    // Month 1-2 ramp up, Month 3-6 peak release, Month 7-12 evergreen long-tail
    const monthlyWeights = [0.035, 0.065, 0.11, 0.14, 0.13, 0.11, 0.09, 0.08, 0.07, 0.06, 0.05, 0.05];

    let runningCumulativeRealistic = 0;
    let runningCumulativeConservative = 0;
    let runningCumulativeOptimistic = 0;
    let breakEvenMonth = 12;
    let breakEvenFound = false;

    const monthlyBreakdown = monthlyWeights.map((weight, index) => {
      const monthName = `T${index + 1}`;
      const realistic = Math.round(totalProjectedRevenueRealistic * weight);
      const conservative = Math.round(totalProjectedRevenueConservative * weight);
      const optimistic = Math.round(totalProjectedRevenueOptimistic * weight);

      runningCumulativeRealistic += realistic;
      runningCumulativeConservative += conservative;
      runningCumulativeOptimistic += optimistic;

      if (!breakEvenFound && runningCumulativeRealistic >= totalProductionCost) {
        breakEvenMonth = Number((index + 1 - (runningCumulativeRealistic - totalProductionCost) / realistic).toFixed(1));
        breakEvenFound = true;
      }

      return {
        month: monthName,
        monthIndex: index + 1,
        weight,
        realistic,
        conservative,
        optimistic,
        cumulativeRealistic: runningCumulativeRealistic,
        cumulativeConservative: runningCumulativeConservative,
        cumulativeOptimistic: runningCumulativeOptimistic,
        views: Math.round(totalProjectedViews * weight),
      };
    });

    if (!breakEvenFound) {
      breakEvenMonth = 12;
    }

    // Revenue streams percentage
    const streamTotal = youtubeShareVND + tiktokShareVND + totalSponsorRevenueVND + crossSellRevenueVND;
    const streams = [
      {
        name: 'YouTube AdSense & Premium (4K)',
        color: '#EF4444',
        amount: Math.round(youtubeShareVND),
        share: streamTotal > 0 ? Math.round((youtubeShareVND / streamTotal) * 100) : 0,
        subtext: 'Bản quyền 4K mid-roll và người xem trả phí',
      },
      {
        name: 'TikTok Creator Rewards & Reels',
        color: '#06B6D4',
        amount: Math.round(tiktokShareVND),
        share: streamTotal > 0 ? Math.round((tiktokShareVND / streamTotal) * 100) : 0,
        subtext: 'Thưởng nhà sáng tạo & viral sound',
      },
      {
        name: 'Tài Trợ Nhãn Hàng (Brand Placement)',
        color: '#F59E0B',
        amount: Math.round(totalSponsorRevenueVND),
        share: streamTotal > 0 ? Math.round((totalSponsorRevenueVND / streamTotal) * 100) : 0,
        subtext: `${sponsorDeals} hợp đồng chèn sản phẩm / mở đầu`,
      },
      {
        name: 'Bán Sách Nói & GITA Academy',
        color: '#10B981',
        amount: Math.round(crossSellRevenueVND),
        share: streamTotal > 0 ? Math.round((crossSellRevenueVND / streamTotal) * 100) : 0,
        subtext: 'Khóa học chuyển đổi & sách kinh điển',
      },
    ];

    return {
      totalProjectedViews,
      totalProjectedRevenueRealistic,
      totalProjectedRevenueConservative,
      totalProjectedRevenueOptimistic,
      totalProductionCost,
      netProfitRealistic,
      roiRealistic,
      breakEvenMonth,
      monthlyBreakdown,
      streams,
      monthlyAverageVND: Math.round(totalProjectedRevenueRealistic / 12),
    };
  }, [
    episodeCount,
    episodeDuration,
    resolutionTier,
    targetViewsPerEp,
    avgCpmVND,
    sponsorDeals,
    sponsorDealValueVND,
    enableCrossSell,
    costPerEpisodeVND,
  ]);

  // Max value for scaling the bar chart
  const maxChartValue = useMemo(() => {
    if (chartViewMode === 'cumulative') {
      return calculations.totalProjectedRevenueOptimistic * 1.05;
    }
    const maxMonthly = Math.max(...calculations.monthlyBreakdown.map((m) => m.optimistic));
    return maxMonthly * 1.15;
  }, [calculations, chartViewMode]);

  const handleCopySummary = () => {
    const text = `=== BÁO CÁO DỰ BÁO TIỀM NĂNG DOANH THU PHIM GITA365 ===\nDự án: ${project.title}\nSố tập: ${episodeCount} tập (${episodeDuration} phút/tập) - Chuẩn: ${resolutionTier}\nTổng lượt xem dự phóng: ${calculations.totalProjectedViews.toLocaleString()} views\n\n1. Kịch bản Khả thi (Realistic): ${calculations.totalProjectedRevenueRealistic.toLocaleString()} VND / năm\n2. Kịch bản Thận trọng (Conservative): ${calculations.totalProjectedRevenueConservative.toLocaleString()} VND / năm\n3. Kịch bản Bùng nổ (Optimistic): ${calculations.totalProjectedRevenueOptimistic.toLocaleString()} VND / năm\n\nChi phí sản xuất: ${calculations.totalProductionCost.toLocaleString()} VND\nLợi nhuận ròng dự kiến: ${calculations.netProfitRealistic.toLocaleString()} VND\nThời gian hòa vốn: ${calculations.breakEvenMonth} tháng\nTỷ suất lợi nhuận ROI: ${calculations.roiRealistic}%\nDoanh thu trung bình/tháng: ${calculations.monthlyAverageVND.toLocaleString()} VND`;
    navigator.clipboard.writeText(text);
    setCopiedData(true);
    setTimeout(() => setCopiedData(false), 2500);
  };

  const handleDownloadReport = () => {
    const reportData = {
      projectTitle: project.title,
      generatedAt: new Date().toISOString(),
      parameters: {
        episodeCount,
        episodeDuration,
        resolutionTier,
        targetViewsPerEp,
        avgCpmVND,
        sponsorDeals,
        sponsorDealValueVND,
        enableCrossSell,
        costPerEpisodeVND,
      },
      summary: {
        totalViews: calculations.totalProjectedViews,
        totalRevenueRealisticVND: calculations.totalProjectedRevenueRealistic,
        totalRevenueConservativeVND: calculations.totalProjectedRevenueConservative,
        totalRevenueOptimisticVND: calculations.totalProjectedRevenueOptimistic,
        totalCostVND: calculations.totalProductionCost,
        netProfitVND: calculations.netProfitRealistic,
        roiPercent: calculations.roiRealistic,
        breakEvenMonths: calculations.breakEvenMonth,
      },
      streams: calculations.streams,
      monthlyBreakdown: calculations.monthlyBreakdown,
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `GITA365_Revenue_Forecast_${project.id || 'film'}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 2500);
  };

  return (
    <div className="bg-slate-900/95 rounded-3xl border border-slate-800 p-6 sm:p-8 shadow-2xl space-y-8 animate-in fade-in">
      {/* Header with Title and Mode Actions */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 border-b border-slate-800/80 pb-6">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gradient-to-r from-amber-500/15 via-yellow-500/15 to-emerald-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold uppercase tracking-wider">
            <DollarSign className="w-3.5 h-3.5 text-amber-400" />
            <span>AI Film Revenue Simulator & Forecast</span>
          </div>
          <h2 className="text-xl sm:text-2xl lg:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <span>Dự Báo Tiềm Năng Doanh Thu Bộ Phim</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-mono font-bold border border-amber-500/30">
              12 Tháng
            </span>
          </h2>
          <p className="text-slate-400 text-xs sm:text-sm max-w-3xl leading-relaxed">
            Mô hình toán học dự phóng dòng tiền điện ảnh AI dựa trên cấu hình dự án ({project.title}),
            định dạng {resolutionTier}, lượng người xem mục tiêu, tỷ lệ đặt quảng cáo AdSense và hệ sinh thái tài trợ đa kênh GITA365.
          </p>
        </div>

        {/* Quick Report Actions */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={handleCopySummary}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-semibold transition-all"
            title="Sao chép tóm tắt doanh thu"
          >
            {copiedData ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedData ? 'Đã Sao Chép' : 'Sao Chép Báo Cáo'}</span>
          </button>

          <button
            onClick={handleDownloadReport}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/20 transition-all transform hover:scale-[1.02]"
            title="Tải báo cáo JSON phân tích đầy đủ"
          >
            {downloadSuccess ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Download className="w-3.5 h-3.5" />}
            <span>{downloadSuccess ? 'Đã Xuất File' : 'Tải Báo Cáo JSON'}</span>
          </button>
        </div>
      </div>

      {/* KPI Financial Overview Cards (4 cards) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Annual Projected Revenue */}
        <div className="bg-gradient-to-br from-slate-950 via-slate-950 to-amber-950/30 p-5 rounded-2xl border border-amber-500/40 shadow-xl space-y-2 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />
          <div className="flex items-center justify-between text-xs text-amber-300 font-semibold">
            <span>Doanh Thu Dự Phóng (1 Năm)</span>
            <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-amber-400 tracking-tight font-mono">
            {calculations.totalProjectedRevenueRealistic.toLocaleString()} <span className="text-sm font-sans font-bold text-slate-400">đ</span>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
            <span>Kịch bản tiêu chuẩn</span>
            <span className="text-emerald-400 font-mono font-bold">~{calculations.monthlyAverageVND.toLocaleString()} đ/tháng</span>
          </div>
        </div>

        {/* Break-even point */}
        <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 shadow-xl space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Mốc Hòa Vốn (Break-even)</span>
            <div className="p-1.5 rounded-lg bg-cyan-500/15 text-cyan-400">
              <Clock className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-white tracking-tight font-mono">
            {calculations.breakEvenMonth} <span className="text-sm font-sans font-bold text-slate-400">Tháng</span>
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 font-medium pt-1 border-t border-slate-800/80">
            <CheckCircle2 className="w-3 h-3 flex-shrink-0" />
            <span>Thu hồi vốn siêu nhanh nhờ AI</span>
          </div>
        </div>

        {/* Estimated ROI */}
        <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 shadow-xl space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Tỷ Suất Sinh Lời (ROI)</span>
            <div className="p-1.5 rounded-lg bg-purple-500/15 text-purple-400">
              <Percent className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-purple-300 tracking-tight font-mono">
            +{calculations.roiRealistic}%
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
            <span>Chi phí SX:</span>
            <span className="text-slate-300 font-mono font-bold">{calculations.totalProductionCost.toLocaleString()} đ</span>
          </div>
        </div>

        {/* Net Profit */}
        <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 shadow-xl space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Lợi Nhuận Ròng Dự Kiến</span>
            <div className="p-1.5 rounded-lg bg-emerald-500/15 text-emerald-400">
              <DollarSign className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-emerald-400 tracking-tight font-mono">
            {calculations.netProfitRealistic.toLocaleString()} <span className="text-sm font-sans font-bold text-slate-400">đ</span>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
            <span>Lượt xem toàn mùa:</span>
            <span className="text-cyan-400 font-mono font-bold">{calculations.totalProjectedViews.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Parameters Simulator (Left) + Interactive Visual Chart (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Interactive Parameters Tuner (5 cols) */}
        <div className="lg:col-span-5 bg-slate-950 rounded-2xl border border-slate-800 p-5 sm:p-6 space-y-5 shadow-inner">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Sliders className="w-4 h-4 text-amber-400" />
              <span>Cài Đặt Thông Số Phim & Dự Báo</span>
            </h3>
            <span className="text-[10px] text-slate-400 font-mono bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
              Cập nhật tức thì
            </span>
          </div>

          <div className="space-y-4 text-xs">
            {/* Episode Count Slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between font-medium">
                <span className="text-slate-300">Số tập phim (Episodes):</span>
                <span className="text-amber-400 font-mono font-bold">{episodeCount} tập</span>
              </div>
              <input
                type="range"
                min="1"
                max="24"
                step="1"
                value={episodeCount}
                onChange={(e) => setEpisodeCount(Number(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>1 tập (Phim ngắn)</span>
                <span>12 tập (Phổ biến)</span>
                <span>24 tập (Series lớn)</span>
              </div>
            </div>

            {/* Episode Duration Slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between font-medium">
                <span className="text-slate-300">Thời lượng mỗi tập:</span>
                <span className="text-amber-400 font-mono font-bold">{episodeDuration} phút</span>
              </div>
              <input
                type="range"
                min="5"
                max="45"
                step="5"
                value={episodeDuration}
                onChange={(e) => setEpisodeDuration(Number(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>5p (TikTok/Shorts)</span>
                <span>15p (Chuẩn web series)</span>
                <span>45p (Tập dài)</span>
              </div>
            </div>

            {/* Resolution Tier */}
            <div className="space-y-1.5">
              <span className="text-slate-300 font-medium block">Độ phân giải & Chất lượng:</span>
              <div className="grid grid-cols-3 gap-2">
                {(['1080p', '4K', '8K'] as const).map((res) => (
                  <button
                    key={res}
                    onClick={() => setResolutionTier(res)}
                    className={`py-1.5 px-2 rounded-xl font-bold transition-all border text-center ${
                      resolutionTier === res
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-sm'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <div>{res}</div>
                    <div className="text-[9px] font-normal text-slate-400 mt-0.5">
                      {res === '8K' ? '+60% RPM' : res === '4K' ? '+35% RPM' : 'Chuẩn'}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Target Views per Episode Slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between font-medium">
                <span className="text-slate-300">Lượt xem mục tiêu / tập:</span>
                <span className="text-cyan-400 font-mono font-bold">
                  {targetViewsPerEp.toLocaleString()} lượt
                </span>
              </div>
              <input
                type="range"
                min="50000"
                max="1500000"
                step="25000"
                value={targetViewsPerEp}
                onChange={(e) => setTargetViewsPerEp(Number(e.target.value))}
                className="w-full accent-cyan-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>50k (Mới lập kênh)</span>
                <span>500k (Kênh thịnh hành)</span>
                <span>1.5M+ (Viral)</span>
              </div>
            </div>

            {/* Expected CPM / RPM */}
            <div className="space-y-1.5">
              <div className="flex justify-between font-medium">
                <span className="text-slate-300">CPM / RPM trung bình (VND / 1.000 views):</span>
                <span className="text-emerald-400 font-mono font-bold">
                  {avgCpmVND.toLocaleString()} đ
                </span>
              </div>
              <input
                type="range"
                min="25000"
                max="120000"
                step="5000"
                value={avgCpmVND}
                onChange={(e) => setAvgCpmVND(Number(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>25k (Nội địa)</span>
                <span>55k (Đa nền tảng)</span>
                <span>120k (Quốc tế/Tài chính)</span>
              </div>
            </div>

            {/* Sponsorship Deals Slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between font-medium">
                <span className="text-slate-300">Hợp đồng tài trợ nhãn hàng (Brand Deals):</span>
                <span className="text-amber-400 font-mono font-bold">
                  {sponsorDeals} deal (~{(sponsorDeals * sponsorDealValueVND).toLocaleString()} đ)
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="6"
                step="1"
                value={sponsorDeals}
                onChange={(e) => setSponsorDeals(Number(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              />
            </div>

            {/* Cross-sell & Affiliate Toggle */}
            <div className="bg-slate-900/90 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
              <div>
                <span className="font-semibold text-white block">Bán Sách Bản Quyền & Khóa Học GITA</span>
                <span className="text-[11px] text-slate-400">
                  Chuyển đổi 0.15% người xem sang học viên
                </span>
              </div>
              <button
                type="button"
                onClick={() => setEnableCrossSell(!enableCrossSell)}
                className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors ${
                  enableCrossSell ? 'bg-emerald-500' : 'bg-slate-700'
                }`}
              >
                <span
                  className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white transition-transform ${
                    enableCrossSell ? 'translate-x-4' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* AI Production Cost Per Episode */}
            <div className="space-y-1.5 pt-1">
              <div className="flex justify-between font-medium">
                <span className="text-slate-300">Chi phí AI & Render / tập:</span>
                <span className="text-purple-300 font-mono font-bold">
                  {costPerEpisodeVND.toLocaleString()} đ
                </span>
              </div>
              <input
                type="range"
                min="3000000"
                max="20000000"
                step="500000"
                value={costPerEpisodeVND}
                onChange={(e) => setCostPerEpisodeVND(Number(e.target.value))}
                className="w-full accent-purple-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              />
            </div>
          </div>
        </div>

        {/* Right Column: Visual Forecast Chart & Scenarios (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Chart Header Bar: Switch between Monthly and Cumulative, Scenario Selector */}
          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            {/* View Mode Toggle */}
            <div className="flex items-center bg-slate-900 p-1 rounded-xl border border-slate-800">
              <button
                onClick={() => setChartViewMode('monthly')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                  chartViewMode === 'monthly'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Theo Tháng (12 Tháng)
              </button>
              <button
                onClick={() => setChartViewMode('cumulative')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                  chartViewMode === 'cumulative'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Lũy Kế & Điểm Hòa Vốn
              </button>
            </div>

            {/* Scenario Filter */}
            <div className="flex items-center gap-1.5">
              <span className="text-slate-400 font-medium">Kịch bản:</span>
              <select
                value={selectedScenario}
                onChange={(e) => setSelectedScenario(e.target.value as any)}
                className="bg-slate-900 border border-slate-700 text-white rounded-lg px-2.5 py-1 text-xs font-semibold focus:outline-none focus:border-amber-500"
              >
                <option value="all">Tất Cả (So Sánh 3 Kịch Bản)</option>
                <option value="realistic">⭐ Khả Thi (Realistic)</option>
                <option value="conservative">🛡️ Thận Trọng (Conservative)</option>
                <option value="optimistic">🚀 Bùng Nổ Viral (Optimistic)</option>
              </select>
            </div>
          </div>

          {/* Interactive Chart Container */}
          <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800 space-y-4 shadow-xl relative">
            <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-800/80 pb-2">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-cyan-400" />
                <span className="font-bold text-white">
                  {chartViewMode === 'monthly'
                    ? 'Biểu Đồ Doanh Thu Dự Phóng Hàng Tháng (T1 - T12)'
                    : 'Đường Tăng Trưởng Doanh Thu Lũy Kế & Ngưỡng Hòa Vốn'}
                </span>
              </div>
              <span className="font-mono text-[11px] text-amber-400">Đơn vị: Triệu VNĐ</span>
            </div>

            {/* Legend */}
            <div className="flex items-center gap-4 text-[11px] text-slate-300 flex-wrap">
              {(selectedScenario === 'all' || selectedScenario === 'conservative') && (
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
                  <span>Thận Trọng (58%)</span>
                </div>
              )}
              {(selectedScenario === 'all' || selectedScenario === 'realistic') && (
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                  <span className="font-bold text-amber-300">Khả Thi (100% - Chuẩn)</span>
                </div>
              )}
              {(selectedScenario === 'all' || selectedScenario === 'optimistic') && (
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-pink-500" />
                  <span>Bùng Nổ Viral (185%)</span>
                </div>
              )}
              {chartViewMode === 'cumulative' && (
                <div className="flex items-center gap-1.5 ml-auto">
                  <span className="w-4 h-0.5 bg-red-400 border-t border-dashed" />
                  <span className="text-red-400 font-mono text-[10px]">Ngưỡng chi phí ban đầu</span>
                </div>
              )}
            </div>

            {/* The Bars / Columns Chart Visualization */}
            <div className="h-64 flex items-end justify-between gap-1.5 sm:gap-2 pt-6 px-1 relative">
              {/* Break-even horizontal line in cumulative mode */}
              {chartViewMode === 'cumulative' && (
                <div
                  className="absolute left-0 right-0 border-b-2 border-dashed border-red-500/80 z-10 pointer-events-none"
                  style={{
                    bottom: `${Math.min(
                      95,
                      Math.max(5, (calculations.totalProductionCost / maxChartValue) * 100)
                    )}%`,
                  }}
                >
                  <span className="absolute -top-4 right-1 text-[9px] bg-red-500/90 text-white font-mono px-1.5 py-0.5 rounded shadow">
                    Điểm hòa vốn: {(calculations.totalProductionCost / 1000000).toFixed(1)}M
                  </span>
                </div>
              )}

              {calculations.monthlyBreakdown.map((item, idx) => {
                const isHovered = hoveredMonthIndex === idx;
                const valueToShow =
                  chartViewMode === 'cumulative' ? item.cumulativeRealistic : item.realistic;
                const conservativeVal =
                  chartViewMode === 'cumulative' ? item.cumulativeConservative : item.conservative;
                const optimisticVal =
                  chartViewMode === 'cumulative' ? item.cumulativeOptimistic : item.optimistic;

                const heightPercentRealistic = Math.min(
                  100,
                  Math.max(6, Math.round((valueToShow / maxChartValue) * 100))
                );
                const heightPercentConservative = Math.min(
                  100,
                  Math.max(4, Math.round((conservativeVal / maxChartValue) * 100))
                );
                const heightPercentOptimistic = Math.min(
                  100,
                  Math.max(8, Math.round((optimisticVal / maxChartValue) * 100))
                );

                return (
                  <div
                    key={item.month}
                    onMouseEnter={() => setHoveredMonthIndex(idx)}
                    onMouseLeave={() => setHoveredMonthIndex(null)}
                    className="flex-1 flex flex-col items-center gap-1.5 group relative cursor-pointer h-full justify-end"
                  >
                    {/* Tooltip on Hover */}
                    {isHovered && (
                      <div className="absolute -top-28 left-1/2 -translate-x-1/2 z-30 w-44 bg-slate-900 border border-slate-700 rounded-xl p-2.5 shadow-2xl text-[10px] space-y-1 text-slate-200 pointer-events-none animate-in fade-in zoom-in-95">
                        <div className="font-bold text-amber-300 border-b border-slate-800 pb-1 flex justify-between">
                          <span>Tháng {item.monthIndex}</span>
                          <span className="font-mono text-cyan-400">
                            ~{(item.views / 1000).toFixed(0)}k views
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-amber-400">Khả thi:</span>
                          <span className="font-mono font-bold">
                            {(valueToShow / 1000000).toFixed(1)}M đ
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-cyan-400">Thận trọng:</span>
                          <span className="font-mono">
                            {(conservativeVal / 1000000).toFixed(1)}M đ
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-pink-400">Bùng nổ:</span>
                          <span className="font-mono">
                            {(optimisticVal / 1000000).toFixed(1)}M đ
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Bars Container */}
                    <div className="w-full flex items-end justify-center gap-0.5 h-48 bg-slate-900/60 rounded-lg p-0.5">
                      {/* Conservative Bar */}
                      {(selectedScenario === 'all' || selectedScenario === 'conservative') && (
                        <div
                          className="w-full max-w-[8px] bg-cyan-500 rounded-t-sm transition-all duration-300 group-hover:brightness-125 opacity-70"
                          style={{ height: `${heightPercentConservative}%` }}
                          title={`Thận trọng: ${(conservativeVal / 1000000).toFixed(1)}M`}
                        />
                      )}

                      {/* Realistic Bar (Primary) */}
                      {(selectedScenario === 'all' || selectedScenario === 'realistic') && (
                        <div
                          className={`w-full max-w-[14px] bg-gradient-to-t from-amber-600 via-amber-500 to-yellow-400 rounded-t-md transition-all duration-300 group-hover:brightness-125 shadow-sm ${
                            isHovered ? 'ring-2 ring-amber-300' : ''
                          }`}
                          style={{ height: `${heightPercentRealistic}%` }}
                          title={`Khả thi: ${(valueToShow / 1000000).toFixed(1)}M`}
                        />
                      )}

                      {/* Optimistic Bar */}
                      {(selectedScenario === 'all' || selectedScenario === 'optimistic') && (
                        <div
                          className="w-full max-w-[8px] bg-gradient-to-t from-purple-600 to-pink-500 rounded-t-sm transition-all duration-300 group-hover:brightness-125 opacity-70"
                          style={{ height: `${heightPercentOptimistic}%` }}
                          title={`Bùng nổ: ${(optimisticVal / 1000000).toFixed(1)}M`}
                        />
                      )}
                    </div>

                    {/* Month Label */}
                    <span
                      className={`text-[10px] font-mono transition-colors ${
                        isHovered
                          ? 'text-amber-300 font-bold'
                          : 'text-slate-400 group-hover:text-slate-200'
                      }`}
                    >
                      {item.month}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Bottom Chart Note */}
            <div className="pt-2 flex items-center justify-between text-[11px] text-slate-500 border-t border-slate-900">
              <span className="flex items-center gap-1">
                <Info className="w-3.5 h-3.5 text-cyan-400" />
                <span>Rê chuột vào cột để xem chi tiết doanh thu và lượt xem dự phóng từng tháng.</span>
              </span>
              <span className="text-emerald-400 font-mono font-semibold">
                Điểm hòa vốn: Tháng thứ {calculations.breakEvenMonth}
              </span>
            </div>
          </div>

          {/* Revenue Stream Breakdown (4 streams) */}
          <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800 space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <PieChart className="w-4 h-4 text-emerald-400" />
                <span>Cơ Cấu Nguồn Thu Phim (Tỷ Trọng % & Ước Tính VND)</span>
              </h3>
              <span className="text-emerald-400 font-mono text-xs font-bold">
                100% Đa Kênh
              </span>
            </div>

            {/* Horizontal Stacked Bar */}
            <div className="h-3 w-full bg-slate-900 rounded-full overflow-hidden flex shadow-inner">
              {calculations.streams.map((stream) => (
                <div
                  key={stream.name}
                  style={{ width: `${stream.share}%`, backgroundColor: stream.color }}
                  className="h-full transition-all duration-500 hover:brightness-125"
                  title={`${stream.name}: ${stream.share}%`}
                />
              ))}
            </div>

            {/* Stream Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              {calculations.streams.map((stream) => (
                <div
                  key={stream.name}
                  className="bg-slate-900/90 p-3 rounded-xl border border-slate-800/80 space-y-1.5"
                >
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                        style={{ backgroundColor: stream.color }}
                      />
                      <span className="font-semibold text-white truncate">{stream.name}</span>
                    </div>
                    <span className="font-mono font-bold text-amber-300 text-xs">
                      {stream.share}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-400 text-[10px]">{stream.subtext}</span>
                    <span className="font-mono font-bold text-emerald-400 text-xs">
                      {stream.amount.toLocaleString()} đ
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Collapsible 12-Month Detailed Data Table */}
      <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-950">
        <button
          onClick={() => setShowDataTable(!showDataTable)}
          className="w-full px-6 py-4 flex items-center justify-between text-left hover:bg-slate-900/60 transition-colors"
        >
          <div className="flex items-center gap-2.5 text-sm font-bold text-white">
            <Calendar className="w-4 h-4 text-amber-400" />
            <span>Bảng Chi Tiết Dự Phóng Dòng Tiền 12 Tháng (Dữ Liệu Số Học)</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span>{showDataTable ? 'Thu gọn' : 'Xem toàn bộ'}</span>
            {showDataTable ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </div>
        </button>

        {showDataTable && (
          <div className="border-t border-slate-800 px-6 py-4 overflow-x-auto">
            <table className="w-full text-xs text-left text-slate-300">
              <thead className="text-[11px] uppercase bg-slate-900/80 text-slate-400 font-mono">
                <tr>
                  <th className="py-2.5 px-3 rounded-l-lg">Tháng</th>
                  <th className="py-2.5 px-3">Lượt Xem Dự Phóng</th>
                  <th className="py-2.5 px-3 text-cyan-400">Thận Trọng (VND)</th>
                  <th className="py-2.5 px-3 text-amber-400 font-bold">Khả Thi (VND)</th>
                  <th className="py-2.5 px-3 text-pink-400">Bùng Nổ (VND)</th>
                  <th className="py-2.5 px-3 text-emerald-400 rounded-r-lg font-bold">
                    Doanh Thu Lũy Kế
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-850 font-mono text-[11px]">
                {calculations.monthlyBreakdown.map((row) => (
                  <tr key={row.month} className="hover:bg-slate-900/40 transition-colors">
                    <td className="py-2.5 px-3 font-bold text-white">{row.month}</td>
                    <td className="py-2.5 px-3 text-slate-400">{row.views.toLocaleString()}</td>
                    <td className="py-2.5 px-3 text-cyan-300">
                      {row.conservative.toLocaleString()} đ
                    </td>
                    <td className="py-2.5 px-3 text-amber-300 font-bold">
                      {row.realistic.toLocaleString()} đ
                    </td>
                    <td className="py-2.5 px-3 text-pink-300">
                      {row.optimistic.toLocaleString()} đ
                    </td>
                    <td className="py-2.5 px-3 text-emerald-400 font-bold">
                      {row.cumulativeRealistic.toLocaleString()} đ
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="border-t-2 border-slate-700 font-mono text-xs font-bold text-white bg-slate-900/60">
                <tr>
                  <td className="py-3 px-3">TỔNG CỘNG</td>
                  <td className="py-3 px-3 text-slate-300">
                    {calculations.totalProjectedViews.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-cyan-400">
                    {calculations.totalProjectedRevenueConservative.toLocaleString()} đ
                  </td>
                  <td className="py-3 px-3 text-amber-400">
                    {calculations.totalProjectedRevenueRealistic.toLocaleString()} đ
                  </td>
                  <td className="py-3 px-3 text-pink-400">
                    {calculations.totalProjectedRevenueOptimistic.toLocaleString()} đ
                  </td>
                  <td className="py-3 px-3 text-emerald-400">
                    {calculations.totalProjectedRevenueRealistic.toLocaleString()} đ
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
