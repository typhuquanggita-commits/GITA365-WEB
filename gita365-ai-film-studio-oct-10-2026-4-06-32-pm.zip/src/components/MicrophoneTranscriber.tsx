import React, { useState, useRef, useEffect } from 'react';
import { Mic, Square, Loader2, Sparkles, Check, Copy, Volume2, Save } from 'lucide-react';
import { saveTranscription } from '../lib/firebase';

interface MicrophoneTranscriberProps {
  onTranscriptionComplete?: (text: string) => void;
  userId?: string;
  projectId?: string;
  placeholder?: string;
  label?: string;
}

export const MicrophoneTranscriber: React.FC<MicrophoneTranscriberProps> = ({
  onTranscriptionComplete,
  userId,
  projectId,
  label = 'Thu âm qua Microphone & Chuyển thành văn bản (Gemini 3.5 Transcribe)',
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [transcribedText, setTranscribedText] = useState('');
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const startRecording = async () => {
    try {
      setError(null);
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        stream.getTracks().forEach((track) => track.stop());
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        await handleTranscribeAudio(audioBlob);
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingDuration(0);

      timerRef.current = setInterval(() => {
        setRecordingDuration((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      console.error('Microphone error:', err);
      setError('Không thể truy cập Microphone. Vui lòng cấp quyền micro trong trình duyệt.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerRef.current) clearInterval(timerRef.current);
    }
  };

  const handleTranscribeAudio = async (blob: Blob) => {
    setIsTranscribing(true);
    setError(null);
    try {
      const reader = new FileReader();
      reader.readAsDataURL(blob);
      reader.onloadend = async () => {
        const base64Data = (reader.result as string).split(',')[1];
        const res = await fetch('/api/transcribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            audioBase64: base64Data,
            mimeType: blob.type || 'audio/webm',
          }),
        });

        const data = await res.json();
        if (data.success && data.text) {
          setTranscribedText(data.text);
          if (onTranscriptionComplete) {
            onTranscriptionComplete(data.text);
          }
          // Optionally save to Firestore if userId is present
          if (userId) {
            const transId = `trans_${Date.now()}`;
            saveTranscription(transId, userId, data.text, projectId).catch((e) =>
              console.warn('Could not save transcription to Firestore:', e)
            );
          }
        } else {
          setError(data.error || 'Không nhận diện được giọng nói.');
        }
        setIsTranscribing(false);
      };
    } catch (err: any) {
      console.error('Transcribe error:', err);
      setError(err.message || 'Lỗi kết nối máy chủ chuyển văn bản.');
      setIsTranscribing(false);
    }
  };

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remaining = secs % 60;
    return `${mins}:${remaining < 10 ? '0' : ''}${remaining}`;
  };

  const handleCopy = () => {
    if (transcribedText) {
      navigator.clipboard.writeText(transcribedText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400">
            <Mic className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">{label}</h4>
            <p className="text-[11px] text-slate-400">
              Công nghệ nhận diện giọng nói tiếng Việt chuẩn xác bằng mô hình{' '}
              <span className="text-red-400 font-mono font-semibold">gemini-3.5-transcribe</span>
            </p>
          </div>
        </div>

        {/* Record button */}
        <div className="flex items-center gap-2">
          {isRecording ? (
            <button
              onClick={stopRecording}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-lg shadow-red-600/30 animate-pulse transition-all"
            >
              <Square className="w-4 h-4 fill-current" />
              <span>Dừng Thu ({formatTime(recordingDuration)})</span>
            </button>
          ) : (
            <button
              onClick={startRecording}
              disabled={isTranscribing}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:brightness-110 text-white font-bold text-xs shadow-lg shadow-red-600/20 disabled:opacity-50 transition-all"
            >
              <Mic className="w-4 h-4" />
              <span>Bắt Đầu Nói & Thu Âm</span>
            </button>
          )}
        </div>
      </div>

      {/* Recording in progress indicator */}
      {isRecording && (
        <div className="flex items-center gap-3 bg-red-950/40 border border-red-500/30 p-3 rounded-xl">
          <div className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
            <span className="w-2 h-2 rounded-full bg-red-500" />
          </div>
          <span className="text-xs text-red-300 font-medium">
            Đang lắng nghe giọng nói của bạn... Hãy nói ý tưởng kịch bản, thoại hoặc tóm tắt phân cảnh!
          </span>
          <span className="ml-auto text-xs font-mono font-bold text-red-400">{formatTime(recordingDuration)}</span>
        </div>
      )}

      {/* Transcribing state */}
      {isTranscribing && (
        <div className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-950 border border-amber-500/30 text-amber-300 text-xs">
          <Loader2 className="w-4 h-4 animate-spin text-amber-400" />
          <span>Mô hình <strong>gemini-3.5-transcribe</strong> đang phân tích âm thanh và bóc băng lời thoại...</span>
        </div>
      )}

      {/* Error state */}
      {error && (
        <div className="p-3 rounded-xl bg-red-950/50 border border-red-700/50 text-red-300 text-xs">
          {error}
        </div>
      )}

      {/* Result box */}
      {transcribedText && (
        <div className="bg-slate-950 rounded-xl border border-slate-800 p-3.5 space-y-2">
          <div className="flex items-center justify-between text-[11px] text-slate-400 border-b border-slate-800/80 pb-2">
            <span className="flex items-center gap-1 text-emerald-400 font-semibold">
              <Check className="w-3.5 h-3.5" /> Bản ghi văn bản hoàn tất (gemini-3.5-transcribe)
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                className="flex items-center gap-1 text-slate-300 hover:text-white px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 transition-colors"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'Đã sao chép' : 'Sao chép'}</span>
              </button>
            </div>
          </div>
          <p className="text-xs text-slate-200 leading-relaxed font-sans whitespace-pre-wrap select-all">
            {transcribedText}
          </p>
        </div>
      )}
    </div>
  );
};
