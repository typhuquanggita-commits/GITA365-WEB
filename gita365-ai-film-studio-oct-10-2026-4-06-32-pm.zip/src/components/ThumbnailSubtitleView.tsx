import React, { useState } from 'react';
import {
  Image as ImageIcon,
  Sparkles,
  Download,
  Languages,
  Subtitles,
  Copy,
  Check,
  Type,
  Sliders,
  Palette,
  FileCode,
  FileText,
  Eye,
} from 'lucide-react';
import { FilmProject, SubtitleLine, VideoFormat } from '../types';

interface ThumbnailSubtitleViewProps {
  project: FilmProject;
  onUpdateProject: (updated: FilmProject) => void;
}

export const ThumbnailSubtitleView: React.FC<ThumbnailSubtitleViewProps> = ({
  project,
  onUpdateProject,
}) => {
  // Thumbnail Studio states
  const [thumbnailFormat, setThumbnailFormat] = useState<VideoFormat>('16:9');
  const [mainHookText, setMainHookText] = useState('TẬP 1: BÍ MẬT HUYỀN BÍ');
  const [subHookText, setSubHookText] = useState('CHUYỂN THỂ ĐIỆN ẢNH 4K');
  const [badgeText, setBadgeText] = useState('PREMIERE 4K');
  const [glowColor, setGlowColor] = useState<'amber' | 'cyan' | 'rose' | 'purple'>('amber');
  const [selectedBgUrl, setSelectedBgUrl] = useState<string>(
    project.episodes[0]?.acts[0]?.scenes[0]?.imageUrl ||
      'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=900&auto=format&fit=crop&q=80'
  );
  const [isGeneratingThumbnail, setIsGeneratingThumbnail] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  // Subtitle Studio states
  const [targetLanguage, setTargetLanguage] = useState<'vi' | 'en' | 'zh' | 'ja' | 'fr'>('vi');
  const [subtitles, setSubtitles] = useState<SubtitleLine[]>([
    {
      id: 'sub-1',
      startTime: '00:00:01,200',
      endTime: '00:00:06,800',
      speaker: 'Nữ Học Giả Ananya',
      text: 'Giáo sư! Bão tuyết đang mạnh dần! Nếu không tìm được nơi trú ẩn trước khi mặt trời lặn, nhiệt độ sẽ xuống âm 30 độ!',
      language: 'vi',
    },
    {
      id: 'sub-2',
      startTime: '00:00:07,500',
      endTime: '00:00:14,200',
      speaker: 'GS. Baird Spalding',
      text: 'Nhìn kìa Ananya! Phía trước vách đá... đó không phải là ảo ảnh! Có ánh lửa màu hổ phách đang dẫn đường cho chúng ta!',
      language: 'vi',
    },
    {
      id: 'sub-3',
      startTime: '00:00:15,000',
      endTime: '00:00:22,800',
      speaker: 'Pháp Sư Chơn Thiện',
      text: 'Chào mừng các bạn từ phương Tây xa xôi. Các bạn đã vượt qua bão tuyết không phải vì đôi chân, mà vì tâm trí các bạn đã sẵn sàng tiếp nhận ánh sáng.',
      language: 'vi',
    },
  ]);

  // English translation mapping
  const englishSubs: SubtitleLine[] = [
    {
      id: 'sub-en-1',
      startTime: '00:00:01,200',
      endTime: '00:00:06,800',
      speaker: 'Scholar Ananya',
      text: 'Professor! The blizzard is intensifying! If we do not find shelter before sunset, the temperature will plummet to minus 30 degrees!',
      language: 'en',
    },
    {
      id: 'sub-en-2',
      startTime: '00:00:07,500',
      endTime: '00:00:14,200',
      speaker: 'Prof. Baird Spalding',
      text: 'Look Ananya! Ahead on that cliff... that is no illusion! There is an amber torchlight guiding our way through the dark!',
      language: 'en',
    },
    {
      id: 'sub-en-3',
      startTime: '00:00:15,000',
      endTime: '00:00:22,800',
      speaker: 'Master Chon Thien',
      text: 'Welcome, travelers from the distant West. You have traversed the snowstorm not by footsteps alone, but because your inner consciousness was prepared to receive the light.',
      language: 'en',
    },
  ];

  const handleLanguageChange = (lang: 'vi' | 'en' | 'zh' | 'ja' | 'fr') => {
    setTargetLanguage(lang);
    if (lang === 'en') {
      setSubtitles(englishSubs);
    } else {
      // Keep Vietnamese original or translated
      setSubtitles(subtitles);
    }
  };

  const handleDownloadSrt = () => {
    let srtContent = '';
    subtitles.forEach((sub, idx) => {
      srtContent += `${idx + 1}\n${sub.startTime} --> ${sub.endTime}\n${sub.speaker ? sub.speaker + ': ' : ''}${sub.text}\n\n`;
    });

    const blob = new Blob([srtContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${project.title || 'gita365_film'}_subtitles_${targetLanguage}.srt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadThumbnail = () => {
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 2500);
  };

  const glowStyles = {
    amber: 'border-amber-500/80 shadow-amber-500/30 text-amber-300',
    cyan: 'border-cyan-500/80 shadow-cyan-500/30 text-cyan-300',
    rose: 'border-rose-500/80 shadow-rose-500/30 text-rose-300',
    purple: 'border-purple-500/80 shadow-purple-500/30 text-purple-300',
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950/40 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5" /> GITA365 AI Cover & Subtitle Studio
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight">
              Tạo Thumbnail Bằng AI & Phụ Đề Đa Ngôn Ngữ
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              Thiết kế ảnh bìa Thumbnail giật gân, tỷ lệ nhấp chuột (CTR) cao cho YouTube, TikTok, Facebook.
              Tự động tạo phụ đề đa ngôn ngữ (SRT/VTT) chính xác theo từng mili-giây.
            </p>
          </div>
        </div>
      </div>

      {/* Main Grid: Thumbnail Studio (Left) + Subtitle Editor (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: AI Thumbnail Studio (6 cols) */}
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-amber-400" /> Xưởng Thiết Kế Thumbnail AI
              </h2>
              <span className="text-xs text-amber-400 font-mono">Tối Ưu CTR &gt; 12%</span>
            </div>

            {/* Thumbnail Canvas Preview */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-400 block">Xem trước ảnh bìa hiển thị:</label>
              <div
                className={`relative mx-auto rounded-2xl overflow-hidden bg-black border-2 transition-all shadow-2xl flex items-center justify-center ${
                  thumbnailFormat === '16:9'
                    ? 'aspect-video w-full'
                    : thumbnailFormat === '9:16'
                    ? 'w-full max-w-xs aspect-[9/16]'
                    : 'w-full max-w-sm aspect-square'
                } ${glowStyles[glowColor].split(' ')[0]}`}
              >
                {/* Background Image */}
                <img
                  src={selectedBgUrl}
                  alt="Thumbnail Background"
                  className="w-full h-full object-cover filter contrast-125 brightness-95"
                />

                {/* Dramatic Vignette & Dark Gradients */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-black/60 pointer-events-none" />

                {/* Top Badge */}
                <div className="absolute top-3 left-3">
                  <span className="px-2.5 py-1 rounded-lg bg-red-600 text-white font-extrabold text-[11px] tracking-wider uppercase shadow-lg border border-red-400">
                    {badgeText}
                  </span>
                </div>

                <div className="absolute top-3 right-3 px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-md text-[10px] text-amber-300 font-bold">
                  GITA365 STUDIO
                </div>

                {/* Typography Hooks */}
                <div className="absolute bottom-4 inset-x-3 text-center space-y-1 z-10 pointer-events-none">
                  <div className="inline-block bg-yellow-400 text-slate-950 font-black text-sm sm:text-base px-3 py-1 rounded-lg shadow-2xl uppercase tracking-tight transform -rotate-1">
                    {mainHookText}
                  </div>
                  <div className="text-[11px] sm:text-xs font-bold text-white drop-shadow-[0_2px_4px_rgba(0,0,0,1)] uppercase tracking-wide">
                    {subHookText}
                  </div>
                </div>
              </div>
            </div>

            {/* Controls for Thumbnail */}
            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Tỷ lệ khung hình:</label>
                  <select
                    value={thumbnailFormat}
                    onChange={(e) => setThumbnailFormat(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none"
                  >
                    <option value="16:9">YouTube 16:9 (1920x1080)</option>
                    <option value="9:16">TikTok / Shorts 9:16 (1080x1920)</option>
                    <option value="1:1">Facebook / Insta 1:1 (1080x1080)</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">Tông màu phát sáng (Glow):</label>
                  <select
                    value={glowColor}
                    onChange={(e) => setGlowColor(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none"
                  >
                    <option value="amber">Vàng Hoàng Gia (Royal Amber)</option>
                    <option value="cyan">Xanh Neon (Cyber Cyan)</option>
                    <option value="rose">Đỏ Giật Gân (Crimson Red)</option>
                    <option value="purple">Tím Huyền Bí (Mystic Violet)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Tiêu đề giật gân chính (Hook Text):</label>
                <input
                  type="text"
                  value={mainHookText}
                  onChange={(e) => setMainHookText(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500 font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Dòng phụ chú:</label>
                  <input
                    type="text"
                    value={subHookText}
                    onChange={(e) => setSubHookText(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Huy hiệu góc:</label>
                  <input
                    type="text"
                    value={badgeText}
                    onChange={(e) => setBadgeText(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none"
                  />
                </div>
              </div>

              {/* Background scene selector */}
              <div>
                <label className="text-slate-400 block mb-1.5">Chọn ảnh nền từ phân cảnh:</label>
                <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
                  {project.episodes[0]?.acts[0]?.scenes.map((sc, i) => (
                    <button
                      key={sc.id}
                      onClick={() => sc.imageUrl && setSelectedBgUrl(sc.imageUrl)}
                      className={`relative w-16 h-10 rounded-lg overflow-hidden border flex-shrink-0 transition-all ${
                        selectedBgUrl === sc.imageUrl
                          ? 'border-amber-400 ring-2 ring-amber-400/40'
                          : 'border-slate-800 opacity-60 hover:opacity-100'
                      }`}
                    >
                      {sc.imageUrl && (
                        <img src={sc.imageUrl} alt="Scene" className="w-full h-full object-cover" />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Download Thumbnail */}
            <button
              onClick={handleDownloadThumbnail}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-xs shadow-lg flex items-center justify-center gap-2 transition-all transform active:scale-95"
            >
              {downloadSuccess ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Đã Tải Xuống Thumbnail 4K!</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  <span>Tải Xuống Thumbnail 4K (PNG)</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Multilingual Subtitle Studio (6 cols) */}
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Subtitles className="w-4 h-4 text-cyan-400" /> Trình Biên Tập Phụ Đề Đa Ngôn Ngữ
              </h2>
              <span className="text-xs text-cyan-400 font-mono">Auto Sync AI</span>
            </div>

            {/* Language Selector */}
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <Languages className="w-3.5 h-3.5 text-cyan-400" />
                <span>Ngôn ngữ phụ đề:</span>
              </div>
              <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
                <button
                  onClick={() => handleLanguageChange('vi')}
                  className={`px-2.5 py-1 rounded-lg font-semibold ${
                    targetLanguage === 'vi' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400'
                  }`}
                >
                  Tiếng Việt
                </button>
                <button
                  onClick={() => handleLanguageChange('en')}
                  className={`px-2.5 py-1 rounded-lg font-semibold ${
                    targetLanguage === 'en' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400'
                  }`}
                >
                  English
                </button>
                <button
                  onClick={() => handleLanguageChange('zh')}
                  className={`px-2.5 py-1 rounded-lg font-semibold ${
                    targetLanguage === 'zh' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400'
                  }`}
                >
                  中文 (Chinese)
                </button>
              </div>
            </div>

            {/* Subtitle Rows List */}
            <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
              {subtitles.map((sub, idx) => (
                <div
                  key={sub.id}
                  className="bg-slate-950 p-3.5 rounded-xl border border-slate-800/90 space-y-2 hover:border-slate-700 transition-colors"
                >
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold text-amber-300 flex items-center gap-1">
                      #{idx + 1} • {sub.speaker || 'Thuyết minh'}
                    </span>
                    <span className="font-mono text-cyan-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                      {sub.startTime} ➔ {sub.endTime}
                    </span>
                  </div>
                  <textarea
                    rows={2}
                    value={sub.text}
                    onChange={(e) => {
                      const updated = [...subtitles];
                      updated[idx].text = e.target.value;
                      setSubtitles(updated);
                    }}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-slate-100 focus:outline-none focus:border-cyan-500 resize-none font-medium leading-relaxed"
                  />
                </div>
              ))}
            </div>

            {/* Export Subtitle Actions */}
            <div className="pt-2 border-t border-slate-800 flex items-center gap-3">
              <button
                onClick={handleDownloadSrt}
                className="flex-1 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold text-xs border border-cyan-500/30 flex items-center justify-center gap-2 transition-all"
              >
                <FileCode className="w-4 h-4" />
                <span>Xuất Tệp Phụ Đề (.SRT)</span>
              </button>
              <button
                onClick={handleDownloadSrt}
                className="flex-1 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 flex items-center justify-center gap-2 transition-all"
              >
                <FileText className="w-4 h-4" />
                <span>Xuất Tệp WebVTT (.VTT)</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
