import React, { useState } from 'react';
import {
  TrendingUp,
  Eye,
  Clock,
  Percent,
  DollarSign,
  BarChart3,
  Flame,
  Globe2,
  Users,
  Compass,
  ArrowUpRight,
  Sparkles,
  Music,
  Disc,
  Award,
  Layers,
  Sliders,
  CheckCircle2,
  Calendar,
  Share2,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { FilmProject } from '../types';
import { VIDEO_ANALYTICS } from '../data/initialData';
import { INITIAL_MV_REVENUE_ANALYTICS } from '../data/mvConfigurations';
import { FilmRevenueForecastChart } from './FilmRevenueForecastChart';

interface AnalyticsTrendsViewProps {
  project: FilmProject;
}

export const AnalyticsTrendsView: React.FC<AnalyticsTrendsViewProps> = ({ project }) => {
  const stats = VIDEO_ANALYTICS;
  const mvData = INITIAL_MV_REVENUE_ANALYTICS;

  // View Mode: 'film_analytics' vs 'mv_revenue'
  const [activeTab, setActiveTab] = useState<'film_analytics' | 'mv_revenue'>('mv_revenue');

  // Interactive Simulator for MV Revenue Prediction
  const [simulatedMVsPerMonth, setSimulatedMVsPerMonth] = useState<number>(3000);

  // Computed simulation figures ($0.50 USD profit per song)
  const simulatedNetProfitUSD = simulatedMVsPerMonth * 0.5;
  const simulatedNetProfitVND = simulatedNetProfitUSD * 25000;
  const simulatedSavedCustomerCostUSD = simulatedMVsPerMonth * 8500; // estimated traditional cost saved

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-300">
      {/* Tab Switcher Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-3">
            <TrendingUp className="w-7 h-7 text-amber-400" />
            <span>Trung Tâm Phân Tích Dữ Liệu & Doanh Thu</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Theo dõi hiệu suất khán giả phim ảnh và Bảng điều khiển Doanh thu MV ca nhạc ($0.5 USD/Bài).
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center bg-slate-950 p-1.5 rounded-2xl border border-slate-800 text-xs font-bold">
          <button
            onClick={() => setActiveTab('mv_revenue')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${
              activeTab === 'mv_revenue'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md font-extrabold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Disc className="w-4 h-4" />
            <span>MV Revenue Dashboard ($0.5/Bài)</span>
            <span className="bg-emerald-500/20 text-emerald-300 px-1.5 py-0.2 rounded text-[10px] font-mono border border-emerald-500/30">
              MỚI
            </span>
          </button>

          <button
            onClick={() => setActiveTab('film_analytics')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${
              activeTab === 'film_analytics'
                ? 'bg-cyan-500 text-slate-950 shadow-md font-extrabold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>Hiệu Suất Phim & Khán Giả</span>
          </button>
        </div>
      </div>

      {/* VIEW 1: MV REVENUE DASHBOARD ($0.5 USD Profit per song) */}
      {activeTab === 'mv_revenue' && (
        <div className="space-y-8 animate-in fade-in">
          {/* Hero Banner for MV Revenue */}
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-amber-950/30 to-slate-950 border border-amber-500/40 p-6 sm:p-8 shadow-2xl">
            <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" />
            <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
              <div className="space-y-2">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold uppercase tracking-wider">
                  <DollarSign className="w-3.5 h-3.5" /> GITA365 MV Revenue Engine
                </div>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  Bảng Điều Khiển Doanh Thu MV Ca Nhạc Triệu Đô
                </h2>
                <p className="text-slate-300 text-xs sm:text-sm max-w-2xl leading-relaxed">
                  Trực quan hóa mô hình kinh doanh minh bạch: <strong className="text-amber-300">Lợi nhuận ròng cố định đúng 0.5 USD (~12.500 VNĐ)</strong> trên mỗi bài hát MV sản xuất thành công. Theo dõi tổng dự án hoạt động, thu nhập ròng lũy kế và mô hình dự báo tăng trưởng dựa trên mức độ tương tác người dùng.
                </p>
              </div>

              <div className="flex items-center gap-3 bg-slate-950 px-4 py-3 rounded-2xl border border-emerald-500/40 text-xs">
                <div className="w-3 h-3 rounded-full bg-emerald-400 animate-ping" />
                <div>
                  <span className="text-slate-400 block text-[10px]">Tỷ lệ lợi nhuận chuẩn:</span>
                  <span className="text-emerald-400 font-mono font-black text-sm">
                    +0.50 USD / MV Cố Định
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* 4 KPI Cards for MV Dashboard */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Card 1: Total Active Projects */}
            <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-lg space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Tổng số MV đã sản xuất</span>
                <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
                  <Disc className="w-4 h-4" />
                </div>
              </div>
              <div className="text-2xl font-black text-white tracking-tight font-mono">
                {mvData.totalActiveMVs.toLocaleString()} <span className="text-xs text-slate-400 font-normal">MV</span>
              </div>
              <div className="flex items-center gap-1 text-[11px] text-emerald-400 font-semibold">
                <ArrowUpRight className="w-3.5 h-3.5" />
                <span>+{mvData.growthRatePercent}% tăng trưởng tháng này</span>
              </div>
            </div>

            {/* Card 2: Net Earnings ($0.5 USD per song) */}
            <div className="bg-slate-900/90 rounded-2xl border border-amber-500/30 p-5 shadow-lg space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Lợi nhuận ròng lũy kế ($0.5/Bài)</span>
                <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
                  <DollarSign className="w-4 h-4" />
                </div>
              </div>
              <div className="text-2xl font-black text-emerald-400 tracking-tight font-mono">
                ${mvData.netEarningsUSD.toLocaleString()} USD
              </div>
              <div className="text-[11px] text-slate-300 font-medium">
                ≈ {mvData.netEarningsVND.toLocaleString()} VNĐ (Đã tất toán)
              </div>
            </div>

            {/* Card 3: Active Creator Users */}
            <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-lg space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Ca sĩ & Nghệ sĩ hoạt động</span>
                <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400">
                  <Users className="w-4 h-4" />
                </div>
              </div>
              <div className="text-2xl font-black text-purple-300 tracking-tight font-mono">
                {mvData.activeCreatorUsers.toLocaleString()} <span className="text-xs text-slate-400 font-normal">Creators</span>
              </div>
              <div className="text-[11px] text-slate-400">
                Trung bình 3.7 MV / nghệ sĩ
              </div>
            </div>

            {/* Card 4: Predicted Monthly Revenue */}
            <div className="bg-slate-900/90 rounded-2xl border border-cyan-500/30 p-5 shadow-lg space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Dự báo doanh thu tháng tới</span>
                <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400">
                  <Sparkles className="w-4 h-4" />
                </div>
              </div>
              <div className="text-2xl font-black text-cyan-300 tracking-tight font-mono">
                ${mvData.predictedMonthlyRevenueUSD.toLocaleString()} USD
              </div>
              <div className="flex items-center gap-1 text-[11px] text-emerald-400 font-semibold">
                <ArrowUpRight className="w-3.5 h-3.5" />
                <span>+103% theo mức tương tác hiện tại</span>
              </div>
            </div>
          </div>

          {/* Active Projects vs Net Earnings Chart & Monthly History Table */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Visual Tracking Bar Chart (7 cols) */}
            <div className="lg:col-span-7 bg-slate-900/90 rounded-3xl border border-slate-800 p-6 sm:p-8 space-y-6 shadow-xl">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-amber-400" />
                    <span>Lộ Trình Tăng Trưởng Dự Án MV & Lợi Nhuận Ròng ($0.5/Bài)</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    So sánh số lượng MV sản xuất thực tế vs Lợi nhuận $0.5 USD thu về qua từng tháng.
                  </p>
                </div>
                <span className="text-xs px-2.5 py-1 rounded-full bg-slate-950 text-slate-300 font-mono">
                  6 Tháng Gần Nhất
                </span>
              </div>

              {/* Bar visualization */}
              <div className="space-y-4 pt-2">
                {mvData.monthlyHistory.map((item) => {
                  const maxProjects = 3000;
                  const percentWidth = Math.min(100, Math.round((item.projectsCount / maxProjects) * 100));
                  const isPredicted = item.month.includes('Dự báo');
                  return (
                    <div key={item.month} className="space-y-1.5 text-xs">
                      <div className="flex items-center justify-between">
                        <span className={`font-semibold ${isPredicted ? 'text-amber-400 font-bold' : 'text-slate-300'}`}>
                          {item.month}
                        </span>
                        <div className="flex items-center gap-3 font-mono">
                          <span className="text-slate-400">{item.projectsCount.toLocaleString()} MVs</span>
                          <span className="text-emerald-400 font-bold">+${item.netProfitUSD.toFixed(1)} USD</span>
                        </div>
                      </div>

                      <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden border border-slate-800 flex">
                        <div
                          className={`h-full transition-all duration-500 ${
                            isPredicted
                              ? 'bg-gradient-to-r from-amber-500 to-yellow-400 animate-pulse'
                              : 'bg-gradient-to-r from-emerald-600 via-teal-500 to-cyan-500'
                          }`}
                          style={{ width: `${percentWidth}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-800 pt-3">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded bg-emerald-500" /> Dữ liệu thực tế đã hoàn thành
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded bg-amber-400" /> Mô hình AI dự báo theo đà tương tác
                </span>
              </div>
            </div>

            {/* Interactive Revenue Projection Simulator (5 cols) */}
            <div className="lg:col-span-5 bg-gradient-to-br from-slate-900 to-amber-950/20 rounded-3xl border border-amber-500/30 p-6 sm:p-8 space-y-6 shadow-xl flex flex-col justify-between">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-amber-300 uppercase tracking-wider">
                  <Sliders className="w-4 h-4 text-amber-400" />
                  <span>Bộ Mô Phỏng Dự Báo Doanh Thu (Revenue Simulator)</span>
                </div>
                <h3 className="text-base font-black text-white">
                  Dự Phóng Quy Mô Sản Xuất & Thu Nhập Ròng
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Kéo thanh trượt để dự đoán lợi nhuận ròng của bạn dựa trên số lượng MV tạo ra mỗi tháng với mức cố định 0.5 USD/bài:
                </p>
              </div>

              {/* Slider */}
              <div className="space-y-3 bg-slate-950 p-4 rounded-2xl border border-slate-800">
                <div className="flex justify-between items-center text-xs font-bold">
                  <span className="text-slate-400">Số lượng MV mỗi tháng:</span>
                  <span className="text-amber-400 font-mono text-base">{simulatedMVsPerMonth.toLocaleString()} bài hát</span>
                </div>

                <input
                  type="range"
                  min="200"
                  max="10000"
                  step="100"
                  value={simulatedMVsPerMonth}
                  onChange={(e) => setSimulatedMVsPerMonth(Number(e.target.value))}
                  className="w-full accent-amber-500 cursor-pointer"
                />

                <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                  <span>200 MV</span>
                  <span>5,000 MV</span>
                  <span>10,000 MV</span>
                </div>
              </div>

              {/* Result of Simulation */}
              <div className="space-y-3">
                <div className="p-3.5 rounded-xl bg-slate-950 border border-emerald-500/40 space-y-1.5">
                  <div className="text-[11px] text-slate-400">Thu nhập ròng cố định nhận về:</div>
                  <div className="text-2xl font-black text-emerald-400 font-mono">
                    ${simulatedNetProfitUSD.toLocaleString()} USD{' '}
                    <span className="text-xs text-slate-300 font-normal">/ tháng</span>
                  </div>
                  <div className="text-xs text-slate-300 font-semibold">
                    ≈ {simulatedNetProfitVND.toLocaleString()} VNĐ
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-[11px] text-slate-300 space-y-1">
                  <div className="text-slate-400">Giá trị khách hàng tiết kiệm so với quay MV truyền thống:</div>
                  <div className="text-amber-300 font-mono font-bold">
                    ≈ ${simulatedSavedCustomerCostUSD.toLocaleString()} USD (~{((simulatedSavedCustomerCostUSD * 25000) / 1000000000).toFixed(1)} tỷ đồng)
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Genre Breakdown & Recent Monetized MVs */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Genre Share (4 cols) */}
            <div className="lg:col-span-4 bg-slate-900/90 rounded-3xl border border-slate-800 p-6 space-y-4 shadow-xl">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
                <Music className="w-4 h-4 text-purple-400" />
                <span>Thị Phần Thể Loại MV Sản Xuất:</span>
              </h3>

              <div className="space-y-3">
                {mvData.genreBreakdown.map((g) => (
                  <div key={g.genre} className="space-y-1 text-xs">
                    <div className="flex justify-between text-slate-300">
                      <span className="truncate">{g.genre}</span>
                      <span className="font-mono text-slate-400">{g.share}%</span>
                    </div>
                    <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                      <div className="h-full" style={{ width: `${g.share}%`, backgroundColor: g.color }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent MVs Table (8 cols) */}
            <div className="lg:col-span-8 bg-slate-900/90 rounded-3xl border border-slate-800 p-6 space-y-4 shadow-xl">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Disc className="w-4 h-4 text-amber-400" />
                  <span>Dự Án MV Ca Nhạc Gần Nhất (Đã Khấu Trừ $0.5 USD Lãi):</span>
                </h3>
                <span className="text-xs text-emerald-400 font-mono">Bản quyền thương mại</span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400">
                      <th className="pb-2">Tên MV & Ca Sĩ</th>
                      <th className="pb-2">Thể Loại</th>
                      <th className="pb-2">Gói Sản Xuất</th>
                      <th className="pb-2">Lãi GITA</th>
                      <th className="pb-2 text-right">Lượt Xem Ước Tính</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {mvData.recentMVs.map((mv) => (
                      <tr key={mv.id} className="hover:bg-slate-950/40 transition-colors">
                        <td className="py-2.5">
                          <div className="font-bold text-white">{mv.title}</div>
                          <div className="text-[10px] text-slate-400">{mv.artist} • {mv.date}</div>
                        </td>
                        <td className="py-2.5 text-slate-300">{mv.genre}</td>
                        <td className="py-2.5">
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-amber-300 font-mono">
                            {mv.vipTier}
                          </span>
                        </td>
                        <td className="py-2.5 font-mono text-emerald-400 font-bold">
                          +${mv.netProfitUSD.toFixed(2)}
                        </td>
                        <td className="py-2.5 text-right font-mono text-slate-200">
                          {mv.viewsEst.toLocaleString()} views
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: ORIGINAL FILM ANALYTICS */}
      {activeTab === 'film_analytics' && (
        <div className="space-y-8 animate-in fade-in">
          {/* KPI Stat Cards (4 columns) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Total Views */}
            <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-lg space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Tổng lượt xem toàn kênh</span>
                <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400">
                  <Eye className="w-4 h-4" />
                </div>
              </div>
              <div className="text-2xl font-black text-white tracking-tight">
                {stats.totalViews.toLocaleString()}
              </div>
              <div className="flex items-center gap-1 text-[11px] text-emerald-400 font-semibold">
                <ArrowUpRight className="w-3.5 h-3.5" />
                <span>+24.5% so với tuần trước</span>
              </div>
            </div>

            {/* Watch Time */}
            <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-lg space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Thời lượng xem (Giờ)</span>
                <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
                  <Clock className="w-4 h-4" />
                </div>
              </div>
              <div className="text-2xl font-black text-white tracking-tight">
                {stats.watchTimeHours.toLocaleString()}h
              </div>
              <div className="flex items-center gap-1 text-[11px] text-emerald-400 font-semibold">
                <ArrowUpRight className="w-3.5 h-3.5" />
                <span>+18.2% tăng trưởng bền vững</span>
              </div>
            </div>

            {/* Retention Rate */}
            <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-lg space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Tỷ lệ giữ chân người xem</span>
                <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400">
                  <Percent className="w-4 h-4" />
                </div>
              </div>
              <div className="text-2xl font-black text-purple-300 tracking-tight">
                {stats.retentionRate}%
              </div>
              <div className="text-[11px] text-slate-400">
                Chuẩn phim điện ảnh chất lượng cao
              </div>
            </div>

            {/* Revenue */}
            <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-lg space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Doanh thu ước tính (VND)</span>
                <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
                  <DollarSign className="w-4 h-4" />
                </div>
              </div>
              <div className="text-2xl font-black text-emerald-400 tracking-tight">
                {stats.estimatedRevenueVND.toLocaleString()} đ
              </div>
              <div className="text-[11px] text-slate-400">
                CTR trung bình: {stats.ctr}%
              </div>
            </div>
          </div>

          {/* Revenue Forecast Chart */}
          <FilmRevenueForecastChart project={project} />

          {/* Retention Moments & Trends Radar */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h2 className="text-sm font-bold text-white flex items-center gap-2">
                  <Flame className="w-4 h-4 text-amber-400" /> Điểm Cao Trào Giữ Chân Khán Giả (Retention Peaks)
                </h2>
                <span className="text-xs text-emerald-400 font-mono">Đỉnh Điểm 96%</span>
              </div>

              <div className="space-y-3">
                {stats.topRetentionMoments.map((m) => (
                  <div
                    key={m.timestamp}
                    className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between gap-3"
                  >
                    <div className="space-y-0.5 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono text-[10px] font-bold">
                          {m.timestamp}
                        </span>
                        <span className="text-xs font-semibold text-white truncate">{m.label}</span>
                      </div>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <span className="text-sm font-extrabold text-emerald-400 font-mono">
                        {m.retention}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h2 className="text-sm font-bold text-white flex items-center gap-2">
                  <Compass className="w-4 h-4 text-purple-400" /> Radar Xu Hướng Làm Phim AI 2026
                </h2>
                <span className="text-xs text-purple-400 font-mono">GITA AI Insights</span>
              </div>

              <div className="space-y-2.5 text-xs text-slate-300">
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 space-y-1">
                  <div className="flex items-center justify-between font-bold text-amber-300">
                    <span>1. Chuyển Thể Sách Triết Lý & Kỳ Ảo</span>
                    <span className="text-[10px] text-emerald-400">+142% Tìm kiếm</span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Khán giả khao khát nội dung sâu sắc, hình ảnh tuyết sơn, cổ tự huyền bí hơn là nội dung giải trí nông cạn.
                  </p>
                </div>

                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 space-y-1">
                  <div className="flex items-center justify-between font-bold text-cyan-300">
                    <span>2. Mini-Series 10 - 15 Phút Chuẩn 4K</span>
                    <span className="text-[10px] text-emerald-400">+89% Xu hướng</span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Thời lượng lý tưởng để xem trên Smart TV và điện thoại mà không gây mệt mỏi.
                  </p>
                </div>

                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 space-y-1">
                  <div className="flex items-center justify-between font-bold text-purple-300">
                    <span>3. Giữ Nhân Vật Nhất Quán 100%</span>
                    <span className="text-[10px] text-emerald-400">Yếu tố quyết định</span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Người xem chỉ gắn bó với bộ phim khi gương mặt và tính cách nhân vật không bị biến đổi qua các tập.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
