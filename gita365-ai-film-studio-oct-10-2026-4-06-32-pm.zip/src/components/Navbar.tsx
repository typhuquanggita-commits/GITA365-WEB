import React, { useState } from 'react';
import {
  Film,
  Sparkles,
  Cloud,
  CheckCircle2,
  Monitor,
  Smartphone,
  Crown,
  PlayCircle,
  Bot,
  Layers,
  Users,
  Settings,
  Download,
  RotateCcw,
  RefreshCw,
} from 'lucide-react';
import { FilmProject } from '../types';

interface NavbarProps {
  currentProject: FilmProject;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenRenderModal: () => void;
  onToggleCopilot: () => void;
  isCopilotOpen: boolean;
  gitaPoints: number;
  currentUser?: { email?: string | null; displayName?: string | null; photoURL?: string | null } | null;
  onLogin?: () => void;
  onLogout?: () => void;
  autoSaveStatus?: 'saved' | 'saving' | 'synced_cloud';
  lastSavedTime?: string;
  onOpenDraftModal?: () => void;
  onManualSaveFirestore?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentProject,
  activeTab,
  setActiveTab,
  onOpenRenderModal,
  onToggleCopilot,
  isCopilotOpen,
  gitaPoints,
  currentUser,
  onLogin,
  onLogout,
  autoSaveStatus = 'saved',
  lastSavedTime = 'Vừa xong',
  onOpenDraftModal,
  onManualSaveFirestore,
}) => {
  const [devicePreview, setDevicePreview] = useState<'desktop' | 'mobile'>('desktop');
  const [showCloudDetails, setShowCloudDetails] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  const navItems = [
    { id: 'script', label: '1. Kịch Bản Sách', icon: '📖' },
    { id: 'character', label: '2. Nhân Vật Nhất Quán', icon: '🎭' },
    { id: 'studio', label: '3. Xưởng Dựng & Render', icon: '🎬' },
    { id: 'audio', label: '4. Thu Âm & Nhạc AI', icon: '🎙️' },
    { id: 'thumbnail', label: '5. Thumbnail & Phụ Đề', icon: '🖼️' },
    { id: 'scheduler', label: '6. Lập Lịch Đa Nền Tảng', icon: '📅' },
    { id: 'analytics', label: '7. Phân Tích & Dự Báo Doanh Thu', icon: '📊' },
    { id: 'webtovideo', label: '8. Web Sang Video', icon: '🌐' },
    { id: 'team', label: '9. Nhóm & Bảng Xếp Hạng', icon: '👥' },
    { id: 'pricing', label: '10. Thanh Toán & Gói Cước', icon: '👑' },
    { id: 'presenters', label: '11. Dàn MC & Trainer Quang', icon: '👔' },
    { id: 'admin', label: '12. Quản Trị Khách Hàng', icon: '🛡️' },
    { id: 'photo2video', label: '13. 1 Ảnh Ra Video 1-3 Phút (VIP)', icon: '📸' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-slate-950/95 backdrop-blur-md border-b border-slate-800 text-slate-100 shadow-2xl">
      {/* Top Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand & Project Info */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-11 h-11 rounded-xl bg-gradient-to-tr from-amber-600 via-amber-500 to-yellow-400 text-slate-950 font-black shadow-lg shadow-amber-500/20">
            <Film className="w-6 h-6 text-slate-950" />
            <span className="absolute -top-1 -right-1 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
            </span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 text-lg">
                GITA365
              </span>
              <span className="text-xs px-2 py-0.5 rounded-full font-semibold uppercase bg-amber-500/10 text-amber-300 border border-amber-500/30">
                Film Studio AI
              </span>
            </div>
            <p className="text-xs text-slate-400 truncate max-w-xs sm:max-w-md font-medium">
              🎬 {currentProject.title}
            </p>
          </div>
        </div>

        {/* Center / Real-Time Auto-Save & Cloud Sync Badge */}
        <div className="hidden md:flex items-center gap-3 bg-slate-900/90 px-3 py-1.5 rounded-xl border border-slate-800">
          <div className="relative">
            <button
              onClick={() => setShowCloudDetails(!showCloudDetails)}
              className={`flex items-center gap-1.5 text-xs transition-colors font-medium ${
                autoSaveStatus === 'saving'
                  ? 'text-amber-300'
                  : autoSaveStatus === 'synced_cloud'
                  ? 'text-cyan-300'
                  : 'text-emerald-400 hover:text-emerald-300'
              }`}
              title="Xem trạng thái lưu nháp tự động và đồng bộ"
            >
              {autoSaveStatus === 'saving' ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 text-amber-400 animate-spin" />
                  <span>Đang Lưu Nháp...</span>
                </>
              ) : autoSaveStatus === 'synced_cloud' ? (
                <>
                  <Cloud className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Cloud Firestore: Đã Đồng Bộ</span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Đã Lưu Nháp ({lastSavedTime})</span>
                </>
              )}
            </button>
            {showCloudDetails && (
              <div className="absolute top-8 left-0 w-72 bg-slate-900 border border-slate-700 rounded-2xl p-4 shadow-2xl text-xs z-50 animate-in fade-in space-y-3">
                <div className="font-bold text-slate-100 flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="flex items-center gap-1.5 text-emerald-400">
                    <CheckCircle2 className="w-4 h-4" /> Hệ Thống Lưu Nháp Tự Động
                  </span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono">
                    Hoạt động
                  </span>
                </div>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  Mọi chỉnh sửa kịch bản, lời thoại và phân cảnh đều được tự động lưu nháp liên tục vào bộ nhớ máy tính. Dữ liệu của bạn luôn được bảo vệ an toàn 100%.
                </p>
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-[11px] space-y-1.5 text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Lần lưu nháp cuối:</span>
                    <span className="text-emerald-400 font-mono font-semibold">{lastSavedTime}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Đám mây Firestore:</span>
                    <span className={currentUser ? 'text-cyan-400 font-semibold' : 'text-amber-400'}>
                      {currentUser ? 'Đã kết nối' : 'Chưa đăng nhập'}
                    </span>
                  </div>
                </div>

                <div className="space-y-1.5 pt-1">
                  {onManualSaveFirestore && (
                    <button
                      onClick={() => {
                        setShowCloudDetails(false);
                        onManualSaveFirestore();
                      }}
                      className="w-full py-1.5 px-3 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <Cloud className="w-3.5 h-3.5" />
                      <span>{currentUser ? 'Lưu Ngay Lên Firestore' : 'Đăng Nhập & Lưu Lên Firestore'}</span>
                    </button>
                  )}
                  {onOpenDraftModal && (
                    <button
                      onClick={() => {
                        setShowCloudDetails(false);
                        onOpenDraftModal();
                      }}
                      className="w-full py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                      <span>Xem Lịch Sử Bản Nháp & Sao Lưu</span>
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>

          <div className="h-4 w-px bg-slate-800" />

          {/* Device preview switch */}
          <div className="flex items-center gap-1 bg-slate-950 p-0.5 rounded-lg border border-slate-800">
            <button
              onClick={() => setDevicePreview('desktop')}
              className={`p-1 rounded ${devicePreview === 'desktop' ? 'bg-amber-500/20 text-amber-300' : 'text-slate-500 hover:text-slate-400'}`}
              title="Chế độ Màn hình lớn"
            >
              <Monitor className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setDevicePreview('mobile')}
              className={`p-1 rounded ${devicePreview === 'mobile' ? 'bg-amber-500/20 text-amber-300' : 'text-slate-500 hover:text-slate-400'}`}
              title="Chế độ Di động"
            >
              <Smartphone className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Right CTA Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* 1 Photo To Video Quick Launcher */}
          <button
            onClick={() => setActiveTab('photo2video')}
            className={`hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all shadow-md ${
              activeTab === 'photo2video'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 border-amber-400 font-extrabold shadow-amber-500/20'
                : 'bg-slate-900 hover:bg-slate-800 text-amber-300 border-amber-500/40 hover:border-amber-400'
            }`}
          >
            <span>📸</span>
            <span>1 Ảnh Ra Video 1-3p</span>
            <span className="bg-emerald-500/20 text-emerald-300 px-1.5 py-0.2 rounded text-[10px] font-mono border border-emerald-500/30">
              Lãi 0.1$
            </span>
          </button>

          {/* Points / Tier badge */}
          <button
            onClick={() => setActiveTab('pricing')}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/10 via-yellow-500/10 to-amber-500/20 border border-amber-500/30 text-amber-300 hover:border-amber-400 transition-all text-xs font-semibold"
          >
            <Crown className="w-3.5 h-3.5 text-yellow-400" />
            <span>VIP Kim Cương</span>
            <span className="bg-amber-400/20 px-1.5 py-0.5 rounded text-[10px] text-amber-200 font-mono">
              {gitaPoints.toLocaleString()} G-Coin
            </span>
          </button>

          {/* AI Copilot Toggle */}
          <button
            onClick={onToggleCopilot}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
              isCopilotOpen
                ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30'
                : 'bg-slate-900 hover:bg-slate-800 text-purple-300 border border-purple-500/30'
            }`}
          >
            <Bot className="w-4 h-4 text-purple-400" />
            <span className="hidden sm:inline">AI Copilot</span>
          </button>

          {/* User Auth Profile / Login */}
          {currentUser ? (
            <div className="relative">
              <button
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="flex items-center gap-2 p-1 pl-2 pr-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700/80 transition-all text-xs"
              >
                <img
                  src={
                    currentUser.photoURL ||
                    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'
                  }
                  alt={currentUser.displayName || 'User'}
                  className="w-6 h-6 rounded-full object-cover border border-amber-500"
                />
                <span className="font-bold text-slate-200 hidden md:inline truncate max-w-[100px]">
                  {currentUser.displayName || 'Nhà làm phim'}
                </span>
              </button>

              {showUserMenu && (
                <div className="absolute right-0 top-10 w-64 bg-slate-900 border border-slate-700 rounded-2xl p-3 shadow-2xl z-50 text-xs space-y-2.5 animate-in fade-in">
                  <div className="border-b border-slate-800 pb-2">
                    <div className="font-bold text-slate-100">{currentUser.displayName}</div>
                    <div className="text-[11px] text-slate-400 truncate">{currentUser.email}</div>
                    <div className="mt-1 flex items-center gap-1 text-[10px] text-emerald-400 font-semibold">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                      Đã xác thực Firebase Firestore
                    </div>
                  </div>

                  <div className="space-y-1">
                    <button
                      onClick={() => {
                        setActiveTab('admin');
                        setShowUserMenu(false);
                      }}
                      className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-slate-800 text-slate-300 hover:text-white flex items-center justify-between transition-colors"
                    >
                      <span>Quản Trị Khách Hàng</span>
                      <span className="text-[10px] bg-purple-500/20 text-purple-300 px-1.5 py-0.2 rounded font-bold">
                        ADMIN
                      </span>
                    </button>
                    <button
                      onClick={() => {
                        setActiveTab('pricing');
                        setShowUserMenu(false);
                      }}
                      className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-slate-800 text-slate-300 hover:text-white transition-colors"
                    >
                      Gói Cước & Quota Video
                    </button>
                  </div>

                  <div className="border-t border-slate-800 pt-2">
                    <button
                      onClick={() => {
                        if (onLogout) onLogout();
                        setShowUserMenu(false);
                      }}
                      className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-red-950/40 text-red-400 hover:text-red-300 transition-colors font-medium"
                    >
                      Đăng Xuất Tài Khoản
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={onLogin}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-bold transition-all"
            >
              <Users className="w-3.5 h-3.5 text-amber-400" />
              <span>Đăng Nhập</span>
            </button>
          )}

          {/* Export / Render 4K */}
          <button
            onClick={onOpenRenderModal}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/25 transition-all transform hover:scale-[1.02]"
          >
            <Sparkles className="w-4 h-4" />
            <span>Xuất Phim 4K</span>
          </button>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8 border-t border-slate-900 bg-slate-950/80 overflow-x-auto no-scrollbar">
        <nav className="flex items-center gap-1 py-1.5 min-w-max">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-amber-500/15 text-amber-300 border border-amber-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                <span>{item.icon}</span>
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
