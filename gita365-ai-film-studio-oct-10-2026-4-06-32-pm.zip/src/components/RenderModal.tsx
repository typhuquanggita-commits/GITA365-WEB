import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Download,
  CheckCircle2,
  Cpu,
  Layers,
  Film,
  Share2,
  HardDrive,
  Play,
  RotateCcw,
  ShieldCheck,
} from 'lucide-react';
import { FilmProject } from '../types';

interface RenderModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: FilmProject;
  onNavigateToScheduler: () => void;
}

export const RenderModal: React.FC<RenderModalProps> = ({
  isOpen,
  onClose,
  project,
  onNavigateToScheduler,
}) => {
  const [resolution, setResolution] = useState<'4K Ultra HD (2160p)' | 'Full HD (1080p)' | 'HD (720p)'>('4K Ultra HD (2160p)');
  const [fps, setFps] = useState<'24 fps (Điện ảnh)' | '30 fps' | '60 fps'>('24 fps (Điện ảnh)');
  const [codec, setCodec] = useState<'H.265 / HEVC' | 'H.264 / MP4' | 'Apple ProRes 422'>('H.265 / HEVC');
  const [isRendering, setIsRendering] = useState(false);
  const [renderProgress, setRenderProgress] = useState(0);
  const [currentStepText, setCurrentStepText] = useState('');
  const [isDone, setIsDone] = useState(false);

  useEffect(() => {
    let timer: number;
    if (isRendering) {
      setRenderProgress(0);
      setIsDone(false);

      const steps = [
        'Khởi tạo luồng xử lý phần cứng GITA365 Super-GPU Cluster...',
        'Khóa nhận diện khuôn mặt nhân vật và khử nhiễu...',
        'Xử lý hiệu ứng chuyển động máy quay Ken Burns 8K...',
        'Tổng hợp âm thanh vòm Dolby Atmos 5.1 & SFX...',
        'Ghép nối lớp phụ đề đa ngôn ngữ tự động...',
        'Mã hóa luồng dữ liệu 4K H.265 Ultra Bitrate...',
        'Đóng gói tệp video hoàn chỉnh (.mp4)...',
      ];

      timer = window.setInterval(() => {
        setRenderProgress((prev) => {
          const next = prev + 5;
          const stepIndex = Math.min(Math.floor((next / 100) * steps.length), steps.length - 1);
          setCurrentStepText(steps[stepIndex]);

          if (next >= 100) {
            clearInterval(timer);
            setIsRendering(false);
            setIsDone(true);
            return 100;
          }
          return next;
        });
      }, 200);
    }
    return () => clearInterval(timer);
  }, [isRendering]);

  if (!isOpen) return null;

  const handleStartRender = () => {
    setIsRendering(true);
  };

  const handleDownloadFile = () => {
    // Generate dummy downloadable file
    const element = document.createElement('a');
    const file = new Blob([`GITA365 Film Export: ${project.title}`], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = `${project.title.replace(/\s+/g, '_')}_4K_Cinema.mp4`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in">
      <div className="w-full max-w-xl bg-slate-900 rounded-3xl border border-slate-800 p-6 sm:p-7 shadow-2xl space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-300">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">Cỗ Máy Xuất Phim 4K Siêu Tốc (GITA Super-Render)</h3>
              <p className="text-xs text-slate-400">
                {project.title} • Tập 1 ({project.episodeDurationMinutes} phút)
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white text-sm">
            ✕
          </button>
        </div>

        {!isRendering && !isDone && (
          <div className="space-y-4 text-xs">
            {/* Setting options */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-300 font-semibold mb-1 block">Độ phân giải xuất:</label>
                <select
                  value={resolution}
                  onChange={(e) => setResolution(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500 font-medium"
                >
                  <option value="4K Ultra HD (2160p)">4K Ultra HD (3840x2160) - Siêu nét</option>
                  <option value="Full HD (1080p)">Full HD (1920x1080) - Tiêu chuẩn</option>
                  <option value="HD (720p)">HD (1280x720) - Nhẹ nhanh</option>
                </select>
              </div>

              <div>
                <label className="text-slate-300 font-semibold mb-1 block">Tốc độ khung hình (FPS):</label>
                <select
                  value={fps}
                  onChange={(e) => setFps(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500 font-medium"
                >
                  <option value="24 fps (Điện ảnh)">24 fps (Chuẩn Điện Ảnh Hollywood)</option>
                  <option value="30 fps">30 fps (Chuẩn Truyền Hình)</option>
                  <option value="60 fps">60 fps (Mượt mà Game/Hành động)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-300 font-semibold mb-1 block">Chuẩn nén Video Codec:</label>
                <select
                  value={codec}
                  onChange={(e) => setCodec(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500 font-medium"
                >
                  <option value="H.265 / HEVC">H.265 / HEVC (Tối ưu dung lượng 4K)</option>
                  <option value="H.264 / MP4">H.264 / MP4 (Tương thích mọi thiết bị)</option>
                  <option value="Apple ProRes 422">Apple ProRes 422 (Dựng phim chuyên nghiệp)</option>
                </select>
              </div>

              <div>
                <label className="text-slate-300 font-semibold mb-1 block">Tăng tốc phần cứng:</label>
                <div className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-emerald-400 font-mono flex items-center gap-1.5">
                  <Cpu className="w-3.5 h-3.5" />
                  <span>NVIDIA H100 GPU Cluster (10x)</span>
                </div>
              </div>
            </div>

            {/* Render Preview Specs */}
            <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 text-[11px] space-y-1.5">
              <div className="flex justify-between text-slate-300">
                <span>Dung lượng ước tính:</span>
                <span className="font-mono text-amber-300 font-bold">~1.24 GB (4K H.265)</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Thời gian render dự kiến:</span>
                <span className="font-mono text-emerald-400 font-bold">Dưới 15 giây</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Bao gồm:</span>
                <span className="text-slate-400">Hình ảnh 8K + Giọng đọc AI + Nhạc vòm + Phụ đề</span>
              </div>
            </div>

            {/* Pre-render Content Moderation Verification Badge */}
            <div className="bg-emerald-950/40 border border-emerald-500/30 p-3 rounded-2xl flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <div>
                  <div className="font-bold text-emerald-300">Bộ Lọc Kiểm Duyệt: Đã Xác Thực An Toàn</div>
                  <div className="text-[10px] text-slate-400">
                    Kịch bản & hình ảnh không vi phạm chính sách cộng đồng YouTube/TikTok.
                  </div>
                </div>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold shrink-0">
                PASS 100%
              </span>
            </div>

            <button
              onClick={handleStartRender}
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 hover:brightness-110 text-slate-950 font-extrabold text-sm shadow-xl shadow-amber-500/25 flex items-center justify-center gap-2 transition-all transform active:scale-95"
            >
              <Sparkles className="w-4 h-4" />
              <span>Bắt Đầu Render Phim 4K Siêu Tốc</span>
            </button>
          </div>
        )}

        {isRendering && (
          <div className="space-y-6 py-6 text-center">
            <div className="relative w-24 h-24 mx-auto flex items-center justify-center">
              <div className="absolute inset-0 rounded-full border-4 border-slate-800 border-t-amber-400 animate-spin" />
              <span className="font-mono text-xl font-black text-amber-300">{renderProgress}%</span>
            </div>

            <div className="space-y-2">
              <h4 className="font-bold text-white text-sm">Đang Xử Lý Kết Xuất Video Đa Luồng...</h4>
              <p className="text-xs text-amber-400 font-mono animate-pulse">{currentStepText}</p>
            </div>

            <div className="w-full h-3 bg-slate-950 rounded-full overflow-hidden p-0.5 border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 rounded-full transition-all duration-200"
                style={{ width: `${renderProgress}%` }}
              />
            </div>
          </div>
        )}

        {isDone && (
          <div className="space-y-5 py-4 text-center">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 mx-auto flex items-center justify-center shadow-lg">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <div>
              <h4 className="font-extrabold text-white text-lg">Xuất Video 4K Thành Công!</h4>
              <p className="text-xs text-slate-400 mt-1">
                Tệp video đã sẵn sàng phát sóng trên YouTube, TikTok, Facebook hoặc chiếu rạp online.
              </p>
            </div>

            {/* Video preview thumbnail */}
            <div className="relative aspect-video rounded-2xl overflow-hidden border border-slate-800 shadow-xl max-w-sm mx-auto">
              <img
                src={project.episodes[0]?.acts[0]?.scenes[0]?.imageUrl || 'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=800&auto=format&fit=crop&q=80'}
                alt="Rendered Video Preview"
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-2 left-2 px-2 py-0.5 rounded bg-black/80 text-[10px] text-amber-300 font-mono">
                {resolution} • 60 FPS
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <button
                onClick={handleDownloadFile}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-bold text-xs shadow-lg flex items-center justify-center gap-2 transition-transform hover:scale-105"
              >
                <Download className="w-4 h-4" />
                <span>Tải Xuống Video .MP4</span>
              </button>
              <button
                onClick={() => {
                  onClose();
                  onNavigateToScheduler();
                }}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 flex items-center justify-center gap-2 transition-all"
              >
                <Share2 className="w-4 h-4 text-amber-400" />
                <span>Lập Lịch Đăng Lên MXH</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
