import React, { useState } from 'react';
import {
  Music,
  Mic,
  Camera,
  Play,
  Pause,
  Sparkles,
  Users,
  Film,
  Crown,
  CheckCircle2,
  Sliders,
  DollarSign,
  ShieldCheck,
  Flame,
  Upload,
  Radio,
  Tv,
  Eye,
  Zap,
  Volume2,
  RefreshCw,
  Video,
  Layers,
  ArrowRight,
  Disc,
  Award,
  Check,
  Info,
  Share2,
} from 'lucide-react';
import { FilmProject, MVTierLevel, MVStageSettings, MVProductionResult, Scene } from '../types';
import {
  MV_TIER_CONFIGS,
  MV_STAGE_LOCATIONS,
  SAMPLE_MV_SONGS,
} from '../data/mvConfigurations';

interface MusicVideoStudioViewProps {
  project: FilmProject;
  onUpdateProject: (updated: FilmProject) => void;
  onNavigateToStudio: () => void;
  onNavigateToAnalytics: () => void;
}

export const MusicVideoStudioView: React.FC<MusicVideoStudioViewProps> = ({
  project,
  onUpdateProject,
  onNavigateToStudio,
  onNavigateToAnalytics,
}) => {
  // Input fields
  const [songTitle, setSongTitle] = useState<string>(SAMPLE_MV_SONGS[0].title);
  const [artistName, setArtistName] = useState<string>(SAMPLE_MV_SONGS[0].artist);
  const [selectedGenre, setSelectedGenre] = useState<string>('vpop');
  const [lyrics, setLyrics] = useState<string>(SAMPLE_MV_SONGS[0].lyrics);
  const [mvConcept, setMvConcept] = useState<string>(SAMPLE_MV_SONGS[0].concept);

  // Audio mode: 'ai_generate' | 'upload'
  const [musicMode, setMusicMode] = useState<'ai_generate' | 'upload'>('ai_generate');
  const [uploadedAudioFileName, setUploadedAudioFileName] = useState<string | null>(null);
  const [uploadedAudioUrl, setUploadedAudioUrl] = useState<string>('');
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);

  // Singer Avatar / User photo anchor
  const [singerPhotoUrl, setSingerPhotoUrl] = useState<string>(SAMPLE_MV_SONGS[0].singerAvatar);
  const [singerPhotoName, setSingerPhotoName] = useState<string>('Chân dung ca sĩ khách hàng');

  // Stage & Ensemble Settings
  const [hasBackupDancers, setHasBackupDancers] = useState<boolean>(true);
  const [dancersChoreography, setDancersChoreography] = useState<
    'kpop_synchronized' | 'circle_singer' | 'freestyle_hype' | 'backing_vocal_group'
  >('kpop_synchronized');
  const [hasLiveBand, setHasLiveBand] = useState<boolean>(true);
  const [bandType, setBandType] = useState<
    'rock_pop_ensemble' | 'acoustic_trio' | 'philharmonic_orchestra' | 'electronic_dj_decks'
  >('rock_pop_ensemble');
  const [selectedLocations, setSelectedLocations] = useState<string[]>([
    'Sân Khấu Concert 50.000 Khán Giả',
    'Phim Trường LED Neon Cyberpunk',
    'Cung Điện Châu Âu Hoàng Gia Baroque',
    'Đường Phố Mưa Đêm Ánh Đèn Cinematic',
  ]);

  // VIP Tier selection
  const [selectedVipTier, setSelectedVipTier] = useState<MVTierLevel>('mv_pro_4k');

  // Execution states
  const [isProducing, setIsProducing] = useState<boolean>(false);
  const [productionProgress, setProductionProgress] = useState<number>(0);
  const [productionResult, setProductionResult] = useState<MVProductionResult | null>(null);
  const [activeSceneIdx, setActiveSceneIdx] = useState<number>(0);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const currentTierConfig = MV_TIER_CONFIGS[selectedVipTier] || MV_TIER_CONFIGS.mv_pro_4k;

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Quick Load Sample Song
  const handleLoadSampleSong = (sample: (typeof SAMPLE_MV_SONGS)[0]) => {
    setSongTitle(sample.title);
    setArtistName(sample.artist);
    setSelectedGenre(sample.genre);
    setLyrics(sample.lyrics);
    setMvConcept(sample.concept);
    setSingerPhotoUrl(sample.singerAvatar);
    setSingerPhotoName(`Mẫu ca sĩ: ${sample.artist}`);
    showToast(`Đã tải mẫu bài hát "${sample.title}"!`);
  };

  // Upload Customer Singer Photo
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const url = event.target?.result as string;
      if (url) {
        setSingerPhotoUrl(url);
        setSingerPhotoName(file.name);
        showToast(`Đã tải ảnh "${file.name}" làm mỏ neo diện mạo ca sĩ!`);
      }
    };
    reader.readAsDataURL(file);
  };

  // Upload Customer Audio File
  const handleAudioUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadedAudioFileName(file.name);
    setMusicMode('upload');
    const url = URL.createObjectURL(file);
    setUploadedAudioUrl(url);
    showToast(`Đã tải lên file nhạc "${file.name}" để khớp video!`);
  };

  // Toggle stage location selection
  const handleToggleLocation = (locName: string) => {
    if (selectedLocations.includes(locName)) {
      if (selectedLocations.length > 1) {
        setSelectedLocations(selectedLocations.filter((l) => l !== locName));
      }
    } else {
      setSelectedLocations([...selectedLocations, locName]);
    }
  };

  // Execute MV Production Pipeline
  const handleProduceMV = async () => {
    if (!singerPhotoUrl) {
      alert('Vui lòng chọn hoặc tải lên ảnh chân dung ca sĩ!');
      return;
    }
    if (!lyrics.trim()) {
      alert('Vui lòng nhập lời bài hát để hệ thống đồng bộ khẩu hình và nhịp điệu!');
      return;
    }

    setIsProducing(true);
    setProductionProgress(15);

    const progressTimer = setInterval(() => {
      setProductionProgress((prev) => (prev < 90 ? prev + 18 : prev));
    }, 800);

    try {
      const payload = {
        songTitle,
        artistName,
        singerPhotoUrl,
        lyrics,
        musicMode,
        audioUrl: uploadedAudioUrl,
        genre: selectedGenre,
        stageSettings: {
          hasBackupDancers,
          dancersChoreography,
          hasLiveBand,
          bandType,
          lipSyncAccuracy: 'high_precision_phoneme',
          spaceLocations: selectedLocations,
        },
        vipTier: selectedVipTier,
      };

      const res = await fetch('/api/mv/produce', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      clearInterval(progressTimer);
      setProductionProgress(100);

      if (data && data.success && Array.isArray(data.scenes)) {
        setProductionResult(data);
        setActiveSceneIdx(0);
        showToast(`Đã sản xuất thành công MV "${songTitle}" chuẩn sân khấu triệu đô!`);
      } else {
        throw new Error(data.error || 'Lỗi sản xuất MV');
      }
    } catch (err: any) {
      clearInterval(progressTimer);
      console.warn('MV production fallback note:', err.message);
      // Fallback local result
      const scenesCount = currentTierConfig.scenesCount;
      const secPerScene = Math.round((currentTierConfig.durationMinutes * 60) / scenesCount);
      const mockResult: MVProductionResult = {
        id: `mv-res-${Date.now()}`,
        title: songTitle,
        artistName,
        genreName: selectedGenre.toUpperCase(),
        durationMinutes: currentTierConfig.durationMinutes,
        totalDurationSeconds: currentTierConfig.durationMinutes * 60,
        audioTrackUrl: uploadedAudioUrl || 'https://samplelib.com/lib/preview/mp3/sample-15s.mp3',
        anchorSingerPhoto: singerPhotoUrl,
        stageLocations: selectedLocations,
        stageChoreographyNotes: `Vũ đoàn nhảy đồng bộ ${dancersChoreography} quanh ca sĩ. Ban nhạc ${bandType} biểu diễn trực tiếp.`,
        lipSyncReport: {
          phonemeSyncRate: 98.8,
          tempoBPM: 126,
          beatDropCount: 8,
        },
        pricingBreakdown: {
          rawComputeCostUSD: currentTierConfig.rawComputeCostUSD,
          gitaMarginUSD: 0.50,
          finalPriceUSD: currentTierConfig.finalPriceUSD,
          finalPriceVND: currentTierConfig.finalPriceVND,
          costItems: [
            { label: 'Render Đa Bối Cảnh & Giữ Nét Ca Sĩ', amountUSD: 1.35, desc: 'Bảo toàn visual từ ảnh gốc' },
            { label: 'AI Lip-Sync Khẩu Hình Chuẩn Lời Hát', amountUSD: 0.95, desc: 'Deep-Phoneme Matching 98.8%' },
            { label: 'Mô Phỏng Vũ Đoàn K-Pop & Ban Nhạc Sống', amountUSD: 0.95, desc: 'Vũ đạo đồng bộ & nhạc công' },
            { label: 'Hòa Âm Audio & Bản Quyền Kiếm Tiền', amountUSD: 0.65, desc: 'Sẵn sàng YouTube Content ID' },
            { label: 'Lợi Nhuận GITA365 Cam Kết Minh Bạch', amountUSD: 0.50, desc: 'Đúng 0.5 USD (~12.500đ) / bài' },
          ],
        },
        commercialRights: {
          youtubeMonetizationReady: true,
          tiktokCommercialLicense: true,
          contentIdProtected: true,
          licenseCode: `GITA-MV-${Date.now().toString(36).toUpperCase()}`,
        },
        scenes: Array.from({ length: scenesCount }).map((_, idx) => {
          const loc = selectedLocations[idx % selectedLocations.length];
          return {
            id: `sc-mv-${idx + 1}`,
            sceneNumber: idx + 1,
            title: `Phân Cảnh ${idx + 1}: ${idx === 0 ? 'Khai Màn Concert Rực Lửa' : idx === Math.floor(scenesCount / 2) ? 'Điệp Khúc Cao Trào Cùng Vũ Đoàn' : 'Đỉnh Cao Hòa Âm & Pháo Hoa'}`,
            location: loc,
            timeOfDay: 'Đêm diễn nghệ thuật',
            lighting: 'Moving Head, Laser 3D, Beam đa sắc',
            cameraAngle: idx % 2 === 0 ? 'Orbit 360 quanh ca sĩ' : 'Crane Shot từ khán đài hạ xuống',
            description: `Ca sĩ hát khẩu hình khớp lời nhạc tại ${loc}. Vũ đoàn và ban nhạc biểu diễn bốc lửa.`,
            visualPrompt: `Million dollar MV cinematic still, ${artistName} performing at ${loc}, laser lights, 8k resolution`,
            dialogue: [
              {
                id: `dg-mv-${idx + 1}`,
                speaker: artistName,
                emotion: 'Bùng nổ đam mê',
                text: lyrics.slice(0, 80) + '...',
              },
            ],
            sfx: 'Âm thanh khán đài 50.000 người reo hò, tiếng trống và guitar solo',
            bgmMood: `${selectedGenre.toUpperCase()} Master Mix`,
            durationSeconds: secPerScene,
            imageUrl: singerPhotoUrl,
          };
        }),
      };
      setProductionResult(mockResult);
    } finally {
      setIsProducing(false);
    }
  };

  // Sync with main Video Studio
  const handleExportToVideoStudio = () => {
    if (!productionResult) return;

    const newActs = [
      {
        actNumber: 1,
        name: `MV: ${productionResult.title} - ${productionResult.artistName}`,
        scenes: productionResult.scenes,
      },
    ];

    const updatedEpisodes = [...project.episodes];
    if (updatedEpisodes.length > 0) {
      updatedEpisodes[0] = {
        ...updatedEpisodes[0],
        title: `MV: ${productionResult.title}`,
        synopsis: `MV Ca Nhạc triệu đô của ${productionResult.artistName} với bối cảnh concert, vũ đoàn và ban nhạc sống.`,
        durationMinutes: productionResult.durationMinutes,
        acts: newActs,
      };
    } else {
      updatedEpisodes.push({
        id: `ep-mv-${Date.now()}`,
        episodeNumber: 1,
        title: `MV: ${productionResult.title}`,
        durationMinutes: productionResult.durationMinutes,
        synopsis: `MV Ca Nhạc triệu đô của ${productionResult.artistName}.`,
        acts: newActs,
      });
    }

    onUpdateProject({
      ...project,
      title: `MV: ${productionResult.title} (${productionResult.artistName})`,
      resolution: selectedVipTier === 'mv_indie_2k' ? '1080p' : '4K UHD',
      episodes: updatedEpisodes,
      updatedAt: new Date().toISOString(),
    });

    showToast('Đã nạp toàn bộ MV vào Xưởng Dựng! Đang chuyển hướng...');
    setTimeout(() => {
      onNavigateToStudio();
    }, 1200);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-300">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 px-5 py-3 rounded-2xl font-bold shadow-2xl flex items-center gap-3 border border-yellow-300 animate-bounce">
          <Sparkles className="w-5 h-5" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950/40 to-amber-950/40 border border-amber-500/40 p-8 sm:p-10 shadow-2xl">
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-96 h-96 rounded-full bg-purple-500/10 blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="space-y-4 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r from-purple-500/20 to-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-bold uppercase tracking-wider">
              <Disc className="w-4 h-4 text-amber-400 animate-spin" />
              <span>Sản Xuất MV Ca Nhạc Triệu Đô Từ Lời Bài Hát & Ảnh Khách Hàng</span>
              <span className="bg-amber-400 text-slate-950 text-[10px] px-1.5 py-0.5 rounded-full font-black">
                VIP
              </span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white leading-tight">
              Biến Bức Ảnh Của Bạn Thành{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500">
                MV Ca Nhạc Triệu Đô
              </span>
            </h1>

            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              Khách có bài hát & lời nhạc ➔ Hệ thống tự tạo nhạc hoặc tải nhạc riêng ➔ Dùng ảnh chân dung khách để tạo MV chuyên nghiệp như ca sĩ hàng đầu. Khớp khẩu hình từng câu hát, vũ đoàn K-Pop nhảy đồng bộ, ban nhạc sống hòa tấu cuồng nhiệt và đa dạng bối cảnh concert hoành tráng!
            </p>

            {/* 0.5 USD Transparent Profit Banner */}
            <div className="inline-flex flex-wrap items-center gap-3 p-3.5 rounded-2xl bg-slate-950/90 border border-emerald-500/40 text-xs text-slate-200 shadow-inner">
              <div className="flex items-center gap-2">
                <span className="flex items-center justify-center w-7 h-7 rounded-full bg-emerald-500/20 text-emerald-400 font-black">
                  $
                </span>
                <span className="font-bold text-emerald-400">CHÍNH SÁCH LỢI NHUẬN CỐ ĐỊNH MINH BẠCH: </span>
              </div>
              <div>
                <span>Toàn bộ chi phí trả cho hệ thống sản xuất. GITA365 chỉ thu đúng </span>
                <strong className="text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded font-black text-sm">
                  +0.5 USD (~12.500 VNĐ)
                </strong>{' '}
                <span>lợi nhuận trên mỗi bài hát MV thành công! Video có đầy đủ bản quyền thương mại để kinh doanh trên mạng xã hội.</span>
              </div>
            </div>
          </div>

          {/* Quick Nav to MV Revenue Dashboard */}
          <div className="bg-slate-950/95 border border-slate-800 p-5 rounded-2xl shadow-xl flex flex-col gap-3 min-w-[260px] text-center">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Theo Dõi Lợi Nhuận MV:
            </div>
            <div className="text-2xl font-black text-amber-400 font-mono">
              0.50 USD <span className="text-xs text-slate-400 font-sans font-normal">/ bài hát</span>
            </div>
            <button
              onClick={onNavigateToAnalytics}
              className="py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2"
            >
              <Eye className="w-4 h-4" />
              <span>Xem MV Revenue Dashboard</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Left Setup (8 cols) / Right Preview & Cost (4 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column (8 cols): Step by Step MV Config */}
        <div className="lg:col-span-8 space-y-8">
          {/* STEP 1: Bài Hát, Lời Nhạc & Âm Nhạc */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="flex items-center justify-center w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 font-black text-sm border border-amber-500/40">
                  1
                </span>
                <div>
                  <h2 className="text-lg font-bold text-white">Bài Hát, Lời Nhạc & Lựa Chọn Âm Thanh</h2>
                  <p className="text-xs text-slate-400">
                    Khách có thể tạo nhạc AI theo lời hát hoặc tải file nhạc riêng để hệ thống khớp video.
                  </p>
                </div>
              </div>
            </div>

            {/* Quick Sample Selector */}
            <div className="space-y-2">
              <div className="text-xs font-bold text-slate-400 flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Hoặc chọn nhanh kịch bản MV mẫu có sẵn:</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {SAMPLE_MV_SONGS.map((sample) => (
                  <button
                    key={sample.id}
                    onClick={() => handleLoadSampleSong(sample)}
                    className={`p-3 rounded-xl border text-left text-xs transition-all ${
                      songTitle === sample.title
                        ? 'bg-amber-500/20 border-amber-500 text-white font-bold'
                        : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-900'
                    }`}
                  >
                    <div className="font-bold truncate text-slate-100">{sample.title}</div>
                    <div className="text-[10px] text-amber-400 truncate">{sample.genreName}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Song Meta Inputs */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Tên bài hát:</label>
                <input
                  type="text"
                  value={songTitle}
                  onChange={(e) => setSongTitle(e.target.value)}
                  placeholder="Vd: Bản Tình Ca Đêm Đông..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Ca sĩ / Nghệ sĩ biểu diễn:</label>
                <input
                  type="text"
                  value={artistName}
                  onChange={(e) => setArtistName(e.target.value)}
                  placeholder="Vd: Nguyễn Văn A ft. GITA Band..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            {/* Music Mode Switcher: AI Generated vs Uploaded Audio */}
            <div className="space-y-3 pt-3 border-t border-slate-800">
              <label className="text-xs font-bold text-slate-300 block">Nguồn âm thanh / Bản phối nhạc:</label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setMusicMode('ai_generate')}
                  className={`p-4 rounded-2xl border text-left flex items-start gap-3 transition-all ${
                    musicMode === 'ai_generate'
                      ? 'bg-amber-500/20 border-amber-500 text-white shadow-md ring-2 ring-amber-500/40'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <Sparkles className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <div className="text-xs font-bold text-white">AI Phối Nhạc Theo Lời Bài Hát</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">
                      Hệ thống tự động sáng tác beat, giai điệu và vocal chuẩn phòng thu 24kHz.
                    </div>
                  </div>
                </button>

                <div
                  className={`p-4 rounded-2xl border text-left flex items-start gap-3 transition-all ${
                    musicMode === 'upload'
                      ? 'bg-purple-500/20 border-purple-500 text-white shadow-md ring-2 ring-purple-500/40'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <Upload className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
                  <div className="w-full">
                    <div className="text-xs font-bold text-white">Khách Tải Nhạc Riêng Lên (MP3/WAV)</div>
                    <div className="text-[11px] text-slate-400 mt-0.5 mb-2">
                      {uploadedAudioFileName ? `Đã chọn: ${uploadedAudioFileName}` : 'Khớp trực tiếp video với bản thu âm của bạn.'}
                    </div>
                    <label className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-[11px] font-bold cursor-pointer transition-colors">
                      <span>{uploadedAudioFileName ? 'Đổi File Khác' : 'Chọn File Audio'}</span>
                      <input type="file" accept="audio/*" onChange={handleAudioUpload} className="hidden" />
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* Lyrics Input */}
            <div className="space-y-2 pt-3 border-t border-slate-800">
              <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                <span>Lời bài hát (Lyrics để khớp khẩu hình Lip-sync):</span>
                <span className="text-[10px] text-amber-400">Động tác hát khớp từng nguyên âm</span>
              </label>
              <textarea
                rows={5}
                value={lyrics}
                onChange={(e) => setLyrics(e.target.value)}
                placeholder="Dán lời bài hát tại đây (gồm Verse, Chorus, Bridge)..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-200 focus:outline-none focus:border-amber-500 font-mono leading-relaxed"
              />
            </div>
          </div>

          {/* STEP 2: Bối Cảnh Không Gian Triệu Đô & Sân Khấu Concert */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="flex items-center justify-center w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 font-black text-sm border border-amber-500/40">
                  2
                </span>
                <div>
                  <h2 className="text-lg font-bold text-white">Đa Dạng Bối Cảnh Không Gian Triệu Đô</h2>
                  <p className="text-xs text-slate-400">
                    Chọn các không gian MV để hệ thống tự động chuyển cảnh điện ảnh mượt mà.
                  </p>
                </div>
              </div>
              <span className="text-xs px-2.5 py-1 rounded-full bg-slate-800 text-amber-400 font-bold">
                Đã chọn: {selectedLocations.length} bối cảnh
              </span>
            </div>

            {/* Locations Cards Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {MV_STAGE_LOCATIONS.map((loc) => {
                const isSelected = selectedLocations.includes(loc.name);
                return (
                  <div
                    key={loc.id}
                    onClick={() => handleToggleLocation(loc.name)}
                    className={`rounded-2xl border p-2.5 cursor-pointer transition-all flex flex-col justify-between ${
                      isSelected
                        ? 'bg-amber-500/20 border-amber-500 ring-2 ring-amber-500/40 shadow-lg'
                        : 'bg-slate-950 border-slate-800 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <div className="relative rounded-xl overflow-hidden aspect-video bg-slate-900 mb-2">
                      <img src={loc.imageUrl} alt={loc.name} className="w-full h-full object-cover" />
                      {isSelected && (
                        <div className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center">
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </div>
                      )}
                    </div>
                    <div className="text-[11px] font-bold text-white line-clamp-1">{loc.name}</div>
                    <div className="text-[9px] text-slate-400 truncate">{loc.category}</div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* STEP 3: Vũ Đoàn Nhảy Phụ Họa & Ban Nhạc Sống */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
            <div className="flex items-center gap-3">
              <span className="flex items-center justify-center w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 font-black text-sm border border-amber-500/40">
                3
              </span>
              <div>
                <h2 className="text-lg font-bold text-white">Vũ Đoàn Nhảy Đồng Bộ & Ban Nhạc Sống Sân Khấu</h2>
                <p className="text-xs text-slate-400">
                  Tùy chỉnh nhóm nhảy bao quanh ca sĩ, hát bè và ban nhạc sống biểu diễn cuồng nhiệt.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {/* Backup Dancers Controls */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
                    <Users className="w-4 h-4 text-amber-400" />
                    <span>Vũ Đoàn Phụ Họa (Backup Dancers)</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={hasBackupDancers}
                    onChange={(e) => setHasBackupDancers(e.target.checked)}
                    className="w-4 h-4 accent-amber-500 rounded"
                  />
                </div>

                {hasBackupDancers && (
                  <div className="space-y-2 pt-2 border-t border-slate-800 text-xs">
                    <label className="text-[11px] text-slate-400 block">Kiểu vũ đạo & đội hình:</label>
                    <select
                      value={dancersChoreography}
                      onChange={(e) => setDancersChoreography(e.target.value as any)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500"
                    >
                      <option value="kpop_synchronized">Vũ đạo K-Pop nhảy đồng bộ bắt mắt</option>
                      <option value="circle_singer">Vũ đoàn nhảy vòng tròn bao quanh ca sĩ</option>
                      <option value="backing_vocal_group">Nhóm vũ công vừa nhảy vừa hát bè cùng ca sĩ</option>
                      <option value="freestyle_hype">Vũ đạo đường phố Hype sôi động</option>
                    </select>
                  </div>
                )}
              </div>

              {/* Live Band Ensemble Controls */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
                    <Zap className="w-4 h-4 text-purple-400" />
                    <span>Ban Nhạc Sống (Live Band Ensemble)</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={hasLiveBand}
                    onChange={(e) => setHasLiveBand(e.target.checked)}
                    className="w-4 h-4 accent-purple-500 rounded"
                  />
                </div>

                {hasLiveBand && (
                  <div className="space-y-2 pt-2 border-t border-slate-800 text-xs">
                    <label className="text-[11px] text-slate-400 block">Quy mô ban nhạc biểu diễn cùng:</label>
                    <select
                      value={bandType}
                      onChange={(e) => setBandType(e.target.value as any)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-none focus:border-purple-500"
                    >
                      <option value="rock_pop_ensemble">Full Rock/Pop Band (Trống, Lead Guitar, Bass, Keys)</option>
                      <option value="acoustic_trio">Acoustic Trio (Guitar mộc, Trống cajon, Violon)</option>
                      <option value="philharmonic_orchestra">Dàn nhạc giao hưởng Philharmonic quy mô lớn</option>
                      <option value="electronic_dj_decks">Bàn xoay DJ decks & Ánh sáng Festival</option>
                    </select>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* STEP 4: Gói Sản Xuất MV & Minh Bạch Chi Phí ($0.5 USD Lợi Nhuận) */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="flex items-center justify-center w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 font-black text-sm border border-amber-500/40">
                  4
                </span>
                <div>
                  <h2 className="text-lg font-bold text-white">Chọn Phân Hạng Gói Sản Xuất MV</h2>
                  <p className="text-xs text-slate-400">
                    Cam kết đúng 0.5 USD (~12.500đ) lợi nhuận / bài hát – Giá gốc tối ưu nhất toàn thị trường.
                  </p>
                </div>
              </div>
              <Crown className="w-5 h-5 text-amber-400" />
            </div>

            {/* 3 MV Tiers */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {Object.values(MV_TIER_CONFIGS).map((tier) => {
                const isSelected = selectedVipTier === tier.id;
                return (
                  <div
                    key={tier.id}
                    onClick={() => setSelectedVipTier(tier.id)}
                    className={`p-4 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between gap-3 ${
                      isSelected
                        ? 'bg-gradient-to-b from-slate-900 to-amber-950/40 border-amber-500 ring-2 ring-amber-500/40 shadow-xl'
                        : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-amber-300 font-bold uppercase">
                          {tier.badge}
                        </span>
                        <span className="text-xs font-black text-white">{tier.resolution}</span>
                      </div>

                      <div className="font-bold text-sm text-white">{tier.name}</div>
                      <p className="text-[11px] text-slate-300 leading-relaxed line-clamp-2">{tier.description}</p>

                      <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-[11px] space-y-1">
                        <div className="flex justify-between text-slate-400">
                          <span>Chi phí hạ tầng:</span>
                          <span className="font-mono text-slate-200">${tier.rawComputeCostUSD.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between text-amber-400 font-bold">
                          <span>Lợi nhuận GITA:</span>
                          <span className="font-mono">+${tier.gitaMarginUSD.toFixed(2)} USD</span>
                        </div>
                        <div className="border-t border-slate-800 pt-1 flex justify-between font-black text-white">
                          <span>Giá cuối cùng:</span>
                          <span className="text-emerald-400 font-mono">${tier.finalPriceUSD.toFixed(2)}</span>
                        </div>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-800 text-center font-black text-xs text-amber-400">
                      ≈ {tier.finalPriceVND.toLocaleString()} VNĐ
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Action Trigger Banner */}
          <div className="bg-gradient-to-r from-amber-600 via-yellow-500 to-amber-600 p-1 rounded-3xl shadow-2xl">
            <div className="bg-slate-950/90 rounded-[22px] p-6 flex flex-col sm:flex-row items-center justify-between gap-6">
              <div className="space-y-1 text-center sm:text-left">
                <div className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center justify-center sm:justify-start gap-1.5">
                  <Flame className="w-4 h-4" />
                  <span>Sản Xuất MV Ca Nhạc Triệu Đô Sẵn Sàng Bắt Đầu</span>
                </div>
                <h3 className="text-lg font-black text-white">
                  Đồng Bộ Khẩu Hình 98.8% • Vũ Đoàn K-Pop • Ban Nhạc Sống
                </h3>
                <p className="text-xs text-slate-400">
                  Tổng chi phí: <strong className="text-amber-300">${currentTierConfig.finalPriceUSD.toFixed(2)}</strong> (~{currentTierConfig.finalPriceVND.toLocaleString()}đ) bao gồm đúng 0.5 USD lợi nhuận.
                </p>
              </div>

              <button
                type="button"
                disabled={isProducing}
                onClick={handleProduceMV}
                className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-sm uppercase tracking-wider shadow-lg shadow-amber-500/30 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isProducing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                    <span>Đang Tạo MV Triệu Đô...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Sản Xuất MV Triệu Đô Ngay</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Real-time Progress Bar */}
          {isProducing && (
            <div className="p-6 rounded-3xl bg-slate-900 border border-amber-500/40 space-y-4 animate-in fade-in">
              <div className="flex items-center justify-between text-xs font-bold text-amber-300">
                <span className="flex items-center gap-2">
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Hệ thống AI đang mô phỏng sân khấu và đồng bộ khẩu hình...
                </span>
                <span>{productionProgress}%</span>
              </div>
              <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden border border-slate-800">
                <div
                  className="bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 h-full transition-all duration-500"
                  style={{ width: `${productionProgress}%` }}
                />
              </div>
              <div className="text-xs text-slate-300 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>
                  {productionProgress < 40 && 'Phân tích chân dung ca sĩ và nạp mỏ neo khuôn mặt...'}
                  {productionProgress >= 40 && productionProgress < 75 && 'Khớp khẩu hình Deep-Phoneme theo từng câu hát và nhịp BPM...'}
                  {productionProgress >= 75 && 'Bố trí vũ đoàn K-Pop và ban nhạc sống qua các đại cảnh concert!'}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Right Column (4 cols): Singer Photo Anchor & Transparent Cost Audit */}
        <div className="lg:col-span-4 space-y-6">
          {/* Singer Avatar Anchor */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm font-bold text-white">
                <Camera className="w-4 h-4 text-amber-400" />
                <span>Hình Tượng Ca Sĩ (Singer Anchor)</span>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                Ảnh Của Bạn
              </span>
            </div>

            {/* Avatar Preview */}
            <div className="relative rounded-2xl overflow-hidden aspect-square bg-slate-950 border border-slate-800 group">
              <img src={singerPhotoUrl} alt="Singer" className="w-full h-full object-cover transition-transform group-hover:scale-105 duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-transparent to-transparent flex flex-col justify-end p-4">
                <span className="text-xs font-bold text-white truncate">{artistName}</span>
                <span className="text-[10px] text-amber-300">
                  Nhân bản thành ca sĩ chính trong mọi đại cảnh concert
                </span>
              </div>
            </div>

            {/* Photo upload trigger */}
            <label className="flex items-center justify-center gap-2 w-full py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold cursor-pointer transition-all border border-slate-700">
              <Upload className="w-4 h-4 text-amber-400" />
              <span>Tải Ảnh Chân Dung Của Bạn Lên</span>
              <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
            </label>
          </div>

          {/* Cost Transparency Breakdown Card */}
          <div className="bg-slate-900/90 border border-emerald-500/40 rounded-3xl p-6 space-y-4 shadow-xl">
            <div className="flex items-center gap-2 text-sm font-bold text-emerald-400">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <span>Bảng Kê Chi Phí Sản Xuất MV Minh Bạch</span>
            </div>

            <p className="text-[11px] text-slate-300 leading-relaxed">
              Chi phí quay MV triệu đô truyền thống tốn từ $10.000 – $50.000 USD. Với công nghệ AI GITA365, khách hàng chỉ thanh toán đúng chi phí điện toán hạ tầng và <strong>lợi nhuận cố định 0.5 USD (~12.500đ)</strong>.
            </p>

            <div className="space-y-2 text-xs border-t border-slate-800 pt-3">
              <div className="flex justify-between text-slate-300">
                <span>1. Render Đa Bối Cảnh & Ca Sĩ:</span>
                <span className="font-mono text-slate-100">${(currentTierConfig.rawComputeCostUSD * 0.35).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>2. AI Lip-Sync Khớp Lời Hát:</span>
                <span className="font-mono text-slate-100">${(currentTierConfig.rawComputeCostUSD * 0.25).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>3. Vũ Đoàn K-Pop & Ban Nhạc Sống:</span>
                <span className="font-mono text-slate-100">${(currentTierConfig.rawComputeCostUSD * 0.25).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>4. Audio Mastering & Dolby 5.1:</span>
                <span className="font-mono text-slate-100">${(currentTierConfig.rawComputeCostUSD * 0.15).toFixed(2)}</span>
              </div>

              <div className="flex justify-between text-slate-400 text-[11px] pt-1">
                <span>Tổng chi phí hạ tầng gốc:</span>
                <span className="font-mono">${currentTierConfig.rawComputeCostUSD.toFixed(2)}</span>
              </div>

              {/* Fixed 0.5 USD Margin */}
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 font-bold">
                <span className="flex items-center gap-1.5">
                  <Award className="w-3.5 h-3.5" />
                  Lợi Nhuận GITA365:
                </span>
                <span className="font-mono text-sm">+$0.50 USD (~12.500đ)</span>
              </div>

              {/* Final Price */}
              <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950 border border-emerald-500/50 text-white font-black text-sm">
                <span>Khách Hàng Thanh Toán:</span>
                <div className="text-right">
                  <div className="text-amber-400 font-mono">${currentTierConfig.finalPriceUSD.toFixed(2)} USD</div>
                  <div className="text-[10px] text-emerald-400 font-normal">
                    ≈ {currentTierConfig.finalPriceVND.toLocaleString()} VNĐ
                  </div>
                </div>
              </div>

              {/* Commercial Rights Badge */}
              <div className="p-2.5 rounded-xl bg-emerald-950/30 border border-emerald-500/30 text-[11px] text-emerald-300 space-y-1">
                <div className="font-bold flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Quyền Kinh Doanh & Kiếm Tiền Mạng Xã Hội:</span>
                </div>
                <div className="text-[10px] text-slate-300">
                  ✓ Bật kiếm tiền YouTube AdSense • TikTok Creator Rewards • Facebook Reels
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Production Result: MV Storyboard & Scene Breakdown */}
      {productionResult && (
        <div className="bg-slate-900 border border-amber-500/40 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl animate-in slide-in-from-bottom duration-500">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-800 pb-6">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40">
                  ✓ MV TRIỆU ĐÔ ĐÃ HOÀN TẤT
                </span>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40">
                  Lip-Sync {productionResult.lipSyncReport.phonemeSyncRate}%
                </span>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-bold border border-purple-500/40">
                  {productionResult.commercialRights.licenseCode}
                </span>
              </div>
              <h2 className="text-2xl font-black text-white">
                {productionResult.title} – {productionResult.artistName}
              </h2>
              <p className="text-xs text-slate-400">
                Thời lượng: <strong>{productionResult.durationMinutes} phút</strong> ({productionResult.totalDurationSeconds} giây) • {productionResult.scenes.length} phân cảnh concert • {productionResult.stageLocations.length} bối cảnh triệu đô
              </p>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={handleExportToVideoStudio}
                className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-500/30 flex items-center gap-2 transition-all hover:scale-105"
              >
                <Video className="w-4 h-4" />
                <span>Chuyển Sang Xưởng Dựng & Render 4K</span>
              </button>
            </div>
          </div>

          {/* Choreography & Lip-Sync Insight */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                Vũ Đạo & Đội Hình Sân Khấu:
              </span>
              <p className="text-xs text-slate-300">{productionResult.stageChoreographyNotes}</p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-xs font-bold text-emerald-300 uppercase tracking-wider">
                Bảo Chứng Bản Quyền Thương Mại (Commercial License):
              </span>
              <p className="text-xs text-slate-300">
                Bản quyền thương mại quốc tế 100%. Sẵn sàng phân phối trên YouTube Music, Spotify, TikTok và bật kiếm tiền ngay lập tức.
              </p>
            </div>
          </div>

          {/* Scenes Grid */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                <Film className="w-4 h-4 text-amber-400" />
                <span>Bảng Phân Cảnh MV Triệu Đô:</span>
              </h3>
              <span className="text-xs text-slate-400">{productionResult.scenes.length} Phân cảnh liên hoàn</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {productionResult.scenes.map((sc, idx) => {
                const isActive = activeSceneIdx === idx;
                return (
                  <div
                    key={sc.id}
                    onClick={() => setActiveSceneIdx(idx)}
                    className={`rounded-2xl border p-4 space-y-3 cursor-pointer transition-all ${
                      isActive
                        ? 'bg-gradient-to-b from-slate-900 to-amber-950/30 border-amber-500 ring-2 ring-amber-500/40 shadow-xl'
                        : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="relative rounded-xl overflow-hidden aspect-video bg-slate-900 border border-slate-800">
                      <img src={sc.imageUrl || singerPhotoUrl} alt={sc.title} className="w-full h-full object-cover" />
                      <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-slate-950/80 text-[10px] font-black text-amber-300 border border-amber-500/30">
                        Cảnh {sc.sceneNumber} • {sc.durationSeconds}s
                      </div>
                      <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded-md bg-slate-950/80 text-[9px] text-slate-300 truncate max-w-[150px]">
                        {sc.location}
                      </div>
                    </div>

                    <div className="space-y-1">
                      <h4 className="text-xs font-bold text-white line-clamp-1">{sc.title}</h4>
                      <p className="text-[11px] text-slate-400 line-clamp-2">{sc.description}</p>
                    </div>

                    {sc.dialogue && sc.dialogue[0] && (
                      <div className="p-2 rounded-lg bg-slate-900/90 border border-slate-800 text-[10px] text-slate-300 flex items-start gap-1.5">
                        <Mic className="w-3 h-3 text-amber-400 flex-shrink-0 mt-0.5" />
                        <span className="italic line-clamp-2">"{sc.dialogue[0].text}"</span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
