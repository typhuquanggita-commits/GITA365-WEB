import React, { useState } from 'react';
import {
  Crown,
  Check,
  CreditCard,
  QrCode,
  ShieldCheck,
  Zap,
  Sparkles,
  Award,
  Gift,
  ArrowRight,
  CheckCircle2,
  Lock,
  Copy,
  Building2,
  Download,
  ExternalLink,
  Camera,
} from 'lucide-react';
import { PricingPlan, LoyaltyTier } from '../types';
import { PRICING_PLANS, LOYALTY_TIERS, BANK_ACCOUNT_INFO } from '../data/initialData';
import { VIP_TIER_CONFIGS } from '../data/industryTemplates';

interface PricingLoyaltyViewProps {
  currentPoints: number;
  onAddPoints: (pts: number) => void;
}

export const PricingLoyaltyView: React.FC<PricingLoyaltyViewProps> = ({
  currentPoints,
  onAddPoints,
}) => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');
  const [selectedPlan, setSelectedPlan] = useState<PricingPlan | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'vnpay' | 'momo' | 'card' | 'bank'>('bank');
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const handleCopy = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleSelectPlan = (plan: PricingPlan) => {
    if (plan.priceMonthly === 0) return;
    setSelectedPlan(plan);
    setPaymentMethod('bank');
    setShowPaymentModal(true);
  };

  const handleExecutePayment = () => {
    setIsProcessingPayment(true);
    setTimeout(() => {
      setIsProcessingPayment(false);
      setPaymentSuccess(true);
      onAddPoints(1000);
      setTimeout(() => {
        setPaymentSuccess(false);
        setShowPaymentModal(false);
      }, 2000);
    }, 1800);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950/40 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold uppercase tracking-wider">
              <Crown className="w-3.5 h-3.5" /> GITA365 Membership & Loyalty
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight">
              Bảng Giá Dịch Vụ & Đặc Quyền Khách Hàng Thân Thiết
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              Mở khóa khả năng render 4K siêu tốc, đồng bộ đám mây dung lượng lớn, đào tạo mô hình nhân vật
              độc quyền và tích lũy điểm GITA Loyalty để đổi quà trọn đời.
            </p>
          </div>

          {/* Billing Switcher */}
          <div className="flex items-center bg-slate-950 p-1.5 rounded-2xl border border-slate-800 text-xs font-bold shadow-lg">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`px-4 py-2 rounded-xl transition-all ${
                billingCycle === 'monthly'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Thanh Toán Hàng Tháng
            </button>
            <button
              onClick={() => setBillingCycle('yearly')}
              className={`px-4 py-2 rounded-xl transition-all flex items-center gap-1.5 ${
                billingCycle === 'yearly'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>Gói Năm (Tiết Kiệm 20%)</span>
              <span className="bg-red-500 text-white text-[9px] px-1.5 py-0.5 rounded-full font-bold uppercase">
                Ưu Đãi
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Pricing Plans Grid (3 columns) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {PRICING_PLANS.map((plan) => {
          const isPro = plan.recommended;
          const displayPrice =
            billingCycle === 'yearly'
              ? Math.round(plan.priceYearly / 12).toLocaleString()
              : plan.priceMonthly.toLocaleString();

          return (
            <div
              key={plan.id}
              className={`relative rounded-3xl p-6 sm:p-7 flex flex-col justify-between border transition-all ${
                isPro
                  ? 'bg-gradient-to-b from-slate-900 via-slate-900 to-amber-950/30 border-amber-500/80 shadow-2xl shadow-amber-500/10 ring-1 ring-amber-500/50'
                  : 'bg-slate-900/80 border-slate-800'
              }`}
            >
              {plan.badge && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-black text-[10px] tracking-wider uppercase shadow-md">
                  {plan.badge}
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-bold text-white">{plan.name}</h3>
                  <p className="text-xs text-slate-400 mt-1 min-h-[32px]">{plan.description}</p>
                </div>

                <div className="py-2 border-y border-slate-800/80">
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl font-black text-white tracking-tight">
                      {plan.priceMonthly === 0 ? '0' : displayPrice}
                    </span>
                    <span className="text-xs text-slate-400 font-semibold">đ / tháng</span>
                  </div>
                  {billingCycle === 'yearly' && plan.priceMonthly > 0 && (
                    <div className="text-[10px] text-amber-400 mt-0.5">
                      Thanh toán theo năm: {plan.priceYearly.toLocaleString()} đ (Tiết kiệm 2 tháng)
                    </div>
                  )}
                </div>

                {/* Specs pill badges */}
                <div className="grid grid-cols-2 gap-2 text-[11px] bg-slate-950 p-2.5 rounded-xl border border-slate-800 font-mono">
                  <div>
                    <span className="text-slate-500 block text-[9px] uppercase">Tốc độ render:</span>
                    <span className="text-amber-300 font-bold">{plan.renderSpeed}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[9px] uppercase">Độ phân giải:</span>
                    <span className="text-cyan-300 font-bold">{plan.maxResolution}</span>
                  </div>
                </div>

                {/* Features list */}
                <div className="space-y-2.5 pt-2">
                  <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block">
                    Tính năng bao gồm:
                  </span>
                  {plan.features.map((feat, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                      <Check className="w-3.5 h-3.5 text-amber-400 flex-shrink-0 mt-0.5" />
                      <span className="leading-tight">{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-6">
                <button
                  onClick={() => handleSelectPlan(plan)}
                  className={`w-full py-3 px-4 rounded-xl font-bold text-xs shadow-lg transition-all transform active:scale-95 ${
                    isPro
                      ? 'bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-slate-950 hover:brightness-110 shadow-amber-500/25'
                      : plan.priceMonthly === 0
                      ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
                  }`}
                >
                  {plan.priceMonthly === 0 ? 'Gói Đang Sử Dụng' : 'Nâng Cấp Gói Ngay'}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Pay-Per-Video Section: 1 Photo to 1-3 Min Video with 0.1 USD Transparent Margin */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-amber-950/30 rounded-3xl border border-amber-500/40 p-6 sm:p-8 shadow-2xl space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800 pb-5">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Camera className="w-5 h-5 text-amber-400" />
              <h2 className="text-xl font-black text-white">
                Gói Sản Xuất Trọn Gói: 1 Bức Ảnh ➔ Video 1 - 3 Phút Chuẩn Ngành
              </h2>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40 uppercase">
                Khách Lẻ & Doanh Nghiệp
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
              Chỉ cần đưa 1 bức ảnh và yêu cầu. Không cần thuê ekip quay dựng đắt đỏ. GITA365 cam kết tuân thủ chính sách giá minh bạch: <strong className="text-emerald-400">Chỉ thu đúng 0.1 USD (~2.500 VNĐ) lợi nhuận</strong> trên mỗi video sản xuất!
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-950 px-4 py-2 rounded-2xl border border-emerald-500/40 text-xs">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span className="text-slate-300">Cam kết biên lợi nhuận cố định:</span>
            <span className="font-mono font-black text-amber-400">+0.10 USD / video</span>
          </div>
        </div>

        {/* 4 VIP Tiers Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {Object.values(VIP_TIER_CONFIGS).map((tier) => (
            <div
              key={tier.id}
              className={`p-5 rounded-2xl border bg-slate-950/80 flex flex-col justify-between gap-4 transition-all ${
                tier.id === 'vip_cinema'
                  ? 'border-amber-500/60 ring-2 ring-amber-500/30 shadow-xl shadow-amber-500/10'
                  : 'border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-amber-300 font-bold uppercase">
                    {tier.badge}
                  </span>
                  <span className="text-xs font-black text-white">{tier.resolution}</span>
                </div>

                <div>
                  <h3 className="text-sm font-bold text-white">{tier.name}</h3>
                  <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">{tier.description}</p>
                </div>

                {/* Price Breakdown */}
                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-[11px] space-y-1">
                  <div className="flex justify-between text-slate-400">
                    <span>Chi phí hạ tầng gốc:</span>
                    <span className="font-mono text-slate-200">${tier.rawComputeCostUSD.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-amber-400 font-bold">
                    <span>Lợi nhuận GITA365:</span>
                    <span className="font-mono">+${tier.gitaMarginUSD.toFixed(2)}</span>
                  </div>
                  <div className="border-t border-slate-800 pt-1 flex justify-between font-black text-white">
                    <span>Giá cuối cùng:</span>
                    <span className="text-emerald-400 font-mono">${tier.finalPriceUSD.toFixed(2)}</span>
                  </div>
                </div>

                {/* Features */}
                <div className="space-y-1 text-[11px] text-slate-300">
                  {tier.features.slice(0, 3).map((f, i) => (
                    <div key={i} className="flex items-start gap-1.5">
                      <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />
                      <span>{f}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800">
                <div className="text-center text-xs font-black text-amber-400">
                  ≈ {tier.finalPriceVND.toLocaleString()} VNĐ
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Loyalty Program Section */}
      <div className="bg-slate-900/90 rounded-3xl border border-slate-800 p-6 sm:p-8 shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Award className="w-5 h-5 text-yellow-400" />
              <h2 className="text-lg font-bold text-white">
                Chương Trình Khách Hàng Thân Thiết (GITA365 Loyalty Club)
              </h2>
            </div>
            <p className="text-xs text-slate-400">
              Tích lũy điểm khi sáng tạo phim, nâng cấp tài khoản và chia sẻ tác phẩm để nhận đặc quyền vĩnh viễn.
            </p>
          </div>

          <div className="flex items-center gap-3 bg-slate-950 px-4 py-2.5 rounded-2xl border border-slate-800 text-xs">
            <div>
              <span className="text-slate-500 block text-[10px]">Điểm tích lũy hiện tại:</span>
              <span className="text-base font-black text-amber-400 font-mono">
                {currentPoints.toLocaleString()} G-Coin
              </span>
            </div>
            <div className="h-6 w-px bg-slate-800" />
            <div>
              <span className="text-slate-500 block text-[10px]">Hạng thành viên:</span>
              <span className="text-xs font-bold text-cyan-300">Kim Cương (Diamond)</span>
            </div>
          </div>
        </div>

        {/* Loyalty Tiers Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {LOYALTY_TIERS.map((tier) => (
            <div
              key={tier.id}
              className={`p-4 rounded-2xl border bg-slate-950/80 space-y-3 ${
                tier.id === 'diamond' ? 'border-cyan-500/60 shadow-lg shadow-cyan-500/10' : 'border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold uppercase ${tier.badgeColor}`}>
                  {tier.name}
                </span>
                <span className="text-[11px] text-slate-400 font-mono">{tier.minPoints}+ pts</span>
              </div>

              <div>
                <span className="text-xs font-bold text-white block">Ưu đãi giảm render:</span>
                <span className="text-sm font-extrabold text-amber-400">{tier.discountRender}</span>
              </div>

              <div className="space-y-1.5 text-[11px] text-slate-300 pt-1">
                {tier.perks.map((perk, i) => (
                  <div key={i} className="flex items-start gap-1.5">
                    <span className="text-amber-400">•</span>
                    <span className="leading-tight">{perk}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Official Payment Receiving Account & Google Visa Integration */}
      <div className="bg-slate-900/95 rounded-3xl border border-slate-800 p-6 sm:p-8 shadow-2xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Building2 className="w-5 h-5 text-emerald-400" />
              <h2 className="text-lg font-bold text-white">
                Tài Khoản Ngân Hàng Thanh Toán Chính Thức GITA365
              </h2>
            </div>
            <p className="text-xs text-slate-400">
              Khách hàng có thể chuyển khoản trực tiếp qua ngân hàng nội địa VietQR hoặc thanh toán quốc tế qua thẻ Visa đã đăng ký với Google.
            </p>
          </div>
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold">
            <ShieldCheck className="w-4 h-4" />
            <span>Xác Thực Chính Chủ • Giao Dịch 24/7</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          {/* Authentic BIDV VietQR Card (Exact design from user's uploaded photo) */}
          <div className="md:col-span-5 flex justify-center">
            <div className="w-full max-w-[320px] rounded-[28px] p-5 shadow-2xl bg-gradient-to-b from-[#004733] to-[#043325] border-2 border-[#166048] text-white space-y-4">
              {/* Card Header: BIDV & VietQR Logos */}
              <div className="flex items-center justify-between px-2 pt-1">
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-lg tracking-wider text-amber-400 font-sans">
                    BIDV
                  </span>
                  <div className="w-4 h-4 text-amber-400">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                      <path d="M12 2L15 9H22L16.5 13.5L18.5 21L12 16.5L5.5 21L7.5 13.5L2 9H9L12 2Z" />
                    </svg>
                  </div>
                </div>
                <div className="flex items-center gap-1 bg-white/10 px-2 py-0.5 rounded-md backdrop-blur-sm">
                  <span className="font-black text-xs text-white tracking-widest font-sans">
                    VietQR
                  </span>
                  <span className="text-[9px] text-emerald-300 font-mono">TM</span>
                </div>
              </div>

              {/* QR White Container */}
              <div className="bg-white rounded-[22px] p-3 shadow-inner flex flex-col items-center justify-center">
                <img
                  src={BANK_ACCOUNT_INFO.vietQrUrl(0, 'GITA365')}
                  alt="BIDV VietQR Code"
                  className="w-56 h-56 object-contain rounded-xl"
                />
              </div>

              {/* Account Details on Card */}
              <div className="text-center space-y-1 pt-1 pb-1">
                <div className="text-amber-400 font-black text-sm tracking-widest uppercase">
                  {BANK_ACCOUNT_INFO.accountHolder}
                </div>
                <div className="text-white font-extrabold text-lg tracking-wider font-mono">
                  {BANK_ACCOUNT_INFO.accountNumber}
                </div>
                <div className="text-[11px] text-emerald-200/90 font-medium leading-tight">
                  {BANK_ACCOUNT_INFO.bankFullName}
                </div>
              </div>
            </div>
          </div>

          {/* Right Information & Quick Action Buttons */}
          <div className="md:col-span-7 space-y-5">
            <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-3.5 text-xs">
              <div className="flex items-center justify-between text-slate-300 border-b border-slate-800/80 pb-2">
                <span className="text-slate-400">Ngân hàng thụ hưởng:</span>
                <span className="font-bold text-white text-sm">
                  BIDV (Ngân hàng TMCP Đầu tư & Phát triển Việt Nam)
                </span>
              </div>

              <div className="flex items-center justify-between text-slate-300 border-b border-slate-800/80 pb-2">
                <span className="text-slate-400">Số tài khoản nhận tiền:</span>
                <div className="flex items-center gap-2">
                  <span className="font-mono font-black text-amber-400 text-base">
                    {BANK_ACCOUNT_INFO.accountNumber}
                  </span>
                  <button
                    onClick={() => handleCopy(BANK_ACCOUNT_INFO.accountNumber, 'stk')}
                    className="px-2.5 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 font-semibold flex items-center gap-1 transition-colors"
                  >
                    {copiedField === 'stk' ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Đã chép</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Sao chép</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between text-slate-300 border-b border-slate-800/80 pb-2">
                <span className="text-slate-400">Chủ tài khoản:</span>
                <div className="flex items-center gap-2">
                  <span className="font-extrabold text-white text-sm">
                    {BANK_ACCOUNT_INFO.accountHolder}
                  </span>
                  <button
                    onClick={() => handleCopy(BANK_ACCOUNT_INFO.accountHolder, 'holder')}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold flex items-center gap-1 transition-colors"
                  >
                    {copiedField === 'holder' ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between text-slate-300">
                <span className="text-slate-400">Cú pháp chuyển khoản:</span>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-cyan-300 font-bold bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800">
                    GITA365 [TÊN GÓI] [SỐ ĐT]
                  </span>
                  <button
                    onClick={() => handleCopy('GITA365 PRO 8878719979', 'memo')}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold flex items-center gap-1 transition-colors"
                  >
                    {copiedField === 'memo' ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* Google International Visa Status Box */}
            <div className="bg-gradient-to-r from-blue-950/40 via-slate-950 to-indigo-950/30 p-5 rounded-2xl border border-blue-500/40 space-y-3 text-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-blue-500/20 pb-2.5">
                <div className="flex items-center gap-2">
                  <div className="px-2.5 py-1 rounded bg-blue-600 text-white font-extrabold text-[11px] tracking-wider shadow">
                    VISA
                  </div>
                  <div>
                    <span className="font-bold text-white text-sm block">Thanh Toán Quốc Tế Qua Thẻ Visa Google</span>
                    <span className="text-[10px] text-slate-400">Google Cloud Billing & Google Payments Ecosystem</span>
                  </div>
                </div>
                <span className="text-[10px] px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 font-semibold flex items-center gap-1 w-fit">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {BANK_ACCOUNT_INFO.googleBilling.status}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px]">
                <div className="bg-slate-900/90 p-2.5 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-slate-400 block text-[10px]">Tài khoản Google liên kết:</span>
                  <span className="font-mono text-cyan-300 font-bold">{BANK_ACCOUNT_INFO.googleBilling.userEmail}</span>
                </div>
                <div className="bg-slate-900/90 p-2.5 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-slate-400 block text-[10px]">Thẻ Visa Quốc tế:</span>
                  <span className="font-mono text-amber-400 font-bold">•••• •••• •••• {BANK_ACCOUNT_INFO.googleBilling.cardLast4} (Verified)</span>
                </div>
              </div>

              <p className="text-slate-300 text-[11px] leading-relaxed">
                Tài khoản Google Payments & Google Cloud của hệ thống GITA365 đã được xác thực thanh toán thành công với thẻ Visa Quốc tế. Khách hàng trong và ngoài nước có thể thanh toán trực tiếp qua <strong>Google Pay</strong> hoặc <strong>Thẻ Visa Quốc tế</strong> với chuẩn bảo mật 3D Secure 2.0 toàn cầu.
              </p>

              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button
                  onClick={() => {
                    const defaultPlan = PRICING_PLANS[1]; // Gói Pro
                    setSelectedPlan(defaultPlan);
                    setPaymentMethod('card');
                    setShowPaymentModal(true);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-[11px] flex items-center gap-1.5 shadow transition-colors"
                >
                  <CreditCard className="w-3.5 h-3.5" />
                  <span>Thanh Toán Quốc Tế Bằng Visa / Google Pay</span>
                </button>
                <button
                  onClick={() => handleCopy(BANK_ACCOUNT_INFO.googleBilling.transactionRef, 'gref')}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-mono flex items-center gap-1 transition-colors"
                >
                  {copiedField === 'gref' ? (
                    <>
                      <Check className="w-3 h-3 text-emerald-400" />
                      <span className="text-emerald-400">Đã chép mã Google Ref</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      <span>Mã Giao Dịch Google: {BANK_ACCOUNT_INFO.googleBilling.transactionRef}</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Payment Gateway Modal */}
      {showPaymentModal && selectedPlan && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-lg bg-slate-900 rounded-3xl border border-slate-800 p-6 shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" /> Thanh Toán Gói {selectedPlan.name}
              </h3>
              <button
                onClick={() => setShowPaymentModal(false)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            {/* Order Details */}
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Gói đăng ký:</span>
                <span className="font-bold text-white">{selectedPlan.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Chu kỳ thanh toán:</span>
                <span className="text-amber-300 font-semibold">
                  {billingCycle === 'monthly' ? 'Hàng tháng' : 'Hàng năm (Ưu đãi 20%)'}
                </span>
              </div>
              <div className="flex justify-between border-t border-slate-800 pt-2 text-sm font-bold">
                <span className="text-slate-200">Tổng thanh toán:</span>
                <div className="text-right">
                  <span className="text-amber-400 font-mono text-base block">
                    {billingCycle === 'yearly'
                      ? selectedPlan.priceYearly.toLocaleString()
                      : selectedPlan.priceMonthly.toLocaleString()}{' '}
                    đ
                  </span>
                  <span className="text-slate-400 text-[10px] font-normal">
                    ≈ ${billingCycle === 'yearly' ? Math.round(selectedPlan.priceYearly / 25000) : Math.round(selectedPlan.priceMonthly / 25000)} USD
                  </span>
                </div>
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-300 block">
                Chọn phương thức thanh toán bảo mật:
              </label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('bank')}
                  className={`p-3 rounded-xl border flex items-center gap-2 transition-all ${
                    paymentMethod === 'bank'
                      ? 'bg-emerald-500/15 border-emerald-500 text-emerald-300 font-bold ring-1 ring-emerald-500/30'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  <Lock className="w-4 h-4 text-emerald-400" />
                  <span>VietQR BIDV (Nội Địa)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`p-3 rounded-xl border flex items-center gap-2 transition-all ${
                    paymentMethod === 'card'
                      ? 'bg-blue-500/15 border-blue-500 text-blue-300 font-bold ring-1 ring-blue-500/30'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  <CreditCard className="w-4 h-4 text-blue-400" />
                  <span>Visa / Google Pay (Quốc Tế)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('vnpay')}
                  className={`p-3 rounded-xl border flex items-center gap-2 transition-all ${
                    paymentMethod === 'vnpay'
                      ? 'bg-red-500/15 border-red-500 text-red-300 font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  <QrCode className="w-4 h-4 text-red-400" />
                  <span>VNPAY QR</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('momo')}
                  className={`p-3 rounded-xl border flex items-center gap-2 transition-all ${
                    paymentMethod === 'momo'
                      ? 'bg-pink-500/15 border-pink-500 text-pink-300 font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  <QrCode className="w-4 h-4 text-pink-400" />
                  <span>Ví MoMo QR</span>
                </button>
              </div>
            </div>

            {/* Dynamic Content based on payment method */}
            {paymentMethod === 'bank' && (
              <div className="bg-[#003828] p-4 rounded-2xl border border-emerald-600/40 space-y-3 text-white">
                <div className="flex items-center justify-between text-xs border-b border-emerald-700/50 pb-2">
                  <div className="flex items-center gap-1.5 font-bold">
                    <span className="text-amber-400 font-black">BIDV</span>
                    <span className="text-slate-300">• VietQR Quét Nhanh Tự Động</span>
                  </div>
                  <span className="text-[10px] bg-emerald-900/80 px-2 py-0.5 rounded text-emerald-200">
                    24/7 Miễn Phí
                  </span>
                </div>

                <div className="flex flex-col sm:flex-row items-center gap-4">
                  <div className="bg-white p-2 rounded-xl shadow-lg flex-shrink-0">
                    <img
                      src={BANK_ACCOUNT_INFO.vietQrUrl(
                        billingCycle === 'yearly' ? selectedPlan.priceYearly : selectedPlan.priceMonthly,
                        `GITA365 ${selectedPlan.id.toUpperCase()}`
                      )}
                      alt="BIDV QR"
                      className="w-36 h-36 object-contain"
                    />
                  </div>
                  <div className="space-y-1.5 text-xs flex-1 w-full">
                    <div>
                      <span className="text-emerald-300 text-[10px] block">Số tài khoản:</span>
                      <div className="flex items-center justify-between font-mono font-black text-amber-400 text-sm">
                        <span>{BANK_ACCOUNT_INFO.accountNumber}</span>
                        <button
                          onClick={() => handleCopy(BANK_ACCOUNT_INFO.accountNumber, 'modal-stk')}
                          className="text-[11px] bg-white/10 px-2 py-0.5 rounded hover:bg-white/20 text-white"
                        >
                          {copiedField === 'modal-stk' ? 'Đã chép' : 'Chép STK'}
                        </button>
                      </div>
                    </div>
                    <div>
                      <span className="text-emerald-300 text-[10px] block">Chủ tài khoản:</span>
                      <span className="font-bold text-white">{BANK_ACCOUNT_INFO.accountHolder}</span>
                    </div>
                    <div>
                      <span className="text-emerald-300 text-[10px] block">Số tiền:</span>
                      <span className="font-mono font-bold text-amber-300">
                        {billingCycle === 'yearly'
                          ? selectedPlan.priceYearly.toLocaleString()
                          : selectedPlan.priceMonthly.toLocaleString()}{' '}
                        đ
                      </span>
                    </div>
                    <div>
                      <span className="text-emerald-300 text-[10px] block">Nội dung chuyển khoản:</span>
                      <span className="font-mono text-[11px] text-cyan-200 bg-black/40 px-2 py-0.5 rounded block truncate">
                        GITA365 {selectedPlan.id.toUpperCase()} 8878719979
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {paymentMethod === 'card' && (
              <div className="bg-slate-950 p-4 rounded-2xl border border-blue-500/40 space-y-3.5 text-xs">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-blue-600 text-white font-black text-[10px] tracking-wider">
                      VISA
                    </span>
                    <span className="font-semibold text-white">Google Pay & Thẻ Visa Quốc Tế</span>
                  </div>
                  <span className="text-[10px] text-emerald-400 font-mono bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Đã trả phí với Google
                  </span>
                </div>

                {/* 1-Click Google Pay Button */}
                <button
                  type="button"
                  onClick={handleExecutePayment}
                  className="w-full py-2.5 px-4 rounded-xl bg-white hover:bg-slate-100 text-slate-900 font-bold flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-95"
                >
                  <span className="font-bold text-slate-900">G</span>
                  <span>Pay</span>
                  <span className="text-slate-400">|</span>
                  <span className="text-xs text-slate-700">Thanh toán nhanh với Google Pay (Visa •••• {BANK_ACCOUNT_INFO.googleBilling.cardLast4})</span>
                </button>

                <div className="relative flex py-1 items-center">
                  <div className="flex-grow border-t border-slate-800"></div>
                  <span className="flex-shrink mx-2 text-[10px] text-slate-500 uppercase">Hoặc nhập thẻ quốc tế</span>
                  <div className="flex-grow border-t border-slate-800"></div>
                </div>

                <div className="space-y-2">
                  <div>
                    <label className="text-slate-400 block text-[11px] mb-1">Số thẻ Visa / Mastercard:</label>
                    <input
                      type="text"
                      defaultValue={`4111 2222 3333 ${BANK_ACCOUNT_INFO.googleBilling.cardLast4}`}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-slate-400 block text-[11px] mb-1">Ngày hết hạn (MM/YY):</label>
                      <input
                        type="text"
                        defaultValue="10/29"
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                      />
                    </div>
                    <div>
                      <label className="text-slate-400 block text-[11px] mb-1">Mã bảo mật CVV:</label>
                      <input
                        type="password"
                        defaultValue="•••"
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                      />
                    </div>
                  </div>
                </div>

                <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800 space-y-1 text-[10px] text-slate-400">
                  <div className="flex justify-between">
                    <span>Email tài khoản Google:</span>
                    <span className="text-cyan-300 font-mono">{BANK_ACCOUNT_INFO.googleBilling.userEmail}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Google Ref ID:</span>
                    <span className="text-amber-300 font-mono">{BANK_ACCOUNT_INFO.googleBilling.transactionRef}</span>
                  </div>
                </div>

                <p className="text-[10px] text-slate-500 italic">
                  🔒 Giao dịch được bảo mật bởi Google Cloud Payments & Verified by Visa với mã hóa SSL 256-bit.
                </p>
              </div>
            )}


            {(paymentMethod === 'vnpay' || paymentMethod === 'momo') && (
              <div className="bg-white p-4 rounded-2xl flex flex-col items-center justify-center space-y-2 text-slate-900">
                <div className="w-36 h-36 border-4 border-slate-950 rounded-xl p-2 flex flex-col items-center justify-center bg-slate-50 shadow-inner">
                  <QrCode className="w-24 h-24 text-slate-900" />
                  <span className="text-[9px] font-bold text-slate-700 tracking-wider font-mono">
                    GITA365-{paymentMethod.toUpperCase()}-{selectedPlan.id.toUpperCase()}
                  </span>
                </div>
                <span className="text-[11px] text-slate-700 font-medium">
                  Quét mã QR qua ứng dụng {paymentMethod === 'vnpay' ? 'VNPAY' : 'MoMo'}
                </span>
              </div>
            )}

            <button
              onClick={handleExecutePayment}
              disabled={isProcessingPayment}
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-extrabold text-xs shadow-lg flex items-center justify-center gap-2 transition-all transform active:scale-95 disabled:opacity-50"
            >
              {isProcessingPayment ? (
                <>
                  <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                  <span>Đang Xác Thực Giao Dịch An Toàn...</span>
                </>
              ) : paymentSuccess ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Thanh Toán Thành Công! Đã Kích Hoạt Gói</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>Xác Nhận Đã Thanh Toán & Kích Hoạt Ngay</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

