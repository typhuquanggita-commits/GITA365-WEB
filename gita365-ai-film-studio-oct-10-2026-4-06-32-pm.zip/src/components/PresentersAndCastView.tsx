import React, { useState } from 'react';
import {
  Users,
  Sparkles,
  Camera,
  Upload,
  Check,
  Copy,
  Play,
  Volume2,
  Crown,
  Award,
  Video,
  Layers,
  Edit2,
  Search,
  Filter,
  CheckCircle2,
  ExternalLink,
  Plus,
  RefreshCw,
  Eye,
} from 'lucide-react';
import { FilmProject, TrainerPose, GitaMC } from '../types';
import { TRAINER_QUANG_POSES, GITA_MC_LIST } from '../data/initialData';
import { playSpeechSample } from '../utils/audioSynth';

interface PresentersAndCastViewProps {
  project: FilmProject;
  onUpdateProject: (proj: FilmProject) => void;
  onNavigateToStudio?: () => void;
}

export const PresentersAndCastView: React.FC<PresentersAndCastViewProps> = ({
  project,
  onUpdateProject,
  onNavigateToStudio,
}) => {
  const [trainerPoses, setTrainerPoses] = useState<TrainerPose[]>(TRAINER_QUANG_POSES);
  const [mcList, setMcList] = useState<GitaMC[]>(GITA_MC_LIST);
  const [activeSubTab, setActiveSubTab] = useState<'trainer' | 'mc'>('trainer');
  const [selectedPose, setSelectedPose] = useState<TrainerPose | null>(null);
  const [selectedMC, setSelectedMC] = useState<GitaMC | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [playingVoiceId, setPlayingVoiceId] = useState<string | null>(null);
  const [notification, setNotification] = useState<string | null>(null);

  // Edit / Upload photo modal state
  const [editingTarget, setEditingTarget] = useState<{ type: 'trainer' | 'mc'; id: string; name: string; currentUrl: string } | null>(null);
  const [newImageUrl, setNewImageUrl] = useState('');

  const showToast = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  const handleCopyPrompt = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    showToast('Đã sao chép Prompt AI chất lượng 8K!');
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handlePlayVoice = (id: string, text: string, voiceName: string) => {
    setPlayingVoiceId(id);
    playSpeechSample(text, voiceName, () => {
      setPlayingVoiceId(null);
    });
  };

  // Add Trainer or MC into current Film Project as a consistent character
  const handleAddToProject = (name: string, rawRole: string, prompt: string, avatarUrl: string) => {
    const role: 'Mentor' | 'Protagonist' | 'Narrator' | 'Supporting' =
      rawRole === 'Protagonist' || rawRole === 'Narrator' || rawRole === 'Supporting' ? rawRole : 'Mentor';
    const newChar = {
      id: `char-cast-${Date.now()}`,
      name,
      role,
      age: name.includes('Quang') ? '38 tuổi' : '28 tuổi',
      archetype: name.includes('Quang') ? 'Chuyên gia huấn luyện & Nhà sáng lập GITA365' : 'MC & BTV Truyền hình GITA365',
      physicalTraits: {
        face: 'Phong thái đĩnh đạc, ánh mắt thông tuệ, nét mặt thanh thoát chuẩn MC truyền hình',
        hair: name.includes('Quang') ? 'Tóc cắt ngắn chỉn chu, vuốt gọn' : 'Tóc đen dài tạo kiểu thanh lịch',
        eyes: 'Mắt đen sáng, tự tin',
        attire: 'Trang phục công sở sang trọng chuẩn phong cách GITA365',
        distinguishingMarks: 'Khí chất tự tin và nụ cười truyền cảm hứng',
      },
      voiceProfile: {
        gender: name.includes('Quang') ? ('Nam' as const) : ('Nữ' as const),
        accent: 'Hà Nội / Bắc Bộ chuẩn',
        tone: 'Truyền cảm, dõng dạc, rõ chữ',
        speed: 1.0,
      },
      consistencyKeyPrompt: prompt,
      avatarUrl,
      consistencyScore: 99,
    };

    onUpdateProject({
      ...project,
      characters: [...project.characters, newChar],
    });

    showToast(`Đã thêm "${name}" vào danh sách Nhân Vật Nhất Quán của phim!`);
  };

  // Update photo for Trainer Pose or MC
  const handleSaveUpdatedPhoto = () => {
    if (!editingTarget || !newImageUrl.trim()) return;

    if (editingTarget.type === 'trainer') {
      setTrainerPoses((prev) =>
        prev.map((item) => (item.id === editingTarget.id ? { ...item, imageUrl: newImageUrl } : item))
      );
    } else {
      setMcList((prev) =>
        prev.map((item) => (item.id === editingTarget.id ? { ...item, imageUrl: newImageUrl } : item))
      );
    }

    showToast(`Đã cập nhật ảnh đại diện mới thành công!`);
    setEditingTarget(null);
    setNewImageUrl('');
  };

  // Handle local file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewImageUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const categories = [
    { id: 'all', label: 'Tất cả 11 MC' },
    { id: 'Sách & Kỹ năng', label: 'Sách & Kỹ năng' },
    { id: 'Kinh tế & Doanh nghiệp', label: 'Kinh tế & Doanh nghiệp' },
    { id: 'Văn hóa & Nghệ thuật', label: 'Văn hóa & Nghệ thuật' },
    { id: 'Lãnh đạo & Quản trị', label: 'Lãnh đạo & Quản trị' },
    { id: 'Công nghệ & AI', label: 'Công nghệ & AI' },
    { id: 'Tài chính & Dữ liệu', label: 'Tài chính & Dữ liệu' },
    { id: 'Khóa học số', label: 'Khóa học số' },
  ];

  const filteredMCs =
    selectedCategory === 'all'
      ? mcList
      : mcList.filter((mc) => mc.category.toLowerCase().includes(selectedCategory.toLowerCase()));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10 animate-in fade-in">
      {/* Toast notification */}
      {notification && (
        <div className="fixed top-20 right-6 z-50 bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-bold px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-2 border border-yellow-200 text-xs animate-in slide-in-from-top-4">
          <CheckCircle2 className="w-4 h-4 text-slate-950" />
          <span>{notification}</span>
        </div>
      )}

      {/* Hero Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950/40 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold uppercase tracking-wider">
              <Crown className="w-3.5 h-3.5" /> GITA365 Film Cast & Presenters
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight">
              Dàn Diễn Viên & MC Độc Quyền GITA365
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              Bộ sưu tập chân dung và bối cảnh chuẩn điện ảnh của <strong className="text-amber-400">Trainer Trương Nhật Quang</strong> và <strong className="text-cyan-400">11 Nữ MC Truyền Hình GITA365</strong>. Tích hợp sẵn Prompt AI nhất quán, lồng tiếng tự nhiên và tính năng đưa trực tiếp vào kịch bản phim.
            </p>
          </div>

          {/* Sub Navigation Switcher */}
          <div className="flex items-center bg-slate-950 p-1.5 rounded-2xl border border-slate-800 text-xs font-bold shadow-lg">
            <button
              onClick={() => setActiveSubTab('trainer')}
              className={`px-5 py-2.5 rounded-xl transition-all flex items-center gap-2 ${
                activeSubTab === 'trainer'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>👔 Trainer Trương Nhật Quang (10 Bối Cảnh)</span>
            </button>
            <button
              onClick={() => setActiveSubTab('mc')}
              className={`px-5 py-2.5 rounded-xl transition-all flex items-center gap-2 ${
                activeSubTab === 'mc'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>🎙️ Dàn 11 Nữ MC Truyền Hình</span>
            </button>
          </div>
        </div>
      </div>

      {/* SECTION 1: TRAINER TRƯƠNG NHẬT QUANG */}
      {activeSubTab === 'trainer' && (
        <div className="space-y-8 animate-in fade-in">
          {/* Trainer Overview Card */}
          <div className="bg-slate-900/90 rounded-3xl border border-slate-800 p-6 sm:p-8 shadow-xl flex flex-col lg:flex-row items-center gap-8">
            <div className="relative group">
              <div className="w-36 h-36 sm:w-44 sm:h-44 rounded-3xl overflow-hidden border-2 border-amber-500/80 shadow-2xl shadow-amber-500/20 ring-4 ring-amber-500/10">
                <img
                  src={trainerPoses[0]?.imageUrl}
                  alt="Trainer Trương Nhật Quang"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="absolute -bottom-2 -right-2 bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase shadow">
                Verified
              </div>
            </div>

            <div className="space-y-3 flex-1 text-center lg:text-left">
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2">
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40">
                  Founder & Master Trainer
                </span>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40">
                  100% Nhất Quán Khuôn Mặt AI
                </span>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-300 font-bold border border-blue-500/40">
                  Giọng Đọc AI Trầm Ấm
                </span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
                Trainer Trương Nhật Quang
              </h2>
              <p className="text-slate-300 text-xs sm:text-sm max-w-3xl leading-relaxed">
                Chuyên gia đào tạo thực chiến hàng đầu về Ứng dụng Trí Tuệ Nhân Tạo & Tự Động Hóa Sản Xuất Phim Điện Ảnh cho Doanh Nghiệp GITA365. Hệ thống đã đồng bộ hóa 10 bối cảnh chuẩn điện ảnh 8K cho Trainer Trương Nhật Quang: từ phòng chủ tịch, bục giảng trường quay, hội thảo quốc tế đến phong thái cố vấn chiến lược.
              </p>

              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 pt-2">
                <button
                  onClick={() =>
                    handlePlayVoice(
                      'tq-voice-hero',
                      'Xin chào tất cả các anh chị học viên và độc giả của GITA365. Tôi là Trương Nhật Quang, người sẽ đồng hành cùng quý vị trong hành trình kiến tạo những tác phẩm phim AI triệu view!',
                      'Quang Điện Ảnh - Nam Bắc'
                    )
                  }
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-semibold flex items-center gap-2 transition-all"
                >
                  <Volume2 className="w-4 h-4" />
                  <span>Nghe Giọng Đọc Mẫu Của Trainer Quang</span>
                </button>

                <button
                  onClick={() =>
                    handleAddToProject(
                      'Trainer Trương Nhật Quang',
                      'Lead Actor / Mentor',
                      trainerPoses[0]?.aiPrompt,
                      trainerPoses[0]?.imageUrl
                    )
                  }
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:brightness-110 text-slate-950 text-xs font-bold flex items-center gap-2 shadow-lg shadow-amber-500/20 transition-all"
                >
                  <Plus className="w-4 h-4" />
                  <span>Thêm Vào Nhân Vật Phim Hiện Tại</span>
                </button>
              </div>
            </div>
          </div>

          {/* 10 Poses Grid */}
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Camera className="w-5 h-5 text-amber-400" /> 10 Bối Cảnh & Phong Thái Điện Ảnh Chuẩn 8K
                </h3>
                <p className="text-xs text-slate-400">
                  Chọn góc máy và bối cảnh phù hợp cho video bài giảng, phim tài liệu hoặc video viral của bạn.
                </p>
              </div>
              <span className="text-xs font-mono text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-full border border-amber-500/20">
                10/10 Poses Sẵn Sàng
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-5">
              {trainerPoses.map((pose, idx) => (
                <div
                  key={pose.id}
                  className="group bg-slate-900 rounded-2xl border border-slate-800 hover:border-amber-500/60 overflow-hidden flex flex-col justify-between transition-all duration-300 hover:shadow-xl hover:shadow-amber-500/10"
                >
                  {/* Photo Container */}
                  <div className="relative aspect-[4/5] overflow-hidden bg-slate-950">
                    <img
                      src={pose.imageUrl}
                      alt={pose.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent opacity-80 group-hover:opacity-60 transition-opacity" />

                    <div className="absolute top-2 left-2">
                      <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-md bg-amber-500/90 text-slate-950 backdrop-blur-sm shadow">
                        Pose #{idx + 1}
                      </span>
                    </div>

                    <div className="absolute top-2 right-2 flex items-center gap-1">
                      <button
                        onClick={() =>
                          setEditingTarget({
                            type: 'trainer',
                            id: pose.id,
                            name: pose.title,
                            currentUrl: pose.imageUrl,
                          })
                        }
                        className="p-1.5 rounded-lg bg-slate-950/80 hover:bg-amber-500 hover:text-slate-950 text-slate-300 transition-colors"
                        title="Đổi ảnh hoặc tải ảnh mới lên"
                      >
                        <Upload className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="absolute bottom-2 left-2 right-2 space-y-1">
                      <span className="text-[9px] px-2 py-0.5 rounded-full bg-slate-900/90 border border-slate-700 text-amber-300 font-semibold block truncate">
                        {pose.tag}
                      </span>
                      <h4 className="text-xs font-bold text-white line-clamp-1">
                        {pose.title}
                      </h4>
                    </div>
                  </div>

                  {/* Body Details */}
                  <div className="p-3.5 space-y-3 flex-1 flex flex-col justify-between text-xs">
                    <div className="space-y-1.5 text-slate-300">
                      <div className="text-[11px] text-slate-400 line-clamp-2">
                        {pose.description}
                      </div>

                      <div className="bg-slate-950 p-2 rounded-xl border border-slate-800 text-[10px] text-slate-400 space-y-1">
                        <div className="flex justify-between">
                          <span className="text-slate-500">Trang phục:</span>
                          <span className="text-slate-300 font-medium truncate max-w-[120px]">
                            {pose.attire}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Màn hình sau:</span>
                          <span className="text-cyan-300 font-medium truncate max-w-[120px]">
                            {pose.screenContent}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className="space-y-1.5 pt-1">
                      <button
                        onClick={() => handleCopyPrompt(pose.aiPrompt, pose.id)}
                        className="w-full py-1.5 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-colors border border-slate-700"
                      >
                        {copiedId === pose.id ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            <span className="text-emerald-400">Đã chép Prompt</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copy AI Prompt 8K</span>
                          </>
                        )}
                      </button>

                      <button
                        onClick={() =>
                          handleAddToProject(
                            `Trainer Quang (${pose.tag})`,
                            'Host / Giảng viên',
                            pose.aiPrompt,
                            pose.imageUrl
                          )
                        }
                        className="w-full py-1.5 px-2 rounded-lg bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-slate-950 text-[11px] font-bold flex items-center justify-center gap-1.5 transition-all"
                      >
                        <Video className="w-3.5 h-3.5" />
                        <span>Dẫn Phim Cảnh Này</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: DÀN 11 MC TRUYỀN HÌNH GITA365 */}
      {activeSubTab === 'mc' && (
        <div className="space-y-8 animate-in fade-in">
          {/* Categories Bar */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
            <Filter className="w-4 h-4 text-amber-400 flex-shrink-0" />
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  selectedCategory === cat.id
                    ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
                    : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* MC Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredMCs.map((mc) => (
              <div
                key={mc.id}
                className="group bg-slate-900 rounded-3xl border border-slate-800 hover:border-cyan-500/60 overflow-hidden flex flex-col justify-between transition-all duration-300 hover:shadow-xl hover:shadow-cyan-500/10"
              >
                {/* Photo & Badge */}
                <div className="relative aspect-[4/5] overflow-hidden bg-slate-950">
                  <img
                    src={mc.imageUrl}
                    alt={mc.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent opacity-85 group-hover:opacity-60 transition-opacity" />

                  {/* Suit Color Pill Indicator */}
                  <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-950/90 backdrop-blur-md border border-slate-700 shadow">
                    <span
                      className="w-3 h-3 rounded-full border border-white/50 shadow-sm"
                      style={{ backgroundColor: mc.suitHex }}
                    />
                    <span className="text-[10px] font-bold text-white truncate max-w-[140px]">
                      {mc.suitColor}
                    </span>
                  </div>

                  {/* Upload new photo button */}
                  <div className="absolute top-3 right-3">
                    <button
                      onClick={() =>
                        setEditingTarget({
                          type: 'mc',
                          id: mc.id,
                          name: mc.name,
                          currentUrl: mc.imageUrl,
                        })
                      }
                      className="p-1.5 rounded-lg bg-slate-950/80 hover:bg-cyan-500 hover:text-slate-950 text-slate-300 transition-colors"
                      title="Cập nhật hoặc tải ảnh mới"
                    >
                      <Upload className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Bottom Text Over Photo */}
                  <div className="absolute bottom-3 left-3 right-3 space-y-1">
                    {mc.badge && (
                      <span className="text-[9px] font-extrabold uppercase px-2 py-0.5 rounded bg-cyan-500/90 text-slate-950 inline-block">
                        {mc.badge}
                      </span>
                    )}
                    <h3 className="text-base font-extrabold text-white">{mc.name}</h3>
                    <p className="text-[11px] text-amber-300 font-medium line-clamp-1">
                      {mc.role}
                    </p>
                  </div>
                </div>

                {/* Details Container */}
                <div className="p-4 space-y-3 flex-1 flex flex-col justify-between text-xs">
                  <div className="space-y-2">
                    <p className="text-slate-300 text-[11px] line-clamp-2 leading-relaxed">
                      {mc.description}
                    </p>

                    <div className="bg-slate-950 p-2.5 rounded-2xl border border-slate-800 text-[10px] space-y-1.5 text-slate-300">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-500">Giọng đọc:</span>
                        <span className="text-emerald-400 font-semibold truncate max-w-[150px]">
                          {mc.voiceStyle}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-500">Tư thế Studio:</span>
                        <span className="text-slate-300 truncate max-w-[150px]">
                          {mc.studioPose}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="space-y-2 pt-2 border-t border-slate-800/80">
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() =>
                          handlePlayVoice(
                            mc.id,
                            `Chào mừng quý vị đến với chương trình đặc biệt của GITA365. Tôi là ${mc.name}, rất vui được đồng hành cùng bạn.`,
                            mc.name
                          )
                        }
                        className="py-1.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-[11px] font-semibold flex items-center justify-center gap-1 transition-colors"
                      >
                        <Volume2 className="w-3.5 h-3.5 text-amber-400" />
                        <span>Nghe Thử</span>
                      </button>

                      <button
                        onClick={() => handleCopyPrompt(mc.aiPrompt, mc.id)}
                        className="py-1.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-[11px] font-semibold flex items-center justify-center gap-1 transition-colors"
                      >
                        {copiedId === mc.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                        <span>Prompt 8K</span>
                      </button>
                    </div>

                    <button
                      onClick={() =>
                        handleAddToProject(
                          mc.name,
                          mc.role,
                          mc.aiPrompt,
                          mc.imageUrl
                        )
                      }
                      className="w-full py-2 px-3 rounded-xl bg-cyan-500/20 hover:bg-cyan-500 text-cyan-300 hover:text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Chọn Dẫn Phim / Bản Tin Này</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal: Update / Upload Custom Photo */}
      {editingTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-md bg-slate-900 rounded-3xl border border-slate-800 p-6 shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                <Camera className="w-5 h-5 text-amber-400" /> Cập Nhật Ảnh Mới
              </h3>
              <button
                onClick={() => setEditingTarget(null)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <span className="text-slate-400 block mb-1">Đối tượng cập nhật:</span>
                <span className="font-bold text-white text-sm">{editingTarget.name}</span>
              </div>

              {/* Photo Preview */}
              <div className="flex justify-center">
                <div className="w-36 h-44 rounded-2xl overflow-hidden border border-slate-700 bg-slate-950 shadow-inner">
                  <img
                    src={newImageUrl || editingTarget.currentUrl}
                    alt="Preview"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>

              {/* Option 1: File Upload */}
              <div className="space-y-1">
                <label className="text-slate-300 font-semibold block">Tải ảnh từ máy tính / điện thoại:</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="w-full text-xs text-slate-400 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-amber-500 file:text-slate-950 hover:file:bg-amber-400 cursor-pointer bg-slate-950 p-2 rounded-xl border border-slate-800"
                />
              </div>

              {/* Option 2: Image URL */}
              <div className="space-y-1">
                <label className="text-slate-300 font-semibold block">Hoặc nhập liên kết URL ảnh trực tiếp:</label>
                <input
                  type="text"
                  placeholder="https://..."
                  value={newImageUrl}
                  onChange={(e) => setNewImageUrl(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500 text-xs"
                />
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={() => setEditingTarget(null)}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs"
              >
                Hủy
              </button>
              <button
                onClick={handleSaveUpdatedPhoto}
                disabled={!newImageUrl.trim()}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:brightness-110 text-slate-950 font-bold text-xs shadow-lg disabled:opacity-50"
              >
                Lưu Thay Đổi
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
