import React, { useState } from 'react';
import {
  Users,
  Video,
  Sparkles,
  Volume2,
  Tv,
  CheckCircle2,
  Copy,
  Check,
  Play,
  Layers,
  Presentation,
  BookOpen,
  Award,
  Sliders,
  Share2,
} from 'lucide-react';
import { FilmProject, TrainerPose, GitaMC } from '../types';
import { TRAINER_QUANG_POSES, GITA_MC_LIST } from '../data/initialData';
import { speakWithGeminiTTS, stopSpeaking } from '../utils/audioSynth';

interface MCStudioViewProps {
  project: FilmProject;
  onNavigateToStudio: () => void;
}

export const MCStudioView: React.FC<MCStudioViewProps> = ({
  project,
  onNavigateToStudio,
}) => {
  const [activeTab, setActiveTab] = useState<'trainer' | 'mc'>('trainer');
  const [selectedTrainerPose, setSelectedTrainerPose] = useState<TrainerPose>(TRAINER_QUANG_POSES[0]);
  const [selectedMC, setSelectedMC] = useState<GitaMC>(GITA_MC_LIST[0]);
  const [screenDisplayMode, setScreenDisplayMode] = useState<'lesson' | 'film' | 'quote' | 'script'>('lesson');
  const [customNarration, setCustomNarration] = useState(
    'Chào mừng các anh chị học viên và khán giả đến với chương trình đào tạo chuyển đổi số và làm chủ công nghệ sản xuất phim AI của hệ sinh thái GITA365.'
  );
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [copiedText, setCopiedText] = useState(false);

  const handleSpeak = async () => {
    setIsSpeaking(true);
    const gender = activeTab === 'trainer' ? 'Nam' : 'Nữ';
    const speakerName = activeTab === 'trainer' ? 'Trainer Trương Nhật Quang' : selectedMC.name;
    const voiceName = activeTab === 'trainer' ? 'Fenrir' : selectedMC.name.includes('Vy') || selectedMC.name.includes('Linh') ? 'Zephyr' : 'Kore';
    const style = activeTab === 'trainer'
      ? 'Giọng đọc nam tiếng Việt chuẩn, phong thái đĩnh đạc, trầm ấm, truyền cảm giảng viên và doanh nhân'
      : `Giọng đọc nữ tiếng Việt thanh lịch, chuẩn phát thanh viên truyền hình, ${selectedMC.voiceStyle}`;

    await speakWithGeminiTTS(customNarration, {
      gender,
      voiceName,
      speakerName,
      style,
      onEnd: () => setIsSpeaking(false),
      onError: () => setIsSpeaking(false),
    });
  };

  const handleStopSpeaking = () => {
    stopSpeaking();
    setIsSpeaking(false);
  };

  const handleCopyPrompt = () => {
    const prompt =
      activeTab === 'trainer'
        ? `Cinematic photorealistic 8k video still, Trainer Truong Nhat Quang GITA365, ${selectedTrainerPose.attire}, in ${selectedTrainerPose.setting}, ${selectedTrainerPose.description}, studio lighting, masterclass presenter, 35mm film lens`
        : `Cinematic photorealistic 8k video still, GITA365 educational presenter ${selectedMC.name}, wearing ${selectedMC.suitColor}, modern TV educational studio with large smart display, ${selectedMC.studioPose}, elegant and friendly`;
    navigator.clipboard.writeText(prompt);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950/40 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold uppercase tracking-wider">
              <Presentation className="w-3.5 h-3.5" /> GITA365 Virtual Presenter & Trainer Studio
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight">
              Phòng Thu MC Ảo & Huấn Luyện Viên Trương Nhật Quang
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              Tích hợp hệ thống hình ảnh Trainer Trương Nhật Quang (Master Trainer) và đội ngũ 11 Nữ MC Giáo Dục GITA365
              thanh lịch bên màn hình tương tác thông minh. Tự động lồng ghép bài giảng, trích đoạn sách và chuyển cảnh chuẩn truyền hình.
            </p>
          </div>

          {/* Switch Tab between Trainer Quang and 11 MCs */}
          <div className="flex items-center bg-slate-950 p-1.5 rounded-2xl border border-slate-800 text-xs font-bold shadow-lg">
            <button
              onClick={() => {
                setActiveTab('trainer');
                setCustomNarration(
                  'Chào mừng các anh chị đến với khóa huấn luyện thực chiến: Bí quyết xây dựng xưởng phim AI và tự động hóa doanh nghiệp toàn diện cùng GITA365.'
                );
              }}
              className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 ${
                activeTab === 'trainer'
                  ? 'bg-amber-500 text-slate-950 shadow-md font-extrabold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>👨‍🏫 Trainer Trương Nhật Quang</span>
              <span className="bg-slate-900 text-amber-300 text-[10px] px-1.5 py-0.5 rounded-full font-mono">
                17 Poses
              </span>
            </button>
            <button
              onClick={() => {
                setActiveTab('mc');
                setCustomNarration(
                  'Kính chào quý vị khán giả và các bạn độc giả đang theo dõi chuyên đề điện ảnh và tóm tắt tác phẩm sách kinh điển của hệ thống GITA365.'
                );
              }}
              className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 ${
                activeTab === 'mc'
                  ? 'bg-amber-500 text-slate-950 shadow-md font-extrabold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>👩‍💼 Đội Ngũ 11 Nữ MC Giáo Dục</span>
              <span className="bg-slate-900 text-amber-300 text-[10px] px-1.5 py-0.5 rounded-full font-mono">
                11 MC
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Studio Interactive Stage */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Virtual Studio Preview with Smart Display Screen (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-slate-900/95 rounded-3xl border border-slate-800 p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Tv className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-white text-sm">
                  {activeTab === 'trainer'
                    ? `Studio Trainer: ${selectedTrainerPose.title}`
                    : `Studio Trực Tuyến: ${selectedMC.name} (${selectedMC.suitColor})`}
                </h3>
              </div>
              <span className="text-[10px] px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-mono">
                4K Studio Broadcast Live
              </span>
            </div>

            {/* Simulated TV Studio Stage with Interactive Smart Screen */}
            <div className="relative aspect-video w-full rounded-2xl overflow-hidden bg-slate-950 border-2 border-slate-800 flex items-center justify-center shadow-inner">
              {/* Studio Background Walls & Lighting */}
              <div className="absolute inset-0 bg-gradient-to-tr from-slate-950 via-slate-900 to-amber-950/30" />
              <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600" />

              {/* Behind-the-Presenter Smart Display Screen */}
              <div className="absolute right-4 top-6 bottom-6 w-[58%] rounded-xl bg-slate-900 border-2 border-slate-700/80 p-4 shadow-2xl flex flex-col justify-between overflow-hidden">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                    <span className="text-[10px] font-bold text-amber-300 font-mono uppercase">
                      GITA365 SMART SCREEN • {screenDisplayMode.toUpperCase()}
                    </span>
                  </div>
                  <span className="text-[9px] text-slate-500 font-mono">100 INCH 8K DISPLAY</span>
                </div>

                {/* Display Screen Content depending on mode */}
                <div className="flex-1 flex flex-col justify-center py-2 space-y-2 text-center">
                  {screenDisplayMode === 'lesson' && (
                    <div className="space-y-1.5 animate-in fade-in">
                      <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-bold">
                        BÀI GIẢNG SỐ 1
                      </span>
                      <h4 className="text-sm font-black text-white leading-tight">
                        {project.title}
                      </h4>
                      <p className="text-[11px] text-slate-300 line-clamp-3">
                        {project.episodes[0]?.synopsis ||
                          'Quy trình 5 bước chuyển thể sách thành phim bộ điện ảnh 4K bằng trí tuệ nhân tạo.'}
                      </p>
                      <div className="flex justify-center gap-2 pt-1 text-[10px] text-emerald-400 font-mono">
                        <span>✓ Cấu trúc 3 Hồi</span>
                        <span>✓ Nhân vật nhất quán</span>
                        <span>✓ Xuất phim 4K</span>
                      </div>
                    </div>
                  )}

                  {screenDisplayMode === 'film' && (
                    <div className="space-y-1 animate-in fade-in">
                      <div className="aspect-video w-full rounded-lg overflow-hidden bg-black border border-slate-800 relative">
                        {project.episodes[0]?.acts[0]?.scenes[0]?.imageUrl && (
                          <img
                            src={project.episodes[0].acts[0].scenes[0].imageUrl}
                            alt="Scene Preview"
                            className="w-full h-full object-cover"
                          />
                        )}
                        <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                          <Play className="w-8 h-8 text-amber-400 fill-amber-400" />
                        </div>
                      </div>
                      <span className="text-[10px] text-slate-400">
                        Phân cảnh 1: {project.episodes[0]?.acts[0]?.scenes[0]?.title}
                      </span>
                    </div>
                  )}

                  {screenDisplayMode === 'quote' && (
                    <div className="space-y-2 p-2 bg-slate-950/60 rounded-xl border border-slate-800 animate-in fade-in">
                      <span className="text-amber-400 text-lg">“</span>
                      <p className="text-xs text-yellow-200 font-semibold italic">
                        {activeTab === 'trainer'
                          ? '“Không có giới hạn nào cho sự sáng tạo khi bạn nắm trong tay sức mạnh của công nghệ AI GITA365.”'
                          : '“Một cuốn sách hay là ngọn hải đăng soi sáng tâm hồn, và điện ảnh là đôi cánh đưa chân lý đến muôn người.”'}
                      </p>
                      <span className="text-[10px] text-slate-400 block">
                        — {activeTab === 'trainer' ? 'Trainer Trương Nhật Quang' : selectedMC.name}
                      </span>
                    </div>
                  )}

                  {screenDisplayMode === 'script' && (
                    <div className="space-y-1 text-left p-2 bg-slate-950/80 rounded-lg font-mono text-[10px] text-slate-300 animate-in fade-in">
                      <span className="text-amber-400 font-bold block">[KỊCH BẢN THUYẾT MINH AI]:</span>
                      <p className="line-clamp-4 leading-relaxed">{customNarration}</p>
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between text-[9px] text-slate-500 pt-1 border-t border-slate-800">
                  <span>Hệ sinh thái GITA365 AI</span>
                  <span className="text-emerald-400 font-mono">Đồng bộ tự động</span>
                </div>
              </div>

              {/* Presenter / Trainer Stage Layer (Left side) */}
              <div className="absolute left-6 bottom-0 z-10 flex flex-col items-center">
                <div className="relative">
                  {/* Avatar badge card representation matching uploaded photo */}
                  <div className="w-48 sm:w-56 rounded-2xl bg-gradient-to-t from-slate-950 via-slate-900/90 to-transparent p-3 border-t border-slate-700/60 flex flex-col items-center text-center">
                    <div className="w-24 h-24 rounded-full border-2 border-amber-400 overflow-hidden shadow-2xl mb-2 bg-slate-800">
                      <img
                        src={
                          activeTab === 'trainer'
                            ? 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80'
                            : 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=300&auto=format&fit=crop&q=80'
                        }
                        alt="Presenter"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <span className="text-xs font-black text-white">
                      {activeTab === 'trainer' ? 'Trương Nhật Quang' : selectedMC.name}
                    </span>
                    <span className="text-[10px] text-amber-300 font-medium">
                      {activeTab === 'trainer'
                        ? 'Master Trainer • Founder GITA365'
                        : selectedMC.role}
                    </span>
                    <span className="text-[9px] text-slate-400 mt-0.5 max-w-[180px] truncate">
                      {activeTab === 'trainer'
                        ? selectedTrainerPose.attire
                        : selectedMC.suitColor}
                    </span>
                  </div>
                </div>
              </div>

              {/* Studio Lower Third Banner */}
              <div className="absolute bottom-2 left-4 right-4 z-20 flex items-center justify-between bg-black/80 backdrop-blur-md px-4 py-1.5 rounded-xl border border-slate-800 text-[11px]">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  <span className="font-bold text-white">
                    {activeTab === 'trainer' ? 'TRAINER TRƯƠNG NHẬT QUANG' : selectedMC.name}
                  </span>
                  <span className="text-slate-500">|</span>
                  <span className="text-slate-300">
                    {activeTab === 'trainer' ? selectedTrainerPose.title : selectedMC.role}
                  </span>
                </div>
                <span className="text-amber-400 font-mono text-[10px] font-bold">GITA365 STUDIO 4K</span>
              </div>
            </div>

            {/* Smart Screen Mode Switcher Controls */}
            <div className="flex items-center justify-between gap-2 pt-2">
              <span className="text-xs font-semibold text-slate-400">Hiển thị trên màn hình lớn:</span>
              <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
                <button
                  onClick={() => setScreenDisplayMode('lesson')}
                  className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                    screenDisplayMode === 'lesson'
                      ? 'bg-amber-500 text-slate-950 font-bold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Bài Giảng Sách
                </button>
                <button
                  onClick={() => setScreenDisplayMode('film')}
                  className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                    screenDisplayMode === 'film'
                      ? 'bg-amber-500 text-slate-950 font-bold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Video 4K
                </button>
                <button
                  onClick={() => setScreenDisplayMode('quote')}
                  className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                    screenDisplayMode === 'quote'
                      ? 'bg-amber-500 text-slate-950 font-bold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Trích Dẫn Vàng
                </button>
                <button
                  onClick={() => setScreenDisplayMode('script')}
                  className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                    screenDisplayMode === 'script'
                      ? 'bg-amber-500 text-slate-950 font-bold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Lời Thoại AI
                </button>
              </div>
            </div>

            {/* Audio Voiceover Practice Bar */}
            <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-300 flex items-center gap-1.5">
                  <Volume2 className="w-4 h-4 text-emerald-400" /> Lời Thuyết Minh Giọng Đọc AI Trong Studio:
                </span>
                <span className="text-[10px] text-slate-500 font-mono">
                  {activeTab === 'trainer' ? 'Giọng Nam Bắc Trầm Ấm' : 'Giọng Nữ Phát Thanh Viên'}
                </span>
              </div>
              <textarea
                rows={2}
                value={customNarration}
                onChange={(e) => setCustomNarration(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-amber-500 font-medium"
              />
              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleSpeak}
                    disabled={isSpeaking}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-bold text-xs shadow-md transition-all hover:scale-105 disabled:opacity-50"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>{isSpeaking ? 'Đang Đọc Thuyết Trình...' : 'Nghe Thuyết Trình Trực Tiếp'}</span>
                  </button>
                  {isSpeaking && (
                    <button
                      onClick={handleStopSpeaking}
                      className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300 text-xs"
                    >
                      Dừng lại
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopyPrompt}
                    className="flex items-center gap-1 text-xs text-amber-400 hover:text-amber-300"
                  >
                    {copiedText ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Đã chép prompt</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Sao chép Prompt 8K</span>
                      </>
                    )}
                  </button>
                  <button
                    onClick={onNavigateToStudio}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs shadow-md hover:bg-amber-400"
                  >
                    <Video className="w-3.5 h-3.5" />
                    <span>Chuyển Sang Xưởng Dựng</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Style Gallery Selector (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900/95 rounded-3xl border border-slate-800 p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-xs uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-400" />
                {activeTab === 'trainer'
                  ? 'Tạo Hình Trainer Trương Nhật Quang (17 Phong Cách)'
                  : 'Danh Sách 11 Nữ MC Giáo Dục GITA365'}
              </h3>
              <span className="text-[10px] text-slate-400">Chọn để kích hoạt</span>
            </div>

            {/* List of Trainer Poses */}
            {activeTab === 'trainer' && (
              <div className="space-y-2.5 max-h-[560px] overflow-y-auto pr-1">
                {TRAINER_QUANG_POSES.map((pose) => {
                  const isSelected = selectedTrainerPose.id === pose.id;
                  return (
                    <div
                      key={pose.id}
                      onClick={() => setSelectedTrainerPose(pose)}
                      className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-slate-950 border-amber-500/80 shadow-lg ring-1 ring-amber-500/50'
                          : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700 hover:bg-slate-950'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white">{pose.title}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 font-mono">
                          {pose.tag.split('•')[0].trim()}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-300 mt-1 font-medium">{pose.description}</p>
                      <div className="mt-2 pt-2 border-t border-slate-900 text-[10px] text-slate-400 flex items-center justify-between">
                        <span>👔 {pose.attire}</span>
                        {pose.hasInteractiveScreen && (
                          <span className="text-emerald-400 font-mono font-semibold">
                            ✦ Màn hình tương tác
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* List of 11 GITA MCs */}
            {activeTab === 'mc' && (
              <div className="space-y-2.5 max-h-[560px] overflow-y-auto pr-1">
                {GITA_MC_LIST.map((mc) => {
                  const isSelected = selectedMC.id === mc.id;
                  return (
                    <div
                      key={mc.id}
                      onClick={() => setSelectedMC(mc)}
                      className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-slate-950 border-amber-500/80 shadow-lg ring-1 ring-amber-500/50'
                          : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700 hover:bg-slate-950'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span
                            className="w-3 h-3 rounded-full border border-slate-700"
                            style={{ backgroundColor: mc.suitHex }}
                          />
                          <span className="text-xs font-bold text-white">{mc.name}</span>
                        </div>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono">
                          {mc.category}
                        </span>
                      </div>
                      <div className="text-[11px] text-amber-300 font-semibold mt-1">{mc.suitColor}</div>
                      <p className="text-[11px] text-slate-300 mt-0.5 leading-tight">{mc.role}</p>
                      <div className="mt-2 pt-1.5 border-t border-slate-900 text-[10px] text-slate-400 flex items-center justify-between">
                        <span>🎙️ {mc.voiceStyle.split('•')[0]}</span>
                        <span className="text-slate-400">{mc.studioPose}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
