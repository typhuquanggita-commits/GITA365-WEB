import React, { useState, useEffect, useMemo } from 'react';
import {
  Users,
  Search,
  Filter,
  Plus,
  Shield,
  Film,
  Crown,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Ban,
  RefreshCw,
  Coins,
  Video,
  HardDrive,
  Mail,
  Phone,
  Building,
  Calendar,
  Clock,
  MoreVertical,
  Download,
  Trash2,
  Edit3,
  ExternalLink,
  ChevronRight,
  TrendingUp,
  UserCheck,
  UserX,
  X,
  Save,
  Check,
  Info,
} from 'lucide-react';
import {
  CustomerAccount,
  fetchAllCustomers,
  updateCustomerInFirestore,
  INITIAL_DEMO_CUSTOMERS,
} from '../lib/firebase';

interface CustomerAdminViewProps {
  currentAdminEmail?: string;
}

export const CustomerAdminView: React.FC<CustomerAdminViewProps> = ({
  currentAdminEmail = 'typhuquanggita@gmail.com',
}) => {
  const [customers, setCustomers] = useState<CustomerAccount[]>(INITIAL_DEMO_CUSTOMERS);
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [tierFilter, setTierFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'recent' | 'renders' | 'points' | 'name'>('recent');

  // Selected customer for detailed modal/drawer
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerAccount | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);

  // Add customer modal state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newCustomer, setNewCustomer] = useState({
    displayName: '',
    email: '',
    phone: '',
    company: '',
    subscriptionTier: 'Creator Pro' as CustomerAccount['subscriptionTier'],
    role: 'filmmaker' as CustomerAccount['role'],
    videoRenderQuota: 25,
    gitaPoints: 5000,
  });

  // Edit / Quota modal state
  const [editingCustomer, setEditingCustomer] = useState<CustomerAccount | null>(null);
  const [notification, setNotification] = useState<{ type: 'success' | 'info' | 'error'; message: string } | null>(null);

  const showNotification = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 4000);
  };

  // Load customers from Firestore
  const loadCustomers = async () => {
    setIsLoading(true);
    try {
      const data = await fetchAllCustomers();
      setCustomers(data);
    } catch (err: any) {
      console.error('Error fetching customers:', err);
      showNotification('Không thể tải từ Firestore, hiển thị danh sách bộ đệm', 'info');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadCustomers();
  }, []);

  // Filter & Sort
  const filteredCustomers = useMemo(() => {
    return customers
      .filter((c) => {
        const query = searchQuery.toLowerCase();
        const matchesQuery =
          c.displayName.toLowerCase().includes(query) ||
          c.email.toLowerCase().includes(query) ||
          (c.company && c.company.toLowerCase().includes(query)) ||
          (c.phone && c.phone.includes(query));

        const matchesTier = tierFilter === 'all' || c.subscriptionTier === tierFilter;
        const matchesStatus = statusFilter === 'all' || c.status === statusFilter;
        const matchesRole = roleFilter === 'all' || c.role === roleFilter;

        return matchesQuery && matchesTier && matchesStatus && matchesRole;
      })
      .sort((a, b) => {
        if (sortBy === 'renders') return b.videoRendersUsed - a.videoRendersUsed;
        if (sortBy === 'points') return b.gitaPoints - a.gitaPoints;
        if (sortBy === 'name') return a.displayName.localeCompare(b.displayName);
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });
  }, [customers, searchQuery, tierFilter, statusFilter, roleFilter, sortBy]);

  // Overall Statistics
  const stats = useMemo(() => {
    const total = customers.length;
    const active = customers.filter((c) => c.status === 'active').length;
    const totalVideos = customers.reduce((sum, c) => sum + (c.videoRendersUsed || 0), 0);
    const totalStorage = customers.reduce((sum, c) => sum + (c.storageUsedGB || 0), 0);
    const paidTiers = customers.filter((c) => c.subscriptionTier !== 'Free').length;
    const totalPoints = customers.reduce((sum, c) => sum + (c.gitaPoints || 0), 0);
    return {
      total,
      active,
      totalVideos,
      totalStorage: totalStorage.toFixed(1),
      paidTiers,
      totalPoints,
    };
  }, [customers]);

  // Quick Action: Update Status (Active / Suspended)
  const handleToggleStatus = async (customer: CustomerAccount) => {
    const nextStatus = customer.status === 'active' ? 'suspended' : 'active';
    try {
      await updateCustomerInFirestore(customer.id, { status: nextStatus });
      setCustomers((prev) =>
        prev.map((c) => (c.id === customer.id ? { ...c, status: nextStatus } : c))
      );
      showNotification(`Đã ${nextStatus === 'active' ? 'mở khóa' : 'tạm khóa'} tài khoản ${customer.displayName}`);
    } catch (err: any) {
      showNotification(err.message || 'Lỗi cập nhật trạng thái', 'error');
    }
  };

  // Quick Action: Adjust Video Quota
  const handleAdjustQuota = async (customer: CustomerAccount, delta: number) => {
    const newQuota = Math.max(0, customer.videoRenderQuota + delta);
    try {
      await updateCustomerInFirestore(customer.id, { videoRenderQuota: newQuota });
      setCustomers((prev) =>
        prev.map((c) => (c.id === customer.id ? { ...c, videoRenderQuota: newQuota } : c))
      );
      showNotification(`Đã ${delta > 0 ? 'cấp thêm' : 'giảm'} quota cho ${customer.displayName}: ${newQuota} video`);
    } catch (err: any) {
      showNotification(err.message || 'Lỗi cập nhật quota', 'error');
    }
  };

  // Quick Action: Grant Points
  const handleGrantPoints = async (customer: CustomerAccount, points: number) => {
    const nextPoints = customer.gitaPoints + points;
    try {
      await updateCustomerInFirestore(customer.id, { gitaPoints: nextPoints });
      setCustomers((prev) =>
        prev.map((c) => (c.id === customer.id ? { ...c, gitaPoints: nextPoints } : c))
      );
      showNotification(`Đã cộng +${points.toLocaleString()} G-Coin cho ${customer.displayName}`);
    } catch (err: any) {
      showNotification(err.message || 'Lỗi tặng điểm', 'error');
    }
  };

  // Save changes from Edit Modal
  const handleSaveCustomerEdits = async () => {
    if (!editingCustomer) return;
    try {
      await updateCustomerInFirestore(editingCustomer.id, editingCustomer);
      setCustomers((prev) =>
        prev.map((c) => (c.id === editingCustomer.id ? editingCustomer : c))
      );
      setEditingCustomer(null);
      showNotification(`Đã lưu cập nhật thông tin khách hàng ${editingCustomer.displayName}`);
    } catch (err: any) {
      showNotification(err.message || 'Lỗi lưu thông tin', 'error');
    }
  };

  // Add new customer
  const handleCreateCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustomer.displayName.trim() || !newCustomer.email.trim()) {
      showNotification('Vui lòng nhập tên và email khách hàng', 'error');
      return;
    }

    const id = `cust_${Date.now()}`;
    const createdAccount: CustomerAccount = {
      id,
      email: newCustomer.email.trim(),
      displayName: newCustomer.displayName.trim(),
      phone: newCustomer.phone.trim(),
      company: newCustomer.company.trim() || 'Khách hàng cá nhân',
      photoURL: `https://images.unsplash.com/photo-${1500000000000 + (customers.length % 10)}?auto=format&fit=crop&w=150&q=80`,
      role: newCustomer.role,
      subscriptionTier: newCustomer.subscriptionTier,
      status: 'active',
      videoRenderQuota: Number(newCustomer.videoRenderQuota) || 25,
      videoRendersUsed: 0,
      storageUsedGB: 0.5,
      gitaPoints: Number(newCustomer.gitaPoints) || 5000,
      lastActiveAt: 'Vừa tạo',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    try {
      await updateCustomerInFirestore(id, createdAccount);
      setCustomers((prev) => [createdAccount, ...prev]);
      setIsAddModalOpen(false);
      setNewCustomer({
        displayName: '',
        email: '',
        phone: '',
        company: '',
        subscriptionTier: 'Creator Pro',
        role: 'filmmaker',
        videoRenderQuota: 25,
        gitaPoints: 5000,
      });
      showNotification(`Đã tạo thành công tài khoản khách hàng: ${createdAccount.displayName}`);
    } catch (err: any) {
      showNotification(err.message || 'Lỗi tạo tài khoản', 'error');
    }
  };

  // Export CSV
  const handleExportCSV = () => {
    const headers = ['ID', 'Họ Tên', 'Email', 'Công Ty/Kênh', 'Gói Cước', 'Trạng Thái', 'Video Đã Dùng', 'Quota', 'Dung Lượng (GB)', 'Điểm G-Coin', 'Ngày Đăng Ký'];
    const rows = customers.map((c) => [
      c.id,
      `"${c.displayName}"`,
      c.email,
      `"${c.company || ''}"`,
      c.subscriptionTier,
      c.status,
      c.videoRendersUsed,
      c.videoRenderQuota,
      c.storageUsedGB,
      c.gitaPoints,
      new Date(c.createdAt).toLocaleDateString('vi-VN'),
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `GITA365_Danh_Sach_Khach_Hang_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showNotification('Đã xuất file CSV báo cáo khách hàng thành công!');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-300">
      {/* Toast Notification */}
      {notification && (
        <div
          className={`fixed top-20 right-6 z-50 flex items-center gap-2.5 px-4 py-3 rounded-2xl shadow-2xl text-xs font-semibold border backdrop-blur-md transition-all ${
            notification.type === 'success'
              ? 'bg-emerald-950/90 text-emerald-200 border-emerald-500/40 shadow-emerald-900/30'
              : notification.type === 'error'
              ? 'bg-rose-950/90 text-rose-200 border-rose-500/40 shadow-rose-900/30'
              : 'bg-amber-950/90 text-amber-200 border-amber-500/40 shadow-amber-900/30'
          }`}
        >
          {notification.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
          {notification.type === 'error' && <AlertTriangle className="w-4 h-4 text-rose-400" />}
          {notification.type === 'info' && <Info className="w-4 h-4 text-amber-400" />}
          <span>{notification.message}</span>
        </div>
      )}

      {/* Top Banner / Header */}
      <div className="bg-gradient-to-r from-slate-900 via-purple-950/40 to-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full text-xs font-extrabold uppercase bg-purple-500/20 text-purple-300 border border-purple-500/30 flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-purple-400" /> Trung Tâm Quản Trị Hệ Thống GITA365
              </span>
              <span className="text-[11px] text-slate-400 font-mono">
                Admin: <strong className="text-amber-400">{currentAdminEmail}</strong>
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-amber-300 tracking-tight">
              Quản Trị Tài Khoản Khách Hàng Sản Xuất Video
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 max-w-2xl leading-relaxed">
              Theo dõi và quản lý toàn bộ các nhà sáng tạo nội dung, doanh nghiệp, và xưởng phim đang sử dụng ứng dụng GITA365 để chuyển thể kịch bản sách thành phim tập và xuất bản video 4K.
            </p>
          </div>

          {/* Header Action Buttons */}
          <div className="flex items-center gap-3 flex-wrap">
            <button
              onClick={loadCustomers}
              disabled={isLoading}
              className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-bold text-slate-200 transition-all"
              title="Đồng bộ lại từ cơ sở dữ liệu Firestore"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-amber-400' : ''}`} />
              <span>Đồng Bộ Firestore</span>
            </button>

            <button
              onClick={handleExportCSV}
              className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-bold text-slate-200 transition-all"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span>Xuất Báo Cáo CSV</span>
            </button>

            <button
              onClick={() => setIsAddModalOpen(true)}
              className="flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/20 transition-all transform hover:scale-[1.02]"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>Cấp Tài Khoản Mới</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-3 sm:gap-4">
        <div className="bg-slate-900/80 border border-slate-800/80 rounded-2xl p-4 shadow-lg flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-[11px] font-semibold">
            <span>Tổng Khách Hàng</span>
            <Users className="w-4 h-4 text-purple-400" />
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-white">{stats.total}</span>
            <span className="text-[10px] text-purple-400 ml-1.5 font-medium">Tài khoản</span>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800/80 rounded-2xl p-4 shadow-lg flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-[11px] font-semibold">
            <span>Đang Hoạt Động</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-emerald-400">{stats.active}</span>
            <span className="text-[10px] text-slate-400 ml-1.5">
              ({Math.round((stats.active / (stats.total || 1)) * 100)}%)
            </span>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800/80 rounded-2xl p-4 shadow-lg flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-[11px] font-semibold">
            <span>Video Đã Render</span>
            <Film className="w-4 h-4 text-amber-400" />
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-amber-400">{stats.totalVideos}</span>
            <span className="text-[10px] text-amber-300 ml-1.5">Tập phim 4K/HD</span>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800/80 rounded-2xl p-4 shadow-lg flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-[11px] font-semibold">
            <span>Gói Trả Phí (Paid)</span>
            <Crown className="w-4 h-4 text-yellow-400" />
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-yellow-400">{stats.paidTiers}</span>
            <span className="text-[10px] text-slate-400 ml-1.5 font-medium">VIP/Pro</span>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800/80 rounded-2xl p-4 shadow-lg flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-[11px] font-semibold">
            <span>Lưu Trữ Cloud</span>
            <HardDrive className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-cyan-400">{stats.totalStorage}</span>
            <span className="text-[10px] text-cyan-300 ml-1.5">GB</span>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800/80 rounded-2xl p-4 shadow-lg flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-[11px] font-semibold">
            <span>Điểm G-Coin</span>
            <Coins className="w-4 h-4 text-rose-400" />
          </div>
          <div className="mt-3">
            <span className="text-xl font-black text-rose-400">{stats.totalPoints.toLocaleString()}</span>
            <span className="text-[10px] text-rose-300 ml-1.5">Lưu hành</span>
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
          {/* Search box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Tìm theo tên khách hàng, email, số điện thoại, công ty hoặc kênh..."
              className="w-full bg-slate-950 border border-slate-800 rounded-2xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 text-xs"
              >
                ✕
              </button>
            )}
          </div>

          {/* Dropdown Filters */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Tier Filter */}
            <select
              value={tierFilter}
              onChange={(e) => setTierFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-2xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-amber-500"
            >
              <option value="all">Tất cả gói cước</option>
              <option value="Enterprise 4K">Enterprise 4K (Doanh Nghiệp)</option>
              <option value="Studio VIP">Studio VIP (Xưởng Phim)</option>
              <option value="Creator Pro">Creator Pro (Nhà Sáng Tạo)</option>
              <option value="Free">Gói Miễn Phí (Free)</option>
            </select>

            {/* Status Filter */}
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-2xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-amber-500"
            >
              <option value="all">Tất cả trạng thái</option>
              <option value="active">Đang hoạt động (Active)</option>
              <option value="trial">Dùng thử (Trial)</option>
              <option value="suspended">Tạm khóa (Suspended)</option>
              <option value="pending">Chờ kích hoạt (Pending)</option>
            </select>

            {/* Role Filter */}
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-2xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-amber-500"
            >
              <option value="all">Tất cả vai trò</option>
              <option value="director">Tổng Đạo Diễn (Director)</option>
              <option value="filmmaker">Nhà Làm Phim (Filmmaker)</option>
              <option value="user">Khách Hàng (User)</option>
              <option value="admin">Quản Trị Viên (Admin)</option>
            </select>

            {/* Sort by */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-slate-950 border border-slate-800 rounded-2xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-amber-500"
            >
              <option value="recent">Mới tham gia nhất</option>
              <option value="renders">Render nhiều video nhất</option>
              <option value="points">Nhiều G-Coin nhất</option>
              <option value="name">Tên A-Z</option>
            </select>
          </div>
        </div>

        <div className="flex items-center justify-between text-xs text-slate-400 pt-1 border-t border-slate-800/60">
          <span>
            Tìm thấy: <strong className="text-white font-bold">{filteredCustomers.length}</strong> / {customers.length} khách hàng
          </span>
          <div className="flex items-center gap-3 text-[11px]">
            <span className="flex items-center gap-1.5 text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              Cơ sở dữ liệu: Firestore Cloud Live Sync
            </span>
          </div>
        </div>
      </div>

      {/* Customer Accounts Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-bold uppercase tracking-wider text-[11px]">
                <th className="py-4 px-5">Khách Hàng & Liên Hệ</th>
                <th className="py-4 px-4">Gói Cước & Quota Video</th>
                <th className="py-4 px-4">Tiến Độ Sản Xuất</th>
                <th className="py-4 px-4">Điểm G-Coin</th>
                <th className="py-4 px-4">Trạng Thái</th>
                <th className="py-4 px-4">Hoạt Động</th>
                <th className="py-4 px-5 text-right">Thao Tác Quản Trị</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredCustomers.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    <Users className="w-10 h-10 text-slate-600 mx-auto mb-2" />
                    <p className="font-semibold text-slate-300">Không tìm thấy khách hàng nào phù hợp bộ lọc</p>
                    <p className="text-[11px] text-slate-500 mt-1">Hãy thử xóa bộ lọc hoặc đổi từ khóa tìm kiếm</p>
                  </td>
                </tr>
              ) : (
                filteredCustomers.map((cust) => {
                  const quotaPercent = Math.min(
                    100,
                    Math.round(((cust.videoRendersUsed || 0) / (cust.videoRenderQuota || 1)) * 100)
                  );
                  const isSuspended = cust.status === 'suspended';

                  return (
                    <tr
                      key={cust.id}
                      className={`hover:bg-slate-800/40 transition-colors ${
                        isSuspended ? 'opacity-60 bg-red-950/10' : ''
                      }`}
                    >
                      {/* Customer Info */}
                      <td className="py-4 px-5">
                        <div className="flex items-center gap-3">
                          <img
                            src={cust.photoURL || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'}
                            alt={cust.displayName}
                            className="w-10 h-10 rounded-full object-cover border border-slate-700 shadow-sm"
                          />
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-slate-100 text-xs sm:text-sm">
                                {cust.displayName}
                              </span>
                              {cust.role === 'admin' && (
                                <span className="text-[10px] px-1.5 py-0.2 rounded font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                                  ADMIN
                                </span>
                              )}
                              {cust.role === 'director' && (
                                <span className="text-[10px] px-1.5 py-0.2 rounded font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                                  ĐẠO DIỄN
                                </span>
                              )}
                            </div>
                            <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                              <Mail className="w-3 h-3 text-slate-500" />
                              <span className="font-mono">{cust.email}</span>
                            </div>
                            {cust.company && (
                              <div className="text-[11px] text-slate-500 flex items-center gap-1.5 mt-0.5">
                                <Building className="w-3 h-3 text-slate-600" />
                                <span>{cust.company}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Plan & Quota */}
                      <td className="py-4 px-4">
                        <div className="space-y-1">
                          <span
                            className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                              cust.subscriptionTier === 'Enterprise 4K'
                                ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                                : cust.subscriptionTier === 'Studio VIP'
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                                : cust.subscriptionTier === 'Creator Pro'
                                ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40'
                                : 'bg-slate-800 text-slate-400 border border-slate-700'
                            }`}
                          >
                            <Crown className="w-3 h-3" />
                            {cust.subscriptionTier}
                          </span>
                          <div className="text-[11px] text-slate-400">
                            Hạn mức: <strong className="text-white">{cust.videoRenderQuota}</strong> video 4K/tháng
                          </div>
                        </div>
                      </td>

                      {/* Video Render Usage */}
                      <td className="py-4 px-4">
                        <div className="space-y-1.5 w-36">
                          <div className="flex justify-between text-[11px]">
                            <span className="text-slate-300 font-semibold">
                              {cust.videoRendersUsed} / {cust.videoRenderQuota} video
                            </span>
                            <span
                              className={`font-mono font-bold ${
                                quotaPercent >= 90
                                  ? 'text-rose-400'
                                  : quotaPercent >= 60
                                  ? 'text-amber-400'
                                  : 'text-emerald-400'
                              }`}
                            >
                              {quotaPercent}%
                            </span>
                          </div>
                          <div className="w-full h-1.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                            <div
                              className={`h-full rounded-full transition-all duration-500 ${
                                quotaPercent >= 90
                                  ? 'bg-rose-500'
                                  : quotaPercent >= 60
                                  ? 'bg-amber-500'
                                  : 'bg-emerald-500'
                              }`}
                              style={{ width: `${quotaPercent}%` }}
                            />
                          </div>
                          <div className="text-[10px] text-slate-500 flex items-center gap-1">
                            <HardDrive className="w-2.5 h-2.5" />
                            <span>{cust.storageUsedGB} GB Cloud</span>
                          </div>
                        </div>
                      </td>

                      {/* Points */}
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-amber-300 bg-amber-500/10 px-2.5 py-1 rounded-xl border border-amber-500/20 w-fit">
                          <Coins className="w-3.5 h-3.5 text-yellow-400" />
                          <span>{cust.gitaPoints.toLocaleString()}</span>
                        </div>
                      </td>

                      {/* Status */}
                      <td className="py-4 px-4">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            cust.status === 'active'
                              ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                              : cust.status === 'trial'
                              ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                              : cust.status === 'suspended'
                              ? 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                              : 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                          }`}
                        >
                          {cust.status === 'active' && <CheckCircle2 className="w-3 h-3 text-emerald-400" />}
                          {cust.status === 'trial' && <Sparkles className="w-3 h-3 text-cyan-400" />}
                          {cust.status === 'suspended' && <Ban className="w-3 h-3 text-rose-400" />}
                          {cust.status === 'pending' && <Clock className="w-3 h-3 text-amber-400" />}
                          <span>
                            {cust.status === 'active'
                              ? 'Hoạt động'
                              : cust.status === 'trial'
                              ? 'Dùng thử'
                              : cust.status === 'suspended'
                              ? 'Tạm khóa'
                              : 'Chờ duyệt'}
                          </span>
                        </span>
                      </td>

                      {/* Last Active */}
                      <td className="py-4 px-4 text-slate-400 text-[11px]">
                        <div>{cust.lastActiveAt || 'Vừa xong'}</div>
                        <div className="text-[10px] text-slate-500">
                          Đăng ký: {new Date(cust.createdAt).toLocaleDateString('vi-VN')}
                        </div>
                      </td>

                      {/* Action Buttons */}
                      <td className="py-4 px-5 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Quick Quota +10 */}
                          <button
                            onClick={() => handleAdjustQuota(cust, 10)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                            title="Cấp thêm +10 lượt render video"
                          >
                            <Plus className="w-3.5 h-3.5 text-emerald-400" />
                          </button>

                          {/* Quick Points +1,000 */}
                          <button
                            onClick={() => handleGrantPoints(cust, 1000)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                            title="Tặng +1,000 G-Coin"
                          >
                            <Coins className="w-3.5 h-3.5 text-amber-400" />
                          </button>

                          {/* Toggle Lock / Unlock */}
                          <button
                            onClick={() => handleToggleStatus(cust)}
                            className={`p-1.5 rounded-lg transition-colors ${
                              isSuspended
                                ? 'bg-emerald-900/50 hover:bg-emerald-800 text-emerald-300'
                                : 'bg-rose-900/40 hover:bg-rose-800 text-rose-300'
                            }`}
                            title={isSuspended ? 'Mở khóa tài khoản' : 'Tạm khóa tài khoản'}
                          >
                            {isSuspended ? (
                              <UserCheck className="w-3.5 h-3.5" />
                            ) : (
                              <UserX className="w-3.5 h-3.5" />
                            )}
                          </button>

                          {/* Edit Details */}
                          <button
                            onClick={() => setEditingCustomer(cust)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                            title="Chỉnh sửa thông tin chi tiết"
                          >
                            <Edit3 className="w-3.5 h-3.5 text-cyan-400" />
                          </button>

                          {/* View Profile Drawer */}
                          <button
                            onClick={() => {
                              setSelectedCustomer(cust);
                              setIsDetailModalOpen(true);
                            }}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                            title="Xem chi tiết & dự án phim"
                          >
                            <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Customer Detail Modal */}
      {isDetailModalOpen && selectedCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in">
          <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="p-6 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src={selectedCustomer.photoURL}
                  alt={selectedCustomer.displayName}
                  className="w-12 h-12 rounded-full object-cover border-2 border-amber-500 shadow-md"
                />
                <div>
                  <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                    {selectedCustomer.displayName}
                    <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      {selectedCustomer.subscriptionTier}
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400">{selectedCustomer.email}</p>
                </div>
              </div>
              <button
                onClick={() => setIsDetailModalOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 overflow-y-auto space-y-5 flex-1 text-xs">
              {/* Account Quick Stats */}
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 text-center">
                  <span className="text-[10px] text-slate-500 uppercase font-bold">Số Video Đã Render</span>
                  <div className="text-xl font-black text-amber-400 mt-1">
                    {selectedCustomer.videoRendersUsed} / {selectedCustomer.videoRenderQuota}
                  </div>
                </div>
                <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 text-center">
                  <span className="text-[10px] text-slate-500 uppercase font-bold">Lưu Trữ Đã Dùng</span>
                  <div className="text-xl font-black text-cyan-400 mt-1">
                    {selectedCustomer.storageUsedGB} GB
                  </div>
                </div>
                <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 text-center">
                  <span className="text-[10px] text-slate-500 uppercase font-bold">Điểm Thưởng G-Coin</span>
                  <div className="text-xl font-black text-yellow-400 mt-1 font-mono">
                    {selectedCustomer.gitaPoints.toLocaleString()}
                  </div>
                </div>
              </div>

              {/* Information Rows */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
                <h4 className="font-bold text-slate-200 text-xs border-b border-slate-800 pb-2">
                  Hồ Sơ Doanh Nghiệp & Liên Hệ
                </h4>
                <div className="grid grid-cols-2 gap-3 text-slate-300">
                  <div>
                    <span className="text-slate-500 block text-[10px]">Đơn Vị / Studio:</span>
                    <strong className="text-white">{selectedCustomer.company || 'Cá nhân'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">Số Điện Thoại:</span>
                    <strong className="text-white">{selectedCustomer.phone || 'Chưa cung cấp'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">Vai Trò Phân Quyền:</span>
                    <strong className="text-white capitalize">{selectedCustomer.role}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">Trạng Thái:</span>
                    <span
                      className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                        selectedCustomer.status === 'active'
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : 'bg-rose-500/20 text-rose-300'
                      }`}
                    >
                      {selectedCustomer.status === 'active' ? 'Hoạt động' : 'Tạm khóa'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">Ngày Đăng Ký:</span>
                    <span>{new Date(selectedCustomer.createdAt).toLocaleString('vi-VN')}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">Lần Hoạt Động Cuối:</span>
                    <span>{selectedCustomer.lastActiveAt || 'Vừa xong'}</span>
                  </div>
                </div>
              </div>

              {/* Capabilities & Access */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
                <h4 className="font-bold text-slate-200 text-xs">Quyền Hạn Sản Xuất Của Gói:</h4>
                <ul className="space-y-1.5 text-slate-400 text-[11px]">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Render video chuẩn điện ảnh 4K Ultra HD & 1080p 60fps</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Lồng tiếng AI tiếng Việt cao cấp V-TTS (Gemini 3.8 Flash TTS Engine)</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Tạo & chỉnh sửa ảnh nhân vật nhất quán (gemini-nano-banana-2.1)</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Sinh nhạc nền tự động (lyria-3-clip-preview) & Nhận diện giọng nói</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between">
              <button
                onClick={() => {
                  setEditingCustomer(selectedCustomer);
                  setIsDetailModalOpen(false);
                }}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition-colors"
              >
                <Edit3 className="w-3.5 h-3.5 text-cyan-400" />
                <span>Chỉnh Sửa Gói & Quota</span>
              </button>

              <button
                onClick={() => setIsDetailModalOpen(false)}
                className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-colors"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Customer / Quota Modal */}
      {editingCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden">
            <div className="p-6 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
              <h3 className="font-extrabold text-white text-sm flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-amber-400" />
                Chỉnh Sửa Tài Khoản: {editingCustomer.displayName}
              </h3>
              <button
                onClick={() => setEditingCustomer(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-slate-400 font-semibold">Tên Khách Hàng</label>
                <input
                  type="text"
                  value={editingCustomer.displayName}
                  onChange={(e) =>
                    setEditingCustomer({ ...editingCustomer, displayName: e.target.value })
                  }
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-400 font-semibold">Gói Cước Sử Dụng</label>
                  <select
                    value={editingCustomer.subscriptionTier}
                    onChange={(e) =>
                      setEditingCustomer({
                        ...editingCustomer,
                        subscriptionTier: e.target.value as any,
                      })
                    }
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="Free">Free (Miễn Phí)</option>
                    <option value="Creator Pro">Creator Pro</option>
                    <option value="Studio VIP">Studio VIP</option>
                    <option value="Enterprise 4K">Enterprise 4K</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-400 font-semibold">Trạng Thái</label>
                  <select
                    value={editingCustomer.status}
                    onChange={(e) =>
                      setEditingCustomer({ ...editingCustomer, status: e.target.value as any })
                    }
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="active">Hoạt động (Active)</option>
                    <option value="trial">Dùng thử (Trial)</option>
                    <option value="suspended">Tạm khóa (Suspended)</option>
                    <option value="pending">Chờ duyệt (Pending)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-400 font-semibold">Quota Render Video (tháng)</label>
                  <input
                    type="number"
                    value={editingCustomer.videoRenderQuota}
                    onChange={(e) =>
                      setEditingCustomer({
                        ...editingCustomer,
                        videoRenderQuota: Number(e.target.value) || 0,
                      })
                    }
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-400 font-semibold">Điểm Thưởng G-Coin</label>
                  <input
                    type="number"
                    value={editingCustomer.gitaPoints}
                    onChange={(e) =>
                      setEditingCustomer({
                        ...editingCustomer,
                        gitaPoints: Number(e.target.value) || 0,
                      })
                    }
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-400 font-semibold">Công Ty / Đơn Vị Sản Xuất</label>
                <input
                  type="text"
                  value={editingCustomer.company || ''}
                  onChange={(e) =>
                    setEditingCustomer({ ...editingCustomer, company: e.target.value })
                  }
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-400 font-semibold">Số Điện Thoại</label>
                <input
                  type="text"
                  value={editingCustomer.phone || ''}
                  onChange={(e) =>
                    setEditingCustomer({ ...editingCustomer, phone: e.target.value })
                  }
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-end gap-3">
              <button
                onClick={() => setEditingCustomer(null)}
                className="px-4 py-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 font-semibold"
              >
                Hủy
              </button>
              <button
                onClick={handleSaveCustomerEdits}
                className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs shadow-lg transition-all"
              >
                <Save className="w-4 h-4" />
                <span>Lưu Cập Nhật</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add New Customer Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden">
            <div className="p-6 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
              <h3 className="font-extrabold text-white text-sm flex items-center gap-2">
                <Plus className="w-4 h-4 text-amber-400" />
                Cấp Tài Khoản Mới Cho Khách Hàng Tạo Video
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateCustomer} className="p-6 space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-slate-400 font-semibold">Họ và Tên Khách Hàng *</label>
                <input
                  type="text"
                  required
                  placeholder="Ví dụ: Hoàng Tuấn Kiệt"
                  value={newCustomer.displayName}
                  onChange={(e) =>
                    setNewCustomer({ ...newCustomer, displayName: e.target.value })
                  }
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-400 font-semibold">Email Đăng Ký *</label>
                <input
                  type="email"
                  required
                  placeholder="tuankiet@studio.vn"
                  value={newCustomer.email}
                  onChange={(e) =>
                    setNewCustomer({ ...newCustomer, email: e.target.value })
                  }
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-400 font-semibold">Số Điện Thoại</label>
                  <input
                    type="text"
                    placeholder="0912 345 678"
                    value={newCustomer.phone}
                    onChange={(e) =>
                      setNewCustomer({ ...newCustomer, phone: e.target.value })
                    }
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-400 font-semibold">Đơn Vị / Kênh Video</label>
                  <input
                    type="text"
                    placeholder="Kênh Phim AI Đột Phá"
                    value={newCustomer.company}
                    onChange={(e) =>
                      setNewCustomer({ ...newCustomer, company: e.target.value })
                    }
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-400 font-semibold">Gói Cước Khởi Tạo</label>
                  <select
                    value={newCustomer.subscriptionTier}
                    onChange={(e) =>
                      setNewCustomer({
                        ...newCustomer,
                        subscriptionTier: e.target.value as any,
                        videoRenderQuota:
                          e.target.value === 'Enterprise 4K'
                            ? 100
                            : e.target.value === 'Studio VIP'
                            ? 50
                            : e.target.value === 'Creator Pro'
                            ? 25
                            : 5,
                      })
                    }
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="Free">Gói Miễn Phí (5 video/tháng)</option>
                    <option value="Creator Pro">Creator Pro (25 video/tháng)</option>
                    <option value="Studio VIP">Studio VIP (50 video/tháng)</option>
                    <option value="Enterprise 4K">Enterprise 4K (100 video/tháng)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-400 font-semibold">Vai Trò Hệ Thống</label>
                  <select
                    value={newCustomer.role}
                    onChange={(e) =>
                      setNewCustomer({ ...newCustomer, role: e.target.value as any })
                    }
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="filmmaker">Nhà Làm Phim (Filmmaker)</option>
                    <option value="director">Tổng Đạo Diễn (Director)</option>
                    <option value="user">Người Dùng Cơ Bản (User)</option>
                    <option value="admin">Quản Trị Viên (Admin)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-400 font-semibold">Hạn Mức Render Video</label>
                  <input
                    type="number"
                    value={newCustomer.videoRenderQuota}
                    onChange={(e) =>
                      setNewCustomer({
                        ...newCustomer,
                        videoRenderQuota: Number(e.target.value) || 0,
                      })
                    }
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-400 font-semibold">Tặng Điểm Ban Đầu (G-Coin)</label>
                  <input
                    type="number"
                    value={newCustomer.gitaPoints}
                    onChange={(e) =>
                      setNewCustomer({
                        ...newCustomer,
                        gitaPoints: Number(e.target.value) || 0,
                      })
                    }
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="p-4 border-t border-slate-800 bg-slate-950/80 -mx-6 -mb-6 mt-6 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 font-semibold"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black text-xs shadow-lg transition-all"
                >
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>Kích Hoạt Tài Khoản Khách Hàng</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
