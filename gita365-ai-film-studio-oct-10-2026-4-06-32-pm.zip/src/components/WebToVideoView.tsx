import React, { useState } from 'react';
import {
  Globe,
  Sparkles,
  Layers,
  ArrowRight,
  Video,
  FileText,
  Clock,
  CheckCircle2,
  ExternalLink,
  Laptop,
} from 'lucide-react';
import { FilmProject } from '../types';

interface WebToVideoViewProps {
  project: FilmProject;
  onNavigateToStudio: () => void;
}

export const WebToVideoView: React.FC<WebToVideoViewProps> = ({
  project,
  onNavigateToStudio,
}) => {
  const [url, setUrl] = useState('https://gita365.vn/academy/quy-trinh-san-xuat-phim-ai-chuyen-nghiep');
  const [videoTopic, setVideoTopic] = useState('Quy Trình 5 Bước Tạo Phim AI Điện Ảnh Chuẩn 4K Cho Doanh Nghiệp');
  const [rawText, setRawText] = useState(
    `Hướng dẫn đầy đủ cách ứng dụng AI để chuyển thể sách thành phim bộ:
Bước 1: Phân tích cấu trúc kịch bản và chia chương hồi.
Bước 2: Thiết kế hồ sơ nhân vật nhất quán và khóa Seed khuôn mặt.
Bước 3: Lồng tiếng AI đa ngôn ngữ với sắc thái truyền cảm.
Bước 4: Render video 4K siêu tốc và chèn phụ đề karaoke.
Bước 5: Tự động lập lịch phát hành lên YouTube, TikTok và Facebook.`
  );
  const [isProcessing, setIsProcessing] = useState(false);
  const [tutorialResult, setTutorialResult] = useState<any>(null);

  const handleConvertWebToVideo = async () => {
    setIsProcessing(true);
    try {
      const response = await fetch('/api/web-to-video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url,
          videoTopic,
          rawText,
        }),
      });

      const data = await response.json();
      setTutorialResult(data);
    } catch (err) {
      console.error('Lỗi chuyển đổi web sang video:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-slate-900 to-teal-950/40 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 rounded-full bg-teal-500/10 blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/15 border border-teal-500/30 text-teal-300 text-xs font-bold uppercase tracking-wider">
              <Globe className="w-3.5 h-3.5" /> GITA365 Web-to-Video Engine
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight">
              Chuyển Đổi Trang Web & Tài Liệu Thành Video Hướng Dẫn
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              Nhập đường link website, bài viết blog hoặc tài liệu đào tạo nội bộ. AI sẽ tự động phân tích
              và dựng thành kịch bản video hướng dẫn (Explainer / Tutorial) chuyên nghiệp, đồ họa sinh động.
            </p>
          </div>
        </div>
      </div>

      {/* Input Section & Result Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Input Form (5 cols) */}
        <div className="lg:col-span-5 space-y-5">
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-4">
            <h2 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
              <ExternalLink className="w-4 h-4 text-teal-400" /> Nguồn Liên Kết / Tài Liệu Web
            </h2>

            <div>
              <label className="text-xs font-semibold text-slate-300 mb-1 block">
                Đường dẫn liên kết (URL):
              </label>
              <input
                type="url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://gita365.com/bai-viet..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-teal-500 font-mono"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 mb-1 block">
                Chủ đề video hướng dẫn:
              </label>
              <input
                type="text"
                value={videoTopic}
                onChange={(e) => setVideoTopic(e.target.value)}
                placeholder="Ví dụ: Hướng dẫn sử dụng hệ thống GITA..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-teal-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 mb-1 block">
                Nội dung trích xuất từ bài viết:
              </label>
              <textarea
                rows={6}
                value={rawText}
                onChange={(e) => setRawText(e.target.value)}
                placeholder="Dán nội dung chi tiết của trang web..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-200 focus:outline-none focus:border-teal-500 font-mono leading-relaxed"
              />
            </div>

            <button
              onClick={handleConvertWebToVideo}
              disabled={isProcessing}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-400 hover:from-teal-400 hover:to-emerald-300 text-slate-950 font-bold text-xs shadow-lg flex items-center justify-center gap-2 transition-all transform active:scale-95 disabled:opacity-50"
            >
              {isProcessing ? (
                <>
                  <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                  <span>AI Đang Phân Tích & Soạn Kịch Bản...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Tạo Video Hướng Dẫn Chuyên Nghiệp</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right: Storyboard Result (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <Laptop className="w-4 h-4 text-teal-400" /> Storyboard Video Hướng Dẫn Tự Động
              </h2>
              {tutorialResult && (
                <span className="text-xs text-teal-400 font-mono">
                  Ước tính: {tutorialResult.estimatedDuration || '8 phút'}
                </span>
              )}
            </div>

            {tutorialResult ? (
              <div className="space-y-4">
                <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
                  <span className="text-[10px] text-teal-400 uppercase font-bold tracking-wider block mb-1">
                    Tiêu Đề Video Xuất Bản:
                  </span>
                  <h3 className="text-base font-bold text-white">{tutorialResult.tutorialTitle}</h3>
                </div>

                <div className="space-y-3">
                  {(tutorialResult.steps || []).map((step: any, idx: number) => (
                    <div
                      key={idx}
                      className="bg-slate-950 p-4 rounded-2xl border border-slate-800/90 space-y-2.5 hover:border-slate-700 transition-all"
                    >
                      <div className="flex items-center justify-between">
                        <span className="px-2.5 py-0.5 rounded-full bg-teal-500/15 text-teal-300 font-bold text-xs">
                          {step.title}
                        </span>
                        <span className="text-[10px] text-slate-500 font-mono">Phân cảnh #{idx + 1}</span>
                      </div>

                      <div className="text-xs text-slate-200 bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                        <span className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                          🎙️ Lời Thuyết Minh Giọng Đọc AI:
                        </span>
                        "{step.narration}"
                      </div>

                      <div className="text-[11px] text-slate-400 font-mono bg-slate-900/40 p-2.5 rounded-xl border border-slate-800/60">
                        <span className="text-teal-400 font-semibold">🖥️ Khung hình trực quan: </span>
                        {step.visualPrompt}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    onClick={onNavigateToStudio}
                    className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-bold text-xs shadow-lg transition-all transform hover:scale-105"
                  >
                    <Video className="w-4 h-4" />
                    <span>Đưa Vào Xưởng Dựng Để Render Video</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center py-12 space-y-3">
                <Globe className="w-10 h-10 text-slate-700 mx-auto" />
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  Nhập link website hoặc tài liệu đào tạo ở cột bên trái và nhấn nút "Tạo Video Hướng Dẫn" để AI xây dựng phân cảnh trực quan.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
