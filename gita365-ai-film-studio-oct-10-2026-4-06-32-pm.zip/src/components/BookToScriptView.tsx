import React, { useState } from 'react';
import {
  BookOpen,
  Sparkles,
  Clapperboard,
  Clock,
  Film,
  Layers,
  Copy,
  Check,
  Play,
  Volume2,
  ChevronRight,
  Plus,
  Trash2,
  Edit3,
  Wand2,
  Video,
  FileText,
  CheckCircle2,
  X,
  Save,
  Edit2,
} from 'lucide-react';
import { FilmProject, Episode, Scene, DialogueItem } from '../types';
import { SAMPLE_BOOKS } from '../data/initialData';
import { speakText } from '../utils/audioSynth';
import { MicrophoneTranscriber } from './MicrophoneTranscriber';

interface BookToScriptViewProps {
  project: FilmProject;
  onUpdateProject: (updated: FilmProject) => void;
  onNavigateToStudio: () => void;
}

export const BookToScriptView: React.FC<BookToScriptViewProps> = ({
  project,
  onUpdateProject,
  onNavigateToStudio,
}) => {
  const [bookTitle, setBookTitle] = useState(project.title);
  const [author, setAuthor] = useState(project.author);
  const [bookContent, setBookContent] = useState(project.originalBook);
  const [episodeDuration, setEpisodeDuration] = useState<string>(
    String(project.episodeDurationMinutes || 15)
  );
  const [episodeCount, setEpisodeCount] = useState<number>(project.episodeCount || 3);
  const [genre, setGenre] = useState(project.genre);
  const [visualStyle, setVisualStyle] = useState(project.visualStyle);
  const [isAdapting, setIsAdapting] = useState(false);
  const [activeEpisodeIdx, setActiveEpisodeIdx] = useState(0);
  const [copiedPromptId, setCopiedPromptId] = useState<string | null>(null);

  // Scene editing and auto-save state
  const [editingScene, setEditingScene] = useState<{
    episodeIdx: number;
    actNumber: number;
    scene: Scene;
  } | null>(null);
  const [editDialogueList, setEditDialogueList] = useState<DialogueItem[]>([]);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Load a sample book
  const handleSelectSample = (sample: typeof SAMPLE_BOOKS[0]) => {
    setBookTitle(sample.title);
    setAuthor(sample.author);
    setGenre(sample.genre);
    setBookContent(sample.content);
  };

  // Call Server-side API to adapt book into multi-part screenplay
  const handleAdaptScript = async () => {
    setIsAdapting(true);
    try {
      const response = await fetch('/api/script/adapt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bookTitle,
          author,
          bookContent,
          genre,
          episodeCount,
          episodeDuration,
          visualStyle,
        }),
      });

      const data = await response.json();
      if (data.episodes && data.episodes.length > 0) {
        // Map new episodes into project
        const formattedEpisodes: Episode[] = data.episodes.map((ep: any, epIdx: number) => ({
          id: `ep-${Date.now()}-${epIdx}`,
          episodeNumber: ep.episodeNumber || epIdx + 1,
          title: ep.title || `Tập ${epIdx + 1}`,
          durationMinutes: ep.durationMinutes || Number(episodeDuration) || 15,
          synopsis: ep.synopsis || 'Tập phim chuyển thể từ nguyên tác.',
          thumbnailUrl: project.episodes[epIdx]?.thumbnailUrl || 'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=800&auto=format&fit=crop&q=80',
          acts: (ep.acts || []).map((act: any, actIdx: number) => ({
            actNumber: act.actNumber || actIdx + 1,
            name: act.name || `Hồi ${actIdx + 1}`,
            scenes: (act.scenes || []).map((sc: any, scIdx: number) => ({
              id: `sc-${Date.now()}-${scIdx}`,
              sceneNumber: sc.sceneNumber || scIdx + 1,
              title: sc.title || `Phân cảnh ${scIdx + 1}`,
              location: sc.location || 'Địa điểm quay',
              timeOfDay: sc.timeOfDay || 'Chiều tà',
              lighting: sc.lighting || 'Ánh sáng điện ảnh',
              cameraAngle: sc.cameraAngle || 'Medium Shot 50mm',
              description: sc.description || 'Mô tả phân cảnh',
              visualPrompt: sc.visualPrompt || `Cinematic film still, ${visualStyle}`,
              imageUrl: project.episodes[0]?.acts[0]?.scenes[scIdx % 3]?.imageUrl || 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800&auto=format&fit=crop&q=80',
              dialogue: (sc.dialogue || []).map((d: any, dIdx: number) => ({
                id: `diag-${Date.now()}-${dIdx}`,
                speaker: d.speaker || 'Nhân vật',
                emotion: d.emotion || 'Trầm ngâm',
                text: d.text || 'Lời thoại',
                durationSeconds: 5,
              })),
              sfx: sc.sfx || 'Tiếng gió rít, tiếng sấm nhẹ',
              bgmMood: sc.bgmMood || 'Cinematic Tension',
              durationSeconds: sc.durationSeconds || 15,
              transition: 'fade',
            })),
          })),
        }));

        const updated: FilmProject = {
          ...project,
          title: bookTitle ? `[Phim Bộ] ${bookTitle}` : project.title,
          originalBook: bookTitle,
          author: author,
          genre: genre,
          visualStyle: visualStyle,
          episodeCount: formattedEpisodes.length,
          episodeDurationMinutes: Number(episodeDuration) || 15,
          episodes: formattedEpisodes,
          updatedAt: new Date().toISOString(),
        };

        onUpdateProject(updated);
        setActiveEpisodeIdx(0);
      }
    } catch (err) {
      console.error('Lỗi chuyển thể:', err);
    } finally {
      setIsAdapting(false);
    }
  };

  const handleStartEditScene = (episodeIdx: number, actNumber: number, scene: Scene) => {
    setEditingScene({
      episodeIdx,
      actNumber,
      scene: { ...scene },
    });
    setEditDialogueList([...(scene.dialogue || [])]);
  };

  const handleSaveEditedScene = () => {
    if (!editingScene) return;
    const { episodeIdx, actNumber, scene } = editingScene;

    const updatedScene: Scene = {
      ...scene,
      dialogue: editDialogueList,
    };

    const updatedEpisodes = project.episodes.map((ep, eIdx) => {
      if (eIdx !== episodeIdx) return ep;
      return {
        ...ep,
        acts: ep.acts.map((act) => {
          if (act.actNumber !== actNumber) return act;
          return {
            ...act,
            scenes: act.scenes.map((sc) => (sc.id === updatedScene.id ? updatedScene : sc)),
          };
        }),
      };
    });

    const updatedProject: FilmProject = {
      ...project,
      episodes: updatedEpisodes,
      updatedAt: new Date().toISOString(),
    };

    onUpdateProject(updatedProject);
    setEditingScene(null);
    showToast(`Đã lưu và tự động cập nhật bản nháp phân cảnh #${updatedScene.sceneNumber}!`);
  };

  const handleAddScene = (episodeIdx: number, actNumber: number) => {
    const targetEpisode = project.episodes[episodeIdx];
    if (!targetEpisode) return;

    const allScenes = targetEpisode.acts.flatMap((a) => a.scenes);
    const nextSceneNumber = allScenes.length + 1;

    const newScene: Scene = {
      id: `sc-custom-${Date.now()}`,
      sceneNumber: nextSceneNumber,
      title: `Phân cảnh mới #${nextSceneNumber}`,
      location: 'Phòng làm việc hiện đại GITA365',
      timeOfDay: 'Sáng sớm',
      lighting: 'Ánh sáng tự nhiên qua cửa kính lớn, rim light điện ảnh',
      cameraAngle: 'Medium Close-Up 50mm',
      description: 'Nhân vật bước vào khung hình với thần thái tập trung, chuẩn bị mở đầu câu chuyện.',
      visualPrompt: `cinematic film still, character entering modern minimalist office room, golden morning rim light, 35mm photograph, 8k`,
      imageUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800&auto=format&fit=crop&q=80',
      dialogue: [
        {
          id: `diag-${Date.now()}`,
          speaker: project.characters[0]?.name || 'Quang GITA',
          emotion: 'Điềm tĩnh',
          text: 'Mọi hành trình vĩ đại đều bắt đầu từ một quyết định dứt khoát.',
          durationSeconds: 5,
        },
      ],
      sfx: 'Tiếng bước chân chắc nịch, tiếng lật trang sách nhẹ',
      bgmMood: 'Inspirational Ambient',
      durationSeconds: 15,
      transition: 'fade',
    };

    const updatedEpisodes = project.episodes.map((ep, eIdx) => {
      if (eIdx !== episodeIdx) return ep;
      return {
        ...ep,
        acts: ep.acts.map((act) => {
          if (act.actNumber !== actNumber) return act;
          return {
            ...act,
            scenes: [...act.scenes, newScene],
          };
        }),
      };
    });

    const updatedProject: FilmProject = {
      ...project,
      episodes: updatedEpisodes,
      updatedAt: new Date().toISOString(),
    };

    onUpdateProject(updatedProject);
    showToast(`Đã thêm Phân cảnh #${nextSceneNumber} và tự động lưu nháp!`);
  };

  const handleDeleteScene = (episodeIdx: number, actNumber: number, sceneId: string) => {
    if (!window.confirm('Bạn có chắc chắn muốn xóa phân cảnh này?')) return;

    const updatedEpisodes = project.episodes.map((ep, eIdx) => {
      if (eIdx !== episodeIdx) return ep;
      return {
        ...ep,
        acts: ep.acts.map((act) => {
          if (act.actNumber !== actNumber) return act;
          return {
            ...act,
            scenes: act.scenes.filter((sc) => sc.id !== sceneId),
          };
        }),
      };
    });

    const updatedProject: FilmProject = {
      ...project,
      episodes: updatedEpisodes,
      updatedAt: new Date().toISOString(),
    };

    onUpdateProject(updatedProject);
    showToast('Đã xóa phân cảnh và tự động cập nhật bản nháp!');
  };

  const handleCopyPrompt = (promptText: string, id: string) => {
    navigator.clipboard.writeText(promptText);
    setCopiedPromptId(id);
    setTimeout(() => setCopiedPromptId(null), 2000);
  };

  const currentEpisode = project.episodes[activeEpisodeIdx] || project.episodes[0];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Hero Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950/40 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5" /> GITA365 AI Screenplay Engine
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight">
              Biên Tập Kịch Bản Sách Thành Phim Bộ Điện Ảnh
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              Tự động phân tích tiểu thuyết, sách kinh doanh hoặc bài giảng thành cấu trúc kịch bản nhiều tập
              chuẩn điện ảnh 10 - 30 phút với phân cảnh, góc máy, ánh sáng, lời thoại và visual prompt nhất quán.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={onNavigateToStudio}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-all"
            >
              <Video className="w-4 h-4 text-amber-400" />
              <span>Chuyển Sang Xưởng Dựng</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Input Setup & Screenplay Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Book Manuscript & Config (4 cols) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-amber-400" /> Nạp Dữ Liệu Sách / Kịch Bản
              </h2>
              <span className="text-xs text-amber-400/80 font-mono">GITA Studio AI</span>
            </div>

            {/* Quick Sample Selector */}
            <div>
              <label className="text-xs font-semibold text-slate-400 mb-2 block">
                Chọn mẫu sách có sẵn để thử nghiệm nhanh:
              </label>
              <div className="grid grid-cols-1 gap-2">
                {SAMPLE_BOOKS.map((b) => (
                  <button
                    key={b.title}
                    type="button"
                    onClick={() => handleSelectSample(b)}
                    className="text-left px-3 py-2 rounded-xl bg-slate-950/80 hover:bg-slate-800/80 border border-slate-800/80 hover:border-amber-500/40 transition-all group"
                  >
                    <div className="text-xs font-bold text-slate-200 group-hover:text-amber-300 flex items-center justify-between">
                      <span>{b.title}</span>
                      <span className="text-[10px] text-slate-500 font-normal">{b.genre}</span>
                    </div>
                    <div className="text-[11px] text-slate-400 truncate mt-0.5">{b.author}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Book Title & Author */}
            <div className="space-y-3">
              <div>
                <label className="text-xs font-medium text-slate-300 mb-1 block">Tên cuốn sách / Dự án:</label>
                <input
                  type="text"
                  value={bookTitle}
                  onChange={(e) => setBookTitle(e.target.value)}
                  placeholder="Ví dụ: Hành Trình Về Phương Đông..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-slate-300 mb-1 block">Tác giả / Nguồn:</label>
                <input
                  type="text"
                  value={author}
                  onChange={(e) => setAuthor(e.target.value)}
                  placeholder="Ví dụ: Nguyên Phong / GITA365..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            {/* Textarea for Book chapters */}
            <div>
              <label className="text-xs font-medium text-slate-300 mb-1 block flex justify-between">
                <span>Nội dung sách / Chương cần chuyển thể:</span>
                <span className="text-slate-500 text-[10px]">{bookContent.length} ký tự</span>
              </label>
              <textarea
                rows={6}
                value={bookContent}
                onChange={(e) => setBookContent(e.target.value)}
                placeholder="Dán nội dung chương sách, văn bản tiểu thuyết hoặc dàn ý câu chuyện tại đây..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-200 focus:outline-none focus:border-amber-500 font-mono leading-relaxed resize-y"
              />
              <div className="mt-3">
                <MicrophoneTranscriber
                  label="Đọc Qua Micro Để Nhận Diện Kịch Bản (gemini-3.5-transcribe)"
                  onTranscriptionComplete={(text) =>
                    setBookContent((prev) => (prev ? prev + '\n\n' + text : text))
                  }
                />
              </div>
            </div>

            {/* Screenplay Parameters */}
            <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-800">
              <div>
                <label className="text-xs font-medium text-slate-300 mb-1 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-amber-400" /> Thời lượng mỗi tập:
                </label>
                <select
                  value={episodeDuration}
                  onChange={(e) => setEpisodeDuration(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                >
                  <option value="10">10 phút (Chuẩn ngắn)</option>
                  <option value="15">15 phút (Đề xuất)</option>
                  <option value="20">20 phút (Chuẩn tập)</option>
                  <option value="30">30 phút (Điện ảnh dài)</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-300 mb-1 flex items-center gap-1">
                  <Layers className="w-3.5 h-3.5 text-amber-400" /> Số tập chuyển thể:
                </label>
                <select
                  value={episodeCount}
                  onChange={(e) => setEpisodeCount(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                >
                  <option value={1}>1 tập (Phim ngắn/Pilot)</option>
                  <option value={2}>2 tập (Phần 1 & 2)</option>
                  <option value={3}>3 tập (Mini-series kinh điển)</option>
                  <option value={5}>5 tập (Series trọn bộ)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-slate-300 mb-1 block">Thể loại phim:</label>
                <select
                  value={genre}
                  onChange={(e) => setGenre(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                >
                  <option value="Điện ảnh Kỳ ảo & Tâm linh">Kỳ ảo & Tâm linh</option>
                  <option value="Kịch tính Giật gân">Kịch tính Giật gân</option>
                  <option value="Khoa học Viễn tưởng Tương lai">Sci-Fi Viễn tưởng</option>
                  <option value="Doanh nghiệp & Truyền cảm hứng">Doanh nghiệp & Bài học</option>
                  <option value="Lịch sử Hào hùng Dân tộc">Lịch sử Hào hùng</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-300 mb-1 block">Phong cách hình ảnh:</label>
                <select
                  value={visualStyle}
                  onChange={(e) => setVisualStyle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                >
                  <option value="Cinematic Hyper-Realistic 8K">8K Hyper-Realistic (Chân thực)</option>
                  <option value="Anime Makoto Shinkai Style">Anime Nghệ thuật (Shinkai)</option>
                  <option value="Cyberpunk Neon Noir">Cyberpunk Ánh sáng Neon</option>
                  <option value="Historical 35mm Film Grain">Nhựa phim 35mm Cổ điển</option>
                </select>
              </div>
            </div>

            {/* Run Adaptation Button */}
            <button
              onClick={handleAdaptScript}
              disabled={isAdapting || !bookContent.trim()}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-sm shadow-xl shadow-amber-500/20 flex items-center justify-center gap-2 transition-all transform active:scale-95 disabled:opacity-50"
            >
              {isAdapting ? (
                <>
                  <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                  <span>AI Đang Phân Tích & Viết Kịch Bản...</span>
                </>
              ) : (
                <>
                  <Wand2 className="w-4 h-4" />
                  <span>Bắt Đầu Biên Tập Kịch Bản Bằng AI</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Screenplay Viewer & Scene Breakdown (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Episode Tabs Header */}
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 shadow-xl">
            <div className="flex items-center justify-between gap-3 mb-3">
              <div className="flex items-center gap-2">
                <Clapperboard className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-white text-sm">
                  Cấu Trúc Các Tập Phim ({project.episodes.length} tập • {episodeDuration} phút/tập)
                </h3>
              </div>
              <span className="text-[11px] px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                Sẵn sàng sản xuất
              </span>
            </div>

            {/* Tabs for each episode */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              {project.episodes.map((ep, idx) => {
                const isSelected = activeEpisodeIdx === idx;
                return (
                  <button
                    key={ep.id}
                    onClick={() => setActiveEpisodeIdx(idx)}
                    className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                      isSelected
                        ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
                        : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                    }`}
                  >
                    <span>Tập {ep.episodeNumber}:</span>
                    <span className="truncate max-w-[140px]">{ep.title.replace(/^Tập \d+: /, '')}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Current Episode Synopsis */}
          {currentEpisode && (
            <div className="bg-slate-900/60 rounded-2xl border border-slate-800/80 p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                <div>
                  <div className="text-xs text-amber-400 font-bold uppercase tracking-wider">
                    TẬP {currentEpisode.episodeNumber} • {currentEpisode.durationMinutes} PHÚT
                  </div>
                  <h2 className="text-lg font-bold text-white">{currentEpisode.title}</h2>
                </div>
                <div className="text-xs text-slate-400 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span>Dự toán: ~{currentEpisode.acts.reduce((acc, a) => acc + a.scenes.length, 0) * 15} giây cảnh chính</span>
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed italic bg-slate-950/60 p-3 rounded-xl border border-slate-800/60">
                "{currentEpisode.synopsis}"
              </p>

              {/* Acts and Scenes */}
              <div className="space-y-6 pt-2">
                {currentEpisode.acts.length === 0 ? (
                  <div className="text-center py-8 text-slate-500 text-xs">
                    Chưa có phân cảnh chi tiết cho tập này. Nhấn "Bắt Đầu Biên Tập Kịch Bản Bằng AI" để tạo tự động.
                  </div>
                ) : (
                  currentEpisode.acts.map((act) => (
                    <div key={act.actNumber} className="space-y-3">
                      <div className="flex items-center gap-2 text-xs font-bold text-amber-300 uppercase tracking-wider bg-slate-950/90 px-3 py-1.5 rounded-lg border border-slate-800">
                        <Layers className="w-3.5 h-3.5 text-amber-400" />
                        <span>{act.name}</span>
                      </div>

                      <div className="space-y-4">
                        {act.scenes.map((scene) => (
                          <div
                            key={scene.id}
                            className="bg-slate-950 rounded-2xl border border-slate-800/90 overflow-hidden hover:border-slate-700 transition-all shadow-md group"
                          >
                            {/* Scene Top Details */}
                            <div className="p-4 bg-slate-900/40 border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-2">
                              <div className="flex items-center gap-2">
                                <span className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-300 flex items-center justify-center text-xs font-bold font-mono">
                                  #{scene.sceneNumber}
                                </span>
                                <span className="font-semibold text-white text-xs">
                                  {scene.title || `Cảnh ${scene.sceneNumber}: ${scene.location}`}
                                </span>
                              </div>
                              <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
                                <span className="bg-slate-800 px-2 py-0.5 rounded text-slate-300">{scene.timeOfDay}</span>
                                <span className="bg-slate-800 px-2 py-0.5 rounded text-slate-300">{scene.cameraAngle}</span>
                                <span className="bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded border border-amber-500/20">
                                  {scene.durationSeconds}s
                                </span>
                                <button
                                  type="button"
                                  onClick={() => handleStartEditScene(activeEpisodeIdx, act.actNumber, scene)}
                                  className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-indigo-500/15 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-500/30 font-semibold transition-all"
                                  title="Chỉnh sửa kịch bản phân cảnh này (Tự động lưu nháp)"
                                >
                                  <Edit3 className="w-3 h-3 text-amber-400" />
                                  <span>Sửa</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteScene(activeEpisodeIdx, act.actNumber, scene.id)}
                                  className="p-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 transition-colors"
                                  title="Xóa phân cảnh"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              </div>
                            </div>

                            {/* Scene Body Grid: Visual Preview + Dialogue */}
                            <div className="p-4 grid grid-cols-1 md:grid-cols-12 gap-4">
                              {/* Left: Visual thumbnail / Prompt (5 cols) */}
                              <div className="md:col-span-5 space-y-2">
                                <div className="relative aspect-video rounded-xl overflow-hidden bg-slate-900 border border-slate-800 group-hover:border-amber-500/30 transition-all">
                                  {scene.imageUrl ? (
                                    <img
                                      src={scene.imageUrl}
                                      alt={scene.title}
                                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                                    />
                                  ) : (
                                    <div className="w-full h-full flex items-center justify-center text-slate-600 text-xs">
                                      Hình ảnh phân cảnh
                                    </div>
                                  )}
                                  <div className="absolute top-2 right-2 px-1.5 py-0.5 rounded bg-slate-950/80 text-[10px] text-amber-300 font-mono">
                                    8K Cinema
                                  </div>
                                </div>

                                {/* Visual Prompt Box */}
                                <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800 text-[11px] text-slate-300 space-y-1.5">
                                  <div className="flex items-center justify-between text-[10px] text-slate-400 font-semibold uppercase">
                                    <span>AI Visual Prompt:</span>
                                    <button
                                      onClick={() => handleCopyPrompt(scene.visualPrompt, scene.id)}
                                      className="flex items-center gap-1 text-amber-400 hover:text-amber-300"
                                      title="Sao chép prompt"
                                    >
                                      {copiedPromptId === scene.id ? (
                                        <>
                                          <Check className="w-3 h-3 text-emerald-400" />
                                          <span className="text-emerald-400">Đã chép</span>
                                        </>
                                      ) : (
                                        <>
                                          <Copy className="w-3 h-3" />
                                          <span>Chép</span>
                                        </>
                                      )}
                                    </button>
                                  </div>
                                  <p className="line-clamp-2 text-slate-300 font-mono text-[10px] leading-tight">
                                    {scene.visualPrompt}
                                  </p>
                                </div>
                              </div>

                              {/* Right: Actions, Lighting, Dialogue (7 cols) */}
                              <div className="md:col-span-7 space-y-3">
                                <div>
                                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-0.5">
                                    Diễn Biến Phân Cảnh:
                                  </span>
                                  <p className="text-xs text-slate-200 leading-relaxed">
                                    {scene.description}
                                  </p>
                                </div>

                                <div className="grid grid-cols-2 gap-2 text-[10px] bg-slate-900/60 p-2 rounded-lg border border-slate-800/80">
                                  <div>
                                    <span className="text-slate-400 font-semibold">Ánh sáng: </span>
                                    <span className="text-slate-300">{scene.lighting}</span>
                                  </div>
                                  <div>
                                    <span className="text-slate-400 font-semibold">Âm thanh SFX: </span>
                                    <span className="text-amber-300">{scene.sfx}</span>
                                  </div>
                                </div>

                                {/* Dialogue bubbles */}
                                {scene.dialogue.length > 0 && (
                                  <div className="space-y-2">
                                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                                      Lời Thoại Nhân Vật:
                                    </span>
                                    {scene.dialogue.map((diag) => (
                                      <div
                                        key={diag.id}
                                        className="bg-slate-900/90 rounded-xl p-2.5 border border-slate-800 flex items-start justify-between gap-3"
                                      >
                                        <div className="space-y-0.5">
                                          <div className="flex items-center gap-2">
                                            <span className="text-xs font-bold text-amber-300">
                                              {diag.speaker}
                                            </span>
                                            <span className="text-[10px] text-slate-400 italic">
                                              ({diag.emotion})
                                            </span>
                                          </div>
                                          <p className="text-xs text-slate-100 font-medium">
                                            "{diag.text}"
                                          </p>
                                        </div>
                                        <button
                                          onClick={() => speakText(diag.text, diag.speaker.includes('Nữ') ? 'Nữ' : 'Nam')}
                                          className="p-1.5 rounded-lg bg-amber-500/10 text-amber-300 hover:bg-amber-500/20 transition-colors flex-shrink-0"
                                          title="Nghe thử giọng đọc"
                                        >
                                          <Volume2 className="w-3.5 h-3.5" />
                                        </button>
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Add Scene to this Act with Auto-Save */}
                      <button
                        type="button"
                        onClick={() => handleAddScene(activeEpisodeIdx, act.actNumber)}
                        className="w-full py-2.5 border-2 border-dashed border-slate-800 hover:border-amber-500/50 rounded-2xl bg-slate-950/40 hover:bg-slate-900/60 text-xs font-bold text-slate-400 hover:text-amber-300 flex items-center justify-center gap-2 transition-all group"
                      >
                        <Plus className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
                        <span>+ Thêm Phân Cảnh Mới Vào {act.name} (Tự Động Lưu Nháp)</span>
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 animate-in fade-in slide-in-from-bottom-5">
          <div className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-2.5 border border-emerald-400/40 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4 text-emerald-200" />
            <span>{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Modal Chỉnh Sửa Phân Cảnh & Lời Thoại với Lưu Nháp Tự Động */}
      {editingScene && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-3xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
            {/* Modal Header */}
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center">
                  <Edit3 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-sm">
                    Chỉnh Sửa Phân Cảnh #{editingScene.scene.sceneNumber} (Lưu Nháp Tự Động)
                  </h3>
                  <span className="text-[11px] text-emerald-400 font-mono">
                    Mọi thay đổi sẽ được tự động lưu vào bộ nhớ an toàn
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditingScene(null)}
                className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 flex-1 overflow-y-auto space-y-4 text-xs">
              <div>
                <label className="text-slate-300 font-semibold mb-1 block">Tựa đề phân cảnh:</label>
                <input
                  type="text"
                  value={editingScene.scene.title}
                  onChange={(e) =>
                    setEditingScene({
                      ...editingScene,
                      scene: { ...editingScene.scene, title: e.target.value },
                    })
                  }
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold mb-1 block">Diễn biến kịch bản chi tiết:</label>
                <textarea
                  rows={3}
                  value={editingScene.scene.description}
                  onChange={(e) =>
                    setEditingScene({
                      ...editingScene,
                      scene: { ...editingScene.scene, description: e.target.value },
                    })
                  }
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-slate-400 font-medium mb-1 block">Địa điểm:</label>
                  <input
                    type="text"
                    value={editingScene.scene.location}
                    onChange={(e) =>
                      setEditingScene({
                        ...editingScene,
                        scene: { ...editingScene.scene, location: e.target.value },
                      })
                    }
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-1.5 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-400 font-medium mb-1 block">Thời gian:</label>
                  <input
                    type="text"
                    value={editingScene.scene.timeOfDay}
                    onChange={(e) =>
                      setEditingScene({
                        ...editingScene,
                        scene: { ...editingScene.scene, timeOfDay: e.target.value },
                      })
                    }
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-1.5 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-400 font-medium mb-1 block">Thời lượng (giây):</label>
                  <input
                    type="number"
                    value={editingScene.scene.durationSeconds}
                    onChange={(e) =>
                      setEditingScene({
                        ...editingScene,
                        scene: { ...editingScene.scene, durationSeconds: Number(e.target.value) || 15 },
                      })
                    }
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-1.5 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 font-medium mb-1 block">Góc máy & Chuyển động:</label>
                  <input
                    type="text"
                    value={editingScene.scene.cameraAngle}
                    onChange={(e) =>
                      setEditingScene({
                        ...editingScene,
                        scene: { ...editingScene.scene, cameraAngle: e.target.value },
                      })
                    }
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-1.5 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-400 font-medium mb-1 block">Ánh sáng:</label>
                  <input
                    type="text"
                    value={editingScene.scene.lighting}
                    onChange={(e) =>
                      setEditingScene({
                        ...editingScene,
                        scene: { ...editingScene.scene, lighting: e.target.value },
                      })
                    }
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-1.5 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-semibold mb-1 block">AI Visual Prompt (Tạo hình ảnh):</label>
                <textarea
                  rows={2}
                  value={editingScene.scene.visualPrompt}
                  onChange={(e) =>
                    setEditingScene({
                      ...editingScene,
                      scene: { ...editingScene.scene, visualPrompt: e.target.value },
                    })
                  }
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-mono text-[11px]"
                />
              </div>

              {/* Dialogue Editor */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-200">Lời thoại nhân vật:</span>
                  <button
                    type="button"
                    onClick={() =>
                      setEditDialogueList([
                        ...editDialogueList,
                        {
                          id: `diag-${Date.now()}`,
                          speaker: project.characters[0]?.name || 'Quang GITA',
                          emotion: 'Tự tin',
                          text: 'Thành công chỉ đến khi chúng ta kiên định đến cùng.',
                          durationSeconds: 5,
                        },
                      ])
                    }
                    className="flex items-center gap-1 text-[11px] text-amber-400 hover:text-amber-300 font-semibold"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Thêm Câu Thoại</span>
                  </button>
                </div>

                {editDialogueList.map((d, dIdx) => (
                  <div key={d.id || dIdx} className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 space-y-2">
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        value={d.speaker}
                        placeholder="Tên nhân vật..."
                        onChange={(e) => {
                          const updated = [...editDialogueList];
                          updated[dIdx].speaker = e.target.value;
                          setEditDialogueList(updated);
                        }}
                        className="bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-white text-[11px]"
                      />
                      <input
                        type="text"
                        value={d.emotion}
                        placeholder="Cảm xúc..."
                        onChange={(e) => {
                          const updated = [...editDialogueList];
                          updated[dIdx].emotion = e.target.value;
                          setEditDialogueList(updated);
                        }}
                        className="bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-white text-[11px]"
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={d.text}
                        placeholder="Nội dung lời thoại..."
                        onChange={(e) => {
                          const updated = [...editDialogueList];
                          updated[dIdx].text = e.target.value;
                          setEditDialogueList(updated);
                        }}
                        className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-white text-xs"
                      />
                      <button
                        type="button"
                        onClick={() => setEditDialogueList(editDialogueList.filter((_, idx) => idx !== dIdx))}
                        className="p-1 rounded bg-rose-500/10 text-rose-400 hover:bg-rose-500/20"
                        title="Xóa câu này"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-slate-800 bg-slate-950/90 flex items-center justify-between">
              <span className="text-[11px] text-slate-500">
                💾 Nhấn Lưu sẽ tự động đồng bộ bản nháp và kích hoạt Auto-save.
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setEditingScene(null)}
                  className="px-3.5 py-1.5 rounded-xl text-slate-400 hover:text-white text-xs"
                >
                  Hủy
                </button>
                <button
                  type="button"
                  onClick={handleSaveEditedScene}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-bold text-xs shadow-lg flex items-center gap-1.5"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Lưu Phân Cảnh (Tự Động Lưu Nháp)</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
