import React, { useState, useEffect } from 'react';
import {
  Clock,
  RotateCcw,
  Download,
  Upload,
  CheckCircle2,
  Trash2,
  X,
  Cloud,
  Layers,
  Film,
  Users,
  AlertTriangle,
  Save,
  Check,
} from 'lucide-react';
import { FilmProject } from '../types';
import {
  DraftSnapshot,
  getDraftHistory,
  clearSavedDraft,
  saveDraftLocally,
} from '../utils/autoSaveManager';
import { saveProjectToFirestore } from '../lib/firebase';

interface DraftHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentProject: FilmProject;
  onRestoreProject: (restored: FilmProject) => void;
  onResetToSample: () => void;
  currentUser: any;
  lastSavedTime: string;
}

export const DraftHistoryModal: React.FC<DraftHistoryModalProps> = ({
  isOpen,
  onClose,
  currentProject,
  onRestoreProject,
  onResetToSample,
  currentUser,
  lastSavedTime,
}) => {
  const [snapshots, setSnapshots] = useState<DraftSnapshot[]>([]);
  const [isCloudSaving, setIsCloudSaving] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  useEffect(() => {
    if (isOpen) {
      setSnapshots(getDraftHistory());
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Manual save to Firestore
  const handleSaveToFirestore = async () => {
    if (!currentUser) {
      showToast('Vui lòng đăng nhập Google để đồng bộ dự án lên Firestore!');
      return;
    }
    setIsCloudSaving(true);
    try {
      await saveProjectToFirestore(currentProject, currentUser.uid);
      showToast('Đã lưu thành công dự án lên Đám mây Firestore!');
    } catch (e) {
      console.error('Lỗi lưu Firestore:', e);
      showToast('Có lỗi xảy ra khi lưu lên Firestore.');
    } finally {
      setIsCloudSaving(false);
    }
  };

  // Export project to JSON
  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(currentProject, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    const safeTitle = currentProject.title.replace(/[^a-z0-9]/gi, '_').toLowerCase();
    downloadAnchor.setAttribute('download', `${safeTitle}_backup_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showToast('Đã xuất file dự án (.json) về máy tính!');
  };

  // Import project from JSON
  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed && parsed.title && parsed.episodes) {
          onRestoreProject(parsed);
          saveDraftLocally(parsed, 'Khôi phục từ file JSON tải lên');
          showToast(`Đã nhập thành công dự án: ${parsed.title}!`);
          onClose();
        } else {
          showToast('File JSON không đúng định dạng dự án GITA365!');
        }
      } catch (err) {
        showToast('Lỗi đọc file JSON!');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in">
      <div className="w-full max-w-3xl bg-slate-900 border border-slate-700 rounded-3xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center text-slate-950 shadow-lg shadow-emerald-500/20">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                Hệ Thống Lưu Nháp Tự Động & Lịch Sử Phiên Bản
              </h3>
              <p className="text-xs text-slate-400">
                Tự động sao lưu kịch bản & phân cảnh trong bộ nhớ an toàn. Lần lưu gần nhất:{' '}
                <strong className="text-emerald-400 font-mono">{lastSavedTime}</strong>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toast */}
        {toastMsg && (
          <div className="bg-emerald-600/20 border-y border-emerald-500/40 px-4 py-2 text-xs font-semibold text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{toastMsg}</span>
          </div>
        )}

        {/* Current status bar */}
        <div className="px-5 py-3 bg-slate-950/90 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
              <CheckCircle2 className="w-4 h-4" />
              <span>Chế độ Lưu Nháp: Luôn Bật (Auto-Save Active)</span>
            </div>
            <div className="text-slate-400">
              Dự án: <span className="text-amber-300 font-bold">{currentProject.title}</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSaveToFirestore}
              disabled={isCloudSaving}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold transition-all shadow-md disabled:opacity-50"
            >
              {isCloudSaving ? (
                <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <Cloud className="w-3.5 h-3.5" />
              )}
              <span>Lưu Lên Cloud Firestore</span>
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="p-5 flex-1 overflow-y-auto space-y-5">
          {/* Snapshots list */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <RotateCcw className="w-3.5 h-3.5 text-amber-400" /> Các Bản Sao Lưu Gần Đây ({snapshots.length})
              </h4>
              <span className="text-[11px] text-slate-500">
                Tự động tạo snapshot khi có chỉnh sửa lớn
              </span>
            </div>

            {snapshots.length === 0 ? (
              <div className="p-6 bg-slate-950/60 rounded-2xl border border-slate-800 text-center space-y-2">
                <Clock className="w-8 h-8 text-slate-600 mx-auto" />
                <p className="text-xs text-slate-400">Chưa có lịch sử snapshot cũ. Bản nháp hiện tại đang được bảo vệ an toàn!</p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {snapshots.map((snap, idx) => (
                  <div
                    key={snap.id}
                    className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 hover:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-all group"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white group-hover:text-amber-300 transition-colors">
                          {snap.title}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono">
                          {snap.readableTime}
                        </span>
                        {idx === 0 && (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                            Mới nhất
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-3 text-[11px] text-slate-400">
                        <span className="flex items-center gap-1">
                          <Film className="w-3 h-3 text-amber-400" /> {snap.episodesCount} tập
                        </span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <Layers className="w-3 h-3 text-indigo-400" /> {snap.scenesCount} phân cảnh
                        </span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <Users className="w-3 h-3 text-cyan-400" /> {snap.charactersCount} nhân vật
                        </span>
                        <span>•</span>
                        <span className="text-slate-500 italic">{snap.reason}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        onRestoreProject(snap.project);
                        showToast(`Đã khôi phục bản nháp lúc ${snap.readableTime}!`);
                        onClose();
                      }}
                      className="flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-amber-500 text-slate-200 hover:text-slate-950 font-bold text-xs transition-all flex-shrink-0"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Khôi Phục Bản Này</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Backup & Import Tools */}
          <div className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-3">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Download className="w-3.5 h-3.5 text-cyan-400" /> Sao Lưu Ra Tệp & Khôi Phục File
            </h4>
            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={handleExportJSON}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-all"
              >
                <Download className="w-3.5 h-3.5 text-cyan-400" />
                <span>Tải File Sao Lưu (.JSON)</span>
              </button>

              <label className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-all cursor-pointer">
                <Upload className="w-3.5 h-3.5 text-amber-400" />
                <span>Nhập File Sao Lưu (.JSON)</span>
                <input
                  type="file"
                  accept=".json,application/json"
                  className="hidden"
                  onChange={handleImportJSON}
                />
              </label>

              <button
                onClick={() => {
                  if (window.confirm('Bạn có chắc chắn muốn đặt lại dự án về kịch bản mẫu ban đầu?')) {
                    onResetToSample();
                    showToast('Đã đặt lại dự án về mẫu ban đầu.');
                    onClose();
                  }
                }}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-semibold border border-rose-500/30 transition-all ml-auto"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Đặt Lại Về Bản Mẫu Gốc</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/90 flex items-center justify-between text-xs text-slate-400">
          <span>💡 Bản nháp luôn được lưu tự động sau mỗi thao tác chỉnh sửa kịch bản.</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};
