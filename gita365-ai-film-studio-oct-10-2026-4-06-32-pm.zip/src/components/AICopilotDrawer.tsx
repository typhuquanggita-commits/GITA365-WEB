import React, { useState, useRef, useEffect } from 'react';
import {
  Bot,
  Sparkles,
  Send,
  X,
  User,
  Film,
  Minimize2,
  RefreshCw,
  Lightbulb,
} from 'lucide-react';
import { FilmProject } from '../types';

interface AICopilotDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  project: FilmProject;
}

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export const AICopilotDrawer: React.FC<AICopilotDrawerProps> = ({
  isOpen,
  onClose,
  project,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: `Xin chào! Tôi là **GITA365 Film AI Copilot** 🎬. 
Tôi đồng hành cùng bạn trong toàn bộ quy trình sản xuất phim:
• Chuyển thể tiểu thuyết, sách kinh doanh thành kịch bản phim 10 - 30 phút.
• Khóa nhận dạng nhân vật nhất quán qua hàng trăm góc máy.
• Tối ưu lồng tiếng AI đa ngôn ngữ và nhạc nền bản quyền.
• Lập lịch đăng bài YouTube / TikTok / Facebook đạt tỷ lệ xem cao nhất.

Bạn muốn tôi hỗ trợ điều gì cho dự án **"${project.title}"**?`,
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const promptSuggestions = [
    'Làm thế nào để kịch bản tập 1 kịch tính hơn?',
    'Cách khóa prompt khuôn mặt nhân vật không bị méo?',
    'Khung giờ vàng đăng video TikTok & YouTube tốt nhất?',
    'Gợi ý âm thanh cao trào cho cảnh bão tuyết?',
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputValue;
    if (!text.trim() || isLoading) return;

    const newMessages: Message[] = [...messages, { role: 'user', content: text }];
    setMessages(newMessages);
    setInputValue('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMessages.map((m) => ({
            role: m.role === 'user' ? 'user' : 'model',
            content: m.content,
          })),
          currentProject: {
            title: project.title,
            genre: project.genre,
            episodesCount: project.episodes.length,
            charactersCount: project.characters.length,
          },
        }),
      });

      const data = await response.json();
      setMessages([
        ...newMessages,
        {
          role: 'assistant',
          content:
            data.reply ||
            'Tôi đã tiếp nhận yêu cầu. Bạn có thể thử tinh chỉnh prompt hoặc điều chỉnh thông số trong dòng thời gian dựng phim!',
        },
      ]);
    } catch (err) {
      setMessages([
        ...newMessages,
        {
          role: 'assistant',
          content:
            'Xin lỗi, kết nối tới máy chủ AI đang bận. Bạn vui lòng thử lại sau vài giây hoặc tiếp tục chỉnh sửa trực tiếp trên giao diện xưởng phim!',
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 w-full max-w-md sm:max-w-lg h-[600px] max-h-[85vh] bg-slate-950/95 backdrop-blur-xl border border-slate-800 rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-5">
      {/* Header */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 to-amber-500 text-white flex items-center justify-center shadow-lg shadow-purple-500/20">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-white text-xs flex items-center gap-1.5">
              <span>GITA365 Film AI Copilot</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
            </h3>
            <p className="text-[10px] text-slate-400">Trợ Lý Sản Xuất Điện Ảnh & Khách Hàng 24/7</p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3.5 text-xs">
        {messages.map((m, idx) => {
          const isUser = m.role === 'user';
          return (
            <div
              key={idx}
              className={`flex items-start gap-2.5 ${isUser ? 'flex-row-reverse' : ''}`}
            >
              <div
                className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs flex-shrink-0 ${
                  isUser
                    ? 'bg-amber-500 text-slate-950 font-bold'
                    : 'bg-purple-600/30 text-purple-300 border border-purple-500/40'
                }`}
              >
                {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div
                className={`p-3 rounded-2xl max-w-[85%] leading-relaxed ${
                  isUser
                    ? 'bg-amber-500 text-slate-950 font-medium rounded-tr-none'
                    : 'bg-slate-900 text-slate-200 border border-slate-800 rounded-tl-none whitespace-pre-wrap'
                }`}
              >
                {m.content}
              </div>
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-center gap-2 text-slate-400 text-xs py-1">
            <div className="w-4 h-4 border-2 border-purple-400 border-t-transparent rounded-full animate-spin" />
            <span>AI Đang Soạn Phản Hồi Điện Ảnh...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompt Chips */}
      <div className="px-3 py-2 bg-slate-900/60 border-t border-slate-800/80 overflow-x-auto no-scrollbar flex items-center gap-1.5">
        <Lightbulb className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
        {promptSuggestions.map((sug, i) => (
          <button
            key={i}
            onClick={() => handleSendMessage(sug)}
            className="px-2.5 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] whitespace-nowrap transition-colors border border-slate-700/60"
          >
            {sug}
          </button>
        ))}
      </div>

      {/* Input Box */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage();
        }}
        className="p-3 bg-slate-900 border-t border-slate-800 flex items-center gap-2"
      >
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="Hỏi bất kỳ điều gì về kịch bản, âm thanh, render 4K..."
          className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-purple-500"
        />
        <button
          type="submit"
          disabled={!inputValue.trim() || isLoading}
          className="p-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-amber-500 hover:brightness-110 text-white font-bold transition-all disabled:opacity-50"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
