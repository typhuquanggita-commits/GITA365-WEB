import React, { useState } from 'react';
import {
  Users,
  Trophy,
  Award,
  Crown,
  Flame,
  MessageSquare,
  Send,
  Plus,
  CheckCircle2,
  Clock,
  ThumbsUp,
  Eye,
  Star,
  Film,
} from 'lucide-react';
import { FilmProject, TeamMember, LeaderboardFilm } from '../types';
import { TEAM_MEMBERS, LEADERBOARD_FILMS } from '../data/initialData';

interface TeamLeaderboardViewProps {
  project: FilmProject;
}

export const TeamLeaderboardView: React.FC<TeamLeaderboardViewProps> = ({ project }) => {
  const [members, setMembers] = useState<TeamMember[]>(TEAM_MEMBERS);
  const [comments, setComments] = useState([
    {
      id: 'c-1',
      author: 'Elena Vũ (Biên Kịch)',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
      timestamp: '00:15',
      timeAgo: '10 phút trước',
      text: 'Đoạn bão tuyết mở đầu cần thêm tiếng thở dốc của GS. Spalding để tăng kịch tính!',
    },
    {
      id: 'c-2',
      author: 'Trần Tuấn Art (Họa Sĩ)',
      avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80',
      timestamp: '02:40',
      timeAgo: '25 phút trước',
      text: 'Đã khóa nét mặt nhân vật Pháp Sư với độ tương thích 99% theo chuẩn Unreal Engine.',
    },
  ]);
  const [newComment, setNewComment] = useState('');
  const [inviteSuccess, setInviteSuccess] = useState(false);

  const handleSendComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    setComments([
      ...comments,
      {
        id: `c-${Date.now()}`,
        author: 'Quang GITA (Bạn)',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
        timestamp: '05:20',
        timeAgo: 'Vừa xong',
        text: newComment,
      },
    ]);
    setNewComment('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-slate-900 to-yellow-950/40 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 rounded-full bg-yellow-500/10 blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-yellow-500/15 border border-yellow-500/30 text-yellow-300 text-xs font-bold uppercase tracking-wider">
              <Trophy className="w-3.5 h-3.5" /> GITA365 Community & Studio Collab
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight">
              Cộng Tác Nhóm Thời Gian Thực & Bảng Xếp Hạng Điện Ảnh
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              Làm việc nhóm đồng thời giữa Đạo diễn, Biên kịch và Kỹ sư âm thanh.
              Cạnh tranh trên Bảng xếp hạng phim AI xuất sắc nhất tháng để nhận cúp vinh danh và tài trợ từ GITA365.
            </p>
          </div>
          <button
            onClick={() => {
              setInviteSuccess(true);
              setTimeout(() => setInviteSuccess(false), 2000);
            }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-semibold transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>{inviteSuccess ? 'Đã sao chép link mời nhóm!' : 'Mời Thành Viên Nhóm'}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Team Collaboration & Timeline Comments (6 cols) */}
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-amber-400" /> Thành Viên Đang Trực Tuyến ({members.length})
              </h2>
              <span className="text-xs text-emerald-400 font-mono">Đồng bộ P2P Real-time</span>
            </div>

            {/* Member Cards */}
            <div className="space-y-3">
              {members.map((m) => (
                <div
                  key={m.id}
                  className="bg-slate-950 p-3.5 rounded-xl border border-slate-800/80 flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3">
                    <div className="relative w-11 h-11 rounded-full overflow-hidden border border-slate-700 flex-shrink-0">
                      <img src={m.avatar} alt={m.name} className="w-full h-full object-cover" />
                      <span
                        className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-slate-950 ${
                          m.status === 'editing'
                            ? 'bg-amber-400 animate-pulse'
                            : m.status === 'online'
                            ? 'bg-emerald-400'
                            : 'bg-slate-500'
                        }`}
                      />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white flex items-center gap-1.5">
                        <span>{m.name}</span>
                        <span className="text-[10px] px-2 py-0.2 rounded-full bg-slate-800 text-slate-300 font-normal">
                          {m.role}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">{m.currentActivity}</p>
                    </div>
                  </div>

                  <span
                    className={`text-[10px] px-2 py-0.5 rounded font-mono ${
                      m.status === 'editing'
                        ? 'bg-amber-500/10 text-amber-300'
                        : m.status === 'online'
                        ? 'bg-emerald-500/10 text-emerald-400'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {m.status === 'editing' ? 'Đang chỉnh sửa' : m.status === 'online' ? 'Online' : 'Vắng mặt'}
                  </span>
                </div>
              ))}
            </div>

            {/* Timeline Comments Stream */}
            <div className="pt-3 border-t border-slate-800 space-y-3">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5 text-amber-400" /> Bình Luận Góp Ý Theo Mốc Thời Gian (Timeline):
              </h3>

              <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
                {comments.map((c) => (
                  <div
                    key={c.id}
                    className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1 text-xs"
                  >
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-bold text-slate-200">{c.author}</span>
                      <div className="flex items-center gap-2">
                        <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono text-[10px]">
                          {c.timestamp}
                        </span>
                        <span className="text-slate-500">{c.timeAgo}</span>
                      </div>
                    </div>
                    <p className="text-slate-300 text-[11px] leading-relaxed">{c.text}</p>
                  </div>
                ))}
              </div>

              {/* Comment Input */}
              <form onSubmit={handleSendComment} className="flex gap-2 pt-1">
                <input
                  type="text"
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder="Nhập góp ý cho phân cảnh hiện tại..."
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                />
                <button
                  type="submit"
                  className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            </div>
          </div>
        </div>

        {/* Right Column: Leaderboard of Top AI Films (6 cols) */}
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Trophy className="w-4 h-4 text-yellow-400" /> Bảng Xếp Hạng Phim AI Xuất Sắc Nhất Tháng
              </h2>
              <span className="text-xs text-yellow-400 font-mono">Giải Thưởng GITA 2026</span>
            </div>

            <div className="space-y-3">
              {LEADERBOARD_FILMS.map((film) => (
                <div
                  key={film.id}
                  className={`p-4 rounded-2xl border transition-all flex items-center justify-between gap-4 ${
                    film.rank === 1
                      ? 'bg-gradient-to-r from-yellow-950/30 via-slate-950 to-slate-950 border-yellow-500/60 shadow-lg shadow-yellow-500/10'
                      : 'bg-slate-950/70 border-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    {/* Rank Badge */}
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center font-black text-sm flex-shrink-0 ${
                        film.rank === 1
                          ? 'bg-yellow-400 text-slate-950 shadow-md shadow-yellow-400/30'
                          : film.rank === 2
                          ? 'bg-slate-300 text-slate-950'
                          : film.rank === 3
                          ? 'bg-amber-700 text-white'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {film.rank === 1 ? <Crown className="w-5 h-5" /> : `#${film.rank}`}
                    </div>

                    {/* Poster */}
                    <div className="w-14 h-18 rounded-lg overflow-hidden bg-slate-900 border border-slate-800 flex-shrink-0 hidden sm:block">
                      <img src={film.posterUrl} alt={film.title} className="w-full h-full object-cover" />
                    </div>

                    <div className="min-w-0 space-y-0.5">
                      <span className="text-[10px] px-2 py-0.2 rounded-full bg-amber-500/10 text-amber-300 font-bold uppercase">
                        {film.badge}
                      </span>
                      <h3 className="text-xs font-bold text-white truncate max-w-[200px] sm:max-w-xs">
                        {film.title}
                      </h3>
                      <div className="text-[11px] text-slate-400 truncate">
                        Đạo diễn: {film.director} • {film.episodes} tập
                      </div>
                      <div className="text-[10px] text-yellow-300/90 font-medium flex items-center gap-1">
                        <Award className="w-3 h-3 text-yellow-400" />
                        <span>{film.award}</span>
                      </div>
                    </div>
                  </div>

                  {/* Views & Likes */}
                  <div className="text-right flex-shrink-0 space-y-1">
                    <div className="text-xs font-bold text-emerald-400 font-mono flex items-center justify-end gap-1">
                      <Eye className="w-3.5 h-3.5" />
                      {(film.views / 1000).toFixed(0)}K
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono">
                      {(film.likes / 1000).toFixed(1)}K thích
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
