import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  Youtube,
  Share2,
  Sparkles,
  Check,
  Plus,
  Send,
  CheckCircle2,
  TrendingUp,
  Hash,
  Eye,
  ThumbsUp,
  MessageSquare,
  Repeat,
  Radio,
} from 'lucide-react';
import { FilmProject, ScheduledPost } from '../types';
import { SCHEDULED_POSTS } from '../data/initialData';

interface SchedulerViewProps {
  project: FilmProject;
  onUpdateProject: (updated: FilmProject) => void;
}

export const SchedulerView: React.FC<SchedulerViewProps> = ({
  project,
  onUpdateProject,
}) => {
  const [posts, setPosts] = useState<ScheduledPost[]>(SCHEDULED_POSTS);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [postTitle, setPostTitle] = useState(
    `[PHIM BỘ 4K] ${project.title} - Tập 1: Tiếng Gọi Huyền Bí`
  );
  const [postDescription, setPostDescription] = useState(
    'Cùng thưởng thức tập phim đỉnh cao được sản xuất bằng hệ sinh thái Xưởng Phim AI GITA365.'
  );
  const [scheduledDate, setScheduledDate] = useState('2026-10-14');
  const [scheduledTime, setScheduledTime] = useState('19:30');
  const [selectedPlatforms, setSelectedPlatforms] = useState<('youtube' | 'tiktok' | 'facebook')[]>([
    'youtube',
    'tiktok',
    'facebook',
  ]);
  const [tags, setTags] = useState<string[]>([
    '#GITA365',
    '#PhimAI',
    '#PhimBo4K',
    '#ChuyenTheSach',
    '#Trending',
  ]);
  const [isGeneratingSeo, setIsGeneratingSeo] = useState(false);
  const [scheduleSuccess, setScheduleSuccess] = useState(false);

  // Call Server-side API to generate trending tags & SEO
  const handleGenerateSeo = async () => {
    setIsGeneratingSeo(true);
    try {
      const response = await fetch('/api/seo/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: project.title,
          synopsis: project.episodes[0]?.synopsis || '',
          genre: project.genre,
        }),
      });

      const data = await response.json();
      if (data.youtubeTitle) setPostTitle(data.youtubeTitle);
      if (data.facebookPost) setPostDescription(data.facebookPost);
      if (data.suggestedHashtags) setTags(data.suggestedHashtags);
    } catch (err) {
      console.error('Lỗi sinh SEO:', err);
    } finally {
      setIsGeneratingSeo(false);
    }
  };

  const handleTogglePlatform = (p: 'youtube' | 'tiktok' | 'facebook') => {
    if (selectedPlatforms.includes(p)) {
      if (selectedPlatforms.length > 1) {
        setSelectedPlatforms(selectedPlatforms.filter((x) => x !== p));
      }
    } else {
      setSelectedPlatforms([...selectedPlatforms, p]);
    }
  };

  const handleSaveSchedule = () => {
    const newPost: ScheduledPost = {
      id: `sched-${Date.now()}`,
      episodeId: project.episodes[0]?.id || 'ep-1',
      videoTitle: postTitle,
      thumbnail:
        project.episodes[0]?.thumbnailUrl ||
        'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=800&auto=format&fit=crop&q=80',
      platforms: selectedPlatforms,
      scheduledDate,
      scheduledTime,
      status: 'scheduled',
      tags,
      description: postDescription,
    };

    setPosts([newPost, ...posts]);
    setScheduleSuccess(true);
    setTimeout(() => {
      setScheduleSuccess(false);
      setShowScheduleModal(false);
    }, 1500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-slate-900 to-rose-950/40 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 rounded-full bg-rose-500/10 blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-bold uppercase tracking-wider">
              <Calendar className="w-3.5 h-3.5" /> GITA365 Multi-Platform Auto-Scheduler
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight">
              Lập Lịch Đăng Bài Tự Động Đa Nền Tảng
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              Tự động xuất bản và hẹn giờ phát sóng video 4K lên đồng thời YouTube, TikTok và Facebook.
              AI tối ưu hóa tiêu đề giật gân, thẻ hashtag thịnh hành và khung giờ vàng tiếp cận hàng triệu khán giả.
            </p>
          </div>
          <button
            onClick={() => setShowScheduleModal(true)}
            className="flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-400 hover:to-amber-400 text-slate-950 font-bold text-xs shadow-lg shadow-rose-500/20 transition-all transform hover:scale-105"
          >
            <Plus className="w-4 h-4" />
            <span>Tạo Lịch Phát Sóng Mới</span>
          </button>
        </div>
      </div>

      {/* Connected Accounts Status Bar */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* YouTube */}
        <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 flex items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-600/20 text-red-400 border border-red-500/30 flex items-center justify-center">
              <Youtube className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <span>YouTube Channel</span>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              </div>
              <div className="text-[11px] text-slate-400">GITA365 Cinema • 145K Subs</div>
            </div>
          </div>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-mono">
            Đã kết nối
          </span>
        </div>

        {/* TikTok */}
        <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 flex items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-600/20 text-cyan-400 border border-cyan-500/30 flex items-center justify-center">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <span>TikTok Creator Pro</span>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              </div>
              <div className="text-[11px] text-slate-400">@gita365film • 320K Followers</div>
            </div>
          </div>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-mono">
            Đã kết nối
          </span>
        </div>

        {/* Facebook */}
        <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 flex items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center">
              <Radio className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <span>Facebook Page & Reels</span>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              </div>
              <div className="text-[11px] text-slate-400">GITA365 Điện Ảnh AI • 88K Thích</div>
            </div>
          </div>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-mono">
            Đã kết nối
          </span>
        </div>
      </div>

      {/* Scheduled Queue Table / Cards */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-5">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-400" />
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">
              Hàng Đợi Phát Sóng ({posts.length} video)
            </h2>
          </div>
          <span className="text-xs text-slate-400">Đồng bộ tự động theo thời gian thực</span>
        </div>

        <div className="space-y-4">
          {posts.map((post) => (
            <div
              key={post.id}
              className="bg-slate-950 p-4 rounded-2xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:border-slate-700 transition-all shadow-md"
            >
              <div className="flex items-start gap-4 min-w-0">
                <div className="relative w-28 h-18 rounded-xl overflow-hidden bg-slate-900 border border-slate-800 flex-shrink-0">
                  <img src={post.thumbnail} alt={post.videoTitle} className="w-full h-full object-cover" />
                  <div className="absolute top-1 left-1 px-1.5 py-0.5 rounded bg-black/80 text-[9px] text-amber-300 font-mono">
                    4K UHD
                  </div>
                </div>

                <div className="min-w-0 space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                        post.status === 'published'
                          ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                          : post.status === 'scheduled'
                          ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {post.status === 'published'
                        ? 'ĐÃ XUẤT BẢN'
                        : post.status === 'scheduled'
                        ? 'ĐANG CHỜ PHÁT SÓNG'
                        : 'BẢN NHÁP'}
                    </span>

                    <span className="text-[11px] text-slate-400 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-400" />
                      {post.scheduledDate} lúc {post.scheduledTime}
                    </span>
                  </div>

                  <h3 className="text-xs font-bold text-white truncate max-w-lg">{post.videoTitle}</h3>

                  {/* Platform Icons */}
                  <div className="flex items-center gap-1.5 pt-1">
                    {post.platforms.includes('youtube') && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-red-600/20 text-red-400 border border-red-500/30 font-semibold">
                        YouTube 4K
                      </span>
                    )}
                    {post.platforms.includes('tiktok') && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-600/20 text-cyan-400 border border-cyan-500/30 font-semibold">
                        TikTok 9:16
                      </span>
                    )}
                    {post.platforms.includes('facebook') && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-600/20 text-blue-400 border border-blue-500/30 font-semibold">
                        Facebook Reels
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Stats or Action */}
              <div className="flex items-center gap-4 flex-shrink-0">
                {post.status === 'published' && post.stats ? (
                  <div className="flex items-center gap-3 text-xs bg-slate-900/80 px-3 py-2 rounded-xl border border-slate-800">
                    <span className="flex items-center gap-1 text-slate-300">
                      <Eye className="w-3.5 h-3.5 text-cyan-400" />
                      {(post.stats.views || 0).toLocaleString()}
                    </span>
                    <span className="flex items-center gap-1 text-slate-300">
                      <ThumbsUp className="w-3.5 h-3.5 text-amber-400" />
                      {(post.stats.likes || 0).toLocaleString()}
                    </span>
                    <span className="flex items-center gap-1 text-slate-300">
                      <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                      {(post.stats.comments || 0).toLocaleString()}
                    </span>
                  </div>
                ) : (
                  <div className="text-right">
                    <button
                      onClick={() => {
                        const updated = posts.map((p) =>
                          p.id === post.id
                            ? {
                                ...p,
                                status: 'published' as const,
                                stats: { views: 12400, likes: 1850, comments: 140, shares: 320 },
                              }
                            : p
                        );
                        setPosts(updated);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-semibold transition-colors"
                    >
                      Xuất Bản Ngay Lập Tức
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modal: Create Schedule Post */}
      {showScheduleModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-xl bg-slate-900 rounded-3xl border border-slate-800 p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                <Calendar className="w-5 h-5 text-amber-400" /> Lập Lịch Phát Sóng Đa Kênh Tự Động
              </h3>
              <button
                onClick={() => setShowScheduleModal(false)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs">
              {/* Platforms Multi-select */}
              <div>
                <label className="text-slate-300 font-semibold mb-1.5 block">
                  Chọn kênh phát sóng tự động:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => handleTogglePlatform('youtube')}
                    className={`p-2.5 rounded-xl border flex items-center justify-center gap-1.5 transition-all ${
                      selectedPlatforms.includes('youtube')
                        ? 'bg-red-600/20 border-red-500 text-red-300 font-bold'
                        : 'bg-slate-950 border-slate-800 text-slate-500'
                    }`}
                  >
                    <Youtube className="w-4 h-4" />
                    <span>YouTube</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTogglePlatform('tiktok')}
                    className={`p-2.5 rounded-xl border flex items-center justify-center gap-1.5 transition-all ${
                      selectedPlatforms.includes('tiktok')
                        ? 'bg-cyan-600/20 border-cyan-500 text-cyan-300 font-bold'
                        : 'bg-slate-950 border-slate-800 text-slate-500'
                    }`}
                  >
                    <Share2 className="w-4 h-4" />
                    <span>TikTok</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTogglePlatform('facebook')}
                    className={`p-2.5 rounded-xl border flex items-center justify-center gap-1.5 transition-all ${
                      selectedPlatforms.includes('facebook')
                        ? 'bg-blue-600/20 border-blue-500 text-blue-300 font-bold'
                        : 'bg-slate-950 border-slate-800 text-slate-500'
                    }`}
                  >
                    <Radio className="w-4 h-4" />
                    <span>Facebook</span>
                  </button>
                </div>
              </div>

              {/* Title & AI Hook Generator */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-slate-300 font-semibold">Tiêu đề phát sóng (Title):</label>
                  <button
                    type="button"
                    onClick={handleGenerateSeo}
                    disabled={isGeneratingSeo}
                    className="text-amber-400 hover:text-amber-300 text-[11px] flex items-center gap-1 font-semibold"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>{isGeneratingSeo ? 'Đang tạo...' : 'AI Gợi Ý Tiêu Đề & Hashtag Hot'}</span>
                  </button>
                </div>
                <input
                  type="text"
                  value={postTitle}
                  onChange={(e) => setPostTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500 font-bold"
                />
              </div>

              {/* Description & Hashtags */}
              <div>
                <label className="text-slate-300 font-semibold mb-1 block">Nội dung bài viết (Caption / Description):</label>
                <textarea
                  rows={3}
                  value={postDescription}
                  onChange={(e) => setPostDescription(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Hashtags display */}
              <div>
                <label className="text-slate-300 font-semibold mb-1 block flex items-center gap-1">
                  <Hash className="w-3.5 h-3.5 text-amber-400" /> Thẻ Hashtag xu hướng hiện hành:
                </label>
                <div className="flex flex-wrap gap-1.5 bg-slate-950 p-2 rounded-xl border border-slate-800">
                  {tags.map((t, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 rounded-lg bg-amber-500/15 text-amber-300 text-[10px] font-mono"
                    >
                      {t}
                    </span>
                  ))}
                </div>
              </div>

              {/* Date & Golden Hour Time */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold mb-1 block">Ngày phát hành:</label>
                  <input
                    type="date"
                    value={scheduledDate}
                    onChange={(e) => setScheduledDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-semibold mb-1 block">Giờ vàng tiếp cận:</label>
                  <select
                    value={scheduledTime}
                    onChange={(e) => setScheduledTime(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none"
                  >
                    <option value="19:30">19:30 (Khung vàng tối YouTube)</option>
                    <option value="20:00">20:00 (Đỉnh xem phim buổi tối)</option>
                    <option value="21:15">21:15 (Khung đêm TikTok & Reels)</option>
                    <option value="11:45">11:45 (Khung giờ trưa văn phòng)</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowScheduleModal(false)}
                className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-xs"
              >
                Hủy
              </button>
              <button
                type="button"
                onClick={handleSaveSchedule}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-bold text-xs shadow-lg flex items-center gap-2"
              >
                {scheduleSuccess ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Đã Lên Lịch Thành Công!</span>
                  </>
                ) : (
                  <>
                    <Calendar className="w-4 h-4" />
                    <span>Xác Nhận Lên Lịch Đa Nền Tảng</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
