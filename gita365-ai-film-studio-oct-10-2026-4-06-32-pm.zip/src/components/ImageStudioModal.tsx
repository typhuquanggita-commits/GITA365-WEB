import React, { useState } from 'react';
import {
  Sparkles,
  Image as ImageIcon,
  Wand2,
  Download,
  Loader2,
  X,
  Upload,
  RefreshCw,
  Check,
  Maximize2,
} from 'lucide-react';

interface ImageStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialPrompt?: string;
  initialImage?: string;
  onApplyImage?: (imageUrl: string) => void;
  sceneTitle?: string;
}

export const ImageStudioModal: React.FC<ImageStudioModalProps> = ({
  isOpen,
  onClose,
  initialPrompt = '',
  initialImage,
  onApplyImage,
  sceneTitle,
}) => {
  const [prompt, setPrompt] = useState(initialPrompt || 'Cinematic shot, hyper-realistic 8K, golden hour lighting, dramatic Vietnamese film production');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16' | '1:1' | '4:3'>('16:9');
  const [imageSize, setImageSize] = useState<'1K' | '2K' | '4K'>('1K');
  const [isGenerating, setIsGenerating] = useState(false);
  const [referenceImage, setReferenceImage] = useState<string | null>(initialImage || null);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleGenerate = async () => {
    setIsGenerating(true);
    setError(null);
    try {
      const payload: any = {
        prompt,
        aspectRatio,
        imageSize,
      };

      if (referenceImage) {
        payload.base64ImageData = referenceImage.replace(/^data:image\/\w+;base64,/, '');
      }

      const res = await fetch('/api/image/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (data.success && data.imageUrl) {
        setGeneratedImage(data.imageUrl);
      } else {
        setError(data.error || 'Không thể tạo hình ảnh với gemini-nano-banana-2.1');
      }
    } catch (err: any) {
      console.error('Image generation error:', err);
      setError(err.message || 'Lỗi mạng khi gọi API sinh ảnh');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setReferenceImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-purple-600/20">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-100 flex items-center gap-2">
                Xưởng Tạo & Chỉnh Sửa Ảnh AI Điện Ảnh
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
                  gemini-nano-banana-2.1
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                {sceneTitle ? `Đang chỉnh phân cảnh: ${sceneTitle}` : 'Tạo concept art, storyboard và sửa ảnh độ phân giải lên tới 4K'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {/* Prompt Input */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Wand2 className="w-3.5 h-3.5 text-amber-400" /> Prompt Mô Tả Chi Tiết (Tạo Mới hoặc Chỉnh Sửa)
            </label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              rows={3}
              placeholder="Ví dụ: Cận cảnh góc quay điện ảnh 8K, ánh sáng hoàng hôn chiếu rọi lên nhân vật đang đứng trên ban công thành phố tương lai..."
              className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-3.5 text-xs text-slate-100 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 transition-all"
            />
          </div>

          {/* Controls: Aspect Ratio & Size */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Aspect Ratio */}
            <div className="bg-slate-950/60 p-3.5 rounded-2xl border border-slate-800 space-y-2">
              <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Tỉ Lệ Khung Hình (Aspect Ratio)
              </label>
              <div className="flex gap-2">
                {(['16:9', '9:16', '1:1', '4:3'] as const).map((ratio) => (
                  <button
                    key={ratio}
                    onClick={() => setAspectRatio(ratio)}
                    className={`flex-1 py-1.5 px-2 rounded-xl text-xs font-semibold transition-all ${
                      aspectRatio === ratio
                        ? 'bg-amber-500 text-slate-950 shadow-md'
                        : 'bg-slate-900 text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    {ratio}
                  </button>
                ))}
              </div>
            </div>

            {/* Image Resolution */}
            <div className="bg-slate-950/60 p-3.5 rounded-2xl border border-slate-800 space-y-2">
              <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Độ Phân Giải (Image Size)
              </label>
              <div className="flex gap-2">
                {(['1K', '2K', '4K'] as const).map((size) => (
                  <button
                    key={size}
                    onClick={() => setImageSize(size)}
                    className={`flex-1 py-1.5 px-2 rounded-xl text-xs font-semibold transition-all ${
                      imageSize === size
                        ? 'bg-purple-600 text-white shadow-md'
                        : 'bg-slate-900 text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Reference Image for Editing */}
          <div className="bg-slate-950/40 p-4 rounded-2xl border border-slate-800/80 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4 text-purple-400" />
                Ảnh Gốc Tham Chiếu (Tùy Chọn Chỉnh Sửa)
              </span>
              {referenceImage && (
                <button
                  onClick={() => setReferenceImage(null)}
                  className="text-[11px] text-red-400 hover:text-red-300"
                >
                  Gỡ ảnh
                </button>
              )}
            </div>

            {referenceImage ? (
              <div className="relative max-w-xs h-32 rounded-xl overflow-hidden border border-slate-700 bg-slate-950">
                <img src={referenceImage} alt="Ref" className="w-full h-full object-cover" />
                <span className="absolute bottom-1 right-1 bg-black/70 px-1.5 py-0.5 rounded text-[10px] text-white">
                  Đã tải ảnh
                </span>
              </div>
            ) : (
              <label className="flex items-center justify-center gap-2 p-4 rounded-xl border border-dashed border-slate-800 hover:border-slate-700 bg-slate-950/30 cursor-pointer text-xs text-slate-400 hover:text-slate-200 transition-colors">
                <Upload className="w-4 h-4 text-slate-500" />
                <span>Tải ảnh lên để yêu cầu AI chỉnh sửa (Img2Img)</span>
                <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
              </label>
            )}
          </div>

          {/* Error */}
          {error && (
            <div className="p-3 bg-red-950/50 border border-red-700/50 rounded-xl text-xs text-red-300">
              {error}
            </div>
          )}

          {/* Result Preview */}
          {generatedImage && (
            <div className="space-y-3 bg-slate-950 p-4 rounded-2xl border border-emerald-500/30">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                  <Check className="w-4 h-4" /> Kết Quả Sinh Ảnh Thành Công ({imageSize})
                </span>
                <div className="flex items-center gap-2">
                  <a
                    href={generatedImage}
                    download="gita365_concept_art.png"
                    className="flex items-center gap-1 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-xl transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" /> Tải Về
                  </a>
                  {onApplyImage && (
                    <button
                      onClick={() => {
                        onApplyImage(generatedImage);
                        onClose();
                      }}
                      className="flex items-center gap-1 px-3.5 py-1 bg-gradient-to-r from-emerald-600 to-teal-600 hover:brightness-110 text-white text-xs font-bold rounded-xl shadow-lg transition-all"
                    >
                      <Check className="w-3.5 h-3.5" /> Áp Dụng Cho Phân Cảnh
                    </button>
                  )}
                </div>
              </div>
              <div className="rounded-xl overflow-hidden border border-slate-800 bg-black flex items-center justify-center max-h-96">
                <img src={generatedImage} alt="Generated" className="max-h-96 w-auto object-contain" />
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            Đóng
          </button>
          <button
            onClick={handleGenerate}
            disabled={isGenerating || !prompt.trim()}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-purple-600 hover:brightness-110 text-white font-bold text-xs shadow-lg shadow-purple-600/30 disabled:opacity-50 transition-all"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Đang render ảnh AI (gemini-nano-banana-2.1)...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>{referenceImage ? 'Chỉnh Sửa Ảnh' : 'Sinh Ảnh Mới (4K/HD)'}</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
