# Security Specification for GITA365 Firestore

## 1. Data Invariants

1. **User Ownership & Identity Invariant**:
   - A user can only read and write their own profile document (`/users/{userId}` where `userId == request.auth.uid`).
   - A user cannot elevate their own role to 'admin' or manipulate other users' data.
   - PII (email, profile) is protected and never readable by unauthenticated or unrelated users.

2. **Project Invariant**:
   - Each project must have `userId == request.auth.uid` on creation and this ownership is immutable on updates (`incoming().userId == existing().userId`).
   - Projects can only be read, modified, or deleted by their verified creator (`request.auth.uid == resource.data.userId`).
   - Non-authenticated requests are strictly rejected with PERMISSION_DENIED.

3. **Scheduled Posts Invariant**:
   - Posts can only be created, read, updated, or deleted by their creator (`request.auth.uid == resource.data.userId`).
   - State cannot bypass allowed transitions or modify immutable foreign keys.

4. **Audio Transcriptions Invariant**:
   - Transcriptions can only be created by the authenticated owner (`incoming().userId == request.auth.uid`).
   - Transcriptions cannot exceed maximum character bounds (10,000 characters).

---

## 2. The Dirty Dozen Payloads (Designed to Fail)

1. **Payload 1: Unauthenticated Read on Users**
   - Attempt: GET `/users/victim_user_123` with `auth == null`.
   - Result: PERMISSION_DENIED.

2. **Payload 2: Identity Spoofing on User Profile Creation**
   - Attempt: POST `/users/victim_user_123` with `auth.uid = attacker_456`, payload `{"id": "victim_user_123", "email": "victim@gita.com"}`.
   - Result: PERMISSION_DENIED (path ID must match auth UID).

3. **Payload 3: Privilege Escalation (Self-Admin Grant)**
   - Attempt: UPDATE `/users/user_123` setting `role: "admin"`.
   - Result: PERMISSION_DENIED.

4. **Payload 4: Project Creation with Spoofed Owner**
   - Attempt: POST `/projects/proj_999` with `auth.uid = attacker_456` and payload `{"userId": "victim_123", "title": "Stolen Film"}`.
   - Result: PERMISSION_DENIED.

5. **Payload 5: Unauthorized Project Modification**
   - Attempt: UPDATE `/projects/proj_abc` owned by `user_123` using credentials `auth.uid = user_999`.
   - Result: PERMISSION_DENIED.

6. **Payload 6: Unauthorized Project Deletion**
   - Attempt: DELETE `/projects/proj_abc` owned by `user_123` using credentials `auth.uid = user_999`.
   - Result: PERMISSION_DENIED.

7. **Payload 7: Unbounded String Injection Attack (Denial of Wallet)**
   - Attempt: POST `/projects/proj_large` with a 2MB title string.
   - Result: PERMISSION_DENIED (enforces `title.size() <= 256`).

8. **Payload 8: Document ID Poisoning with Special Characters**
   - Attempt: POST `/projects/../../malicious$path` or 1KB long ID.
   - Result: PERMISSION_DENIED (enforces `isValidId(projectId)`).

9. **Payload 9: Blanket Query Scraping Attack**
   - Attempt: LIST `/projects` without scoping `resource.data.userId == request.auth.uid`.
   - Result: PERMISSION_DENIED.

10. **Payload 10: Ownership Hijacking on Project Update**
    - Attempt: UPDATE `/projects/proj_abc` trying to change `userId` from `user_123` to `attacker_456`.
    - Result: PERMISSION_DENIED (enforces `incoming().userId == existing().userId`).

11. **Payload 11: Ghost Field Injection (Shadow Update)**
    - Attempt: UPDATE `/projects/proj_abc` injecting `__isAdminOverride: true`.
    - Result: PERMISSION_DENIED.

12. **Payload 12: Unauthenticated Audio Transcription Insertion**
    - Attempt: POST `/audioTranscriptions/audio_1` with `auth == null`.
    - Result: PERMISSION_DENIED.
