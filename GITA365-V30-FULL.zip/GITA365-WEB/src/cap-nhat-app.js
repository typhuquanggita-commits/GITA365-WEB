/* Filled by tao-site.mjs; source-mode runs do not poll deployments. */
'use strict';
(function(){
var G=window.G,build='__GITA_RELEASE_ID__',checking=false,shown=false;
async function check(){if(checking||shown||build.indexOf('__')===0||document.hidden)return;checking=true;
 try{var r=await fetch('version.json?fresh='+Date.now(),{cache:'no-store',signal:AbortSignal.timeout(12000)});if(!r.ok)return;var v=await r.json();if(v.schema!=='gita.release.v1'||!/^[a-f0-9]{20}$/.test(v.build)||v.build===build)return;
 shown=true;var box=document.createElement('aside');box.setAttribute('role','status');box.style.cssText='position:fixed;bottom:16px;left:16px;right:16px;z-index:99999;background:#123c36;color:white;padding:16px;border-radius:12px;box-shadow:0 4px 20px #0005';var text=document.createElement('p');text.textContent='GITA365 có bản mới. Lưu bản sao công việc trước khi tải lại.';box.appendChild(text);var button=document.createElement('button');button.className='btn';button.textContent='Đã lưu · tải bản mới';button.onclick=async function(){button.disabled=true;try{if('serviceWorker' in navigator){var reg=await navigator.serviceWorker.getRegistration();if(reg)await reg.update();}}catch(e){}location.reload();};box.appendChild(button);var later=document.createElement('button');later.className='btn';later.textContent='Để sau';later.onclick=function(){box.remove();};box.appendChild(later);document.body.appendChild(box);
 }catch(e){/* Offline is not an update failure. */}finally{checking=false;}}
G.kiemBanMoi=check;window.addEventListener('load',check);document.addEventListener('visibilitychange',check);setInterval(check,300000);
})();
