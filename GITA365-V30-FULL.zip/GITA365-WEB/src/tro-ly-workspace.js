/* GITA Chat workspace. All transcripts, document text and connection tokens
   live only in this tab. No automatic persistence and no remote model calls. */
'use strict';
(function(){
var G=window.G, U=G.U, h=U.h, threads=[], current=null, seq=0, epoch=0, request=null;
var connection={token:'',models:[],model:'',mode:'gita'}, ENDPOINT='http://127.0.0.1:8767';
var baseAsk=G.chatHoi, baseView=G.VIEWS['tro-ly'];
var stopWords=new Set('va la cua cho voi mot nhung cac toi ban minh gi duoc co khong trong nay ve thi nhu de da se tai sao the nao'.split(' '));
function normal(s){return String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').toLowerCase();}
function words(s){return normal(s).split(/[^a-z0-9]+/).filter(function(t){return t.length>1&&!stopWords.has(t);});}
function staff(){return !!(G.S&&G.S.acc&&/^R(?:0[1-9]|1[0-2])$/.test(G.S.role||''))&&!G.LA_MAY_KHACH&&!(G.LA_KHACH&&G.LA_KHACH());}
function make(){return {id:'c'+(++seq),title:'Cuộc trò chuyện mới',messages:[],context:null,docs:[],draft:'',revision:0,updated:Date.now()};}
function ensure(){if(!current){current=make();current.messages=G.CHAT||[];threads.push(current);}return current;}
function sync(){var c=ensure();c.messages=G.CHAT;c.context=G.chatLayNguCanh();c.updated=Date.now();if(c.title==='Cuộc trò chuyện mới'){var m=c.messages.find(function(x){return x.ai==='toi';});if(m)c.title=m.loi.slice(0,64);}}
function repaint(){if(G.S&&G.S.view==='tro-ly'&&G.render)G.render();else if(G.veChat)G.veChat();}
function panels(){var e=document.getElementById('gchatThreads');if(e)e.innerHTML=threadRows((document.getElementById('gchatSearch')||{}).value||'');e=document.getElementById('gchatDocs');if(e)e.innerHTML=docRows();e=document.getElementById('gchatStop');if(e)e.hidden=!request;}
function saveDraft(){var e=document.getElementById('aiQ');if(e)ensure().draft=e.value;}
G.chatDungMoHinh=function(){if(request){var r=request;request=null;r.answer.trangThai='stopped';r.controller.abort();}if(G.chatNgungDoc)G.chatNgungDoc();if(G.ngungMic)G.ngungMic();panels();};
G.chatPhienMoi=function(){if(threads.length>=30){U.toast('Phiên này tối đa 30 cuộc trò chuyện. Xóa một cuộc cũ để tiếp tục.','err');return;}saveDraft();sync();G.chatDungMoHinh();current=make();threads.unshift(current);G.chatDatPhien(current.messages);repaint();};
G.chatMoPhien=function(id){var next=threads.find(function(c){return c.id===id;});if(!next||next===current)return;saveDraft();sync();G.chatDungMoHinh();current=next;G.chatDatPhien(next.messages,next.context);repaint();};
G.chatDonTatCa=function(){epoch++;G.chatDungMoHinh();threads=[];current=null;connection={token:'',models:[],model:'',mode:'gita'};G.chatDatPhien([]);};
G.chatXoa=function(){G.chatDungMoHinh();var c=ensure();c.revision++;c.messages=[];c.context=null;c.docs=[];c.draft='';c.title='Cuộc trò chuyện mới';G.chatDatPhien(c.messages);repaint();};
G.chatTimTep=function(query){
  var terms=Array.from(new Set(words(query))),chunks=[];
  if(!terms.length)return [];
  ensure().docs.forEach(function(doc){doc.chunks.forEach(function(c){chunks.push({doc:doc,chunk:c,tokens:words(c.text)});});});
  var df={};terms.forEach(function(t){df[t]=chunks.filter(function(c){return c.tokens.indexOf(t)>=0;}).length;});
  var avg=chunks.reduce(function(n,c){return n+c.tokens.length;},0)/(chunks.length||1);
  return chunks.map(function(c){var score=0,hits=0;
    terms.forEach(function(t){var tf=c.tokens.filter(function(w){return w===t;}).length;if(tf){hits++;score+=Math.log(1+(chunks.length-df[t]+0.5)/(df[t]+0.5))*tf*2.2/(tf+1.2*(0.25+0.75*c.tokens.length/(avg||1)));}});
    return {label:c.doc.name+' · '+(c.chunk.page?'trang '+c.chunk.page:'đoạn '+c.chunk.part),text:c.chunk.text,score:score,hits:hits};
  }).filter(function(c){return c.hits>=Math.min(2,terms.length);}).sort(function(a,b){return b.score-a.score;}).slice(0,4).map(function(c,i){return {id:'S'+(i+1),label:c.label,text:c.text};});
};
G.chatVeNguon=function(refs){if(!refs||!refs.length)return '';return '<details class="gchat-sources"><summary>Nguồn tham khảo ('+refs.length+')</summary>'+refs.map(function(s){return '<article><b>['+h(s.id)+'] '+h(s.label)+'</b><blockquote>'+h(s.text)+'</blockquote></article>';}).join('')+'</details>';};
function chunks(pages){var result=[];pages.forEach(function(p){var text=String(p.text||'').replace(/\r\n?/g,'\n').trim();for(var i=0;i<text.length;i+=850){result.push({text:text.slice(i,i+1000),page:p.page||null,part:result.length+1});if(i+1000>=text.length)break;}});return result;}
G.chatThemVanBan=function(name,pages,target){
  target=target||ensure();if(!threads.includes(target))throw Error('Cuộc trò chuyện đã đóng.');
  if(target.docs.length>=8)throw Error('Mỗi cuộc trò chuyện tối đa 8 tài liệu.');
  var count=pages.reduce(function(n,p){return n+String(p.text||'').length;},0);
  var total=target.docs.reduce(function(n,d){return n+d.characters;},0);
  if(count>500000||total+count>1000000)throw Error('Tối đa 500.000 ký tự/tệp và 1 triệu ký tự/cuộc trò chuyện.');
  var parts=chunks(pages);if(!parts.length)throw Error('Tệp chưa có chữ để tra cứu.');
  var doc={id:'d'+(++seq),name:String(name).slice(0,180),characters:count,chunks:parts};target.docs.push(doc);return doc.id;
};
async function responseJSON(response){var body=await response.json();if(!response.ok)throw Error(body.error||'Không kết nối được máy cục bộ.');return body;}
async function importFile(file,target,stamp){
  if(!file)return;
  var revision=target.revision;
  var pdf=/\.pdf$/i.test(file.name);if(!pdf&&!/\.(txt|md|csv|json)$/i.test(file.name))throw Error('Chọn PDF, TXT, MD, CSV hoặc JSON.');
  if(file.size>(pdf?10:1)*1024*1024)throw Error(pdf?'PDF tối đa 10 MB.':'Tệp văn bản tối đa 1 MB.');
  var pages;
  if(pdf){
    if(!staff()||!connection.token)throw Error('PDF cần kết nối máy cục bộ ở phần bên dưới (dành cho đội ngũ).');
    var data=await responseJSON(await fetch(ENDPOINT+'/v1/pdf',{method:'POST',headers:{'Authorization':'Bearer '+connection.token,'Content-Type':'application/pdf'},body:file,signal:AbortSignal.timeout(30000),credentials:'omit',cache:'no-store'}));
    pages=data.pages;U.toast('Đã đọc PDF, tối đa 100 trang đầu. PDF scan cần OCR trước.','ok');
  }else{var text=await file.text();if(text.indexOf('\u0000')>=0)throw Error('Tệp nhị phân không được hỗ trợ.');pages=[{text:text}];}
  if(stamp!==epoch||!threads.includes(target)||target.revision!==revision)return;
  G.chatThemVanBan(file.name,pages,target);panels();
}
function docRows(){var ds=ensure().docs;return ds.length?ds.map(function(d){return '<div class="gchat-doc"><span>'+h(d.name)+'<small>'+d.chunks.length+' đoạn</small></span><button type="button" class="btn ghost sm" data-gchat-remove="'+d.id+'" aria-label="Xóa '+h(d.name)+'">×</button></div>';}).join(''):'<p class="tiny dim">Chưa có tài liệu đính kèm.</p>';}
function threadRows(query){var q=normal(query);return threads.filter(function(c){return !q||normal(c.title+' '+c.messages.map(function(m){return m.loi||m.dap&&m.dap.cucBo||m.dap&&m.dap.loi||'';}).join(' ')).includes(q);}).map(function(c){return '<button type="button" class="gchat-thread'+(c===current?' active':'')+'" data-gchat-open="'+c.id+'" aria-pressed="'+(c===current)+'"><b>'+h(c.title)+'</b><small>'+c.messages.filter(function(m){return m.ai==='toi';}).length+' câu hỏi · '+c.docs.length+' tài liệu</small></button>';}).join('')||'<p class="tiny dim">Không tìm thấy cuộc trò chuyện.</p>';}
function panelHTML(){ensure();return '<section class="card pad-sm gchat-workspace"><div class="row wrap"><b>Cuộc trò chuyện</b><button class="btn sm" type="button" data-gchat="new">+ Mới</button></div><input class="gchat-search" id="gchatSearch" type="search" placeholder="Tìm trong phiên này…" aria-label="Tìm cuộc trò chuyện"><div id="gchatThreads">'+threadRows('')+'</div><div class="row wrap"><button class="btn ghost sm" data-gchat="rename">Đổi tên</button><button class="btn ghost sm" data-gchat="delete">Xóa cuộc này</button></div><p class="tiny dim">Lịch sử và tài liệu chỉ giữ trong tab này. Tải bản sao trước khi đóng.</p></section>'+
    '<section class="card pad-sm gchat-workspace"><b>Tài liệu cho cuộc này</b><label class="gchat-upload">Thêm PDF / TXT / MD / CSV / JSON<input id="gchatUpload" type="file" accept=".pdf,.txt,.md,.csv,.json"></label><div id="gchatDocs">'+docRows()+'</div><p class="tiny dim">Văn bản được tra trên thiết bị. PDF dùng máy cục bộ và chỉ đọc 100 trang đầu.</p></section>'+
    (staff()?'<section class="card pad-sm gchat-workspace"><b>Mô hình cục bộ</b><p class="tiny dim">Khởi động GITA Chat và Ollama trên máy này, rồi nhập mã kết nối. Thiết lập chỉ giữ trong phiên.</p><input id="gchatToken" type="password" autocomplete="off" placeholder="Mã kết nối" aria-label="Mã kết nối cục bộ"><button class="btn sm" data-gchat="connect">Kết nối / làm mới</button><label>Chế độ<select id="gchatMode"><option value="gita"'+(connection.mode==='gita'?' selected':'')+'>Tra kho GITA</option><option value="local"'+(connection.mode==='local'?' selected':'')+'>Mô hình cục bộ</option></select></label><label>Mô hình<select id="gchatModel">'+connection.models.map(function(m){return '<option value="'+h(m)+'"'+(m===connection.model?' selected':'')+'>'+h(m)+'</option>';}).join('')+'</select></label><p class="tiny dim">'+(connection.token?'Đã kết nối companion; mô hình cần được tải trong Ollama.':'Chưa kết nối.')+'</p></section>':'');}
G.VIEWS['tro-ly']=function(){ensure();var html=baseView().replace('<div class="cs-ben">','<div class="cs-ben">'+panelHTML()+(G.chatLivePanel?G.chatLivePanel():''));
  html=html.replace('<div id="chKhung"','<div class="gchat-bar">'+(staff()?'<button class="btn ghost sm" data-v="v30">Bàn sản xuất V30</button><button class="btn ghost sm" data-gchat="plan">Giao việc cho bộ não</button><button class="btn ghost sm" data-v="dieu-phoi">Sổ điều phối</button>':'')+'<button class="btn ghost sm" data-gchat="new">+ Cuộc mới</button><button class="btn ghost sm" id="gchatStop" data-gchat="stop"'+(request?'':' hidden')+'>Dừng trả lời</button><button class="btn ghost sm" data-gchat="retry">Thử lại câu cuối</button><span class="tiny dim">'+h(connection.mode==='local'&&staff()?'Mô hình: '+connection.model:'Tra kho trên thiết bị')+'</span></div><div id="chKhung"');
  var draft=current.draft,renderId=current.id,renderEpoch=epoch;setTimeout(function(){var el=document.getElementById('aiQ');if(el&&draft&&current&&current.id===renderId&&epoch===renderEpoch){el.value=draft;if(G.aiOCao)G.aiOCao(el);}},0);return html;
};
function sources(q){var out=G.chatTimTep(q);(G.aiTra?G.aiTra(q):[]).filter(function(n){return !G.khachMoDuoc||G.khachMoDuoc(n.loai,n.ma);}).slice(0,4).forEach(function(n){out.push({label:String(n.ma+' · '+n.ten).slice(0,240),text:String(n.tom||n.ten).slice(0,1600)});});return out.slice(0,8).map(function(s,i){return {id:'S'+(i+1),label:s.label,text:s.text};});}
async function localAsk(q,project){
  var c=ensure(),stamp=epoch,refs=project?project.sources:sources(q),history=c.messages.filter(function(m){return m.ai==='toi'||m.dap&&m.dap.cucBo;}).slice(-10).map(function(m){return {role:m.ai==='toi'?'user':'assistant',content:String(m.loi||m.dap.cucBo).slice(0,3500)};});
  if(project)history=[];
  history.push({role:'user',content:q});
  var answer={cucBo:'',trangThai:'streaming',model:connection.model,tepNguon:refs,nguon:[]};
  c.messages.push({ai:'toi',loi:q,luc:new Date()},{ai:'trolY',dap:answer,luc:new Date()});G.CHAT=c.messages;
  var active={controller:new AbortController(),answer:answer};request=active;sync();panels();G.veChat();
  var timer=setTimeout(function(){active.controller.abort();},120000),lastPaint=0,reader;
  try{
    var response=await fetch(ENDPOINT+'/v1/chat',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+connection.token},body:JSON.stringify({model:connection.model,messages:history,sources:refs}),signal:active.controller.signal,credentials:'omit',cache:'no-store'});
    if(!response.ok){await responseJSON(response);}
    if(!response.body)throw Error('Trình duyệt không hỗ trợ nhận phản hồi từng phần.');
    reader=response.body.getReader();var decoder=new TextDecoder(),pending='',done=false;
    function line(s){if(!s.trim())return;var event=JSON.parse(s);if(event.error)throw Error(event.error);if(event.delta){answer.cucBo+=event.delta;if(answer.cucBo.length>64000)throw Error('Câu trả lời quá dài.');}if(event.done)done=true;}
    while(true){var part=await reader.read();if(epoch!==stamp||request!==active)break;if(part.done){pending+=decoder.decode();if(pending.trim())line(pending);break;}pending+=decoder.decode(part.value,{stream:true});if(pending.length>128000)throw Error('Phản hồi quá dài.');var end;while((end=pending.indexOf('\n'))>=0){line(pending.slice(0,end));pending=pending.slice(end+1);}if(Date.now()-lastPaint>90){G.veChat();lastPaint=Date.now();}}
    if(request===active){if(!done)throw Error('Kết nối ngắt trước khi hoàn tất.');answer.trangThai='done';}
  }catch(e){if(epoch===stamp&&request===active){answer.trangThai=active.controller.signal.aborted?'stopped':'error';answer.loiLoi=active.controller.signal.aborted?'Đã dừng hoặc hết thời gian chờ.':String(e.message||e);}}
  finally{clearTimeout(timer);if(reader)try{await reader.cancel();}catch(e){}if(request===active)request=null;if(epoch===stamp){panels();G.veChat();}}
  if(project){if(epoch!==stamp||answer.trangThai!=='done')throw Error(answer.loiLoi||'Đã hủy biên tập.');return answer.cucBo;}
}
G.chatBienTapDuAn=async function(prompt,refs){
  if(!staff())throw Error('Chỉ nhân sự được dùng biên tập cục bộ.');
  if(request)throw Error('Mô hình đang bận. Dừng câu trả lời hiện tại trước.');
  if(!connection.token||!connection.model)throw Error('Kết nối mô hình cục bộ trong chatbot trước.');
  if(typeof prompt!=='string'||prompt.length>12000||!Array.isArray(refs)||refs.length>8)throw Error('Brief quá dài. Rút gọn trước khi biên tập.');
  if(threads.length>=30)throw Error('Xóa bớt cuộc chat trước khi biên tập.');
  G.chatPhienMoi();return localAsk(prompt,{sources:refs});
};
G.chatHoi=function(q){
  q=String(q||'').trim();if(!q)return false;ensure();
  // Always run the established emergency handoff, even at conversation limits.
  if(G.aiCoKhan&&G.aiCoKhan(q)){G.chatDungMoHinh();baseAsk(q);current.draft='';sync();panels();return true;}
  if(q.length>6000){U.toast('Câu hỏi tối đa 6.000 ký tự.','err');return false;}
  if(G.CHAT.length>=240){U.toast('Cuộc này đã dài. Mở cuộc trò chuyện mới để tiếp tục.','err');return false;}
  if(request){U.toast('Đang trả lời. Bấm Dừng trước khi gửi câu mới.','err');return false;}
  if(connection.mode==='local'&&staff()){
    if(!connection.token||!connection.model){U.toast('Kết nối máy cục bộ và chọn mô hình trước.','err');return false;}
    if(G.chatNgungDoc)G.chatNgungDoc();current.draft='';localAsk(q).catch(function(e){U.toast(String(e.message||e),'err');});return true;
  }
  baseAsk(q);current.draft='';sync();panels();return true;
};
// Public read-only snapshot for diagnostics/tests; never includes the connection token.
G.chatNhanBrief=function(value){
  if(!staff())return false;
  if(typeof value!=='string'||value.length>6000){U.toast('Yêu cầu vượt 6.000 ký tự. Tải yêu cầu biên tập rồi đính kèm dưới dạng tài liệu trong chatbot.','err');return false;}
  if(threads.length>=30){U.toast('Xóa một cuộc trò chuyện cũ trước.','err');return false;}
  G.chatPhienMoi();ensure().draft=value;G.go('tro-ly');return true;
};
G.chatTrangThai=function(){return {active:ensure().id,count:threads.length,documents:current.docs.length,busy:!!request,mode:connection.mode};};
G.chatLapViec=function(){
  if(!staff())return;
  var last=G.CHAT.slice().reverse().find(function(m){return m.ai==='toi';});
  var agents=G.DP_TRO_LY||[];
  if(!agents.length){U.toast('Danh sách agent chưa được nạp.','err');return;}
  G.U.modal('<h2>Giao việc cho bộ não GITA</h2><p class="tiny dim">Biên tập yêu cầu trước khi lưu vào sổ việc. Việc mới được tạo ở trạng thái chờ; chạy agent và duyệt kết quả tại Điều phối.</p><div class="gchat-workspace">'+
    '<label>Agent phụ trách<select id="gchatTaskAgent">'+agents.map(function(a){return '<option value="'+h(a.phucVu)+'">'+h(a.ma+' · '+a.phucVu)+'</option>';}).join('')+'</select></label>'+
    '<label>Tiêu đề<input id="gchatTaskTitle" maxlength="160" value="'+h(last?last.loi.slice(0,160):'')+'"></label>'+
    '<label>Mục tiêu<textarea id="gchatTaskGoal" rows="3" maxlength="1500">'+h(last?last.loi.slice(0,1500):'')+'</textarea></label>'+
    '<label>Đầu ra và tiêu chí hoàn thành<textarea id="gchatTaskChecks" rows="3" maxlength="1500" placeholder="Ví dụ: kịch bản 5 phút, 3 phần, có nguồn và bước kiểm tra"></textarea></label>'+
    '<label>Giới hạn / thông tin còn thiếu<textarea id="gchatTaskLimits" rows="2" maxlength="600" placeholder="Thời hạn, chi phí, dữ liệu cần bổ sung…"></textarea></label>'+
    '<p id="gchatTaskResult" role="status"></p><button type="button" class="btn pri" data-gchat="save-task">Lưu việc vào sổ điều phối</button><button type="button" class="btn" data-act="dong-modal">Đóng</button></div>');
};
document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-gchat],[data-gchat-open],[data-gchat-remove]');if(!b)return;
  var id=b.getAttribute('data-gchat-open');if(id){G.chatMoPhien(id);return;}
  id=b.getAttribute('data-gchat-remove');if(id){ensure().docs=current.docs.filter(function(d){return d.id!==id;});panels();return;}
  var action=b.getAttribute('data-gchat');
  if(action==='new')G.chatPhienMoi();
  if(action==='plan')G.chatLapViec();
  if(action==='save-task'&&staff()){
    var title=document.getElementById('gchatTaskTitle').value.trim(),goal=document.getElementById('gchatTaskGoal').value.trim(),checks=document.getElementById('gchatTaskChecks').value.trim(),limits=document.getElementById('gchatTaskLimits').value.trim(),gate=document.getElementById('gchatTaskAgent').value;
    var status=document.getElementById('gchatTaskResult'),taskEpoch=epoch;
    if(!title||!goal||!checks){status.textContent='Điền tiêu đề, mục tiêu và tiêu chí hoàn thành.';return;}
    if(!G.goiMayChu){status.textContent='Chưa nối máy chủ GITA.';return;}
    var content='## Mục tiêu\n'+goal+'\n\n## Đầu ra và tiêu chí hoàn thành\n'+checks+'\n\n## Giới hạn và dữ kiện thiếu\n'+(limits||'Chưa khai báo.')+'\n\nNguồn giao việc: Trợ lý GITA; người dùng đã biên tập.';
    if(title.length>160||content.length>4000){status.textContent='Nội dung vượt giới hạn của sổ việc.';return;}
    b.disabled=true;status.textContent='Đang lưu…';
    G.goiMayChu('viecDieuPhoi',{hanhDong:'tao',cua:gate,tieuDe:title,noiDung:content}).then(function(data){if(taskEpoch!==epoch)return;if(!data||!data.ok)throw Error(data&&data.error||'Chưa lưu được việc.');G.dpViec=null;status.textContent='Đã tạo việc '+data.id+'. Mở Điều phối để chạy agent và theo dõi.';}).catch(function(e){if(taskEpoch!==epoch)return;status.textContent=String(e.message||e);b.disabled=false;});
  }
  if(action==='stop'){G.chatDungMoHinh();G.veChat();}
  if(action==='rename'){var name=window.prompt('Tên cuộc trò chuyện',ensure().title);if(name&&name.trim()){current.title=name.trim().slice(0,64);panels();}}
  if(action==='delete'&&window.confirm('Xóa cuộc trò chuyện và tài liệu đính kèm khỏi phiên này?')){G.chatDungMoHinh();threads=threads.filter(function(c){return c!==current;});current=threads[0]||make();if(!threads.length)threads.push(current);G.chatDatPhien(current.messages,current.context);repaint();}
  if(action==='retry'){var last=G.CHAT.slice().reverse().find(function(m){return m.ai==='toi';});if(last){G.chatDungMoHinh();G.chatHoi(last.loi);}else U.toast('Chưa có câu hỏi để thử lại.','err');}
  if(action==='connect'&&staff()){
    var token=document.getElementById('gchatToken').value.trim()||connection.token,stamp=epoch;
    if(token.length<32){U.toast('Nhập mã kết nối do máy cục bộ cung cấp.','err');return;}
    b.disabled=true;
    fetch(ENDPOINT+'/v1/status',{headers:{'Authorization':'Bearer '+token},signal:AbortSignal.timeout(8000),credentials:'omit',cache:'no-store'}).then(responseJSON).then(function(data){if(epoch!==stamp)return;connection.token=token;connection.models=data.models;connection.model=data.models[0]||'';saveDraft();repaint();U.toast('Đã kết nối máy cục bộ.','ok');}).catch(function(e){if(epoch===stamp)U.toast(String(e.message||e),'err');}).finally(function(){b.disabled=false;});
  }
});
document.addEventListener('input',function(e){if(e.target.id==='gchatSearch'){var list=document.getElementById('gchatThreads');if(list)list.innerHTML=threadRows(e.target.value);}if(e.target.id==='aiQ')ensure().draft=e.target.value;});
document.addEventListener('change',function(e){var el=e.target;
  if(el.id==='gchatMode'){G.chatDungMoHinh();connection.mode=staff()&&el.value==='local'?'local':'gita';saveDraft();repaint();}
  if(el.id==='gchatModel'&&connection.models.includes(el.value))connection.model=el.value;
  if(el.id==='gchatUpload'){var file=el.files&&el.files[0],target=ensure(),stamp=epoch;el.value='';if(file){el.disabled=true;importFile(file,target,stamp).catch(function(error){if(epoch===stamp)U.toast(String(error.message||error),'err');}).finally(function(){el.disabled=false;});}}
});
})();
