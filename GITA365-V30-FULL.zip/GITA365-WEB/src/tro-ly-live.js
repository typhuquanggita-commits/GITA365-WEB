/* Owncast integration uses the official embedded player/chat pages.
   Neither GITA credentials nor private chatbot transcripts are sent to it. */
'use strict';
(function(){
var G=window.G, h=G.U.h;
G.chatOwncastURL=function(value){
  try{var u=new URL(String(value||''));
    if(u.protocol!=='https:'||u.username||u.password||u.search||u.hash||u.pathname!=='/')return '';
    return u.origin;
  }catch(e){return '';}
};
G.chatLivePanel=function(){
  var url=G.chatOwncastURL(G.OWNCAST_URL);
  return '<section class="card pad-sm gchat-workspace"><b>Lớp học trực tiếp</b><p class="tiny dim">'+
    (url?'Xem giảng viên và tham gia phòng chat lớp học. Tin nhắn trong phòng được gửi tới máy chủ Owncast của lớp.':'Lớp trực tiếp chưa được kết nối.')+
    '</p>'+(url?'<button class="btn sm pri" data-gita-live="open">Mở lớp trực tiếp</button>':'')+'</section>';
};
G.chatLiveHTML=function(){var url=G.chatOwncastURL(G.OWNCAST_URL);if(!url)return '<p>Lớp trực tiếp chưa được kết nối.</p>';
  return '<div class="gchat-live"><h2>Lớp học trực tiếp GITA</h2><p class="tiny dim">Phòng chat lớp dùng danh tính Owncast riêng. Chỉ chia sẻ nội dung phù hợp với cả lớp.</p>'+
    '<div class="gchat-live-grid"><iframe src="'+h(url)+'/embed/video?autoplay=off" title="Video lớp học trực tiếp GITA" referrerpolicy="no-referrer" allow="fullscreen; picture-in-picture" allowfullscreen></iframe>'+
    '<iframe src="'+h(url)+'/embed/chat/readwrite" title="Phòng chat lớp học GITA" referrerpolicy="no-referrer"></iframe></div>'+
    '<div class="row wrap mt"><a class="btn sm" href="'+h(url)+'" target="_blank" rel="noopener noreferrer">Mở lớp trong tab riêng</a><button class="btn sm" data-gita-live="question">Soạn câu hỏi cho trợ lý GITA</button><button class="btn sm" data-act="dong-modal">Đóng lớp</button></div>'+
    '<p class="tiny dim">Nếu khung không tải, mở lớp trong tab riêng. Trạng thái trực tiếp và kiểm duyệt chat do Owncast quản lý.</p></div>';
};
document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-gita-live]');if(!b)return;
  if(b.getAttribute('data-gita-live')==='open'&&G.chatOwncastURL(G.OWNCAST_URL)){
    if(G.chatNgungDoc)G.chatNgungDoc();if(G.ngungMic)G.ngungMic();G.U.modal(G.chatLiveHTML());
  }
  if(b.getAttribute('data-gita-live')==='question'){
    G.U.closeModal();var input=document.getElementById('aiQ');if(input){input.value='Trong buổi học, tôi muốn làm rõ: ';input.focus();if(G.aiOCao)G.aiOCao(input);}
  }
});
})();
