/* ═══════════════════════════════════════════════════════════════
   GITA STUDIO 365 — XƯỞNG DỰNG VIDEO  (9.99.94)

   Đây là **P9 của bộ đặc tả Studio** — màn chính, thứ `ST_PHAN` khai
   `chuaCo` từ 9.99.92. Dựng theo bản mẫu chạy được của chủ hệ, sau một
   lượt đo tìm ra chín lỗi và bảy chỗ đúng (`G.XU_LOI` · `G.XU_HOP`).

   ══ BỐN CHỖ CỐ Ý KHÁC BẢN MẪU ══

   1. **KHÔNG có bảng từ cấm nào ở đây.** Đèn ngôn từ gọi thẳng cửa
      `soatNoiDung` đã chạy từ 9.99.41. Bản mẫu tự dựng một `WAF` —
      và dòng regex ấy mang HAI bẫy cùng lúc: `\bhư\b` không bao giờ
      khớp (bẫy dò chữ #1 của kho), còn `\bngu\b` khớp vào "ngu|ồn"
      tức là bắt oan chính ô *Nguồn tri thức* đứng ngay bên trên.

   2. **KHÔNG gọi thẳng bộ tạo chữ ngoài lãnh thổ từ trình duyệt.**
      Chuỗi đi ra mang chủ đề, người xem và điều nhỏ của một gia đình.
      Đường ra khỏi hệ đã có cổng ẩn danh từ 9.99.62; một lời `fetch`
      trong mã trình duyệt đi vòng qua nó.

   3. **KHÔNG có `esc()` riêng.** `U.h()` đã có, và bản chép của bản
      mẫu sót dấu nháy đơn — mà lời đọc tiếng Việt đầy dấu nháy đơn.

   4. **Không sinh mã bằng `crypto.randomUUID()`.** Bản `.exe` mở tệp
      bằng `file://`, ở đó nó không tồn tại và cả xưởng ném lỗi ngay
      dòng đầu — trong khi mọi lượt thử qua https đều xanh. Đúng lớp
      lỗi nhánh `isTTY` ở 9.99.79.

   ══ CHỖ BẢN MẪU ĐÚNG VÀ KHÔNG ĐƯỢC "CẢI TIẾN" ══

   **Giọng chỉ đến từ micro người thật hoặc tệp có sẵn.** Không một
   dòng sinh giọng nào. Đó là luật C20 giữ nguyên, và nó là chỗ dễ bị
   sửa nhất ở bản sau — nên nó có một phép đo riêng ở mục 103.
   ═══════════════════════════════════════════════════════════════ */
'use strict';
var G = window.G || {}; window.G = G;
G.VIEWS = G.VIEWS || {};

(function () {
  var U = G.U, h = U.h, ic = U.ic;

  /* Mã cục bộ trong bộ nhớ — KHÔNG dùng crypto.randomUUID: nó chỉ có
     trong ngữ cảnh an toàn, và bản máy tính mở bằng file://. */
  var demMa = 0;
  function ma(tien) { demMa += 1; return tien + '-' + demMa.toString(36); }

  var KHO_HINH = function () { return G.XU_KHO_HINH || []; };
  var NGAN = function () { return G.XU_NGANKHO || []; };
  var KHUON = function () { return G.XU_KHUON || []; };

  /* ══ TRẠNG THÁI ══ */
  G.xuDA = G.xuDA || {           // dự án đang mở
    ten: 'GITA 365 — một điều nhỏ mỗi tối cùng con',
    kho: '9:16', dich: 60, khuon: 'SC2',
    nguoiXem: 'Phụ huynh chưa biết GITA', tang: 'T1 · công khai',
    dieuNho: 'Tối nay hỏi con: hôm nay chỗ nào khó nhất?',
    nguon: 'KS-04 · Triết lý Một Điều Nhỏ',
    canh: []
  };
  G.xuVat = G.xuVat || {};       // mã → {ma,ten,loai,url,el,buffer,file}
  G.xuRendererToken = G.xuRendererToken || ''; // chỉ giữ trong RAM của tab
  G.xuRenderTrangThai = G.xuRenderTrangThai || '';
  G.xuRenderLast = G.xuRenderLast || '';
  G.xuLingoLang = G.xuLingoLang || 'vi';
  G.xuAnhFile = G.xuAnhFile || null;
  G.xuAnhPreset = G.xuAnhPreset || 'post';
  G.xuAnhStatus = G.xuAnhStatus || '';
  G.xuAnhPreview = G.xuAnhPreview || '';
  G.xuAnhName = G.xuAnhName || '';
  G.xuChuDeHD = G.xuChuDeHD || 'bat-dau';
  G.xuSoat = G.xuSoat || null;   // kết quả cửa soatNoiDung
  G.xuDangSoat = false;
  G.xuGiuLai = '';               // lời khai lúc bấm Dừng khẩn

  window.addEventListener('gita:3d-capture',function(ev){
    var blob=ev&&ev.detail&&ev.detail.blob;if(!blob||blob.size>12*1024*1024)return;
    var id=ma('v'),ten=String(ev.detail.name||'gita-khung-3d.png');
    G.xuVat[id]={ma:id,ten:ten,loai:'hinh',file:blob,imageFit:'contain'};
    createImageBitmap(blob).then(function(bm){if(G.xuVat[id])G.xuVat[id].el=bm;veLai();}).catch(function(){delete G.xuVat[id];});
    U.toast('Khung 3D đã vào kho hình của Studio. Gắn khung đó vào cảnh video muốn dùng.','ok');
  });

  function tong() {
    return (G.xuDA.canh || []).reduce(function (a, c) { return a + (+c.giay || 0); }, 0);
  }
  function phut(s) {
    return Math.floor(s / 60) + 'p' + String(Math.round(s % 60)).padStart(2, '0');
  }
  function veLai() {
    if (!G.S || G.S.view !== 'studio') return;
    if (typeof document === 'undefined' || !document.getElementById('main')) return;
    G.render && G.render();
  }

  /* ══ BỘ VIẾT KỊCH BẢN — hàm ở đây, CÂU ở kho ══
     Luật 1 của kho nội dung: JSON.stringify bỏ hàm, nên phần chạy phải
     ở src/. Ngân khố câu nằm ở `G.XU_NGANKHO` để người viết nội dung
     sửa được mà không phải sửa mã. */
  function nhom(vai) {
    return NGAN().filter(function (n) { return n.vai === vai; })[0];
  }
  function lay(vai, dem) {
    var n = nhom(vai);
    if (!n || !n.cau.length) return {loi: '', chu: '', hinh: ''};
    var i = dem % n.cau.length;
    return {loi: n.cau[i], chu: (n.chuMan || [])[i] || '', hinh: n.hinh || ''};
  }
  function moiCanh(vai, giay, dem) {
    var x = lay(vai, dem);
    return {id: ma('c'), vai: vai, giay: giay,
      loi: x.loi, chuMan: x.chu, hinh: x.hinh, vatHinh: '', vatTieng: ''};
  }

  G.xuViet = function () {
    var d = G.xuDA;
    var dich = Math.max(30, Math.min(300, +d.dich || 60));
    var k = KHUON().filter(function (x) { return x.ma === d.khuon; })[0];
    var nhip = (k && k.nhip) || ['vi_sao', 'cach_lam'];
    var dem = {}, ds = [];
    function ke(vai) { dem[vai] = (dem[vai] == null ? -1 : dem[vai]) + 1; return dem[vai]; }

    ds.push(moiCanh('hook', 4, ke('hook')));
    var da = 4, i = 0, tuNhipTho = 0, chotDai = 4;

    /* Trần vòng lặp là một cái chặn THẬT, không phải phòng xa: `dich`
       tối đa 300 giây và mỗi cảnh ít nhất 3 giây, nên 120 vòng là dư —
       nhưng một vòng `while` đọc dữ liệu người nhập mà không có trần
       thì nó treo cả trang, và trang treo thì không có dòng lỗi nào. */
    var vong = 0;
    while (da < dich - chotDai - 5 && vong < 120) {
      vong += 1;
      if (tuNhipTho >= 8) {
        ds.push(moiCanh('nhip_tho', 3, ke('nhip_tho'))); da += 3; tuNhipTho = 0; continue;
      }
      var vai = nhip[i % nhip.length];
      ds.push(moiCanh(vai, 6, ke(vai))); da += 6; i += 1; tuNhipTho += 1;
    }

    var cuoi = moiCanh('cta', Math.max(3, dich - da), ke('cta'));
    if (String(d.dieuNho || '').trim()) cuoi.loi = String(d.dieuNho).trim();
    ds.push(cuoi);

    d.canh = ds;
    G.xuSoat = null;
    veLai();
  };

  G.xuThemCanh = function () {
    G.xuDA.canh.push(moiCanh('cach_lam', 6, 0)); G.xuSoat = null; veLai();
  };
  G.xuXoaCanh = function (id) {
    G.xuDA.canh = G.xuDA.canh.filter(function (c) { return c.id !== id; });
    G.xuSoat = null; veLai();
  };
  G.xuSuaCanh = function (id, o, gt) {
    var c = G.xuDA.canh.filter(function (x) { return x.id === id; })[0];
    if (!c) return;
    c[o] = (o === 'giay') ? Math.max(1, Math.min(60, +gt || 1)) : gt;
    if (o === 'loi') G.xuSoat = null;
    if (o === 'giay' || o === 'vatHinh') G.xuVe(G.xuDongHo);
    G.xuTomTat();
  };
  G.xuSuaO = function (o, gt) {
    G.xuDA[o] = gt;
    if (o === 'kho') G.xuCoManh();
    veLai();
  };

  /* Khớp giây theo độ dài giọng — một phép đo, không phải một lời khai.
     Người gõ tay con số giây thì con số ấy đúng lúc gõ và sai từ lượt
     ghi giọng sau. */
  G.xuKhopGiay = function (id) {
    var c = G.xuDA.canh.filter(function (x) { return x.id === id; })[0];
    if (!c) return;
    var v = G.xuVat[c.vatTieng];
    if (!v || !v.buffer) { U.toast('Cảnh này chưa gắn giọng.', 'err'); return; }
    c.giay = Math.round((v.buffer.duration + 0.4) * 10) / 10;
    veLai();
  };

  /* ══ ĐÈN KIỂM ĐỊNH ══
     D1 và D2 KHÔNG đo ở đây. Chúng đọc kết quả cửa `soatNoiDung` —
     mục 103 canh rằng tệp này không khai một cụm dấu hiệu nào. */
  G.xuGoiSoat = function () {
    var chu = (G.xuDA.canh || []).map(function (c) { return c.loi; })
      .filter(Boolean).join(' ');
    if (chu.trim().length < 40) {
      G.xuSoat = {ok: false, error: 'QUANGAN',
        vi: 'Lời đọc cộng lại chưa đủ 40 ký tự — cửa nội dung không soát bài quá ngắn.'};
      veLai(); return;
    }
    if (!G.goiMayChu) return;
    G.xuDangSoat = true; veLai();
    G.goiMayChu('soatNoiDung', {chu: chu, tang: G.xuDA.tang, khuon: 'BAIHOC',
      doiTuong: /công khai|phụ huynh/i.test(G.xuDA.tang) ? 'khach' : 'noiBo'})
      .then(function (x) { G.xuSoat = x; G.xuDangSoat = false; veLai(); })
      .catch(function (e) {
        G.xuSoat = {ok: false, error: String(e && e.message || e)};
        G.xuDangSoat = false; veLai();
      });
  };

  function den() {
    var d = G.xuDA, ds = d.canh || [], t = tong(), s = G.xuSoat;
    var coHinh = ds.filter(function (c) { return c.vatHinh; }).length;
    var coTieng = ds.filter(function (c) { return c.vatTieng; }).length;
    var chan = (s && s.ok && (s.cam || []).filter(function (x) { return !x.canhBao; })) || [];
    var o = [];

    o.push(!s ? {tt: 'cho', t: 'Ngôn từ qua hiến pháp nội dung', ref: 'soatNoiDung',
        n: 'Chưa soát. Bấm "Soát lời đọc" — xưởng KHÔNG tự đo, nó hỏi cửa nội dung.'}
      : !s.ok ? {tt: 'bad', t: 'Ngôn từ qua hiến pháp nội dung', ref: 'soatNoiDung',
        n: String(s.vi || s.error || 'Cửa nội dung từ chối.')}
      : {tt: chan.length ? 'bad' : 'ok', t: 'Ngôn từ qua hiến pháp nội dung', ref: 'soatNoiDung',
        n: chan.length ? chan.map(function (x) { return x.ma; }).join(' · ') + ' — ' +
             String(chan[0].vi || '').slice(0, 160)
           : 'Cửa nội dung không nêu chỗ chặn nào.'});

    o.push(!s || !s.ok ? {tt: 'cho', t: 'Câu đủ ngắn để nghe', ref: 'soatNoiDung',
        n: 'Ngưỡng câu dài nằm ở cửa nội dung, không nằm ở xưởng.'}
      : {tt: (s.cauDai && s.cauDai.length) ? 'warn' : 'ok', t: 'Câu đủ ngắn để nghe',
        ref: 'soatNoiDung',
        n: (s.cauDai && s.cauDai.length) ? s.cauDai.length + ' câu vượt ngưỡng của cửa nội dung.'
           : 'Không câu nào vượt ngưỡng.'});

    o.push({tt: (t < 30 || t > 300) ? 'bad' : 'ok', t: 'Thời lượng trong khung 30 giây – 5 phút',
      ref: 'FV-2', n: phut(t) + ' trên ' + ds.length + ' cảnh.'});

    o.push({tt: String(d.dieuNho || '').trim() ? 'ok' : 'bad', t: 'Điều nhỏ có thật',
      ref: 'TG_DIEUNHO.DN2',
      n: String(d.dieuNho || '').trim()
        ? 'Có chữ. Câu ấy có phải một việc LÀM ĐƯỢC hay không thì DN2 chốt — cấm "hiểu · nhớ · tin".'
        : 'Chưa ghi điều nhỏ người xem làm được.'});

    o.push({tt: String(d.nguon || '').trim() ? 'ok' : 'bad', t: 'Có nguồn tri thức',
      ref: 'KS-*', n: String(d.nguon || '').trim() || 'Chưa gắn nguồn.'});

    o.push({tt: !ds.length ? 'bad' : coHinh < ds.length ? 'warn' : 'ok', t: 'Hình cho từng cảnh',
      ref: 'P6', n: coHinh + '/' + ds.length + ' cảnh đã gắn hình. Cảnh trống dùng nền ' +
        'ánh đèn — vàng, không đỏ: nền ánh đèn là một lựa chọn hợp lệ.'});

    o.push({tt: coTieng ? 'ok' : 'warn', t: 'Giọng đọc', ref: 'ST_VA.SV1',
      n: coTieng ? coTieng + '/' + ds.length + ' cảnh có giọng.'
        : 'Chưa có giọng — video xuất ra sẽ im tiếng. Xưởng KHÔNG sinh giọng: luật C20 ' +
          'nói máy TRỘN, không SINH.'});

    o.push({tt: 'nguoi', t: 'Chất ấm — nghe có như người quen nói không', ref: 'LT_AM.WS-3',
      n: 'Một người nghe hết rồi ký tên, và người ấy không được là người dựng. Máy chấm ' +
        'được từ ngữ và nhịp câu; nó KHÔNG chấm được câu này, và câu trả lời của máy cho ' +
        'nó nghe y hệt câu trả lời thật.'});

    if (G.xuGiuLai) o.push({tt: 'bad', t: 'Video đang bị giữ lại', ref: 'LT_MOC.G1-4',
      n: G.xuGiuLai});
    return o;
  }
  function congMo() {
    return !den().some(function (l) { return l.tt === 'bad'; });
  }

  /* ══ VẼ 1080p ══ */
  G.xuDongHo = 0;
  function khung() {
    var k = KHO_HINH().filter(function (x) { return x.ma === G.xuDA.kho; })[0];
    return (k && k.r) || [1080, 1920];
  }
  G.xuCoManh = function () {
    var cv = document.getElementById('xu-man'); if (!cv) return;
    var r = khung(); cv.width = r[0]; cv.height = r[1];
    G.xuVe(G.xuDongHo);
  };
  function canhTai(giay) {
    var ds = G.xuDA.canh || [], a = 0;
    for (var i = 0; i < ds.length; i++) {
      var b = a + (+ds[i].giay || 0);
      if (giay < b || i === ds.length - 1) return {i: i, c: ds[i], a: a, b: b};
      a = b;
    }
    return null;
  }
  G.xuVe = function (giay) {
    var cv = document.getElementById('xu-man'); if (!cv) return;
    var ct = cv.getContext('2d'), W = cv.width, H = cv.height, u = W / 1080;
    ct.fillStyle = '#0B0E15'; ct.fillRect(0, 0, W, H);
    var t = tong();

    /* Chưa có cảnh thì DỪNG ở đây. Bản mẫu chia `giay / total()` và
       `0/0` ra NaN — fillRect với NaN không ném lỗi, nó vẽ ra không có
       gì, nên chỗ hỏng im lặng. */
    if (!t) {
      ct.fillStyle = 'rgba(255,255,255,.55)'; ct.textAlign = 'center';
      ct.font = '600 ' + (44 * u) + 'px sans-serif';
      ct.fillText('Chưa có cảnh nào', W / 2, H / 2);
      return;
    }
    var cur = canhTai(Math.min(giay, t)); if (!cur) return;
    var c = cur.c, p = (cur.b - cur.a) ? (giay - cur.a) / (cur.b - cur.a) : 0;

    var v = G.xuVat[c.vatHinh];
    if (v && v.loai === 'hinh' && v.el) phu(ct, v.el, W, H, 1.06 + 0.08 * p);
    else nenDen(ct, W, H, cur.i, p);

    var g = ct.createLinearGradient(0, H * 0.45, 0, H);
    g.addColorStop(0, 'rgba(6,8,12,0)'); g.addColorStop(1, 'rgba(6,8,12,.82)');
    ct.fillStyle = g; ct.fillRect(0, H * 0.45, W, H * 0.55);

    if (c.chuMan) {
      ct.globalAlpha = Math.min(1, (giay - cur.a) / 0.45);
      ct.textAlign = 'center'; ct.fillStyle = '#FFF6E8';
      xuong(ct, c.chuMan, W / 2, H * (c.vai === 'cta' ? 0.46 : 0.34), W * 0.82, 112 * u, 800);
      ct.globalAlpha = 1;
    }
    if (c.loi) karaoke(ct, c, giay - cur.a, W, H, u);

    ct.fillStyle = 'rgba(255,255,255,.14)'; ct.fillRect(0, 0, W, 6 * u);
    ct.fillStyle = '#E8A33C'; ct.fillRect(0, 0, W * (giay / t), 6 * u);
    ct.textAlign = 'right'; ct.fillStyle = 'rgba(255,255,255,.6)';
    ct.font = '700 ' + (34 * u) + 'px sans-serif';
    ct.fillText('GITA 365', W - 40 * u, H - 46 * u);

    var dh = document.getElementById('xu-gio');
    if (dh) dh.textContent = giay.toFixed(1) + ' / ' + t.toFixed(1) + 's';
  };
  function nenDen(ct, W, H, i, p) {
    var am = 0.3 + 0.5 * ((i % 5) / 4);
    var g = ct.createRadialGradient(W / 2, H * (0.36 - 0.03 * p), 20, W / 2, H / 2, H * 0.82);
    g.addColorStop(0, 'rgb(' + ((232 * am + 22) | 0) + ',' + ((163 * am + 20) | 0) +
      ',' + ((60 * am + 28) | 0) + ')');
    g.addColorStop(1, '#0B0E15');
    ct.fillStyle = g; ct.fillRect(0, 0, W, H);
  }
  function phu(ct, el, W, H, ti) {
    var iw = el.width || el.naturalWidth, ih = el.height || el.naturalHeight;
    if (!iw || !ih) return;
    var r = Math.max(W / iw, H / ih) * ti, w = iw * r, hh = ih * r;
    ct.drawImage(el, (W - w) / 2, (H - hh) / 2, w, hh);
  }
  function xuong(ct, chu, x, y, rong, co, dam) {
    ct.font = dam + ' ' + co + 'px sans-serif';
    var ws = String(chu).split(' '), d = '', yy = y;
    ws.forEach(function (w) {
      if (ct.measureText(d + w).width > rong && d) { ct.fillText(d.trim(), x, yy); yy += co * 1.1; d = ''; }
      d += w + ' ';
    });
    ct.fillText(d.trim(), x, yy);
  }
  function karaoke(ct, c, cucBo, W, H, u) {
    var ws = String(c.loi).trim().split(/\s+/).filter(Boolean);
    if (!ws.length) return;
    var moi = (+c.giay || 1) / ws.length, dang = Math.floor(cucBo / moi);
    ct.font = '700 ' + (56 * u) + 'px sans-serif';
    var rongMax = W * 0.84, dong = [[]], cong = 0;
    ws.forEach(function (w) {
      var ww = ct.measureText(w + ' ').width;
      if (cong + ww > rongMax && dong[dong.length - 1].length) { dong.push([]); cong = 0; }
      dong[dong.length - 1].push(w); cong += ww;
    });
    var hien = dong.slice(0, 3), y0 = H * 0.845 - (hien.length - 1) * 34 * u, k = 0;
    hien.forEach(function (d, li) {
      var ws2 = d.map(function (w) { return ct.measureText(w + ' ').width; });
      var x = W / 2 - ws2.reduce(function (m, n) { return m + n; }, 0) / 2;
      ct.textAlign = 'left';
      d.forEach(function (w, j) {
        ct.fillStyle = k === dang ? '#FFD37A' : k < dang ? 'rgba(255,255,255,.95)'
          : 'rgba(255,255,255,.45)';
        ct.fillText(w, x, y0 + li * 74 * u); x += ws2[j]; k += 1;
      });
    });
  }

  /* ══ TIẾNG ══ */
  var AC = null, nut = [];
  function ac() { return (AC = AC || new (window.AudioContext || window.webkitAudioContext)()); }
  function xepTieng(dich) {
    dungTieng();
    var a = ac(), t0 = a.currentTime + 0.08, at = 0;
    (G.xuDA.canh || []).forEach(function (c) {
      var v = G.xuVat[c.vatTieng];
      if (v && v.buffer) {
        var n = a.createBufferSource(); n.buffer = v.buffer;
        n.connect(dich); n.start(t0 + at); nut.push(n);
      }
      at += (+c.giay || 0);
    });
  }
  function dungTieng() { nut.forEach(function (n) { try { n.stop(); } catch (e) {} }); nut = []; }

  var chay = false, raf = 0, mocTruoc = 0;
  G.xuXem = function () {
    if (!tong()) return;
    if (G.xuDongHo >= tong()) G.xuDongHo = 0;
    chay = true; mocTruoc = performance.now();
    ac().resume(); xepTieng(ac().destination);
    raf = requestAnimationFrame(nhip);
  };
  G.xuDung = function () { chay = false; cancelAnimationFrame(raf); dungTieng(); };
  function nhip(gio) {
    if (!chay) return;
    G.xuDongHo += (gio - mocTruoc) / 1000; mocTruoc = gio;
    if (G.xuDongHo >= tong()) { G.xuDongHo = tong(); G.xuVe(G.xuDongHo); G.xuDung(); return; }
    G.xuVe(G.xuDongHo);
    raf = requestAnimationFrame(nhip);
  }
  G.xuTua = function (v) {
    G.xuDung(); G.xuDongHo = tong() * (+v / 100); G.xuVe(G.xuDongHo);
  };

  /* ══ DỪNG KHẨN — GIỮ LẠI, không chỉ tạm dừng ══
     Một nút dừng chỉ tạm dừng thì nó không phải dừng khẩn: bấm xong
     người ta bấm chạy lại và video vẫn ra. Ở đây nó bật một đèn ĐỎ,
     và đèn đỏ đóng cổng xuất. */
  G.xuDungKhan = function () {
    if (G.xuGiuLai) {
      G.xuGiuLai = '';
      U.toast('Mở lại — nhớ ghi một dòng vào sổ tay (RM-8).', 'ok');
      veLai(); return;
    }
    G.xuDung();
    if (G.xuGhi && G.xuGhi.state === 'recording') { G.xuHuyXuat = true; G.xuGhi.stop(); }
    G.xuGiuLai = 'Dừng khẩn lúc ' + G.xuDongHo.toFixed(1) + ' giây — video giữ lại chờ rà. ' +
      'Cổng xuất đóng cho tới khi có người mở lại.';
    veLai();
  };

  /* ══ KHO VẬT LIỆU — nằm trong máy, không tải lên đâu ══ */
  G.xuNhanTep = function (ds) {
    if (ds.length > 40) { U.toast('Mỗi lượt chọn tối đa 40 ảnh/tiếng.','err'); return; }
    var total=Array.prototype.reduce.call(ds,function(a,f){return a+(+f.size||0);},0);
    if(total>200*1024*1024||Array.prototype.some.call(ds,function(f){return f.size>80*1024*1024;})) {
      U.toast('Media tối đa 80 MB mỗi tệp và 200 MB mỗi lượt.','err'); return;
    }
    var xong = 0, n = ds.length;
    function het() { xong += 1; if (xong >= n) veLai(); }
    Array.prototype.forEach.call(ds, function (f) {
      var id = ma('v');
      /* KHÔNG `URL.createObjectURL` — mục 8 và 18 cấm nó trong `src/`,
         và cấm đúng: một địa chỉ blob là một tệp tải về được. Ảnh đi
         thẳng vào `createImageBitmap`, tiếng đi thẳng vào
         `decodeAudioData`. Cả hai đều KHÔNG sinh ra một địa chỉ nào. */
      if (/^image\//.test(f.type)) {
        G.xuVat[id] = {ma: id, ten: f.name, loai: 'hinh', file:f};
        createImageBitmap(f).then(function (bm) { G.xuVat[id].el = bm; het(); })
          .catch(function () { delete G.xuVat[id]; het(); });
      } else if (/^audio\//.test(f.type)) {
        G.xuVat[id] = {ma: id, ten: f.name, loai: 'tieng', file:f};
        f.arrayBuffer().then(function (b) { return ac().decodeAudioData(b); })
          .then(function (buf) { G.xuVat[id].buffer = buf; het(); })
          .catch(function () { delete G.xuVat[id]; het(); });
      } else {
        /* Tệp PHIM cần một địa chỉ để `<video src>` bám vào, và địa chỉ
           ấy là thứ bị cấm. Nói ra thay vì im: một tệp lặng lẽ bị bỏ
           qua thì người dùng tưởng mình đã gắn được. */
        U.toast('Chọn ảnh tĩnh hoặc âm thanh tại đây. Video nguồn chưa được dựng thành timeline.', 'err');
        het();
      }
    });
  };

  /* Ghi giọng bằng micro — ĐƯỜNG DUY NHẤT sinh tiếng trong xưởng, và
     nó không sinh gì cả: nó ghi lại một người đang nói. Luật C20. */
  G.xuGhiGiong = function (id) {
    if (G.xuMicDang) { try { G.xuMicDang.stop(); } catch (e) {} return; }
    if (!navigator.mediaDevices) { U.toast('Trình duyệt này không mở được micro.', 'err'); return; }
    navigator.mediaDevices.getUserMedia({audio: true}).then(function (st) {
      var mr = new MediaRecorder(st), manh = [];
      G.xuMicDang = mr; G.xuMicCanh = id; veLai();
      mr.ondataavailable = function (e) { if (e.data.size) manh.push(e.data); };
      mr.onstop = function () {
        st.getTracks().forEach(function (t) { t.stop(); });
        var bl = new Blob(manh, {type: mr.mimeType});
        bl.arrayBuffer().then(function (b) { return ac().decodeAudioData(b); })
          .then(function (buf) {
            var vid = ma('v');
            G.xuVat[vid] = {ma: vid, ten: 'giong-' + id + '.webm', loai: 'tieng', buffer: buf, file:bl};
            var c = G.xuDA.canh.filter(function (x) { return x.id === id; })[0];
            if (c) c.vatTieng = vid;
            G.xuMicDang = null; G.xuMicCanh = '';
            U.toast('Đã ghi ' + buf.duration.toFixed(1) + ' giây giọng.', 'ok');
            veLai();
          }).catch(function () { G.xuMicDang = null; veLai(); });
      };
      mr.start();
    }).catch(function (e) {
      U.toast('Không mở được micro: ' + (e && e.message), 'err');
    });
  };

  /* ══ GHI NHẬN HỘ CHIẾU ══

     Hộ chiếu chỉ ghi metadata và lời khai đèn từ trình duyệt; nó KHÔNG
     chứng minh đã có MP4 hay xác minh lại ảnh/âm thanh ở máy chủ. Tên
     API cũ `ghiDeBaiVideo` không tồn tại trong worker, khiến thao tác
     này thất bại im lặng. Gọi đúng cửa hiện có, và ghi rõ giới hạn đó. */
  G.xuGuiDeBai = function () {
    if (!congMo()) { U.toast('Còn đèn đỏ — cổng gửi đóng.', 'err'); return; }
    if (!G.goiMayChu) return;
    if (!window.confirm('Ghi nhật ký hộ chiếu từ thông tin và đèn do trình duyệt khai báo? Máy chủ không xác minh tệp MP4 hay chạy bộ dựng.')) return;
    G.goiMayChu('ghiHoChieuVideo', {
      ten: G.xuDA.ten, kho: G.xuDA.kho, tang: G.xuDA.tang, nguon: G.xuDA.nguon,
      dieuNho: G.xuDA.dieuNho, khuon: G.xuDA.khuon, giay: tong(), soCanh:(G.xuDA.canh||[]).length,
      den: den().map(function (x) { return {tt:x.tt,t:x.t,ref:x.ref,n:x.n}; })
    }).then(function (x) {
      U.toast((x && x.ok)
        ? 'Đã ghi hộ chiếu metadata. Đây không phải xác nhận MP4 đã được tạo.'
        : String((x && x.vi) || 'Cửa đề bài từ chối.'), (x && x.ok) ? 'ok' : 'err');
    }).catch(function (e) { U.toast(String(e && e.message || e), 'err'); });
  };

  /* Render thẳng tới companion cục bộ trên loopback. Chỉ các asset gắn
     vào cảnh mới được gửi; tuyệt đối không đi qua Worker/Cloudflare. */
  G.xuRenderCucBo = async function () {
    var token = String(G.xuRendererToken || '').trim();
    if (token.length < 32) { U.toast('Nhập mã kết nối của renderer cục bộ (tối thiểu 32 ký tự).','err'); return; }
    var d=G.xuDA, r=khung(), ids={}, form=new FormData(), tongByte=0;
    function duong(id,loai) {
      if (!id) return null;
      var v=G.xuVat[id], f=v && (v.file || v.blob);
      if (!v || !f) throw Error('Tài nguyên '+id+' không còn trong bộ nhớ tab. Hãy chọn lại tệp.');
      if (v.loai!==loai) throw Error('Loại media của '+v.ten+' không khớp cảnh.');
      var ext=String(v.ten||'').match(/\.[a-z0-9]{1,8}$/i);
      ext=ext?ext[0].toLowerCase():(loai==='hinh'?'.png':'.webm');
      var ok=loai==='hinh'?['.png','.jpg','.jpeg','.webp','.bmp']:['.wav','.mp3','.m4a','.aac','.ogg','.flac','.webm'];
      if(ok.indexOf(ext)<0) throw Error('Định dạng '+ext+' chưa hỗ trợ.');
      ids[id]={file:f,name:id+ext,ext:ext};
      return 'assets/'+id+ext;
    }
    var canh=[];
    try {
      (d.canh||[]).forEach(function(c){
        var asset=G.xuVat[c.vatHinh];
        canh.push({seconds:Math.max(1,+c.giay||1),image:duong(c.vatHinh,'hinh'),imageFit:asset&&asset.imageFit==='contain'?'contain':'cover',
          narration:duong(c.vatTieng,'tieng'),caption:String(c.loi||c.chuMan||''),background:'#10131a'});
      });
      if (!canh.length) throw Error('Hãy viết kịch bản và có ít nhất một cảnh trước khi dựng.');
      Object.keys(ids).forEach(function(id){
        var a=ids[id]; tongByte+=Number(a.file.size||0);
        if(a.file.size>80*1024*1024) throw Error('Mỗi tệp tối đa 80 MB.');
        form.append('asset_'+id,a.file,a.name);
      });
      if(tongByte>200*1024*1024) throw Error('Tổng media một lượt tối đa 200 MB.');
      var project={schemaVersion:'gita.video.v1',title:String(d.ten||'GITA video').slice(0,160),
        width:r[0],height:r[1],fps:30,preset:'medium',crf:20,burnSubtitles:true,music:null,scenes:canh};
      form.append('project',JSON.stringify(project));
    } catch(e) { U.toast(String(e.message||e),'err'); return; }
    if (!window.confirm('Dựng MP4 trên chính máy này? '+(Object.keys(ids).length)+' media · '+
      (tongByte/1024/1024).toFixed(1)+' MB · '+Math.round(tong())+' giây. Tệp media chỉ gửi tới 127.0.0.1:8766, không gửi Cloudflare.')) return;
    G.xuRenderTrangThai='Đang kiểm tra companion renderer…'; veLai();
    try {
      var origin='http://127.0.0.1:8766';
      var health=await fetch(origin+'/health',{cache:'no-store'});
      if(!health.ok) throw Error('Renderer cục bộ chưa sẵn sàng. Chạy node tools/video/may-chu-cuc-bo.mjs trong thư mục repo.');
      var res=await fetch(origin+'/v1/render',{method:'POST',headers:{Authorization:'Bearer '+token},body:form});
      var x=await res.json();
      if(!res.ok||!x.ok) throw Error(x.error||'Renderer từ chối project.');
      G.xuRenderLast=x.video;
      G.xuRenderTrangThai='Đã dựng '+x.video+' · SRT '+x.subtitles+' · '+x.output;
      U.toast('Đã dựng MP4 cục bộ: '+x.output+'/'+x.video,'ok');
    } catch(e) {
      G.xuRenderTrangThai='Chưa dựng được: '+String(e.message||e);
      U.toast(G.xuRenderTrangThai,'err');
    }
    veLai();
  };

  G.xuChayVideoLingo = async function () {
    if(!G.xuRendererToken||String(G.xuRendererToken).length<32){U.toast('Nhập mã renderer cục bộ trước.','err');return;}
    if(!G.xuRenderLast){U.toast('Hãy dựng MP4 trong phiên này trước khi chạy VideoLingo.','err');return;}
    var lang=String(G.xuLingoLang||'vi').trim();
    if(!/^[a-zA-Z-]{2,20}$/.test(lang)){U.toast('Mã ngôn ngữ chưa hợp lệ.','err');return;}
    if(!window.confirm('Gửi MP4 tới VideoLingo đang chạy trên máy này để nhận dạng, căn chỉnh và dịch phụ đề sang “'+lang+'”? Lồng tiếng AI đang tắt. VideoLingo dùng nhà cung cấp/model theo config riêng của máy; nếu cấu hình provider ngoài, nội dung có thể rời máy. Tiếp tục?'))return;
    var base='http://127.0.0.1:8766', headers={Authorization:'Bearer '+G.xuRendererToken,'Content-Type':'application/json'};
    try{
      var health=await fetch(base+'/health',{cache:'no-store'}), h=await health.json();
      if(!health.ok||!h.videoLingoConfigured)throw Error('Companion chưa nối VideoLingo. Khởi động API VideoLingo ở 127.0.0.1:8000 và đặt GITA_VIDEOLINGO_URL=http://127.0.0.1:8000 khi chạy companion.');
      var start=await fetch(base+'/v1/videolingo',{method:'POST',headers:headers,body:JSON.stringify({video:G.xuRenderLast,targetLanguage:lang})});
      var sx=await start.json(); if(!start.ok||!sx.ok)throw Error(sx.error||'Không mở được tác vụ VideoLingo.');
      G.xuRenderTrangThai='VideoLingo: đang chuẩn bị video…';veLai();
      var done=false;
      while(!done){
        await new Promise(function(r){setTimeout(r,1500);});
        var poll=await fetch(base+'/v1/videolingo/'+encodeURIComponent(sx.job.id),{headers:{Authorization:'Bearer '+G.xuRendererToken},cache:'no-store'});
        var px=await poll.json();if(!poll.ok||!px.ok)throw Error(px.error||'Không đọc được tiến độ VideoLingo.');
        G.xuRenderTrangThai='VideoLingo: '+String(px.job.progress||px.job.state);
        if(px.job.state==='error')throw Error(px.job.error||'VideoLingo gặp lỗi.');
        if(px.job.state==='completed'){
          done=true;G.xuRenderTrangThai='Đã lưu phụ đề '+px.job.result.subtitle+' tại video-output/';
          U.toast(G.xuRenderTrangThai,'ok');
        } else veLai();
      }
    }catch(e){G.xuRenderTrangThai='VideoLingo chưa hoàn tất: '+String(e.message||e);U.toast(G.xuRenderTrangThai,'err');}
    veLai();
  };

  var CHUOI_HD={
    'bat-dau':{title:'Hướng dẫn GITA · Bắt đầu an toàn',source:'Trải nghiệm mở đầu GITA365',scenes:[
      ['Mở đầu','Chào mừng gia đình đến với GITA 365. Đây là nơi đồng hành theo từng bước nhỏ.'],
      ['Chọn đúng vai','Đăng nhập bằng vai phù hợp để chỉ nhìn thấy đúng phần dành cho mình.'],
      ['Khám phá ngôi nhà','Bản đồ Ngôi nhà cho biết các khu vực và cách đi tới từng công cụ.'],
      ['Bắt đầu từ hôm nay','Mở việc hôm nay, chọn một hành động rõ ràng và vừa sức với gia đình.'],
      ['Cùng đi tiếp','Làm một bước nhỏ trước. Khi cần, hãy mở mục Đồng hành để tìm trợ giúp.']]},
    'nam-tang':{title:'Hướng dẫn GITA · Hành trình 5 tầng',source:'Bản đồ hành trình phát triển GITA',scenes:[
      ['Năm tầng · năm câu hỏi','GITA dùng năm tầng nối tiếp nhau. Mỗi tầng có mục tiêu, thời lượng và cổng phù hợp.'],
      ['T1 · Nhận diện','Quan sát điều đang xảy ra và ghi dữ liệu ban đầu, chưa vội chữa vấn đề.'],
      ['T2 · Giải mã','Kiểm chứng giả thuyết qua các vòng thực hành để hiểu vì sao vấn đề xảy ra.'],
      ['T3, T4, T5','Kiến tạo hệ thống, chuyển thay đổi thành năng lực, rồi bứt phá và tạo giá trị.'],
      ['Xem lộ trình tương ứng','Mở Bản đồ hành trình để xem chặng và yêu cầu đào tạo của gia đình.']]},
    'nhiem-vu':{title:'Hướng dẫn GITA · Việc hôm nay',source:'Màn Việc hôm nay và nhiệm vụ',scenes:[
      ['Chọn việc vừa sức','Mở Việc hôm nay để xem nhiệm vụ đang phù hợp với chặng của gia đình.'],
      ['Đọc yêu cầu trước','Kiểm tra mục tiêu, thời hạn và cách ghi nhận trước khi bắt đầu.'],
      ['Cùng con thực hành','Chọn một bước nhỏ, để con tự tham gia và người lớn đồng hành đúng lúc.'],
      ['Ghi nhận tiến trình','Hoàn thành xong thì ghi lại điều đã làm và đính kèm minh chứng nếu cần.'],
      ['Nhìn lại và điều chỉnh','Nếu chưa xong, quay lại nhiệm vụ, xem điều gì cản trở rồi chọn bước tiếp theo.']]},
    'tien-bo':{title:'Hướng dẫn GITA · Theo dõi tiến bộ',source:'Màn Tiến bộ và bảng theo dõi',scenes:[
      ['Tiến bộ nhìn từ dữ liệu','Mở Tiến bộ để xem những gì gia đình đã thực hiện và ghi nhận.'],
      ['Xem theo thời gian','Đối chiếu các mốc đã có, thay vì kết luận từ một ngày riêng lẻ.'],
      ['Ghi nhận điều cụ thể','Tìm một thói quen, kỹ năng hoặc kết quả đã thay đổi có bằng chứng.'],
      ['Chọn một điểm cần sửa','Nếu tiến độ chậm, chọn một nguyên nhân có thể thay đổi trong tuần này.'],
      ['Tiếp tục lộ trình','Dùng kết quả đã ghi để trao đổi với người đồng hành và xác định bước kế.']]},
    'thu-vien':{title:'Hướng dẫn GITA · Tài liệu và đồng hành',source:'Kho thư viện và người đồng hành',scenes:[
      ['Tìm đúng tài liệu','Mở Kho tài liệu chung và bắt đầu bằng nội dung phù hợp với nhu cầu hiện tại.'],
      ['Dùng tài liệu thành hành động','Chọn một ý, thử trong thực tế rồi ghi lại kết quả.'],
      ['Hỏi khi còn vướng','Mở Người đồng hành để gửi câu hỏi hoặc xin hỗ trợ theo đúng kênh.'],
      ['Chia sẻ đủ ngữ cảnh','Nêu điều đã thử, điều đang khó và bước muốn được trợ giúp.'],
      ['Khép vòng thực hành','Quay lại nhiệm vụ hoặc nhật ký, ghi điều học được và bước tiếp theo.']]}
  };
  G.xuTaoVideoHD=function(){
    var ep=CHUOI_HD[G.xuChuDeHD]||CHUOI_HD['bat-dau'];
    G.xuDA.ten=ep.title;G.xuDA.nguon=ep.source;G.xuDA.dich=30;G.xuDA.khuon=G.xuDA.khuon||'SC2';
    G.xuDA.canh=ep.scenes.map(function(x,i){return{id:ma('c'),vai:i===0?'hook':(i===4?'cta':'cach_lam'),giay:6,loi:x[1],chuMan:x[0],hinh:'',vatHinh:'',vatTieng:''};});
    G.xuSoat=null;G.xuDongHo=0;G.xuVe(0);veLai();
    U.toast('Đã nạp storyboard 5 cảnh · 30 giây. Ghi giọng người thật, gắn ảnh/chụp 3D rồi soát trước khi render.','ok');
  };

  G.xuXuLyAnh = async function () {
    var token=String(G.xuRendererToken||'').trim(), file=G.xuAnhFile;
    if(token.length<32){U.toast('Nhập mã renderer cục bộ trước.','err');return;}
    if(!file){U.toast('Chọn một ảnh trước.','err');return;}
    if(file.size>40*1024*1024){U.toast('Ảnh nguồn tối đa 40 MB.','err');return;}
    if(!/^image\/(jpeg|png|webp|tiff|bmp)$/.test(file.type)){U.toast('Chỉ nhận JPEG, PNG, WebP, TIFF hoặc BMP.','err');return;}
    if(!window.confirm('Gửi ảnh tới ImageMagick đang chạy cục bộ trên máy này để cắt khung, tăng nét nhẹ, gỡ metadata và tối ưu WebP? Ảnh không đi qua Cloudflare. Tiếp tục?'))return;
    G.xuAnhStatus='Đang xử lý ảnh trên máy này…'; G.xuAnhPreview=''; veLai();
    try {
      var form=new FormData(); form.append('image',file,file.name); form.append('preset',G.xuAnhPreset||'post'); form.append('fit','cover'); form.append('format','webp');
      var response=await fetch('http://127.0.0.1:8766/v1/image',{method:'POST',headers:{Authorization:'Bearer '+token},body:form,cache:'no-store'});
      if(!response.ok){var err=await response.json().catch(function(){return{};});throw Error(err.error||'ImageMagick trả HTTP '+response.status);}
      var blob=await response.blob();
      if(blob.size>15*1024*1024)throw Error('Ảnh kết quả vượt 15 MB; hãy giảm kích thước nguồn rồi thử lại.');
      var data=await new Promise(function(resolve,reject){var reader=new FileReader();reader.onload=function(){resolve(String(reader.result||''));};reader.onerror=function(){reject(Error('Không đọc được ảnh kết quả.'));};reader.readAsDataURL(blob);});
      G.xuAnhPreview=data; G.xuAnhName=(response.headers.get('content-disposition')||'').match(/filename="?([^";]+)"?/i)?.[1]||('gita-'+G.xuAnhPreset+'.webp');
      G.xuAnhStatus='Đã xử lý '+response.headers.get('x-gita-image-width')+'×'+response.headers.get('x-gita-image-height')+' · metadata đã gỡ · '+Math.round(blob.size/1024)+' KB';
      U.toast('Ảnh đã sẵn sàng để tải xuống.','ok');
    }catch(e){G.xuAnhStatus='Chưa xử lý được: '+String(e.message||e);U.toast(G.xuAnhStatus,'err');}
    veLai();
  };

  /* ══ MÀN ══ */
  function oChon(o, gt, ds) {
    return '<select onchange="G.xuSuaO(\'' + o + '\',this.value)">' + ds.map(function (x) {
      return '<option' + (x === gt ? ' selected' : '') + '>' + h(x) + '</option>';
    }).join('') + '</select>';
  }
  function veCanh(c, i, t0) {
    var vHinh = Object.keys(G.xuVat).filter(function (k) { return G.xuVat[k].loai !== 'tieng'; });
    var vTieng = Object.keys(G.xuVat).filter(function (k) { return G.xuVat[k].loai === 'tieng'; });
    var o = '<div class="giay xu-canh"><div class="row">' +
      '<b>' + h(String(c.vai).toUpperCase()) + '</b>' +
      '<span class="note">' + t0.toFixed(0) + '–' + (t0 + (+c.giay || 0)).toFixed(0) + 's · ' +
      h(c.hinh || '') + '</span></div>';
    o += '<textarea rows="2" oninput="G.xuSuaCanh(\'' + h(c.id) + '\',\'loi\',this.value)">' +
      h(c.loi) + '</textarea>';
    o += '<div class="row"><label>Chữ trên màn <input type="text" value="' + h(c.chuMan) +
      '" oninput="G.xuSuaCanh(\'' + h(c.id) + '\',\'chuMan\',this.value)"></label>';
    o += '<label>Giây <input type="number" min="1" max="60" step="0.5" value="' +
      h(String(c.giay)) + '" oninput="G.xuSuaCanh(\'' + h(c.id) + '\',\'giay\',this.value)"></label>';
    o += '<label>Hình <select onchange="G.xuSuaCanh(\'' + h(c.id) + '\',\'vatHinh\',this.value)">' +
      '<option value="">— nền ánh đèn —</option>' + vHinh.map(function (k) {
        return '<option value="' + h(k) + '"' + (k === c.vatHinh ? ' selected' : '') + '>' +
          h(G.xuVat[k].ten) + '</option>';
      }).join('') + '</select></label></div>';
    o += '<div class="row"><label>Giọng <select onchange="G.xuSuaCanh(\'' + h(c.id) +
      '\',\'vatTieng\',this.value)"><option value="">— chưa có giọng —</option>' +
      vTieng.map(function (k) {
        return '<option value="' + h(k) + '"' + (k === c.vatTieng ? ' selected' : '') + '>' +
          h(G.xuVat[k].ten) + '</option>';
      }).join('') + '</select></label>';
    o += '<span class="row">' +
      '<button class="btn" onclick="G.xuGhiGiong(\'' + h(c.id) + '\')">' +
      (G.xuMicCanh === c.id && G.xuMicDang ? 'Dừng ghi' : 'Ghi giọng') + '</button>' +
      '<button class="btn" onclick="G.xuKhopGiay(\'' + h(c.id) + '\')">Khớp giây theo giọng</button>' +
      '<button class="btn" onclick="G.xuXoaCanh(\'' + h(c.id) + '\')">Xoá cảnh</button>' +
      '</span></div></div>';
    return o;
  }
  G.xuTomTat = function () {
    var e = document.getElementById('xu-tom');
    if (e) e.textContent = (G.xuDA.canh || []).length + ' cảnh · ' + phut(tong()) +
      ' · đích ' + phut(+G.xuDA.dich || 0);
  };

  G.VIEWS['studio'] = function () {
    var o = '<div class="hd"><h2>' + ic('spark') + ' GITA Studio · Xưởng dựng video</h2>' +
      '<p class="sub">Lập cảnh, chụp tư liệu từ bản đồ WebGL 3D, chuẩn hóa ảnh, xem thử canvas 1080p và ghi giọng người thật. ' +
      'Bộ dựng MP4 cùng bộ xử lý ảnh chạy tại máy biên tập; máy chủ web không render media. ' +
      'Ảnh và âm thanh trong màn này ở bộ nhớ phiên trình duyệt.</p></div>';

    /* Một chỗ chặn duy nhất, TRƯỚC mọi ngăn. Vai không có gói nghề thì
       kho không bao giờ nạp, và mọi ngăn sẽ dựng ra khung rỗng — mà
       một khung rỗng đọc ra là "chỗ này chưa làm xong", không đọc ra
       là "vai của bạn không mở được" (bài học 9.99.63). */
    if (!(G.XU_NGANKHO || []).length) {
      return o + U.empty('Xưởng dựng video thuộc gói nghề',
        'Màn này là công cụ sản xuất của Học viện: nó xuất tệp video, tệp phụ đề và hộ ' +
        'chiếu video ra máy người dùng, nên nó chỉ mở cho người của Học viện đã đăng ' +
        'nhập bằng tài khoản nghề. Gia đình xem video đã phát hành ở kênh, không dựng ' +
        'video trong hệ — và đó là một quyết định về bảo mật, không phải một chỗ chưa ' +
        'làm xong. Ngân khố câu, năm khuôn kịch bản và tám đèn kiểm định đều nằm trong ' +
        'gói nghề, nên với vai này màn không có gì để dựng.');
    }

    /* Bọc phần điều khiển trong .man-xu để nới vùng chạm ĐÚNG Ở ĐÂY,
       không nới toàn cục: thanh kéo tua và ô nhập của xưởng cần ≥32px
       trên màn chạm, mà nới `input` toàn cục thì trăm ô ở màn khác nở
       theo (bài học "nới đúng chỗ" của cổng vào 9.99.80). */
    o += '<div class="man-xu">';

    /* 1 · Yêu cầu */
    o += '<div class="giay"><h3>1 · Yêu cầu</h3>';
    o += '<label>Chủ đề <input type="text" value="' + h(G.xuDA.ten) +
      '" oninput="G.xuSuaO(\'ten\',this.value)"></label>';
    o += '<div class="row"><label>Khổ hình ' +
      oChon('kho', G.xuDA.kho, KHO_HINH().map(function (k) { return k.ma; })) + '</label>';
    o += '<label>Thời lượng đích (giây) <input type="number" min="30" max="300" step="5" value="' +
      h(String(G.xuDA.dich)) + '" oninput="G.xuSuaO(\'dich\',this.value)"></label>';
    o += '<label>Khuôn ' + '<select onchange="G.xuSuaO(\'khuon\',this.value)">' +
      KHUON().map(function (k) {
        return '<option value="' + h(k.ma) + '"' + (k.ma === G.xuDA.khuon ? ' selected' : '') +
          '>' + h(k.ma + ' · ' + k.ten) + '</option>';
      }).join('') + '</select></label></div>';
    o += '<div class="row"><label>Tầng quyền ' +
      oChon('tang', G.xuDA.tang, ['T1 · công khai', 'T2 · phụ huynh đã đăng ký', 'T3 · nội bộ']) +
      '</label>';
    o += '<label>Nguồn tri thức <input type="text" value="' + h(G.xuDA.nguon) +
      '" oninput="G.xuSuaO(\'nguon\',this.value)"></label></div>';
    o += '<label>Điều nhỏ người xem làm được <input type="text" value="' + h(G.xuDA.dieuNho) +
      '" oninput="G.xuSuaO(\'dieuNho\',this.value)"></label>';
    o += '<div class="row"><button class="btn btn-chinh" onclick="G.xuViet()">Viết kịch bản</button>' +
      '<button class="btn" onclick="G.xuGoiSoat()">Soát lời đọc</button></div>';
    o += '<p class="note">Bộ viết chạy ngay trong máy, không gọi mạng. Ngân khố câu nằm ' +
      'trong kho nghề nên người viết nội dung sửa được mà không phải sửa mã.</p></div>';

    /* 2 · Màn xem thử */
    o += '<div class="giay"><h3>2 · Xem thử</h3>' +
      '<div class="row"><label>Chuỗi video hướng dẫn <select onchange="G.xuChuDeHD=this.value">' +
      [['bat-dau','Tập 1 · Bắt đầu an toàn'],['nam-tang','Tập 2 · Hành trình 5 tầng'],['nhiem-vu','Tập 3 · Việc hôm nay'],['tien-bo','Tập 4 · Theo dõi tiến bộ'],['thu-vien','Tập 5 · Tài liệu &amp; đồng hành']].map(function(x){return '<option value="'+x[0]+'"'+(G.xuChuDeHD===x[0]?' selected':'')+'>'+x[1]+'</option>';}).join('') +
      '</select></label><button class="btn" onclick="G.xuTaoVideoHD()">Nạp storyboard tập này</button></div>' +
      '<p class="note">5 storyboard bám theo các màn thật của GITA365. Mỗi tập có 5 cảnh/30 giây; xưởng không sinh giọng. Ghi lời đọc người thật, gắn ảnh màn hình hoặc khung 3D rồi mới dựng MP4.</p>' +
      '<canvas id="xu-man" class="xu-man" width="1080" height="1920"></canvas>';
    o += '<div class="row"><button class="btn btn-chinh" onclick="G.xuXem()">Xem thử</button>' +
      '<button class="btn" onclick="G.xuDung()">Tạm dừng</button>' +
      '<button class="btn btn-do" onclick="G.xuDungKhan()">' +
      (G.xuGiuLai ? 'Mở lại video' : 'Dừng khẩn') + '</button>' +
      '<span class="note" id="xu-gio">0.0 / ' + tong().toFixed(1) + 's</span></div>';
    o += '<input type="range" min="0" max="100" step="0.1" value="0" class="xu-tua" ' +
      'aria-label="Tua video" oninput="G.xuTua(this.value)">';
    o += '<div class="row"><button class="btn btn-chinh" onclick="G.xuGuiDeBai()"' +
      (congMo() ? '' : ' disabled') + '>' +
      (congMo() ? 'Ghi hộ chiếu metadata' : 'Chưa đủ đèn để ghi') + '</button></div>';
    o += '<div class="row"><label>Mã kết nối renderer cục bộ <input type="password" autocomplete="off" ' +
      'value="' + h(G.xuRendererToken) + '" oninput="G.xuRendererToken=this.value" placeholder="Mã hiện trong cửa sổ terminal"></label>' +
      '<button class="btn btn-chinh" onclick="G.xuRenderCucBo()">Dựng MP4 trên máy này</button></div>' +
      (G.xuRenderTrangThai ? '<p class="note" role="status">'+h(G.xuRenderTrangThai)+'</p>' : '');
    o += '<div class="row"><label>Ngôn ngữ phụ đề đích <input type="text" maxlength="20" value="'+h(G.xuLingoLang)+'" ' +
      'oninput="G.xuLingoLang=this.value" aria-label="Mã ngôn ngữ VideoLingo, ví dụ vi hoặc en"></label>' +
      '<button class="btn" onclick="G.xuChayVideoLingo()"'+(G.xuRenderLast?'':' disabled')+'>VideoLingo · nhận dạng &amp; dịch phụ đề</button></div>' +
      (G.xuRenderLast?'<p class="note">MP4 hiện tại: <code>'+h(G.xuRenderLast)+'</code></p>':'');
    o += '<p class="note" id="xu-tt">Để tạo MP4 thật, dùng bộ dựng cục bộ trong gói mã: ' +
      '<code>node tools/video/dung-phim.mjs project.json --out ./video-output</code>. ' +
      'Tệp SRT và hộ chiếu JSON được xuất kèm. Hộ chiếu trong Cloudflare chỉ ghi lại lời khai ' +
      'đèn và metadata; không xác minh nội dung MP4. Hãy xem phần Hướng dẫn triển khai video.</p></div>';

    /* 3 · Kịch bản */
    o += '<div class="giay"><h3>3 · Kịch bản</h3>';
    var a = 0;
    o += (G.xuDA.canh || []).map(function (c, i) {
      var s = veCanh(c, i, a); a += (+c.giay || 0); return s;
    }).join('') || '<p class="note">Chưa có cảnh nào — bấm “Viết kịch bản”.</p>';
    o += '<div class="row"><button class="btn" onclick="G.xuThemCanh()">Thêm cảnh</button>' +
      '<span class="note" id="xu-tom">' + (G.xuDA.canh || []).length + ' cảnh · ' +
      phut(tong()) + ' · đích ' + phut(+G.xuDA.dich || 0) + '</span></div></div>';

    /* 4 · Kho vật liệu */
    o += '<div class="giay"><h3>4 · Kho hình &amp; tiếng</h3>' +
      '<input type="file" multiple accept="image/*,video/*,audio/*" ' +
      'onchange="G.xuNhanTep(this.files)" aria-label="Chọn ảnh, video hoặc tiếng">';
    var ks = Object.keys(G.xuVat);
    o += '<p class="note">' + (ks.length ? ks.length + ' tệp trong bộ nhớ trình duyệt: ' +
      ks.map(function (k) { return h(G.xuVat[k].ten); }).join(' · ')
      : 'Chưa có tệp nào. Tệp anh chọn nằm trong máy anh, xưởng không tải lên đâu cả.') +
      '</p></div>';

    o += '<div class="giay"><h3>4a · Xưởng ảnh sắc nét</h3>' +
      '<p class="note">Xử lý cục bộ bằng ImageMagick: crop/fit theo kênh, tăng nét nhẹ, chuẩn màu sRGB, gỡ metadata và xuất WebP tối ưu. Chọn ảnh và bấm xử lý để gửi ảnh riêng tới companion localhost.</p>' +
      '<div class="row"><input type="file" accept="image/jpeg,image/png,image/webp,image/tiff,image/bmp" onchange="G.xuAnhFile=this.files&&this.files[0]||null;G.xuAnhPreview=\'\';G.xuAnhStatus=G.xuAnhFile?G.xuAnhFile.name+\' · \'+Math.round(G.xuAnhFile.size/1024)+\' KB\':\'\';G.render()" aria-label="Chọn ảnh để xử lý cục bộ">' +
      '<label>Khổ xuất <select onchange="G.xuAnhPreset=this.value">' +
      [['post','Bài đăng vuông · 1080×1080'],['story','Story · 1080×1920'],['landscape','Ngang · 1920×1080'],['thumbnail','Thumbnail · 1280×720'],['print','In · 2400×3000']].map(function(x){return '<option value="'+x[0]+'"'+(G.xuAnhPreset===x[0]?' selected':'')+'>'+x[1]+'</option>';}).join('')+
      '</select></label><button class="btn btn-chinh" onclick="G.xuXuLyAnh()">Tối ưu ảnh tại máy này</button></div>' +
      (G.xuAnhStatus?'<p class="note" role="status">'+h(G.xuAnhStatus)+'</p>':'') +
      (G.xuAnhPreview?'<img src="'+h(G.xuAnhPreview)+'" alt="Ảnh đã xử lý cục bộ" style="display:block;max-width:min(100%,360px);max-height:420px;object-fit:contain;border-radius:12px;margin:12px 0"><a class="btn" href="'+h(G.xuAnhPreview)+'" download="'+h(G.xuAnhName)+'">Tải ảnh đã xử lý</a>':'') + '</div>';

    /* 5 · Đèn */
    o += '<div class="giay"><h3>5 · Đèn kiểm định</h3>' +
      '<p class="note">Một đèn đỏ là cổng xuất đóng — cổng cứng, không có “xuất tạm” ' +
      '(LT_RM.RM-1). Hai đèn đầu <b>không đo ở đây</b>: chúng hỏi cửa <code>soatNoiDung</code>, ' +
      'vì hai bảng dấu hiệu lệch nhau thì cả hai đều xanh trên hai thứ khác nhau.</p>';
    o += (G.xuDangSoat ? '<p class="note">Đang hỏi cửa nội dung…</p>' : '');
    o += '<ul class="xu-den">' + den().map(function (l) {
      return '<li class="xu-' + l.tt + '"><b>' + h(l.t) + '</b> <em>' + h(l.ref) + '</em>' +
        '<span>' + h(l.n) + '</span></li>';
    }).join('') + '</ul></div>';

    /* 6 · Xuất kèm */
    o += '<div class="giay"><h3>6 · Sản xuất &amp; bàn giao</h3>' +
      '<p class="note">Năm storyboard video hướng dẫn đang có sẵn. Từ Ngôi nhà, chụp khung WebGL 3D vào kho hình, gắn cho từng cảnh, thu lời đọc người thật; FFmpeg tạo MP4 + SRT + passport JSON và chuyển động chậm cho ảnh tĩnh. ' +
      'VideoLingo, Video2X và Remotion hiện chưa nối tự động vào GITA365: xem ma trận adapter, ' +
      'yêu cầu GPU/giấy phép và quy trình thiết lập tại <code>docs/GITA-STUDIO-VIDEO-PIPELINE.md</code>. ' +
      'Không tải footage lên dịch vụ ngoài nếu chưa được phép.</p>' +
      '<ul class="note"><li><b>FFmpeg local:</b> render MP4 thật qua companion localhost; đang có trong gói mã.</li>' +
      '<li><b>VideoLingo:</b> bridge loopback chạy được ASR/căn thời gian/dịch và trả SRT khi API local đã nối; lồng tiếng vẫn tắt.</li>' +
      '<li><b>Video2X:</b> upscale/nội suy GPU Vulkan; chạy hậu kỳ riêng, chưa có binary/model trong GITA365.</li>' +
      '<li><b>Remotion:</b> composition React và batch render; chưa nhúng runtime, cần rà soát điều khoản đơn vị.</li>' +
      '<li><b>CS video courses:</b> danh mục học tập, không phải bộ dựng; kiểm tra quyền từng khóa.</li></ul></div>';

    setTimeout(function () { G.xuCoManh(); }, 0);
    return o + '</div>';
  };
})();
