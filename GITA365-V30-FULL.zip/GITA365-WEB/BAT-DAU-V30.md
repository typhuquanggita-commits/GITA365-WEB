# GITA365 V30

- Toàn bộ source hiện có + nâng cấp V30 nằm trong thư mục này.
- Hướng dẫn cập nhật và lỗi khóa kho: **docs/CLOUDFLARE-CAP-NHAT-V30.md**.
- Cách dùng và phạm vi tính năng: **docs/V30-BAN-GIAO.md**.
- Chỉ deploy **_site/** lên Cloudflare Pages. Không upload toàn bộ source ZIP làm website.
- Cấu hình URL Worker trong cau-hinh.js rồi chạy `node tools/gop-src.js` và `node tools/tao-site.mjs`.
- Không có khóa giải mã/mật khẩu/API token trong bản bàn giao. Dùng bộ khóa đúng các tệp kho hiện tại.
- Mở menu V30 bằng nhân sự có quyền quản trị nội dung. Tải bản sao dự án trước khi đóng tab.
