# GITA 365 — HƯỚNG DẪN TRIỂN KHAI (Cloudflare + GitHub)

> Bản full 9.99.238 · giao diện đã nâng cấp (bảng khung rõ · khối 3D · sơ đồ quy trình).
> Đọc phần ⚠ BẢO MẬT trước tiên.

---

## ⚠ BẢO MẬT — ĐỌC TRƯỚC KHI LÀM BẤT KỲ VIỆC GÌ

**KHOÁ GIẢI MÃ (giấy phép / `khoa.json`) KHÔNG BAO GIỜ ĐƯỢC ĐƯA LÊN GITHUB.**

- Repo GitHub là **công khai**. Kho nội dung `kho/*.enc` đã mã hoá — vô hại nếu để công khai
  vì **không có khoá thì không mở được**.
- Nhưng nếu đưa **khoá** (7 khoá AES trong giấy phép) lên GitHub, bất kỳ ai cũng giải mã được
  **toàn bộ nội dung chuyên môn** của Học viện. Đó là mất tài sản, và không lấy lại được.
- Khoá chỉ nằm **một chỗ duy nhất**: trong **secret của Cloudflare Worker** (`GITA_KHOA_KHO`).
  Máy khách xin khoá từ Worker sau khi đăng nhập, giải mã trong bộ nhớ, không lưu lại.
- Gói này **không** chứa khoá. File `.gitignore` cũng chặn sẵn `kho/khoa.json` và `giay-phep/`.

---

## Kiến trúc (đồng nhất một tên miền)

```
   Trình duyệt khách
        │
        ├──►  Cloudflare Pages   →  phần tĩnh: index.html · gita-app.js · assets · kho/*.enc
        │                            (lấy từ repo GitHub — CÔNG KHAI, KHÔNG khoá)
        │
        └──►  Cloudflare Worker  →  máy chủ: đăng nhập · cấp khoá · CRM · nhật ký · tài chính
                                     (mã ở may-chu/ — khoá nằm trong SECRET, không ở repo)
```

Cùng một tên miền (ví dụ `gita.edu.vn`): Pages phục vụ phần tĩnh, Worker giữ route `/api/*`.
Cùng tên miền thì không có CORS, không có lượt gọi thăm dò trước mỗi yêu cầu.

---

## PHẦN 1 — GITHUB + CLOUDFLARE PAGES (phần tĩnh, công khai)

1. Đưa **toàn bộ gói này** lên repo `GITA365-WEB` (kéo-thả trên GitHub, hoặc `git push`).
2. Cloudflare → **Workers & Pages** → **Create** → **Pages** → **Connect to Git** → chọn repo `GITA365-WEB`.
3. Build settings: **Build command** `node tools/gop-src.js --kiem && node tools/tao-site.mjs`, **Build output directory** `_site`.
   Không chọn gốc repository làm thư mục xuất bản: gốc còn chứa `may-chu/`, `src/` và công cụ nội bộ.
4. Deploy. Pages cho một địa chỉ `*.pages.dev`.

## PHẦN 2 — CLOUDFLARE WORKER (máy chủ, có khoá)

Mở terminal trong thư mục `may-chu/` rồi làm các bước sau (đã ghi sẵn trong `wrangler.toml`):

```bash
cd may-chu

# 1) Tạo cơ sở dữ liệu, dán database_id vào wrangler.toml
npx wrangler d1 create gita365

# 2) Dựng bảng
npx wrangler d1 execute gita365 --file=csdl.sql --remote

# 3) NẠP KHOÁ (giấy phép) — đây là bước dùng file khoá riêng của anh:
bash nap-bi-mat.sh /duong/dan/toi/khoa.json
#   (hoặc: cat khoa.json | npx wrangler secret put GITA_KHOA_KHO)
#   Rồi nạp các bí mật còn lại theo hướng dẫn script IN RA (GITA_TIEU sinh MỘT LẦN, giữ mãi).

# 4) Tạo mã KHỞI TẠO Super Admin (64 ký tự hex), giữ mã ở nơi riêng:
#    node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
#    npx wrangler secret put GITA_MA_KHOI_TAO
#    Khi được hỏi, dán mã vừa tạo. Nhập cùng mã vào ô "Mã khởi tạo"
#    của màn tạo Super Admin đầu tiên. Không ghi mã vào repo hoặc URL.

# 5) (Tên miền) xác thực gita.edu.vn ở nhà gửi thư — SPF/DKIM (xem wrangler.toml)

# 6) Đưa Worker lên
npx wrangler deploy
```

Nếu dùng **cùng tên miền** với Pages, gắn Worker vào route
`gita.edu.vn/api/*` trong Cloudflare **Workers & Pages → Worker → Settings →
Domains & Routes → Add → Route** (zone và DNS phải thuộc Cloudflare). Worker
hiện nhận yêu cầu POST ở route này; trong màn **Nối máy chủ**, nhập
`https://gita.edu.vn/api/`. Nếu chưa thiết lập route, dùng URL `*.workers.dev`
do Cloudflare cấp và kiểm tra CORS/CSP ở `index.html` trước khi cho khách dùng.
Không trỏ toàn bộ `gita.edu.vn/*` vào Worker vì nó sẽ thay đường phục vụ
tệp tĩnh của Pages.

## PHẦN 3 — NỐI HAI ĐẦU

Mở app → đăng nhập **Super Admin** → **Quản trị trang → Nối máy chủ** → dán địa chỉ Worker → **Lưu** → **Gọi thử**.
Thấy **số khoá > 0** là xong. Đổi địa chỉ máy chủ đảo ngược được trong một phút.

## NÂNG CẤP SỔ VIỆC ĐIỀU PHỐI

GITA365 có sổ việc điều phối trong màn **Điều phối trợ lý AI**. Sổ lưu công
việc, trạng thái, kết quả và 50 sự kiện gần nhất của mỗi việc trong D1. R01–R12
tạo và xem việc của mình; R01–R02 xem toàn bộ và duyệt hoàn tất. Tác vụ AI11
được tắt mặc định, cần R01 bật ở **Quyền năng AI**. Với việc mới, người giao có
thể bấm **Chạy agent** và xác nhận gửi tên/mô tả tới Cloudflare Workers AI.
Worker quét dấu hiệu dữ liệu nhận dạng trước khi gửi, giới hạn ba lượt mỗi việc
và mười lượt mỗi tài khoản mỗi giờ. Kết quả chỉ là bản nháp ở trạng thái
`cho_duyet`; agent không có công cụ, không thao tác dữ liệu khách và không thể
duyệt hoặc hoàn tất việc.

Mỗi agent nhận đúng ngữ cảnh việc và cửa chuyên môn được giao. Hệ thống kiểm
tra bốn phần bắt buộc của bản nháp (mục tiêu, bước đề xuất, cách kiểm chứng,
rủi ro/giới hạn); thiếu mục nào thì từ chối bản nháp, mở lại việc và ghi sự
kiện kiểm định. Bảy lớp Harness được hiện trong màn điều phối: context, tool,
orchestration, evaluation, security, governance và AgentOps. Hiện chưa cấp
quyền gọi công cụ hay tự giao chéo agent; việc nhiều miền cần được chia thành
các việc có cửa sở hữu riêng.

Chế độ **V20 Orchestrator + Critic** chạy tối đa hai lời gọi model cho một
lượt: agent chuyên môn soạn nháp, critic ở vai trò riêng nêu thiếu sót, tuyên
bố cần kiểm chứng và rủi ro. Critic không viết lại, không phê duyệt và không
được quyền hành động. Nếu critic lỗi hoặc đầu ra sai JSON, bản nháp vẫn ở
`cho_duyet` kèm cảnh báo người duyệt phải kiểm tra; cổng cấu trúc xác định
trước đó vẫn là điều kiện để nhận bản nháp. Đây là vòng ngắn đồng bộ; việc
nền dài, cần retry bền hoặc chờ duyệt lâu nên chuyển sang Cloudflare Workflows
ở bước triển khai riêng, không giữ một request Worker mở.

R01–R02 có thể khôi phục một việc `dang_lam` nếu không cập nhật ít nhất 10
phút. Thao tác mở lại về `moi`, xóa kết quả dang dở và ghi sự kiện/audit. Nếu
lượt model cũ còn chạy, cập nhật có điều kiện ngăn nó ghi đè trạng thái mới;
model vẫn có thể tiếp tục phát sinh chi phí. Chỉ dùng sau khi xác nhận lượt cũ
đã kẹt.

Phần **Hồ sơ phong cách GITA** nhận/tải file Markdown đã biên tập, giới hạn
12.000 ký tự và lưu cục bộ trong trình duyệt. Có thể tải mẫu phỏng vấn 100 câu,
sau đó biên tập thành hồ sơ ngắn tái sử dụng. Hồ sơ chỉ là gợi ý phong cách
văn bản, không tạo hay nhân bản giọng âm thanh. Hồ sơ chỉ gửi cùng việc khi
người dùng xác nhận chạy agent; bộ lọc nhận dạng áp dụng cho cả hồ sơ lẫn mô
tả việc. Tránh đưa transcript thô, dữ liệu học sinh/phụ huynh hoặc thông tin
nhạy cảm vào hồ sơ.

`may-chu/wrangler.toml` khai báo binding Workers AI (`AI`) và model mặc định
`@cf/google/gemma-4-26b-a4b-it`. Có thể đổi model bằng biến
`GITA_AGENT_MODEL`. Workers AI có thể phát sinh phí theo mức dùng; gọi model
cũng tính phí khi chạy `wrangler dev`, nên bộ kiểm cục bộ bên dưới chỉ dùng
model giả lập và không gửi yêu cầu ra Cloudflare. Không gửi thông tin nhận dạng
hoặc nội dung nhạy cảm vào mô tả việc. Bộ lọc nhận dạng là biện pháp chặn hữu
hạn, không thay thế việc người dùng rà soát nội dung.

Nâng cấp sổ việc trước đây thêm bảng `suKienDieuPhoi`; nếu D1 chưa có bảng này,
nạp lại `csdl.sql` bằng lệnh phía dưới. Các câu lệnh tạo bảng/chỉ mục dùng
`IF NOT EXISTS`, nên giữ nguyên dữ liệu việc đã có. Phần AI11 lần này không đổi
cấu trúc D1.

Với cơ sở dữ liệu **đã tồn tại**, chạy lệnh sau trong `may-chu/` **trước khi
triển khai Worker mới**. `csdl.sql` dùng `CREATE TABLE IF NOT EXISTS` và
`CREATE INDEX IF NOT EXISTS`; sao lưu D1 trước khi nâng cấp production.

```bash
npx wrangler d1 execute gita365 --file=csdl.sql --remote
npx wrangler deploy
```

Sau đó xuất bản mã web mới. Có thể kiểm tra phân quyền, quét dữ liệu, gọi model
giả lập, xử lý lỗi và yêu cầu duyệt bằng `node --experimental-sqlite
tools/thu-viec-dieu-phoi.mjs` ở thư mục gốc (Node 24). Muốn chạy agent trên
Cloudflare thật cần triển khai binding, đăng nhập Worker, chủ hệ bật AI11 và
người giao xác nhận từng lượt gọi; lượt thường có tối đa hai lời gọi model,
nên kiểm tra mức dùng trước khi mở cho nhiều tài khoản.

Thiết kế giữ ngữ cảnh công việc và lịch sử cộng tác bền vững được tham khảo
từ [Collab](https://github.com/collabs-inc/collab-public): GITA365 áp dụng
ngữ cảnh từng việc cùng dòng sự kiện trong D1. Dự án Collab là môi trường
desktop local-first với canvas/terminal cho agent; GITA365 không mở quyền
terminal hoặc thực thi lệnh máy tính cho model.

Ý tưởng nhật ký hoạt động cũng được tham khảo từ dự án mã nguồn mở
[Block Buzz](https://github.com/block/buzz); GITA365 chỉ áp dụng dòng sự kiện
theo việc và giữ nguyên hệ phân quyền cùng hạ tầng D1 của mình.
(https://github.com/androoAGI/starnet-releases/releases/tag/v0.12.4).
Không nhúng bộ cài, tên, logo hay hình ảnh StarNet vào GITA365.

---

## Các bí mật của Worker (nạp bằng lệnh, KHÔNG viết vào file)

| Secret | Là gì | Lưu ý |
|---|---|---|
| `GITA_KHOA_KHO` | Nội dung `khoa.json` (7 khoá giải mã kho) | Chìa mở toàn bộ nội dung. Chỉ ở đây. |
| `GITA_TIEU` | Tiêu băm mật khẩu | Sinh **một lần**, giữ mãi. Đổi = mọi mật khẩu hỏng. |
| `GITA_KHOA_KY` | Khoá ký chứng cứ (HMAC) | Chuỗi ngẫu nhiên bất kỳ. |
| `GITA_KHOA_THU` | Khoá gửi thư (Resend) | Chỉ cần nếu gửi email xác nhận. |
| `GITA_MA_KHOI_TAO` | Mã khởi tạo Super Admin đầu tiên | Ít nhất 32 ký tự, cất riêng; bắt buộc trước khi đưa Worker lên Internet. |

Tuỳ chọn (mặc định TẮT): `GITA_KHOA_NGANHANG`, `GITA_KHOA_VE`/`GITA_CONG_VE` (bộ tạo ảnh ngoài).

---

## Dựng video MP4 cục bộ

GITA Studio cũng có xưởng ảnh local chạy bằng ImageMagick, 5 storyboard hướng
dẫn và khung WebGL 3D lấy tầng/chương trình từ kho T1–T5. Cài ImageMagick
6/7 cùng Node.js và FFmpeg, chạy companion; tại Ngôi nhà, dùng **Chụp khung 3D
→ Studio** để đưa PNG vào kho hình của tab. Trong Studio chọn storyboard, thu
lời đọc người thật, gắn ảnh cho cảnh rồi dựng MP4. Xem chi tiết tại
`docs/GITA-STUDIO-IMAGE-PIPELINE.md` và
`docs/GITA-STUDIO-VIDEO-PIPELINE.md`.

GITA Studio có bộ dựng FFmpeg độc lập tại `tools/video/dung-phim.mjs`. Cài
Node.js 20+ và FFmpeg có libx264; muốn chèn phụ đề vào hình cần thêm libass.
Từ gốc repo chạy:

```bash
node tools/video/dung-phim.mjs tools/video/mau-gita.json --out ./video-output
```

Muốn nút **Dựng MP4 trên máy này** trong GITA Studio gọi renderer cục bộ,
mở terminal thứ hai và chạy `node tools/video/may-chu-cuc-bo.mjs`. Giữ terminal
mở, chỉ định origin web đúng nếu đang dùng preview, rồi nhập token ngẫu nhiên
mà terminal in ra vào Studio. Service chỉ bind `127.0.0.1`, không mở ra Internet.
Muốn bật dịch phụ đề qua VideoLingo, chạy API VideoLingo local riêng rồi khởi
động companion với `GITA_VIDEOLINGO_URL=http://127.0.0.1:8000`; trong Studio
chọn mã ngôn ngữ và xác nhận lượt xử lý. Dubbing đang tắt.

Bộ dựng tạo MP4, SRT và passport JSON; xem schema, giới hạn, adapter
VideoLingo/Video2X/Remotion và kiểm thử tại
`docs/GITA-STUDIO-VIDEO-PIPELINE.md`. Render chạy trên máy cục bộ, không phải
Cloudflare Worker. Hộ chiếu Worker chỉ ghi metadata và đèn do trình duyệt khai
báo; nó không xác minh tệp MP4. Media không gửi ra ngoài qua bộ dựng này.

*Gói do phiên khôi phục + nâng cấp thiết kế dựng ra. Bộ gộp: `node tools/gop-src.js`.*

## Chatbot · Bộ não · Owncast (28/09/2026)

Xem `docs/GITA-CHATBOT-BRAIN.md`: quản lý hội thoại theo phiên, tài liệu có
trích dẫn, PDF cục bộ, Ollama streaming, giao việc vào bộ não điều phối và
nhúng lớp trực tiếp Owncast. Companion: `node tools/chat/may-chu-chat.mjs`.
