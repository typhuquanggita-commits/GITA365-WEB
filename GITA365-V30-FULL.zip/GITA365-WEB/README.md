# GITA 365 · Hệ Sinh Thái Gia Đình Thịnh Vượng

Web app/PWA của Học viện GITA: giao diện tĩnh, kho nội dung mã hóa và máy chủ Cloudflare Worker dùng D1. Các phần mã nguồn hiện có trong repository này; việc cấp phép thật cần triển khai Worker, D1, R2 và các bí mật của Học viện.

## Chạy và kiểm tra trên máy

```bash
node tools/gop-src.js --kiem
node tools/thu-khoi-tao.mjs
node tools/thu-service-worker.mjs
node tools/thu-phien-trinh-duyet.mjs
node tools/thu-viec-dieu-phoi.mjs
node tools/thu-xuat-hoi-thoai.mjs
node tools/thu-giong-doc.mjs
node tools/thu-micro.mjs
python3 tools/thu-piper-proxy.py
node tools/tao-site.mjs
python3 -m http.server 8099 -d _site
```

Mở `http://localhost:8099`. Khi sửa tệp trong `src/`, chạy `node tools/gop-src.js` để dựng lại `gita-app.js` và `gita-nghe.js`, rồi chạy lại `node tools/tao-site.mjs`. Bộ kiểm thử dùng Node 24. Các tài khoản trải nghiệm trong giao diện chỉ dùng để xem bản mẫu; chúng không phải phiên đăng nhập máy chủ.

## Cấu trúc đang có

| Đường dẫn | Vai trò |
|---|---|
| `index.html`, `assets/`, `sw.js`, `manifest.webmanifest` | Giao diện, tài nguyên và vỏ PWA |
| `src/`, `tools/danh-sach-src.json` | Mã nguồn trình duyệt và thứ tự ghép gói |
| `gita-app.js`, `gita-nghe.js` | Hai gói JavaScript đã ghép để phát hành |
| `kho/*.enc` | Nội dung mã hóa; không đưa tệp khóa vào repository |
| `may-chu/` | Cloudflare Worker, lược đồ D1, thiết lập Wrangler |
| `tools/tao-site.mjs` | Chỉ sao chép tài nguyên web vào `_site/` |
| `.github/workflows/deploy.yml` | Kiểm tra và xuất bản `_site/` lên GitHub Pages |

Service worker lưu vỏ web và nội dung mẫu theo chính sách bộ đệm; nội dung có cấp phép cần kết nối và không được hứa mở đầy đủ khi ngoại tuyến. Sổ việc trong màn **Điều phối trợ lý AI** lưu công việc và kết quả vào D1, có bước quản trị duyệt; nó không tự chạy mô hình AI. Sổ có lịch sử sự kiện chỉ ghi thêm (tạo việc, chuyển trạng thái, duyệt và ghi chú), lấy ý tưởng nhật ký hoạt động thống nhất từ [Block Buzz](https://github.com/block/buzz) và điều chỉnh cho quyền truy cập R01–R02 cùng cách triển khai D1 của GITA365. Hội thoại trợ lý chạy trên thiết bị và không được lưu bền; lấy cảm hứng từ cách Codex ChatGPT Web giữ mạch hội thoại theo tác vụ, GITA365 cho phép người dùng chủ động tải transcript Markdown khi cần lưu hoặc chuyển ngữ cảnh.

Phiên máy chủ giữ token trong bộ nhớ, đăng xuất sẽ yêu cầu máy chủ thu hồi token và nạp lại trang. Dữ liệu công việc lưu trong trình duyệt theo từng tên tài khoản để khôi phục sau khi chính tài khoản đó đăng nhập thật; nếu dùng máy chung, cần lưu ý dữ liệu ở bộ nhớ trình duyệt vẫn có thể được người có quyền truy cập máy đọc bằng công cụ của trình duyệt.

Tính năng đọc câu trả lời bằng tiếng Việt và hướng dẫn cài Piper tùy chọn xem tại [VOICE.md](VOICE.md). Đọc thành tiếng bị khóa với khách hàng và nội dung có bảo vệ bản sao.

## Đưa lên mạng

Xem [TRIEN-KHAI.md](TRIEN-KHAI.md). Cloudflare Pages dùng lệnh build `node tools/gop-src.js --kiem && node tools/tao-site.mjs`, thư mục xuất bản `_site`. Worker cần `database_id` thật trong `may-chu/wrangler.toml`, bucket R2 và các secret; giá trị chờ tạo trong repository không thể dùng để triển khai production. Nâng cấp D1 trước Worker rồi mới phát hành giao diện mới.

GitHub Pages workflow là phương án phát hành tĩnh riêng; `_headers` và `_redirects` chỉ có hiệu lực trên nền tảng hỗ trợ chúng như Cloudflare Pages. Tên miền tùy chỉnh của GitHub Pages phải cấu hình trong cài đặt repository.

Mã nguồn và nội dung GITA tuân theo [LICENSE](LICENSE) và [NOTICE](NOTICE). Không đưa `kho/khoa.json`, mã khởi tạo hay bất kỳ secret nào vào git.
