import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';

const source = readFileSync(new URL('../src/tro-ly-chat.js', import.meta.url), 'utf8');
const spoken = [], canceled = [], toasts = [], audit = [];
const speech = {getVoices(){return [
  {name:'English voice',lang:'en-US',localService:true},
  {name:'Vietnamese cloud',lang:'vi-VN',localService:false},
  {name:'Vietnamese Natural',lang:'vi-VN',localService:true}
];}, speak(x){spoken.push(x);}, cancel(){canceled.push(true);}};
function SpeechSynthesisUtterance(text){this.text=text;}
const document = {addEventListener(){}, hidden:false};
const G = {U:{h:x=>String(x),ic:()=>'',toast:(...x)=>toasts.push(x)},S:{acc:{ten:'Minh'}},VIEWS:{},
  BI_KHOA_CHEP:()=>true, secLog:(...x)=>audit.push(x)};
const window = {G, speechSynthesis:speech, SpeechSynthesisUtterance, addEventListener(){}};
vm.runInNewContext(source, {window, document, URL, Date, setTimeout(){}, console});

const bubble = {cloneNode(){return {querySelectorAll(){return [];},innerText:'Đây là câu trả lời tiếng Việt.'};}};
const button = {textContent:'Nghe', attrs:{}, closest(){return bubble;}, setAttribute(k,v){this.attrs[k]=v;}};
G.chatDoc(button);
assert.equal(spoken.length,0,'tài khoản bị khóa không được đọc nội dung');
assert.equal(audit.at(-1)[0],'Chặn đọc to');

G.BI_KHOA_CHEP=()=>false;
G.chatDoc(button);
assert.equal(spoken.length,1,'vai nội bộ phát giọng cục bộ');
assert.equal(spoken[0].text,'Đây là câu trả lời tiếng Việt.');
assert.equal(spoken[0].voice.name,'Vietnamese Natural','ưu tiên giọng Việt cục bộ');
assert.equal(spoken[0].lang,'vi-VN');
assert.equal(spoken[0].rate,0.96);
assert.equal(button.textContent,'Dừng nghe');
G.chatDoc(button);
assert.equal(canceled.length > 0,true,'bấm lần nữa dừng giọng đang chạy');
assert.equal(button.textContent,'Nghe');

speech.getVoices=()=>[{name:'Vietnamese remote',lang:'vi-VN',localService:false}];
G.chatDoc(button);
assert.equal(spoken.length,1,'không tự gửi nội dung sang giọng đám mây');
assert.match(toasts.at(-1)[0],/cục bộ/);
console.log('Giọng trợ lý: khóa vai khách, giọng vi-VN cục bộ, dừng và từ chối voice mạng đạt.');
