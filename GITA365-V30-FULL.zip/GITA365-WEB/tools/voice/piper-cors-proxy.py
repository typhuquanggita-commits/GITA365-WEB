#!/usr/bin/env python3
"""Loopback-only CORS bridge for a locally running Piper HTTP server.

The bridge deliberately exposes one endpoint, limits request/audio size,
checks browser Origin, and never logs speech text. It is not an internet API.
"""
from __future__ import annotations

import argparse
import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.error import URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen

MAX_TEXT = 6000
MAX_BODY = 32000
MAX_AUDIO = 20 * 1024 * 1024
DEFAULT_ORIGINS = {
    "https://gita.edu.vn", "https://www.gita.edu.vn",
    "http://localhost:8099", "http://127.0.0.1:8099",
}


def parse_payload(raw: bytes) -> str:
    if len(raw) > MAX_BODY:
        raise ValueError("request too large")
    try:
        data = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("invalid JSON") from exc
    text = data.get("text") if isinstance(data, dict) else None
    if not isinstance(text, str) or not text.strip():
        raise ValueError("text is required")
    text = text.strip()
    if len(text) > MAX_TEXT:
        raise ValueError("text too long")
    return text


def safe_upstream(value: str) -> str:
    p = urlparse(value)
    if p.scheme != "http" or p.hostname not in {"127.0.0.1", "localhost"} or p.path != "/synthesize":
        raise ValueError("upstream must be local Piper /synthesize")
    return value


def make_handler(upstream: str, allowed_origins: set[str]):
    class Handler(BaseHTTPRequestHandler):
        server_version = "GITA-Piper-Local/1.0"

        def _cors(self) -> bool:
            origin = self.headers.get("Origin", "")
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
            self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.send_header("Access-Control-Allow-Private-Network", "true")
            self.send_header("Cache-Control", "no-store")
            return True

        def do_OPTIONS(self):
            if self.path != "/synthesize":
                self.send_error(404)
                return
            if self.headers.get("Origin", "") not in allowed_origins:
                self.send_error(403, "origin not allowed")
                return
            self.send_response(204)
            self._cors()
            self.end_headers()

        def do_POST(self):
            if self.path != "/synthesize":
                self.send_error(404)
                return
            if self.headers.get("Origin", "") not in allowed_origins:
                self.send_error(403, "origin not allowed")
                return
            if self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower() != "application/json":
                self.send_error(415, "application/json required")
                return
            try:
                size = int(self.headers.get("Content-Length", "-1"))
                if size < 0 or size > MAX_BODY:
                    raise ValueError("request too large")
                text = parse_payload(self.rfile.read(size))
            except ValueError as exc:
                self.send_error(400, str(exc))
                return
            req = Request(upstream, data=json.dumps({"text": text}, ensure_ascii=False).encode("utf-8"),
                          headers={"Content-Type": "application/json"}, method="POST")
            try:
                with urlopen(req, timeout=180) as response:
                    kind = response.headers.get_content_type()
                    audio = response.read(MAX_AUDIO + 1)
                if kind not in {"audio/wav", "audio/x-wav"} or len(audio) > MAX_AUDIO:
                    self.send_error(502, "invalid Piper audio response")
                    return
            except (URLError, TimeoutError, OSError) as exc:
                self.send_error(502, "local Piper server unavailable")
                return
            self.send_response(200)
            self._cors()
            self.send_header("Content-Type", "audio/wav")
            self.send_header("Content-Length", str(len(audio)))
            self.end_headers()
            self.wfile.write(audio)

        def log_message(self, fmt, *args):
            # Do not log headers, JSON payloads, or generated text.
            super().log_message(fmt, *args)

    return Handler


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--upstream", default="http://127.0.0.1:5000/synthesize")
    parser.add_argument("--origin", action="append", help="Allowed exact web origin; repeat as needed")
    args = parser.parse_args()
    upstream = safe_upstream(args.upstream)
    origins = set(args.origin or [])
    origins.update(filter(None, os.environ.get("GITA_VOICE_ORIGINS", "").split(",")))
    if not origins:
        origins = DEFAULT_ORIGINS.copy()
    server = ThreadingHTTPServer(("127.0.0.1", args.port), make_handler(upstream, origins))
    print(f"Piper bridge: http://127.0.0.1:{args.port}/synthesize (loopback only)")
    print("Allowed browser origins: " + ", ".join(sorted(origins)))
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
