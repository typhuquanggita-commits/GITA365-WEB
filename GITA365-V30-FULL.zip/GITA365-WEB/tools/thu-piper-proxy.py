import importlib.util
import json
import threading
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

spec = importlib.util.spec_from_file_location('gita_piper_proxy', Path(__file__).parent / 'voice' / 'piper-cors-proxy.py')
proxy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(proxy)

assert proxy.parse_payload(b'{"text":"Xin chao"}') == 'Xin chao'
for raw in (b'{}', b'{bad', json.dumps({'text':'x' * (proxy.MAX_TEXT + 1)}).encode()):
    try:
        proxy.parse_payload(raw)
    except ValueError:
        pass
    else:
        raise AssertionError('invalid or oversized payload accepted')
for url in ('https://remote.example/synthesize', 'http://127.0.0.1:5000/other'):
    try:
        proxy.safe_upstream(url)
    except ValueError:
        pass
    else:
        raise AssertionError('non-local or wrong-path Piper upstream accepted')

wav = b'RIFF\x00\x00\x00\x00WAVE'
seen = []
class Upstream(BaseHTTPRequestHandler):
    def do_POST(self):
        seen.append(json.loads(self.rfile.read(int(self.headers['Content-Length']))))
        self.send_response(200); self.send_header('Content-Type','audio/wav'); self.end_headers(); self.wfile.write(wav)
    def log_message(self, *_args): pass

up = ThreadingHTTPServer(('127.0.0.1',0), Upstream)
bridge = ThreadingHTTPServer(('127.0.0.1',0), proxy.make_handler(
    f'http://127.0.0.1:{up.server_port}/synthesize', {'https://gita.edu.vn'}))
threads = [threading.Thread(target=s.serve_forever,daemon=True) for s in (up,bridge)]
for t in threads: t.start()
try:
    url = f'http://127.0.0.1:{bridge.server_port}/synthesize'
    pre = urllib.request.Request(url, method='OPTIONS', headers={'Origin':'https://gita.edu.vn'})
    with urllib.request.urlopen(pre) as r:
        assert r.status == 204 and r.headers['Access-Control-Allow-Private-Network'] == 'true'
    req = urllib.request.Request(url, data=b'{"text":"Chao ban"}', method='POST', headers={
        'Origin':'https://gita.edu.vn','Content-Type':'application/json'})
    with urllib.request.urlopen(req) as r:
        assert r.status == 200 and r.headers['Content-Type'] == 'audio/wav' and r.read() == wav
    assert seen == [{'text':'Chao ban'}]
    bad = urllib.request.Request(url, data=b'{"text":"Noi dung"}', method='POST', headers={
        'Origin':'https://evil.example','Content-Type':'application/json'})
    try:
        urllib.request.urlopen(bad)
    except urllib.error.HTTPError as e:
        assert e.code == 403
    else:
        raise AssertionError('unapproved origin passed CORS gate')
finally:
    bridge.shutdown(); up.shutdown()
    bridge.server_close(); up.server_close()
print('Piper bridge: localhost-only upstream, CORS, WAV relay and payload limits đạt.')
