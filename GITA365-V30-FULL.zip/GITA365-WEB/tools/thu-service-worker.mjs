import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';

const handlers = {}, saved = new Map();
let online = true;
const caches = {
  async open() { return {
    async addAll() {},
    async put(req, res) { saved.set(req.url, res); }
  }; },
  async match(req) { return saved.get(req.url); },
  async keys() { return []; },
  async delete() { return true; }
};
const context = {
  URL, Response, caches, console,
  self: {location: {origin:'https://gita.edu.vn'},
    registration: {scope:'https://gita.edu.vn/'},
    clients:{claim:async()=>{}}, skipWaiting:async()=>{},
    addEventListener(type, handler) { handlers[type] = handler; }},
  async fetch(req) {
    if (!online) throw Error('offline');
    return new Response('ok', {status:200,
      headers: {'Cache-Control': req.url.includes('private') ? 'private' : 'public, max-age=60'}});
  }
};
vm.runInNewContext(readFileSync(new URL('../sw.js', import.meta.url), 'utf8'), context);
async function request(path) {
  let response, pending = [];
  const req = {method:'GET', url:'https://gita.edu.vn' + path};
  handlers.fetch({request:req, respondWith(p){ response=p; }, waitUntil(p){pending.push(p);}});
  if (!response) return null;
  const result = await response;
  await Promise.all(pending);
  return result;
}
assert.equal(await request('/api/hoc-vien'), null);
assert.equal(await request('/cap-phep'), null);
assert.equal(await request('/khach-hang.json'), null);
assert.equal(await request('/index.html?token=secret'), null);
assert.equal((await request('/index.html')).status, 200);
assert.equal(saved.has('https://gita.edu.vn/index.html'), true);
online = false;
assert.equal((await request('/index.html')).status, 200);
assert.equal((await request('/gita-nghe.js')).status, 503);
console.log('Service worker: API không cache, trang tĩnh cache, offline trả mã rõ ràng.');
assert.equal(await request('/kho/nen.enc'),null);
assert.equal(await request('/kho/nen.enc?fresh=123'),null);
assert.equal(await request('/kho/mau.json'),null);
assert.equal(await request('/version.json?fresh=123'),null);
const removed=[];context.caches.keys=async()=>['other-app','gita365-old','gita365-v9-99-243'];context.caches.delete=async k=>{removed.push(k);return true;};
let activation;handlers.activate({waitUntil:p=>activation=p});await activation;assert.deepEqual(removed,['gita365-old']);
console.log('Licensed store bypasses caches; activation preserves unrelated app caches.');
