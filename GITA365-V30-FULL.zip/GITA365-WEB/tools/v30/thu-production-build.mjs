import assert from 'node:assert/strict';import {execFile} from 'node:child_process';import {promisify} from 'node:util';import {readFileSync} from 'node:fs';import vm from 'node:vm';
const exec=promisify(execFile),root=new URL('../../',import.meta.url).pathname,env={...process.env};delete env.GITA_API_URL;
try{
 await assert.rejects(exec(process.execPath,['tools/tao-site.mjs','--production'],{cwd:root,env}),e=>e.stderr.includes('Production cần'));
 await assert.rejects(exec(process.execPath,['tools/tao-site.mjs','--production'],{cwd:root,env:{...env,GITA_API_URL:'https://api.example.com/?token=secret'}}),e=>e.stderr.includes('không chứa token'));
 await exec(process.execPath,['tools/tao-site.mjs','--production'],{cwd:root,env:{...env,GITA_API_URL:'https://api.example.com/gita'}});
 const context={window:{},localStorage:{getItem:()=>null}};vm.runInNewContext(readFileSync(new URL('../../_site/cau-hinh.js',import.meta.url),'utf8'),context);assert.equal(context.window.G.API_CAP_PHEP,'https://api.example.com/gita');
}finally{await exec(process.execPath,['tools/tao-site.mjs'],{cwd:root,env});}
console.log('Production build: missing/unsafe API blocked; configured URL injected; default build restored.');
