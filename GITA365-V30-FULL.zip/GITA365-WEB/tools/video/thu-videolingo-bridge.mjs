import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import http from 'node:http';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';

async function freePort(){const s=net.createServer();await new Promise(r=>s.listen(0,'127.0.0.1',r));const p=s.address().port;await new Promise(r=>s.close(r));return p;}
const dir=await fs.mkdtemp(path.join(os.tmpdir(),'gita-lingo-bridge-'));
const origin='http://localhost:4173', token='bridge-test-'+'x'.repeat(40), projectPort=await freePort(), lingoPort=await freePort();
let stage='idle', reads=0, calls=[];
const upstream=http.createServer(async(req,res)=>{
  const chunks=[];for await(const c of req)chunks.push(c);const body=Buffer.concat(chunks).toString();
  if(req.url==='/input'&&req.method==='POST'){
    const d=JSON.parse(body);calls.push(['input',d]);assert.ok((await fs.stat(d.source)).isFile());stage='input';reads=0;res.writeHead(202,{'Content-Type':'application/json'});res.end('{"accepted":true}');return;
  }
  if(req.url==='/run'&&req.method==='POST'){
    const d=JSON.parse(body);calls.push(['run',d]);assert.equal(d.stage,'all');assert.equal(d.dubbing,false);assert.equal(d.target_language,'vi');stage='run';reads=0;res.writeHead(202,{'Content-Type':'application/json'});res.end('{"accepted":true}');return;
  }
  if(req.url==='/status'){
    reads++;const done=reads>=2;res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({state:done?'completed':'running',active:!done,step:stage,files:['trans.srt']}));return;
  }
  if(req.url==='/files/trans.srt'){
    res.writeHead(200,{'Content-Type':'text/plain; charset=utf-8'});res.end('1\n00:00:00,000 --> 00:00:01,000\nXin chào GITA\n');return;
  }
  res.writeHead(404);res.end();
});
await new Promise(r=>upstream.listen(lingoPort,'127.0.0.1',r));
const output=path.join(dir,'out');await fs.mkdir(output);await fs.writeFile(path.join(output,'source.mp4'),'test source');
const serverFile=path.join(path.dirname(fileURLToPath(import.meta.url)),'may-chu-cuc-bo.mjs');
const child=spawn(process.execPath,[serverFile],{cwd:path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..'),env:{...process.env,
  GITA_VIDEO_PORT:String(projectPort),GITA_VIDEO_TOKEN:token,GITA_VIDEO_OUTPUT:output,GITA_VIDEO_ORIGINS:origin,
  GITA_VIDEOLINGO_URL:`http://127.0.0.1:${lingoPort}`},stdio:['ignore','ignore','pipe']});
let err='';child.stderr.on('data',b=>err+=b.toString());
try{
  let health;
  for(let i=0;i<50;i++){try{health=await fetch(`http://127.0.0.1:${projectPort}/health`,{headers:{Origin:origin}});break;}catch{await new Promise(r=>setTimeout(r,100));}}
  assert.ok(health,err);assert.equal((await health.json()).videoLingoConfigured,true);
  const start=await fetch(`http://127.0.0.1:${projectPort}/v1/videolingo`,{method:'POST',headers:{Origin:origin,Authorization:'Bearer '+token,'Content-Type':'application/json'},
    body:JSON.stringify({video:'source.mp4',targetLanguage:'vi'})});
  const job=(await start.json()).job;assert.equal(start.status,202);
  let result;
  for(let i=0;i<50;i++){await new Promise(r=>setTimeout(r,100));const q=await fetch(`http://127.0.0.1:${projectPort}/v1/videolingo/${job.id}`,{headers:{Origin:origin,Authorization:'Bearer '+token}});result=(await q.json()).job;if(result.state==='completed'||result.state==='error')break;}
  assert.equal(result.state,'completed',result.error);assert.equal(result.result.subtitle,'source.vi.srt');
  assert.match(await fs.readFile(path.join(output,'source.vi.srt'),'utf8'),/Xin chào GITA/);
  assert.deepEqual(calls.map(x=>x[0]),['input','run']);
  console.log('VideoLingo adapter: local-only API, task polling, dubbing off, SRT handoff đạt.');
}finally{child.kill('SIGTERM');await new Promise(r=>upstream.close(r));await fs.rm(dir,{recursive:true,force:true});}
