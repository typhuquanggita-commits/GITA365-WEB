import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import {spawn,spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';

const dir=await fs.mkdtemp(path.join(os.tmpdir(),'gita-renderer-test-'));
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');
const serverFile=path.join(path.dirname(fileURLToPath(import.meta.url)),'may-chu-cuc-bo.mjs');
const token='test-token-'+ 'a'.repeat(48), origin='http://localhost:4173';
const listener=net.createServer();
await new Promise(resolve=>listener.listen(0,'127.0.0.1',resolve));
const port=listener.address().port; await new Promise(resolve=>listener.close(resolve));
const slide=path.join(dir,'slide.png');
const gen=spawnSync('ffmpeg',['-hide_banner','-loglevel','error','-f','lavfi','-i','color=c=teal:s=160x90:d=1','-frames:v','1',slide,'-y'],{encoding:'utf8'});
assert.equal(gen.status,0,gen.stderr);
const output=path.join(dir,'rendered');
const child=spawn(process.execPath,[serverFile],{cwd:root,env:{...process.env,GITA_VIDEO_PORT:String(port),GITA_VIDEO_TOKEN:token,
  GITA_VIDEO_OUTPUT:output,GITA_VIDEO_ORIGINS:origin},stdio:['ignore','pipe','pipe']});
let stderr=''; child.stderr.on('data',b=>stderr+=b.toString());
async function waitHealth() {
  for(let i=0;i<50;i++) { try { return await fetch(`http://127.0.0.1:${port}/health`,{headers:{Origin:origin}}); } catch { await new Promise(r=>setTimeout(r,100)); } }
  throw Error('Renderer không khởi động: '+stderr);
}
try {
  const health=await waitHealth(); assert.equal(health.status,200); assert.equal(health.headers.get('access-control-allow-origin'),origin);
  const unauth=await fetch(`http://127.0.0.1:${port}/v1/render`,{method:'POST',headers:{Origin:origin,Authorization:'Bearer wrong','Content-Type':'multipart/form-data; boundary=x'},body:'--x--\r\n'});
  assert.equal(unauth.status,401);
  const form=new FormData();
  form.append('project',JSON.stringify({schemaVersion:'gita.video.v1',title:'Local render',width:160,height:90,fps:24,
    scenes:[{seconds:1,image:'assets/v-1.png',imageFit:'contain',caption:'Kiểm tra bridge'},{seconds:1,background:'#121820',caption:'Đã render'}]}));
  form.append('asset_v-1',new Blob([await fs.readFile(slide)],{type:'image/png'}),'v-1.png');
  const response=await fetch(`http://127.0.0.1:${port}/v1/render`,{method:'POST',headers:{Origin:origin,Authorization:'Bearer '+token},body:form});
  const result=await response.json(); assert.equal(response.status,200,JSON.stringify(result)); assert.equal(result.ok,true);
  assert.ok((await fs.stat(path.join(output,result.video))).size>0);
  assert.ok((await fs.stat(path.join(output,result.subtitles))).size>0);
  const probe=spawnSync('ffprobe',['-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',path.join(output,result.video)],{encoding:'utf8'});
  assert.equal(probe.status,0,probe.stderr); assert.ok(Math.abs(+probe.stdout.trim()-2)<0.2);
  const imageForm=new FormData();
  imageForm.append('image',new Blob([await fs.readFile(slide)],{type:'image/png'}),'cover.png');
  imageForm.append('preset','thumbnail');imageForm.append('fit','cover');imageForm.append('format','webp');
  const imageRes=await fetch(`http://127.0.0.1:${port}/v1/image`,{method:'POST',headers:{Origin:origin,Authorization:'Bearer '+token},body:imageForm});
  assert.equal(imageRes.status,200);assert.equal(imageRes.headers.get('content-type'),'image/webp');
  assert.equal(imageRes.headers.get('x-gita-image-width'),'1280');assert.equal(imageRes.headers.get('x-gita-image-height'),'720');
  assert.match(String(imageRes.headers.get('access-control-expose-headers')||''),/X-GITA-Image-Width/i);
  assert.ok((await imageRes.arrayBuffer()).byteLength>500);
  console.log('GITA local studio companion: CORS/token, upload, MP4 thật và xử lý ảnh ImageMagick đạt.');
} finally { child.kill('SIGTERM'); await fs.rm(dir,{recursive:true,force:true}); }
