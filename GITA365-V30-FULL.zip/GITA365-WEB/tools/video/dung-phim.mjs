#!/usr/bin/env node
/* Bộ dựng video cục bộ GITA. Chạy ffmpeg bằng argv, không qua shell. */
import fs from 'node:fs/promises';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';

const VERSION = 'gita.video.v1';
const help = `GITA Video Renderer — dựng MP4 tại máy bằng FFmpeg\n\n` +
  `Cách dùng: node tools/video/dung-phim.mjs <project.json> [--out thu-muc]\n` +
  `Ví dụ:    node tools/video/dung-phim.mjs tools/video/mau-gita.json --out ./rendered\n`;

function args(argv) {
  if (!argv.length || argv.includes('--help') || argv.includes('-h')) return null;
  const file = argv[0]; let out = 'video-output';
  for (let i = 1; i < argv.length; i++) {
    if (argv[i] === '--out' && argv[i + 1]) out = argv[++i];
    else throw Error('Tham số không hợp lệ: ' + argv[i]);
  }
  return {file:path.resolve(file), out:path.resolve(out)};
}

function run(bin, argv) {
  return new Promise((resolve, reject) => {
    const p = spawn(bin, argv, {stdio:['ignore','ignore','pipe'], windowsHide:true});
    let err = '';
    p.stderr.on('data', b => { if (err.length < 12000) err += b.toString(); });
    p.on('error', e => reject(Error(`${bin} không chạy được: ${e.message}`)));
    p.on('close', code => code === 0 ? resolve() : reject(Error(`${bin} kết thúc mã ${code}: ${err.slice(-3000)}`)));
  });
}

function srtTime(seconds) {
  const ms = Math.max(0, Math.round(seconds * 1000));
  const hh = String(Math.floor(ms / 3600000)).padStart(2,'0');
  const mm = String(Math.floor(ms / 60000) % 60).padStart(2,'0');
  const ss = String(Math.floor(ms / 1000) % 60).padStart(2,'0');
  return `${hh}:${mm}:${ss},${String(ms % 1000).padStart(3,'0')}`;
}
function subtitleChunks(text, max=34) {
  const words=String(text||'').replace(/\s+/g,' ').trim().split(' ').filter(Boolean), lines=[];
  let line='';
  for(const word of words) {
    if(line && (line+' '+word).length>max) { lines.push(line); line=word; }
    else line+=(line?' ':'')+word;
  }
  if(line) lines.push(line);
  const chunks=[];
  for(let i=0;i<lines.length;i+=2) chunks.push(lines.slice(i,i+2).join('\n'));
  return chunks;
}

function validate(p) {
  if (!p || p.schemaVersion !== VERSION) throw Error(`schemaVersion phải là ${VERSION}.`);
  if (typeof p.title !== 'string' || !p.title.trim() || p.title.length > 160) throw Error('Tên video cần 1–160 ký tự.');
  const w = Number(p.width || 1080), h = Number(p.height || 1920), fps = Number(p.fps || 30);
  if (!Number.isInteger(w) || !Number.isInteger(h) || w < 160 || h < 90 || w > 3840 || h > 3840 || w % 2 || h % 2 || w * h > 3840 * 2160)
    throw Error('Kích thước phải là số chẵn từ 160×90 đến tối đa 4K.');
  if (![24,25,30,50,60].includes(fps)) throw Error('FPS hỗ trợ: 24, 25, 30, 50 hoặc 60.');
  if (!Number.isInteger(Number(p.crf ?? 20)) || Number(p.crf ?? 20) < 0 || Number(p.crf ?? 20) > 51)
    throw Error('CRF phải là số nguyên từ 0 đến 51.');
  if (!['ultrafast','superfast','veryfast','faster','fast','medium','slow','slower','veryslow'].includes(String(p.preset || 'medium')))
    throw Error('Preset H.264 không hợp lệ.');
  if (!Array.isArray(p.scenes) || !p.scenes.length || p.scenes.length > 120) throw Error('Cần 1–120 cảnh.');
  let total = 0;
  p.scenes.forEach((s,i) => {
    if (!s || !Number.isFinite(+s.seconds) || +s.seconds < 1 || +s.seconds > 600)
      throw Error(`Cảnh ${i + 1}: thời lượng phải từ 1 đến 600 giây.`);
    if (s.image != null && typeof s.image !== 'string') throw Error(`Cảnh ${i + 1}: image phải là đường dẫn tương đối.`);
    if (s.imageFit != null && !['cover','contain'].includes(s.imageFit)) throw Error(`Cảnh ${i + 1}: imageFit chỉ nhận cover hoặc contain.`);
    if (s.narration != null && typeof s.narration !== 'string') throw Error(`Cảnh ${i + 1}: narration phải là đường dẫn tương đối.`);
    if (s.caption != null && String(s.caption).length > 2000) throw Error(`Cảnh ${i + 1}: phụ đề vượt 2.000 ký tự.`);
    total += +s.seconds;
  });
  if (total > 1800) throw Error('Bản dựng cục bộ giới hạn 30 phút mỗi lượt.');
  if (p.music != null && (typeof p.music !== 'object' || Array.isArray(p.music))) throw Error('music phải là object hoặc null.');
  if (p.music && p.music.volume != null && (!Number.isFinite(+p.music.volume) || +p.music.volume < 0 || +p.music.volume > 1))
    throw Error('Âm lượng nhạc nền nằm trong khoảng 0–1.');
  return {w,h,fps,total};
}

async function resolveAsset(root, rel, label) {
  if (!rel) return null;
  if (path.isAbsolute(rel)) throw Error(`${label}: chỉ nhận đường dẫn tương đối trong thư mục project.`);
  const full = path.resolve(root, rel), back = path.relative(root, full);
  if (back === '..' || back.startsWith('..' + path.sep) || path.isAbsolute(back)) throw Error(`${label}: đường dẫn vượt khỏi thư mục project.`);
  const st = await fs.stat(full).catch(() => null);
  if (!st || !st.isFile()) throw Error(`${label}: không tìm thấy tệp ${rel}.`);
  if (st.size > 80*1024*1024) throw Error(`${label}: mỗi tệp media tối đa 80 MB.`);
  return full;
}

export async function renderProject(opt) {
  const ffmpegBin=opt.ffmpeg || 'ffmpeg';
  const project = JSON.parse(await fs.readFile(opt.file, 'utf8'));
  const {w,h,fps,total} = validate(project), root = path.dirname(opt.file);
  const scenes = [];
  for (let i = 0; i < project.scenes.length; i++) {
    const s = project.scenes[i];
    const imagePath=await resolveAsset(root,s.image,`Cảnh ${i + 1} · ảnh`);
    const narrationPath=await resolveAsset(root,s.narration,`Cảnh ${i + 1} · giọng`);
    if(imagePath&&!['.png','.jpg','.jpeg','.webp','.bmp'].includes(path.extname(imagePath).toLowerCase()))
      throw Error(`Cảnh ${i + 1}: ảnh chỉ nhận PNG, JPG, WebP hoặc BMP.`);
    if(narrationPath&&!['.wav','.mp3','.m4a','.aac','.ogg','.flac','.webm'].includes(path.extname(narrationPath).toLowerCase()))
      throw Error(`Cảnh ${i + 1}: định dạng giọng chưa hỗ trợ.`);
    scenes.push({...s,imagePath,narrationPath});
    if (!scenes[i].imagePath && !/^#[0-9a-f]{6}$/i.test(String(s.background || '#10131a')))
      throw Error(`Cảnh ${i + 1}: background cần mã màu #RRGGBB.`);
  }
  const musicPath = await resolveAsset(root, project.music && project.music.path, 'Nhạc nền');
  if(musicPath&&!['.wav','.mp3','.m4a','.aac','.ogg','.flac','.webm'].includes(path.extname(musicPath).toLowerCase()))
    throw Error('Nhạc nền phải là WAV, MP3, M4A, AAC, OGG, FLAC hoặc WebM.');
  await fs.mkdir(opt.out,{recursive:true});
  const safeName = String(project.slug || project.title).normalize('NFKD').replace(/[\u0300-\u036f]/g,'')
    .replace(/[^a-zA-Z0-9_-]+/g,'-').replace(/^-|-$/g,'').slice(0,60) || 'gita-video';
  let fileBase=safeName, revision=2;
  while(await fs.access(path.join(opt.out,fileBase+'.mp4')).then(()=>true,()=>false)) fileBase=safeName+'-v'+revision++;
  const mp4 = path.join(opt.out,fileBase + '.mp4'), srt = path.join(opt.out,fileBase + '.srt');
  const inputs = [], filters = [], labels = [], audioLabels = [];
  let sceneStart = 0, idx = 0;
  for (let i = 0; i < scenes.length; i++) {
    const s = scenes[i], duration = +s.seconds, inputIndex = idx++;
    if (s.imagePath) inputs.push('-loop','1','-framerate',String(fps),'-t',String(duration),'-i',s.imagePath);
    else inputs.push('-f','lavfi','-i',`color=c=${s.background || '#10131a'}:s=${w}x${h}:r=${fps}:d=${duration}`);
    const v = `v${i}`;
    const frameFit=s.imageFit==='contain'
      ? `scale=${w}:${h}:force_original_aspect_ratio=decrease,pad=${w}:${h}:(ow-iw)/2:(oh-ih)/2:color=0x10131a`
      : `scale=${w}:${h}:force_original_aspect_ratio=increase,crop=${w}:${h}`;
    const fit = `${frameFit},zoompan=z='min(zoom+0.0005,1.08)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=1:s=${w}x${h}:fps=${fps},setsar=1,trim=duration=${duration},setpts=PTS-STARTPTS,format=yuv420p`;
    filters.push(`[${inputIndex}:v]${fit}[${v}]`); labels.push(`[${v}]`);
    if (s.narrationPath) {
      const ai = idx++;
      inputs.push('-i',s.narrationPath);
      const a = `a${i}`, delay = Math.round(sceneStart * 1000);
      filters.push(`[${ai}:a]aresample=48000,apad,atrim=duration=${duration},asetpts=PTS-STARTPTS,adelay=${delay}|${delay}[${a}]`);
      audioLabels.push(`[${a}]`);
    }
    sceneStart += duration;
  }
  if (musicPath) {
    const mi = idx++, volume = Math.max(0,Math.min(1,Number(project.music.volume ?? 0.12)));
    inputs.push('-stream_loop','-1','-i',musicPath);
    filters.push(`[${mi}:a]aresample=48000,volume=${volume},atrim=duration=${total},asetpts=PTS-STARTPTS[amusic]`);
    audioLabels.push('[amusic]');
  }
  filters.push(`${labels.join('')}concat=n=${scenes.length}:v=1:a=0[vjoined]`);
  if (audioLabels.length) filters.push(`${audioLabels.join('')}amix=inputs=${audioLabels.length}:duration=longest:normalize=0,alimiter=limit=0.95[aout]`);
  const sub = [];
  sceneStart = 0; let captionIndex = 0;
  scenes.forEach(s => {
    const caption = String(s.caption || '').trim();
    if (caption) {
      const chunks=subtitleChunks(caption), span=(+s.seconds)/chunks.length;
      chunks.forEach((part,i)=>sub.push(String(++captionIndex),`${srtTime(sceneStart+span*i)} --> ${srtTime(sceneStart+span*(i+1))}`,part,''));
    }
    sceneStart += +s.seconds;
  });
  await fs.writeFile(srt, sub.join('\n') + (sub.length ? '\n' : ''),'utf8');
  const filterPath = path.join(opt.out,fileBase + '.burn.srt');
  const burn = project.burnSubtitles !== false && sub.length > 0;
  if (burn) await fs.writeFile(filterPath,sub.join('\n'),'utf8');
  if (burn) filters.push(`[vjoined]subtitles=filename='${filterPath.replace(/\\/g,'/').replace(/:/g,'\\:')}':original_size=${w}x${h}:force_style='FontName=Arial,FontSize=8,PrimaryColour=&H00FFF6E8,OutlineColour=&H990B0E15,BorderStyle=1,Outline=1,Shadow=0.5,Alignment=2,MarginL=100,MarginR=100,MarginV=120,WrapStyle=0'[vout]`);
  else filters.push('[vjoined]null[vout]');
  const makeArgs = graph => [...inputs,'-filter_complex',graph,'-map','[vout]',...(audioLabels.length?['-map','[aout]']:[]),
    '-t',String(total),'-c:v','libx264','-preset',String(project.preset || 'medium'),'-crf',String(project.crf ?? 20),
    '-pix_fmt','yuv420p','-r',String(fps),...(audioLabels.length?['-c:a','aac','-b:a','192k']:['-an']),
    '-movflags','+faststart','-metadata',`title=${String(project.title).replace(/[\r\n]/g,' ').slice(0,160)}`,'-y',mp4];
  try {
    await run(ffmpegBin,['-hide_banner','-loglevel','error',...makeArgs(filters.join(';'))]);
  } catch (e) {
    if (!burn) throw e;
    const noSub = filters.slice(0,-1).concat('[vjoined]null[vout]').join(';');
    await run(ffmpegBin,['-hide_banner','-loglevel','error',...makeArgs(noSub)]);
    process.stderr.write('CẢNH BÁO: FFmpeg không có libass; đã xuất MP4 không chèn chữ. Tệp SRT được giữ riêng.\n');
  }
  if (burn) await fs.rm(filterPath,{force:true});
  const passport = {schemaVersion:VERSION,title:project.title,output:path.basename(mp4),subtitle:path.basename(srt),
    durationSeconds:total,frameRate:fps,resolution:`${w}x${h}`,sceneCount:scenes.length,
    audioTracks:audioLabels.length,renderedAt:new Date().toISOString(),renderer:'FFmpeg local',
    postProcessing:{upscale:'not-run',interpolation:'not-run',asr:'not-run',translation:'not-run'}};
  await fs.writeFile(path.join(opt.out,fileBase + '.passport.json'),JSON.stringify(passport,null,2)+'\n','utf8');
  process.stdout.write(`Đã dựng ${mp4}\n${w}×${h} · ${fps} fps · ${total}s · ${scenes.length} cảnh\nPhụ đề: ${srt}\n`);
  return {mp4,srt,passport:path.join(opt.out,fileBase + '.passport.json'),metadata:passport};
}

async function main() {
  const opt = args(process.argv.slice(2));
  if (!opt) { process.stdout.write(help); return; }
  await renderProject(opt);
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url))
  main().catch(e => { console.error('Dựng phim thất bại:',e.message); process.exitCode=1; });
