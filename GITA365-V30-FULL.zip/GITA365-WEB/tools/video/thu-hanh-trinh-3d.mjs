import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import vm from 'node:vm';
const file=new URL('../../src/hanh-trinh-3d.js',import.meta.url);
const source=await fs.readFile(file,'utf8');
const tiers=[
  {code:'T1',name:'NHẬN DIỆN',q:'Đang có vấn đề gì?',c:'#185AB4',goal:'Quan sát.'},
  {code:'T2',name:'GIẢI MÃ',q:'Vì sao?',c:'#5140B4',goal:'Kiểm chứng.'},
  {code:'T3',name:'KIẾN TẠO',q:'Làm thế nào?',c:'#0B6675',goal:'Kiến tạo.'},
  {code:'T4',name:'CHUYỂN HÓA',q:'Duy trì ra sao?',c:'#0B7350',goal:'Duy trì.'},
  {code:'T5',name:'BỨT PHÁ',q:'Phát triển tới đâu?',c:'#BE0E16',goal:'Lan tỏa.'}
];
const window={G:{TIERS:tiers}};
vm.runInNewContext(source,{window});
const stages=window.G.hanhTrinh3D.stages;
assert.deepEqual(stages.map(x=>x.code),tiers.map(x=>x.code));
assert.deepEqual(stages.map(x=>x.name),tiers.map(x=>x.name));
assert.deepEqual(stages.map(x=>x.colorHex),tiers.map(x=>x.c));
assert.equal(stages[2].desc,tiers[2].goal);
assert.match(source,/getContext\('webgl'/);
assert.match(source,/prefers-reduced-motion/);
assert.match(source,/toBlob/);
console.log('GITA Learning World: tầng/màu/mục tiêu lấy từ G.TIERS; WebGL, reduced-motion và đường chụp Studio có mặt.');
