#!/usr/bin/env node
/* Companion renderer chỉ bind loopback. Không có route shell/đọc tệp tùy ý. */
import {createServer} from 'node:http';
import {randomBytes,randomUUID,timingSafeEqual} from 'node:crypto';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {renderProject} from './dung-phim.mjs';
import {processImage,PRESETS} from '../image/xu-anh.mjs';

const HOST='127.0.0.1', PORT=Math.max(1024,Math.min(65535,Number(process.env.GITA_VIDEO_PORT||8766)));
const TOKEN=process.env.GITA_VIDEO_TOKEN || randomBytes(32).toString('hex');
const MAX_BODY=200*1024*1024, MAX_FILES=40, MAX_FILE=80*1024*1024;
const OUTPUT=path.resolve(process.env.GITA_VIDEO_OUTPUT || path.join(process.cwd(),'video-output'));
const IMAGE_OUTPUT=path.resolve(process.env.GITA_IMAGE_OUTPUT || path.join(process.cwd(),'image-output'));
const ORIGINS=new Set((process.env.GITA_VIDEO_ORIGINS || 'https://gita.edu.vn,http://localhost:4173,http://127.0.0.1:4173')
  .split(',').map(x=>x.trim()).filter(Boolean));
const EXTS=new Set(['.png','.jpg','.jpeg','.webp','.bmp','.wav','.mp3','.m4a','.aac','.ogg','.flac','.webm']);
let busy=false;
let busyImage=false;
let busyLingo=false;
const lingoJobs=new Map();
const LINGO_URL=String(process.env.GITA_VIDEOLINGO_URL||'').replace(/\/$/,'');
if (LINGO_URL) {
  const u=new URL(LINGO_URL);
  if (u.protocol!=='http:' || !['127.0.0.1','localhost','[::1]'].includes(u.hostname))
    throw Error('GITA_VIDEOLINGO_URL phải là HTTP loopback (127.0.0.1, localhost hoặc ::1).');
}

function cors(origin) {
  return {'Access-Control-Allow-Origin':origin,'Vary':'Origin','Access-Control-Allow-Methods':'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers':'Authorization, Content-Type','Access-Control-Expose-Headers':'Content-Disposition, X-GITA-Image-Width, X-GITA-Image-Height, X-GITA-Image-Bytes','Access-Control-Max-Age':'600',
    'Access-Control-Allow-Private-Network':'true'};
}
function reply(res,code,obj,origin) {
  const headers={'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',
    'X-Content-Type-Options':'nosniff',...(origin?cors(origin):{})};
  res.writeHead(code,headers); res.end(JSON.stringify(obj));
}
function authorized(req) {
  const got=String(req.headers.authorization||'').replace(/^Bearer\s+/i,'');
  const a=Buffer.from(got), b=Buffer.from(TOKEN);
  return a.length===b.length && timingSafeEqual(a,b);
}
async function bodyLimited(req) {
  const n=Number(req.headers['content-length']||0);
  if (n>MAX_BODY) throw Object.assign(Error('Gói media vượt giới hạn 200 MB.'),{status:413});
  const chunks=[]; let total=0;
  for await (const chunk of req) {
    total+=chunk.length;
    if (total>MAX_BODY) throw Object.assign(Error('Gói media vượt giới hạn 200 MB.'),{status:413});
    chunks.push(chunk);
  }
  return Buffer.concat(chunks,total);
}

const server=createServer(async (req,res)=>{
  const origin=String(req.headers.origin||'');
  if (req.method==='OPTIONS') {
    if (!ORIGINS.has(origin)) return reply(res,403,{ok:false,error:'Origin chưa được cho phép. Khai báo GITA_VIDEO_ORIGINS.'});
    res.writeHead(204,cors(origin)); res.end(); return;
  }
  if (req.url==='/health' && req.method==='GET') {
    if (origin && !ORIGINS.has(origin)) return reply(res,403,{ok:false,error:'Origin chưa được cho phép.'});
    return reply(res,200,{ok:true,name:'GITA local video renderer',version:'1',busy,output:OUTPUT,
      videoLingoConfigured:!!LINGO_URL,busyLingo},origin||undefined);
  }
  const lingoStatus=req.url.match(/^\/v1\/videolingo\/([a-f0-9-]{36})$/i);
  if (lingoStatus && req.method==='GET') {
    if (!ORIGINS.has(origin)) return reply(res,403,{ok:false,error:'Origin chưa được cho phép.'});
    if (!authorized(req)) return reply(res,401,{ok:false,error:'Mã kết nối cục bộ không đúng.'},origin);
    const job=lingoJobs.get(lingoStatus[1]);
    if (!job) return reply(res,404,{ok:false,error:'Không tìm thấy tác vụ VideoLingo.'},origin);
    return reply(res,200,{ok:true,job:{id:job.id,state:job.state,progress:job.progress,error:job.error,result:job.result}},origin);
  }
  if (req.url==='/v1/videolingo' && req.method==='POST') {
    if (!ORIGINS.has(origin)) return reply(res,403,{ok:false,error:'Origin chưa được cho phép.'});
    if (!authorized(req)) return reply(res,401,{ok:false,error:'Mã kết nối cục bộ không đúng.'},origin);
    if (!LINGO_URL) return reply(res,503,{ok:false,error:'VideoLingo chưa được nối. Khởi động local API rồi đặt GITA_VIDEOLINGO_URL=http://127.0.0.1:8000.'},origin);
    if (busy || busyLingo) return reply(res,409,{ok:false,error:'Renderer hoặc VideoLingo đang xử lý tác vụ khác.'},origin);
    try {
      const bytes=await bodyLimited(req), input=JSON.parse(bytes.toString('utf8'));
      const video=String(input.video||''), language=String(input.targetLanguage||'vi');
      if (!/^[A-Za-z0-9_-]{1,80}\.mp4$/.test(video)) throw Object.assign(Error('Tên MP4 không hợp lệ.'),{status:400});
      if (!/^[a-zA-Z-]{2,20}$/.test(language)) throw Object.assign(Error('Mã ngôn ngữ không hợp lệ.'),{status:400});
      const file=path.resolve(OUTPUT,video), rel=path.relative(OUTPUT,file);
      if (rel.startsWith('..') || path.isAbsolute(rel)) throw Object.assign(Error('Video phải nằm trong thư mục renderer.'),{status:400});
      const st=await fs.stat(file).catch(()=>null);
      if (!st || !st.isFile() || st.size>4*1024*1024*1024) throw Object.assign(Error('Không tìm thấy MP4 hợp lệ trong thư mục renderer.'),{status:404});
      const id=randomUUID(), job={id,state:'queued',progress:'Đang xếp lượt cục bộ',error:'',result:null};
      lingoJobs.set(id,job);
      while (lingoJobs.size>20) lingoJobs.delete(lingoJobs.keys().next().value);
      busyLingo=true;
      runVideoLingo(job,file,video,language).catch(e=>{job.state='error';job.error=String(e.message||e).slice(0,1200);})
        .finally(()=>{busyLingo=false;});
      return reply(res,202,{ok:true,job:{id,state:job.state}},origin);
    } catch(e) { return reply(res,e.status||400,{ok:false,error:String(e.message||e).slice(0,1200)},origin); }
  }
  if (req.url==='/v1/image' && req.method==='POST') {
    if (!ORIGINS.has(origin)) return reply(res,403,{ok:false,error:'Origin chưa được cho phép. Khai báo GITA_VIDEO_ORIGINS.'});
    if (!authorized(req)) return reply(res,401,{ok:false,error:'Mã kết nối cục bộ không đúng.'},origin);
    if (busyImage) return reply(res,409,{ok:false,error:'Bộ xử lý ảnh đang xử lý một ảnh khác.'},origin);
    if (!/^multipart\/form-data;\s*boundary=/i.test(String(req.headers['content-type']||'')))
      return reply(res,415,{ok:false,error:'Cần gửi ảnh dạng multipart/form-data.'},origin);
    busyImage=true;
    let temp='';
    try {
      const bytes=await bodyLimited(req);
      const webReq=new Request('http://127.0.0.1/v1/image',{method:'POST',headers:{'content-type':req.headers['content-type']},body:bytes});
      const form=await webReq.formData(), image=form.get('image'), preset=String(form.get('preset')||'post');
      const fit=String(form.get('fit')||'cover'), format=String(form.get('format')||'webp');
      if (!image || typeof image==='string' || image.size<1 || image.size>40*1024*1024)
        throw Object.assign(Error('Chọn một ảnh hợp lệ, tối đa 40 MB.'),{status:413});
      const ext=path.extname(image.name||'').toLowerCase();
      if (!['.jpg','.jpeg','.png','.webp','.tif','.tiff','.bmp'].includes(ext))
        throw Object.assign(Error('Định dạng ảnh chưa hỗ trợ.'),{status:415});
      if (!PRESETS[preset]) throw Object.assign(Error('Preset ảnh không hợp lệ.'),{status:400});
      temp=await fs.mkdtemp(path.join(os.tmpdir(),'gita365-image-'));
      const original=path.basename(String(image.name||'anh'+ext)).replace(/[^A-Za-z0-9._-]+/g,'-').slice(0,80)||'anh'+ext;
      const input=path.join(temp,original); await fs.writeFile(input,Buffer.from(await image.arrayBuffer()),{flag:'wx'});
      const result=await processImage({input,preset,fit,format,out:IMAGE_OUTPUT,
        magick:process.env.GITA_MAGICK||'magick',identify:process.env.GITA_IDENTIFY||'identify'});
      const payload=await fs.readFile(result.file), type=format==='jpg'?'image/jpeg':`image/${format}`;
      res.writeHead(200,{'Content-Type':type,'Content-Length':payload.length,'Content-Disposition':`attachment; filename="${path.basename(result.file)}"`,
        'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','X-GITA-Image-Width':String(result.width),
        'X-GITA-Image-Height':String(result.height),'X-GITA-Image-Bytes':String(result.bytes),...(origin?cors(origin):{})});
      res.end(payload);
    } catch(e) { reply(res,e.status||400,{ok:false,error:String(e.message||e).slice(0,1200)},origin); }
    finally { busyImage=false; if(temp) await fs.rm(temp,{recursive:true,force:true}).catch(()=>{}); }
    return;
  }
  if (req.url!=='/v1/render' || req.method!=='POST') return reply(res,404,{ok:false,error:'Không tìm thấy route.'},origin||undefined);
  if (!ORIGINS.has(origin)) return reply(res,403,{ok:false,error:'Origin chưa được cho phép. Khai báo GITA_VIDEO_ORIGINS.'});
  if (!authorized(req)) return reply(res,401,{ok:false,error:'Mã kết nối cục bộ không đúng.'},origin);
  if (busy) return reply(res,409,{ok:false,error:'Renderer đang xử lý một video khác.'},origin);
  if (!/^multipart\/form-data;\s*boundary=/i.test(String(req.headers['content-type']||'')))
    return reply(res,415,{ok:false,error:'Cần gửi project và media dạng multipart/form-data.'},origin);
  busy=true;
  let temp='';
  try {
    const bytes=await bodyLimited(req);
    const webReq=new Request('http://127.0.0.1/v1/render',{method:'POST',headers:{'content-type':req.headers['content-type']},body:bytes});
    const form=await webReq.formData();
    const projectText=form.get('project');
    if (typeof projectText!=='string' || projectText.length>1024*1024) throw Object.assign(Error('Project JSON thiếu hoặc vượt 1 MB.'),{status:400});
    const project=JSON.parse(projectText);
    const assets=[];
    for (const [key,value] of form.entries()) {
      if (key==='project') continue;
      if (!/^asset_[a-z0-9-]{1,80}$/i.test(key) || typeof value==='string') throw Object.assign(Error('Trường media không hợp lệ.'),{status:400});
      if (value.size>MAX_FILE) throw Object.assign(Error('Mỗi media tối đa 80 MB.'),{status:413});
      const ext=path.extname(value.name||'').toLowerCase();
      if (!EXTS.has(ext)) throw Object.assign(Error('Định dạng media chưa hỗ trợ: '+(ext||'(không đuôi)')), {status:415});
      assets.push({id:key.slice(6),file:value,ext});
    }
    if (assets.length>MAX_FILES) throw Object.assign(Error('Tối đa 40 tệp media trong một lượt.'),{status:413});
    temp=await fs.mkdtemp(path.join(os.tmpdir(),'gita365-video-'));
    const assetDir=path.join(temp,'assets'); await fs.mkdir(assetDir);
    for (const asset of assets) {
      const name=asset.id+asset.ext, content=Buffer.from(await asset.file.arrayBuffer());
      await fs.writeFile(path.join(assetDir,name),content,{flag:'wx'});
    }
    await fs.writeFile(path.join(temp,'project.json'),JSON.stringify(project),'utf8');
    const result=await renderProject({file:path.join(temp,'project.json'),out:OUTPUT,ffmpeg:process.env.GITA_FFMPEG||'ffmpeg'});
    reply(res,200,{ok:true,output:OUTPUT,video:path.basename(result.mp4),subtitles:path.basename(result.srt),
      passport:path.basename(result.passport),metadata:result.metadata},origin);
  } catch (e) {
    reply(res,e.status||400,{ok:false,error:String(e.message||e).slice(0,1200)},origin);
  } finally {
    busy=false;
    if (temp) await fs.rm(temp,{recursive:true,force:true}).catch(()=>{});
  }
});

async function lingoFetch(route,options={}) {
  const response=await fetch(LINGO_URL+route,{...options,signal:AbortSignal.timeout(15000)});
  const type=String(response.headers.get('content-type')||'');
  if (!response.ok) throw Error(`VideoLingo ${route} trả HTTP ${response.status}.`);
  return {response,json:type.includes('json')?await response.json():null};
}
async function waitVideoLingo(job,label) {
  const began=Date.now(); let empty=0;
  while(Date.now()-began<30*60*1000) {
    const {json}=await lingoFetch('/status');
    if (!json) throw Error('API VideoLingo trả status không phải JSON.');
    job.progress=String(json.step||json.pause_message||json.state||label).slice(0,180);
    if (json.state==='error') throw Error(json.error||'VideoLingo báo lỗi.');
    if (json.state==='completed' && !json.active) return json;
    if (!json.active && json.state==='idle') {
      empty++; if (empty>60) throw Error('VideoLingo không bắt đầu tác vụ trong 60 giây.');
    }
    await new Promise(r=>setTimeout(r,1000));
  }
  throw Error('VideoLingo vượt giới hạn chờ 30 phút. Kiểm tra local API trước khi thử lại.');
}
async function runVideoLingo(job,file,video,language) {
  try {
    job.state='running'; job.progress='Chuẩn bị video trong VideoLingo';
    const inp=await lingoFetch('/input',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({source:file,existing:'archive'})});
    if (inp.json && inp.json.error) throw Error(String(inp.json.error));
    await waitVideoLingo(job,'Chuẩn bị video');
    job.progress='Nhận dạng, căn chỉnh và dịch phụ đề';
    const run=await lingoFetch('/run',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({stage:'all',target_language:language,dubbing:false})});
    if (run.json && run.json.error) throw Error(String(run.json.error));
    const status=await waitVideoLingo(job,'Xử lý video');
    const {response}=await lingoFetch('/files/trans.srt');
    const srt=await response.text();
    if (!srt || srt.length>20*1024*1024 || !/-->/.test(srt)) throw Error('VideoLingo chưa trả tệp trans.srt hợp lệ.');
    const outName=video.replace(/\.mp4$/i,'')+'.'+language+'.srt';
    await fs.writeFile(path.join(OUTPUT,outName),srt,'utf8');
    job.state='completed'; job.progress='Đã lưu phụ đề đã dịch';
    job.result={video,subtitle:outName,files:Array.isArray(status.files)?status.files.map(f=>path.basename(String(f))):[]};
  } catch(e) { job.state='error'; job.error=String(e.message||e).slice(0,1200); }
}

server.on('error',e=>{console.error('Không khởi động được renderer:',e.message);process.exitCode=1;});
server.listen(PORT,HOST,()=>{
  console.log(`GITA local renderer đang chạy tại http://${HOST}:${PORT}`);
  console.log(`Mã kết nối (giữ kín, chỉ dán trong GITA Studio): ${TOKEN}`);
  console.log(`Nguồn web cho phép: ${[...ORIGINS].join(', ')}`);
  console.log(`Thư mục đầu ra: ${OUTPUT}`);
  console.log('Chỉ bind vào loopback; dừng bằng Ctrl+C.');
});
