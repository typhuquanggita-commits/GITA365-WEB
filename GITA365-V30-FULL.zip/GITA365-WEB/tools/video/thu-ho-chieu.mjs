import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import {ghiHoChieuVideo} from '../../may-chu/studio.js';

const sqlite=new DatabaseSync(':memory:');
sqlite.exec(readFileSync(new URL('../../may-chu/csdl.sql',import.meta.url),'utf8'));
const db={prepare(sql){
  const statement=sqlite.prepare(sql);
  const methods=params=>({
    async first(){return statement.get(...params)},
    async all(){return {results:statement.all(...params)}},
    async run(){return {meta:{changes:statement.run(...params).changes}}}
  });
  return {...methods([]),bind(...params){return methods(params)}};
}};
const admin={uid:'1',u:'admin',role:'R01'}, staff={uid:'2',u:'editor',role:'R07'}, customer={uid:'3',u:'family',role:'R13'};
const valid={ten:'Video kiểm định',kho:'9:16',tang:'T1 · công khai',nguon:'KS-04',dieuNho:'Một bước nhỏ',giay:30,soCanh:4,
  den:[{tt:'ok',t:'Nguồn tri thức',ref:'KS-*',n:'Có nguồn'}]};
assert.equal((await ghiHoChieuVideo(valid,{},db,customer)).code,'NOPERM');
assert.equal((await ghiHoChieuVideo({...valid,ten:''},{},db,staff)).code,'THIEUTEN');
assert.equal((await ghiHoChieuVideo({...valid,giay:301},{},db,staff)).code,'NGOAIKHUNG');
assert.equal((await ghiHoChieuVideo({...valid,den:[]},{},db,staff)).code,'THIEUDEN');
assert.equal((await ghiHoChieuVideo({...valid,den:[{tt:'bad',t:'Đỏ'}]},{},db,staff)).code,'CONDENDO');
const ok=await ghiHoChieuVideo(valid,{},db,admin);
assert.equal(ok.ok,true);
assert.match(ok.hoChieu.vaSaoLaLoiKhai,/không chạy lại được/i);
assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM audit WHERE viec='XU_HOCHIEU'").get().n,1);
console.log('GITA Studio passport: giới hạn vai, đèn đỏ, độ dài và nhật ký metadata đạt.');
