import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';

const root = await fs.mkdtemp(path.join(os.tmpdir(),'gita-video-test-'));
const cli = fileURLToPath(new URL('./dung-phim.mjs',import.meta.url));
function run(bin,args) { return spawnSync(bin,args,{encoding:'utf8',timeout:60000}); }
try {
  const gen = run('ffmpeg',['-hide_banner','-loglevel','error','-f','lavfi','-i','color=c=navy:s=160x90:d=1','-frames:v','1',path.join(root,'slide.png'),'-y']);
  assert.equal(gen.status,0,gen.stderr);
  const sound = run('ffmpeg',['-hide_banner','-loglevel','error','-f','lavfi','-i','sine=frequency=440:duration=0.4','-c:a','pcm_s16le',path.join(root,'voice.wav'),'-y']);
  assert.equal(sound.status,0,sound.stderr);
  const project = {schemaVersion:'gita.video.v1',title:'GITA kiểm thử',width:160,height:90,fps:24,
    music:null,scenes:[{seconds:1,image:'slide.png',narration:'voice.wav',caption:'Chào GITA'},
      {seconds:1,background:'#121820',caption:'Một điều nhỏ'}]};
  await fs.writeFile(path.join(root,'project.json'),JSON.stringify(project));
  const render = run(process.execPath,[cli,path.join(root,'project.json'),'--out',path.join(root,'out')]);
  assert.equal(render.status,0,render.stderr);
  const mp4 = path.join(root,'out','GITA-kiem-thu.mp4');
  const probe = run('ffprobe',['-v','error','-show_entries','format=duration:stream=codec_name,codec_type,width,height','-of','json',mp4]);
  assert.equal(probe.status,0,probe.stderr);
  const parsed = JSON.parse(probe.stdout);
  assert.ok(parsed.streams.some(s => s.codec_type==='video' && s.width===160 && s.height===90));
  assert.ok(parsed.streams.some(s => s.codec_type==='audio'));
  assert.ok(Math.abs(+parsed.format.duration - 2) < 0.2);
  assert.match(await fs.readFile(path.join(root,'out','GITA-kiem-thu.srt'),'utf8'),/Chào GITA/);
  const passport = JSON.parse(await fs.readFile(path.join(root,'out','GITA-kiem-thu.passport.json'),'utf8'));
  assert.equal(passport.sceneCount,2);
  assert.equal(passport.postProcessing.upscale,'not-run');

  project.scenes[0].image='../outside.png';
  await fs.writeFile(path.join(root,'bad.json'),JSON.stringify(project));
  const traversal = run(process.execPath,[cli,path.join(root,'bad.json'),'--out',path.join(root,'bad-out')]);
  assert.notEqual(traversal.status,0);
  assert.match(traversal.stderr,/vượt khỏi thư mục project/);
  console.log('GITA Video Renderer: dựng MP4/SRT/audio/passport, probe codec/thời lượng và chặn path traversal đạt.');
} finally { await fs.rm(root,{recursive:true,force:true}); }
