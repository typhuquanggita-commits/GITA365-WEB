// Issue a portable vault license only from an existing, verified key set.
import {readFileSync,writeFileSync,readdirSync} from 'node:fs';
import {resolve,relative,join} from 'node:path';
import {createDecipheriv,createHash,randomUUID} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('..',import.meta.url));
export function issue(keysDocument,dir,recipient,expires){
 if(typeof recipient!=='string'||!recipient.trim()||recipient.length>160)throw Error('Cần tên người/đơn vị nhận (tối đa 160 ký tự).');
 const until=new Date(expires);if(!expires||!Number.isFinite(+until)||+until<=Date.now())throw Error('Ngày hết hạn phải hợp lệ và ở tương lai.');
 if(keysDocument.hetHan&&(+new Date(keysDocument.hetHan)<+until||!Number.isFinite(+new Date(keysDocument.hetHan))))throw Error('Không được kéo dài hạn của giấy phép nguồn.');
 const keys=keysDocument.khoa||keysDocument,khoa={},hashes={};
 const names=readdirSync(dir).filter(n=>/^[\w-]+\.enc$/.test(n)).sort();if(!names.length)throw Error('Không có kho mã hóa.');
 for(const name of names){const id=name.slice(0,-4),value=keys[id];if(typeof value!=='string'||!/^[A-Za-z0-9+/]{43}=$/.test(value))throw Error('Thiếu hoặc sai khóa: '+id);const key=Buffer.from(value,'base64'),bytes=readFileSync(join(dir,name));try{const decipher=createDecipheriv('aes-256-gcm',key,bytes.subarray(0,12));decipher.setAuthTag(bytes.subarray(12,28));decipher.update(bytes.subarray(28));decipher.final();}catch{throw Error('Khóa không khớp kho: '+id);}khoa[id]=value;hashes[id]=createHash('sha256').update(bytes).digest('hex');}
 return {schema:'gita.vault-license.v1',soGiayPhep:'GITA-'+randomUUID(),capCho:recipient.trim(),taoLuc:new Date().toISOString(),hetHan:until.toISOString(),khoa,khoHashes:hashes};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 try{const [keyfile,out,recipient,expires,dir]=process.argv.slice(2);if(!keyfile||!out)throw Error('Dùng: node tools/cap-giay-phep.mjs <bo-khoa.json> <tep-dich-ngoai-repo.json> <nguoi-nhan> <YYYY-MM-DD> [thu-muc-kho]');const target=resolve(out),rel=relative(root,target);if(!rel.startsWith('..')&&!rel.startsWith('/'))throw Error('Lưu giấy phép ngoài repo và ngoài _site để tránh công khai khóa.');const license=issue(JSON.parse(readFileSync(keyfile,'utf8')),resolve(dir||'_site/kho'),recipient,expires);writeFileSync(target,JSON.stringify(license,null,2)+'\n',{mode:0o600,flag:'wx'});console.log('Đã cấp giấy phép cho '+Object.keys(license.khoa).length+' gói khớp kho; tệp riêng đã lưu.');}catch(e){console.error(e.message);process.exitCode=1;}
}
