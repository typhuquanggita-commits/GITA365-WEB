import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import worker from '../may-chu/worker.js';

const sqlite = new DatabaseSync(':memory:');
sqlite.exec(readFileSync(new URL('../may-chu/csdl.sql', import.meta.url), 'utf8'));
const db = {prepare(sql) {
  const statement = sqlite.prepare(sql);
  const bind = params => ({
    async first() { return statement.get(...params); },
    async all() { return {results:statement.all(...params)}; },
    async run() { return {meta:{changes:statement.run(...params).changes}}; }
  });
  return {...bind([]), bind(...params) {return bind(params);}};
}};
const env = {CSDL:db, GITA_TIEU:'pepper-for-test-only', GITA_MA_KHOI_TAO:'a'.repeat(64)};
env.GITA_KHOA_KHO = JSON.stringify({khoa:{nen:'test-key-only'}});
async function post(body) {
  const res = await worker.fetch(new Request('https://gita.edu.vn/api/',
    {method:'POST', body:JSON.stringify(body)}), env);
  return res.json();
}
const data = {fn:'taoAdminDau', tenMoi:'chuhe', hoTen:'Chủ hệ', mk:'BinhMinh!48Q'};
assert.equal((await post(data)).code, 'BOOTSTRAP');
assert.equal((await post({...data, maKhoiTao:'b'.repeat(64)})).code, 'BOOTSTRAP');
assert.equal((await post({...data, mk:'1234567890', maKhoiTao:env.GITA_MA_KHOI_TAO})).code, 'MATKHAU');
assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM users").get().n, 0);
assert.equal((await post({...data, maKhoiTao:env.GITA_MA_KHOI_TAO})).ok, true);
assert.equal((await post({...data, maKhoiTao:env.GITA_MA_KHOI_TAO})).code, 'DACO');
assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM users WHERE role='R01'").get().n, 1);
sqlite.prepare('DELETE FROM users').run();
const sameTime = await Promise.all([
  post({...data, tenMoi:'mot', maKhoiTao:env.GITA_MA_KHOI_TAO}),
  post({...data, tenMoi:'hai', maKhoiTao:env.GITA_MA_KHOI_TAO})
]);
assert.equal(sameTime.filter(x => x.ok).length, 1);
assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM users WHERE role='R01'").get().n, 1);
const adminName = sqlite.prepare("SELECT username FROM users WHERE role='R01'").get().username;
const login = await post({fn:'dangNhap',u:adminName,mk:'BinhMinh!48Q'});
assert.equal(login.ok, true);
assert.ok(login.token);
const keys = await post({fn:'capKhoa',u:adminName,token:login.token,goi:['nen']});
assert.equal(keys.ok, true);
assert.equal(keys.khoa.nen, 'test-key-only');
const task = await post({fn:'viecDieuPhoi', u:adminName, token:login.token,
  hanhDong:'tao', cua:'docHomNay', tieuDe:'Kiểm tra buổi học'});
assert.equal(task.ok, true);
const tasks = await post({fn:'viecDieuPhoi', u:adminName, token:login.token,
  hanhDong:'danhSach'});
assert.equal(tasks.ds.some(x => x.id === task.id), true);
assert.equal((await post({fn:'capKhoa',u:adminName,token:login.token,goi:['nen','nghe']})).code, 'KEYSET_MISMATCH');
assert.equal((await post({fn:'dangXuat', token:login.token})).ok, true);
assert.equal((await post({fn:'capKhoa',u:adminName,token:login.token,goi:['nen']})).code, 'AUTH');
console.log('Worker: khởi tạo, đăng nhập, cấp khóa và thu hồi phiên đạt.');
