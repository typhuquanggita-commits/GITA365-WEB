#!/usr/bin/env node
/* Chuẩn hóa ảnh chiến dịch tại máy bằng ImageMagick; không gọi dịch vụ/API. */
import fs from 'node:fs/promises';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';

export const PRESETS={
  story:{width:1080,height:1920,format:'webp'},
  post:{width:1080,height:1080,format:'webp'},
  landscape:{width:1920,height:1080,format:'webp'},
  thumbnail:{width:1280,height:720,format:'webp'},
  print:{width:2400,height:3000,format:'jpg'}
};
const INPUT_EXTS=new Set(['.jpg','.jpeg','.png','.webp','.tif','.tiff','.bmp']);
const help='GITA image prep — crop, resize, sharpen nhẹ và tối ưu WebP/JPEG bằng ImageMagick.\n\n'+
  'Dùng: node tools/image/xu-anh.mjs <ảnh> --preset story|post|landscape|thumbnail|print [--out thư-mục] [--fit contain|cover] [--format webp|jpg|png]\n';

function run(bin,args){return new Promise((resolve,reject)=>{
  const p=spawn(bin,args,{stdio:['ignore','ignore','pipe'],windowsHide:true}); let err='';
  p.stderr.on('data',b=>{if(err.length<4000)err+=b.toString();});
  p.on('error',e=>{const x=Error(`${bin} không chạy được: ${e.message}`);x.code=e.code;reject(x);});
  p.on('close',code=>code===0?resolve():reject(Error(`${bin} kết thúc mã ${code}: ${err.slice(-1200)}`)));
});}
function parse(argv){
  if(!argv.length||argv.includes('--help')||argv.includes('-h'))return null;
  const input=path.resolve(argv[0]), o={preset:'post',fit:'cover',format:'webp',out:path.resolve('image-output'),magick:process.env.GITA_MAGICK||'magick',identify:process.env.GITA_IDENTIFY||'identify'};
  for(let i=1;i<argv.length;i++){
    if(['--preset','--fit','--format','--out','--magick','--identify'].includes(argv[i])&&argv[i+1])o[argv[i++].slice(2)]=argv[i];
    else throw Error('Tham số không hợp lệ: '+argv[i]);
  }
  return {input,...o};
}
async function identify(file,bin){
  const invoke=(cmd,args)=>new Promise((resolve,reject)=>{
    const p=spawn(cmd,args,{stdio:['ignore','pipe','pipe'],windowsHide:true});
    let out='',err=''; p.stdout.on('data',b=>out+=b); p.stderr.on('data',b=>{if(err.length<1000)err+=b;});
    p.on('error',e=>{e.stderr=err;reject(e);}); p.on('close',c=>c===0?resolve(out.trim()):reject(Error(err||'Không đọc được ảnh.')));
  });
  let r;
  if(bin==='magick') { try { r=await invoke('magick',['identify','-ping','-format','%m %w %h','--',file]); } catch(e) { if(e.code!=='ENOENT')throw e; r=await invoke('identify',['-ping','-format','%m %w %h','--',file]); } }
  else r=await invoke(bin,['-ping','-format','%m %w %h','--',file]);
  const m=String(r).match(/^([A-Z0-9]+)\s+(\d+)\s+(\d+)$/); if(!m)throw Error('Không đọc được kích thước ảnh.');
  return {format:m[1],width:+m[2],height:+m[3]};
}
export async function processImage(options){
  const input=path.resolve(options.input), ext=path.extname(input).toLowerCase();
  if(!INPUT_EXTS.has(ext))throw Error('Chỉ nhận ảnh raster JPG, PNG, WebP, TIFF hoặc BMP.');
  const st=await fs.stat(input).catch(()=>null); if(!st?.isFile()||st.size>40*1024*1024)throw Error('Ảnh nguồn phải là tệp và tối đa 40 MB.');
  const preset=PRESETS[options.preset]; if(!preset)throw Error('Preset không hợp lệ: '+options.preset);
  const fit=options.fit||'cover', format=options.format||preset.format;
  if(!['cover','contain'].includes(fit))throw Error('fit hỗ trợ cover hoặc contain.');
  if(!['webp','jpg','png'].includes(format))throw Error('Định dạng đầu ra hỗ trợ webp, jpg hoặc png.');
  const bin=options.magick||'magick', idBin=options.identify||'magick';
  const info=await identify(input,idBin);
  if(info.width<1||info.height<1||info.width*info.height>80_000_000)throw Error('Ảnh vượt ngưỡng 80 megapixel.');
  await fs.mkdir(options.out,{recursive:true});
  const stem=path.basename(input,path.extname(input)).normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^A-Za-z0-9_-]+/g,'-').replace(/^-|-$/g,'').slice(0,48)||'gita-image';
  let dest=path.join(options.out,`${stem}-${options.preset}.${format==='jpg'?'jpg':format}`), n=2;
  while(await fs.access(dest).then(()=>true,()=>false))dest=path.join(options.out,`${stem}-${options.preset}-v${n++}.${format==='jpg'?'jpg':format}`);
  const size=`${preset.width}x${preset.height}`;
  const fitArgs=fit==='cover'?['-resize',size+'^','-gravity','center','-extent',size]:['-resize',size,'-gravity','center','-background','#10131a','-extent',size];
  const args=['-limit','memory','512MiB','-limit','map','1GiB','--',input,'-auto-orient','-colorspace','sRGB',...fitArgs,
    '-unsharp','0x0.55+0.55+0.02','-strip'];
  if(format==='webp')args.push('-quality','88','-define','webp:method=6');
  else if(format==='jpg')args.push('-quality','90','-sampling-factor','4:2:0');
  args.push(dest);
  try { await run(bin,args); }
  catch(e) { if(e.code==='ENOENT'&&bin==='magick') await run('convert',args); else throw e; }
  const outInfo=await identify(dest,idBin), outStat=await fs.stat(dest);
  if(outInfo.width!==preset.width||outInfo.height!==preset.height)throw Error('ImageMagick không tạo được kích thước preset mong muốn.');
  return {file:dest,width:outInfo.width,height:outInfo.height,format:outInfo.format,bytes:outStat.size,
    source:{width:info.width,height:info.height,format:info.format},fit,sharpen:'subtle',metadata:'stripped'};
}
async function main(){const o=parse(process.argv.slice(2));if(!o){process.stdout.write(help);return;}const r=await processImage(o);process.stdout.write(`Đã xử lý ${r.file}\n${r.width}×${r.height} · ${r.format} · ${(r.bytes/1024).toFixed(1)} KB · metadata đã gỡ\n`);}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))main().catch(e=>{console.error('Xử lý ảnh thất bại:',e.message);process.exitCode=1;});
