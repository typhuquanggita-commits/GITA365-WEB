import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {processImage} from './xu-anh.mjs';

const dir=await fs.mkdtemp(path.join(os.tmpdir(),'gita-image-test-'));
try {
  const input=path.join(dir,'nguon.png'), out=path.join(dir,'out');
  const made=spawnSync('convert',['-size','800x600','gradient:#f5d7a1-#234b56',input],{encoding:'utf8'});
  assert.equal(made.status,0,made.stderr);
  const result=await processImage({input,out,preset:'story',fit:'cover',format:'webp',magick:process.env.GITA_MAGICK||'convert',identify:process.env.GITA_IDENTIFY||'identify'});
  assert.equal(result.width,1080);assert.equal(result.height,1920);assert.equal(result.format,'WEBP');
  assert.ok(result.bytes>500);assert.equal(result.metadata,'stripped');
  const dims=spawnSync('identify',['-format','%w×%h %[EXIF:*]',result.file],{encoding:'utf8'});
  assert.equal(dims.status,0,dims.stderr);assert.match(dims.stdout,/^1080×1920\s*$/);
  await assert.rejects(()=>processImage({input,out,preset:'bad',magick:'convert',identify:'identify'}),/Preset không hợp lệ/);
  console.log('GITA image prep: preset crop, kích thước WebP, metadata strip và kiểm tra preset đạt.');
} finally {await fs.rm(dir,{recursive:true,force:true});}
