import {createHash} from 'node:crypto';
import {cpSync, existsSync, mkdirSync, readdirSync, rmSync, statSync, readFileSync, writeFileSync} from 'node:fs';
import {join, resolve} from 'node:path';
import {fileURLToPath} from 'node:url';

const root = resolve(fileURLToPath(new URL('..', import.meta.url)));
const out = join(root, '_site');
const files = [
  'index.html', '404.html', 'cap-nhat.html', 'cap-nhat.js', 'CNAME', '.nojekyll', 'manifest.webmanifest',
  'sw.js', 'cau-hinh.js', 'gita-app.js', 'gita-nghe.js', '_headers', '_redirects',
  'robots.txt', 'sitemap.xml', 'cau-hoi-thuong-gap.html', 'duong-vao.html',
  'hanh-trinh-12-chang.html', 'mo-thuc-huan-luyen-gita.html',
  'nam-tang-dong-hanh.html'
];
// Validate public deployment configuration before replacing the previous build.
const apiText=String(process.env.GITA_API_URL||'').trim();
if(process.argv.includes('--production')&&!apiText)throw Error('Production cần biến GITA_API_URL trỏ tới Worker thật.');
if(apiText){const u=new URL(apiText);if(u.protocol!=='https:'||u.username||u.password||u.search||u.hash)throw Error('GITA_API_URL phải là HTTPS, không chứa token, query hoặc fragment.');}
rmSync(out, {recursive:true, force:true});
mkdirSync(out);
for (const name of files) {
  if (!existsSync(join(root, name))) throw Error('Thiếu tài nguyên: ' + name);
  cpSync(join(root, name), join(out, name));
}
if(apiText){const config=join(out,'cau-hinh.js');writeFileSync(config,'window.G=window.G||{};window.G.API_CAP_PHEP='+JSON.stringify(apiText)+';\n'+readFileSync(config,'utf8'));}
cpSync(join(root, 'assets'), join(out, 'assets'), {recursive:true});
mkdirSync(join(out, 'kho'));
for (const name of readdirSync(join(root, 'kho'))) {
  if (!/^[\w-]+\.enc$/.test(name) && name !== 'mau.json') continue;
  const source = join(root, 'kho', name);
  if (!statSync(source).isFile()) throw Error('Tài nguyên kho không phải tệp: ' + name);
  cpSync(source, join(out, 'kho', name));
}
if (!existsSync(join(out, 'index.html')) || !existsSync(join(out, 'gita-app.js')))
  throw Error('Gói web thiếu tệp khởi động.');
console.log('Đã đóng gói phần web tại _site/ (không gồm máy chủ, mã nguồn, công cụ, bí mật).');

const hashes = {};
for (const name of ['index.html','gita-app.js','gita-nghe.js','cau-hinh.js','sw.js','cap-nhat.js', ...readdirSync(join(out,'kho')).filter(n=>n.endsWith('.enc')).map(n=>'kho/'+n)]) {
  hashes[name] = createHash('sha256').update(readFileSync(join(out,name))).digest('hex');
}
const build = createHash('sha256').update(JSON.stringify(hashes)).digest('hex').slice(0,20);
// Bind delivered JS and offline cache to this build without exposing secrets.
const appFile=join(out,'gita-app.js'),swFile=join(out,'sw.js');
writeFileSync(appFile,readFileSync(appFile,'utf8').replace('__GITA_RELEASE_ID__',build));
writeFileSync(swFile,readFileSync(swFile,'utf8').replace(/const CACHE = '[^']+';/,"const CACHE = 'gita365-"+build+"';"));
for(const name of ['gita-app.js','sw.js'])hashes[name]=createHash('sha256').update(readFileSync(join(out,name))).digest('hex');
writeFileSync(join(out,'version.json'), JSON.stringify({schema:'gita.release.v1',version:'V30',build,commit:process.env.CF_PAGES_COMMIT_SHA||null,hashes},null,2)+'\n');
console.log('Release fingerprint: '+build);
