// Offline verification only. Does not print keys or decrypted content.
import {readFileSync,readdirSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {createDecipheriv} from 'node:crypto';
const file=process.argv[2];if(!file){console.error('Dùng: node tools/kiem-khoa-kho.mjs <đường-dẫn-bộ-khóa-riêng> [thư-mục-kho]');process.exit(1);}
let failed=false;
try{const raw=JSON.parse(readFileSync(resolve(file),'utf8')),keys=raw.khoa||raw,dir=resolve(process.argv[3]||'kho');
const names=readdirSync(dir).filter(n=>/^[\w-]+\.enc$/.test(n));if(!names.length)throw Error('Không có tệp kho mã hóa.');
for(const name of names){try{const key=Buffer.from(keys[name.slice(0,-4)]||'','base64'),bytes=readFileSync(join(dir,name));if(key.length!==32||bytes.length<29)throw Error('invalid');const decipher=createDecipheriv('aes-256-gcm',key,bytes.subarray(0,12));decipher.setAuthTag(bytes.subarray(12,28));decipher.update(bytes.subarray(28));decipher.final();console.log('KHỚP '+name);}catch{failed=true;console.log('KHÔNG KHỚP / THIẾU KHÓA: '+name);}}
}catch{failed=true;console.error('Không đọc/kiểm tra được tệp khóa hoặc thư mục kho.');}
process.exitCode=failed?1:0;
