import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';

const saved = new Map(), calls = [];
const G = {U:{h:x=>x,ic:()=>''}, ACCOUNTS:[], AUDITORS:[], PHANQUYEN_GOC:{}};
const window = {G, innerWidth:1400, addEventListener(){}};
const location = {hash:'', pathname:'/', search:'', replace(url){calls.push(['nav',url]);}};
const context = {window, location, history:{replaceState(){}}, navigator:{},
  document:{addEventListener(){}, querySelector(){return null},
    documentElement:{setAttribute(){}, removeAttribute(){}}},
  getComputedStyle(){return {getPropertyValue(){return ''}};},
  localStorage:{getItem:k=>saved.get(k) || null, setItem:(k,v)=>saved.set(k,v),
    removeItem:k=>saved.delete(k)},
  fetch:async (url,opts)=>{calls.push(['fetch',JSON.parse(opts.body)]);return {ok:true};},
  setTimeout, clearTimeout, console};
vm.runInNewContext(readFileSync(new URL('../src/app.js',import.meta.url),'utf8'),context);
G.S.acc = {u:'coach@gita365.vn', role:'R07', tuMayChu:true};
G.S.viec = {homNay:'Bài tập riêng'};
G.save();
assert.equal(saved.has('gita365.v7'), false);
assert.equal(saved.has('gita365.v7.real.coach%40gita365.vn'), true);
G.S.viec = {};
assert.equal(G.load(), null); // không tự nạp dữ liệu thật khi chưa xác thực
assert.equal(G.S.viec.homNay, undefined);
assert.equal(G.load('coach@gita365.vn').u, 'coach@gita365.vn');
assert.equal(G.S.viec.homNay, 'Bài tập riêng');
G.PHIEN_TOKEN = 'server-token-for-test'; G.API_CAP_PHEP = 'https://gita.edu.vn/api/';
G.donKho = ()=>{};
G.raNgoai();
assert.equal(G.PHIEN_TOKEN, '');
assert.equal(calls.some(x=>x[0]==='fetch' && x[1].fn==='dangXuat' && x[1].token==='server-token-for-test'),true);
assert.equal(calls.some(x=>x[0]==='nav' && x[1]==='/#dangnhap'),true);
console.log('Phiên web: chỉ khôi phục đúng người, đăng xuất xóa token và đóng phiên máy chủ.');
