import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';

const source = readFileSync(new URL('../src/app.js', import.meta.url), 'utf8');
const start = source.indexOf('var dongYNhanDangGiongTrongPhien = false;');
const end = source.indexOf('/* ═══════════════ HỘP LỆNH ═══════════════ */', start);
assert.ok(start >= 0 && end > start, 'tìm được phần điều khiển micro');
const listeners = {};
const toasts = [], dialogs = [], questions = [];
const button = {style:{}, attrs:{}, setAttribute(k,v){ this.attrs[k]=v; }};
const input = {value:'', focus(){}};
const document = {
  hidden:false,
  addEventListener(name, fn){ listeners[name]=fn; },
  getElementById(id){ return id === 'micBtn' ? button : (id === 'aiQ' ? input : null); }
};
class SpeechRecognition {
  start(){ this.started=true; }
  abort(){ this.aborted=true; }
  stop(){ this.stopped=true; }
}
const G = {LANG:'vi', U:{modal:x=>dialogs.push(x),closeModal(){},toast:(...x)=>toasts.push(x)},ask:x=>questions.push(x)};
const window = {G, SpeechRecognition};
vm.runInNewContext('var G=window.G, U=G.U;\n' + source.slice(start,end), {window,document});

G.mic();
assert.equal(dialogs.length,1,'hiện thông báo trước khi bật nhận dạng');
assert.match(dialogs[0],/có thể gửi âm thanh tới dịch vụ bên ngoài/);
assert.equal(G.REC,undefined,'chưa mở micro trước khi người dùng đồng ý');
G.micDongY();
const rec = G.REC;
toasts.length=0;
assert.ok(rec instanceof SpeechRecognition);
assert.equal(rec.lang,'vi-VN');
assert.equal(rec.started,true);
assert.equal(button.attrs['aria-pressed'],'true');
rec.onresult({results:[Object.assign([{transcript:'Xin chào'}],{isFinal:true})]});
assert.deepEqual(questions,['Xin chào']);

document.hidden=true;
listeners.visibilitychange();
assert.equal(rec.aborted,true,'micro tự dừng khi tab bị ẩn');
assert.equal(G.REC,null);
assert.equal(button.attrs['aria-pressed'],'false');
rec.onerror({error:'aborted'});
assert.equal(toasts.length,0,'dừng chủ động không hiện lỗi giả');
console.log('Micro: thông báo riêng tư, đồng ý trước khi nghe, gửi chữ nhận dạng và tự dừng đạt.');
