// Read-only release check. Never requests or prints account/key secrets.
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const base=new URL(process.argv[2]||'http://localhost:8080/');
if(!['https:','http:'].includes(base.protocol)||base.username||base.password)throw Error('Dùng URL web không chứa thông tin đăng nhập.');
if(!base.pathname.endsWith('/'))base.pathname+='/';base.search='';base.hash='';
const expected=JSON.parse(readFileSync(new URL('../_site/version.json',import.meta.url),'utf8'));
async function get(path){const url=new URL(path,base);url.searchParams.set('fresh',Date.now());const r=await fetch(url,{cache:'no-store',redirect:'error',signal:AbortSignal.timeout(30000)});if(!r.ok)throw Error(path+': HTTP '+r.status);return r;}
try{
 const live=await (await get('version.json')).json();
 if(live.build!==expected.build)throw Error('Sai bản deploy: máy chủ '+live.build+'; bản ZIP '+expected.build);
 for(const [path,hash] of Object.entries(expected.hashes)){
  const r=await get(path),actual=createHash('sha256').update(Buffer.from(await r.arrayBuffer())).digest('hex');
  if(actual!==hash)throw Error('Tệp không khớp: '+path);console.log('OK '+path);
 }
 console.log('Đạt: các tệp vỏ và kho mã hóa khớp bản đóng gói. Chưa kiểm tra secret/quyền tài khoản Worker.');
}catch(e){console.error('KHÔNG ĐẠT: '+e.message);process.exitCode=1;}
