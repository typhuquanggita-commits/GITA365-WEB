import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';

const taptin = readFileSync(new URL('../src/tro-ly-chat.js', import.meta.url), 'utf8');
const taiXuong = [], toast = [];
const body = {appendChild(){}, removeChild(){}};
let dongChat = [];
function element(tag) {
  const e = {tagName:tag, style:{}, attrs:{}, download:'', href:'', open:false,
    setAttribute(k,v){this.attrs[k]=v;}, querySelectorAll(){return [];}, click(){this.clicked=true;}};
  Object.defineProperty(e, 'innerText', {get(){return (e.innerHTML || '').replace(/<[^>]*>/g,' ');}});
  Object.defineProperty(e, 'textContent', {get(){return e.innerText;}});
  return e;
}
const khung = {querySelectorAll(){return dongChat;}};
const document = {body, createElement:element, addEventListener(){}, getElementById(id){return id === 'chKhung' ? khung : null;}};
const window = {G:{U:{h:x=>String(x).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;'),
  ic:()=>'' , toast:(...x)=>toast.push(x)}, S:{acc:{ten:'Minh'}} , VIEWS:{}, CHAT:[]}, addEventListener(){}};
const urlApi = {createObjectURL(blob){taiXuong.push({blob}); return 'blob:test';}, revokeObjectURL(){}};
vm.runInNewContext(taptin, {window, document, URL:urlApi, Blob, Date, setTimeout(fn){fn();}, console});

window.G.chatXuat();
assert.equal(taiXuong.length, 0, 'chat trống không tạo tệp');
assert.equal(toast.at(-1)[0], 'Chưa có nội dung để xuất.');

window.G.CHAT = [
  {ai:'toi', loi:'Con không tự giác, phải nhắc mãi', luc:new Date('2026-09-28T01:00:00Z')},
  {ai:'trolY', dap:{loi:'Mình thử bắt đầu từ một việc nhỏ tối nay.', nguon:[], chot:'Em sẽ cùng nhà mình theo dõi.'}, luc:new Date('2026-09-28T01:01:00Z')}
];
window.G.CHAT[1]._hien = Date.now() + 60000;
window.G.chatXuat();
assert.equal(taiXuong.length, 0, 'đang soạn thì chưa xuất bản sao');
assert.equal(toast.at(-1)[0].includes('đang soạn'), true);
window.G.CHAT[1]._hien = 0;
function row(role, text) { return {classList:{contains:cls=>cls===role}, innerText:text}; }
dongChat = [row('ch-troly','Chào Minh.'), row('ch-toi','Con không tự giác, phải nhắc mãi'),
  row('ch-troly','Mình thử bắt đầu từ một việc nhỏ tối nay. Em sẽ cùng nhà mình theo dõi.')];
window.G.chatXuat();
assert.equal(taiXuong.length, 1, 'có hội thoại thì tạo đúng một tệp');
assert.match(taiXuong[0].blob.type, /text\/markdown/);
assert.equal(taiXuong[0].blob.size > 0, true);
const banSao = await taiXuong[0].blob.text();
assert.match(banSao, /Chào Minh/);
assert.match(banSao, /Con không tự giác/);
assert.match(banSao, /Mình thử bắt đầu từ một việc nhỏ tối nay/);
assert.equal(toast.at(-1)[0], 'Đã tải bản sao hội thoại xuống thiết bị.');
console.log('Xuất hội thoại: chat trống, bản Markdown cục bộ và thông báo đạt.');
