import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';

for(const [file,id] of [['tro-ly-chat.js','aiQ'],['tro-ly-noi.js','aiQNoi']]){
 const events={},input={value:'Giữ câu hỏi đang soạn',style:{},scrollHeight:40};
 const G={U:{h:String,ic:()=>'',toast(){}},S:{acc:{ten:'Coach'},role:'R07'},VIEWS:{},CHAT:[]};
 const document={activeElement:input,getElementById:key=>key===id?input:null,querySelectorAll:()=>[],
   addEventListener:(type,fn)=>(events[type]||=[]).push(fn)};
 const context={window:{G,addEventListener(){}},document,setTimeout,clearTimeout,Date,console};
 vm.runInNewContext(readFileSync(new URL('../../src/'+file,import.meta.url),'utf8'),context);
 let calls=0;G.chatHoi=()=>{calls++;return false;};
 const enter={key:'Enter',shiftKey:false,preventDefault(){}};
 events.keydown.forEach(fn=>fn(enter));
 assert.equal(input.value,'Giữ câu hỏi đang soạn');assert.equal(calls,1);
 events.keydown.forEach(fn=>fn({...enter,isComposing:true}));assert.equal(calls,1);
 G.chatHoi=()=>true;events.keydown.forEach(fn=>fn(enter));assert.equal(input.value,'');
}
console.log('Ô nhập: giữ câu bị từ chối, chỉ xóa câu đã nhận, tôn trọng IME ở cả chat đầy đủ và chat nổi.');
