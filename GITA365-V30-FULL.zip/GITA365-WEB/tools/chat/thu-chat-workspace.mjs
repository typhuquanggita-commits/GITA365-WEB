import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
const listeners={},elements={},toasts=[],calls=[];
const h=x=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const G={U:{h,ic:()=>'',toast:(...a)=>toasts.push(a),modal:s=>calls.push(s),closeModal(){}},S:{acc:{u:'coach'},role:'R07',view:'test'},VIEWS:{'tro-ly':()=>'<div class="cs-ben"></div><div id="chKhung"></div>'},CHAT:[],DP_TRO_LY:[{ma:'AI1',phucVu:'docHomNay'}],aiTra:()=>[],aiCoKhan:q=>q.includes('khẩn'),chatLayNguCanh:()=>({cau:'context',da:[]}),chatDatPhien:a=>{G.CHAT=a;},veChat(){},render(){},goiMayChu:async(fn,data)=>{calls.push({fn,data});return {ok:true,id:'task-id'};}};
G.chatHoi=q=>G.CHAT.push({ai:'toi',loi:q},{ai:'trolY',dap:{loi:'Trả lời '+q}});
const document={getElementById:id=>elements[id]||null,addEventListener:(type,fn)=>(listeners[type]||=[]).push(fn)};
const context={window:{G,prompt:()=>null,confirm:()=>true},document,setTimeout,clearTimeout,AbortController,AbortSignal,TextDecoder,URL,console,fetch:async()=>{throw Error('Unexpected network request');}};
vm.createContext(context);
for(const file of ['tro-ly-live.js','tro-ly-workspace.js'])vm.runInContext(readFileSync(new URL('../../src/'+file,import.meta.url),'utf8'),context);
const first=G.chatTrangThai().active;
G.chatHoi('Kế hoạch tuần này');G.chatThemVanBan('<img src=x>.txt',[{page:3,text:'Kế hoạch tuần gồm đào tạo và thực hành.'}]);
const refs=G.chatTimTep('kế hoạch đào tạo');assert.equal(refs.length,1);assert.match(refs[0].label,/trang 3/);assert.match(G.chatVeNguon(refs),/&lt;img/);assert.doesNotMatch(G.chatVeNguon(refs),/<img/);
G.chatPhienMoi();assert.equal(G.chatTrangThai().count,2);assert.equal(G.CHAT.length,0);assert.equal(G.chatTimTep('kế hoạch đào tạo').length,0);
G.chatHoi('Câu hỏi mới');G.chatMoPhien(first);assert.equal(G.CHAT[0].loi,'Kế hoạch tuần này');assert.equal(G.chatTrangThai().documents,1);
assert.throws(()=>G.chatThemVanBan('large.txt',[{text:'x'.repeat(500001)}]),/500.000/);
assert.equal(G.chatOwncastURL('javascript:alert(1)'), '');assert.equal(G.chatOwncastURL('https://user:secret@example.com'),'');assert.equal(G.chatOwncastURL('https://live.gita.edu.vn'),'https://live.gita.edu.vn');
G.OWNCAST_URL='https://live.gita.edu.vn';assert.doesNotMatch(G.chatLivePanel(),/<iframe/);assert.match(G.chatLiveHTML(),/embed\/chat\/readwrite/);assert.doesNotMatch(G.chatLiveHTML(),/Kế hoạch tuần/);
G.chatLapViec();assert.match(calls.at(-1),/Tiêu đề/);
for(const [id,value] of Object.entries({gchatTaskTitle:'Chuẩn bị bài học',gchatTaskGoal:'Soạn kịch bản',gchatTaskChecks:'Có 3 phần',gchatTaskLimits:'Không gửi ngoài',gchatTaskAgent:'docHomNay'}))elements[id]={value};
elements.gchatTaskResult={};
const button={getAttribute:k=>k==='data-gchat'?'save-task':null,disabled:false};
listeners.click.forEach(fn=>fn({target:{closest:selector=>selector.includes('data-gchat')?button:null}}));
await new Promise(r=>setTimeout(r,0));assert.equal(calls.at(-1).fn,'viecDieuPhoi');assert.equal(calls.at(-1).data.hanhDong,'tao');assert.match(calls.at(-1).data.noiDung,/Có 3 phần/);assert.equal(calls.some(c=>c?.data?.hanhDong==='chayAgent'),false);
G.chatDonTatCa();assert.equal(G.CHAT.length,0);assert.equal(G.chatTrangThai().documents,0);assert.equal(G.chatTrangThai().count,1);
G.S.role='R13';G.S.acc={u:'family'};const before=calls.length;G.chatLapViec();assert.equal(calls.length,before);assert.doesNotMatch(G.VIEWS['tro-ly'](),/id="gchatToken"/);
console.log('Chat workspace: phân tách hội thoại/tài liệu, BM25, XSS, xóa phiên, Owncast, giao việc và chặn vai khách đạt.');

// Exercise the real frontend stream reader, cancellation, and emergency routing.
G.S.role='R07';G.S.acc={u:'coach'};
const click=action=>{const b={getAttribute:k=>k==='data-gchat'?action:null,disabled:false};listeners.click.forEach(fn=>fn({target:{closest:s=>s.includes('data-gchat')?b:null}}));};
let streamController,streamMode='complete';
context.fetch=async(url,options)=>{
 if(url.endsWith('/status'))return {ok:true,json:async()=>({models:['test-model']})};
 const body=JSON.parse(options.body);assert.equal(body.model,'test-model');
 return {ok:true,body:new ReadableStream({start(controller){streamController=controller;if(streamMode==='complete'){
   const bytes=new TextEncoder().encode('{"delta":"Trả lời <img> [S1]"}\n{"done":true}\n');
   controller.enqueue(bytes.slice(0,15));controller.enqueue(bytes.slice(15));controller.close();
 }else {controller.enqueue(new TextEncoder().encode('{"delta":"Một phần"}\n'));options.signal.addEventListener('abort',()=>{try{controller.error(new DOMException('Aborted','AbortError'));}catch{}},{once:true});}}})};
};
elements.gchatToken={value:'x'.repeat(40)};click('connect');await new Promise(r=>setTimeout(r,0));
listeners.change.forEach(fn=>fn({target:{id:'gchatMode',value:'local'}}));
G.chatHoi('Câu hỏi cho mô hình');await new Promise(r=>setTimeout(r,15));assert.equal(G.CHAT.at(-1).dap.trangThai,'done');assert.match(G.CHAT.at(-1).dap.cucBo,/<img>/);assert.equal(G.chatTrangThai().busy,false);
streamMode='wait';G.chatHoi('Chờ phản hồi');await new Promise(r=>setTimeout(r,5));assert.equal(G.chatTrangThai().busy,true);
G.chatHoi('Tình huống khẩn');await new Promise(r=>setTimeout(r,5));assert.match(G.CHAT.at(-1).dap.loi,/khẩn/);assert.equal(G.chatTrangThai().busy,false);
G.chatHoi('Đổi người khi đang chạy');await new Promise(r=>setTimeout(r,5));G.chatDonTatCa();await new Promise(r=>setTimeout(r,5));assert.equal(G.CHAT.length,0);assert.equal(G.chatTrangThai().mode,'gita');
console.log('Frontend streaming: tách byte UTF-8, hoàn tất, hủy, chuyển tuyến khẩn và đổi phiên khi đang chạy đạt.');

assert.equal(G.chatHoi('x'.repeat(6001)),false);
G.CHAT.push(...Array.from({length:240},()=>({ai:'toi',loi:'Lịch sử'})));
assert.equal(G.chatHoi('Câu hỏi thông thường'),false);
assert.equal(G.chatHoi('Tình huống khẩn '+ 'x'.repeat(6001)),true);
assert.match(G.CHAT.at(-1).dap.loi,/khẩn/);
G.chatXoa();
let finishRead;
const upload={id:'gchatUpload',value:'pending',files:[{name:'pending.txt',size:30,text:()=>new Promise(resolve=>{finishRead=resolve;})}]};
listeners.change.forEach(fn=>fn({target:upload}));
G.chatXoa();finishRead('Tài liệu cũ đang được nhập');await new Promise(r=>setTimeout(r,0));
assert.equal(G.chatTrangThai().documents,0);
console.log('Giới hạn hội thoại không chặn chuyển tuyến khẩn; xóa cuộc chat loại kết quả nhập tệp còn treo.');
// Project generation reuses the private connection but never includes another chat's documents.
streamMode='complete';click('connect');await new Promise(r=>setTimeout(r,0));
let projectBody;context.fetch=async(url,options)=>{projectBody=JSON.parse(options.body);return {ok:true,body:new ReadableStream({start(controller){controller.enqueue(new TextEncoder().encode('{"delta":"{\\"drafts\\":[]}"}\n{"done":true}\n'));controller.close();}})};};
const projectOutput=await G.chatBienTapDuAn('Return project JSON',[{label:'f1',text:'Only project fact'}]);assert.equal(projectOutput,'{"drafts":[]}');assert.equal(projectBody.messages.length,1);assert.equal(projectBody.sources.length,1);assert.equal(projectBody.sources[0].label,'f1');
G.chatDonTatCa();await assert.rejects(G.chatBienTapDuAn('Next',[]),/Kết nối/);
console.log('Project AI editor uses isolated context and clears local authorization on logout.');
