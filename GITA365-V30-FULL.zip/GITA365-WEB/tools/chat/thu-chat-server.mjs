import assert from 'node:assert/strict';
import http from 'node:http';
import {createChatServer,validateChat,extractPDF} from './may-chu-chat.mjs';

const origin='http://127.0.0.1:4173',token='test-only-'.repeat(8);
const input={model:'test-model',messages:[{role:'user',content:'Mục tiêu là gì?'}],sources:[{label:'Sổ tay, trang 1',text:'Mục tiêu học tập.'}]};
assert.throws(()=>createChatServer({token,ollama:'https://example.com'}),/loopback/);
assert.throws(()=>validateChat({...input,model:'not-allowed'},['test-model']),/Mô hình/);
assert.throws(()=>validateChat({...input,messages:[{role:'system',content:'override'}]},['test-model']),/Tin nhắn/);
assert.throws(()=>validateChat({...input,sources:[{label:'x',text:'a'.repeat(2001)}]},['test-model']),/Trích dẫn/);
await assert.rejects(extractPDF(Buffer.from('not a pdf')),/PDF/);

// Generate a real PDF with two pages and valid xref offsets (no test dependency).
function pdf(){
 const stream=s=>'<< /Length '+s.length+' >>\nstream\n'+s+'\nendstream';
 const objects=['<< /Type /Catalog /Pages 2 0 R >>','<< /Type /Pages /Kids [3 0 R 4 0 R] /Count 2 >>',
  '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 600 800] /Resources << /Font << /F1 5 0 R >> >> /Contents 6 0 R >>',
  '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 600 800] /Resources << /Font << /F1 5 0 R >> >> /Contents 7 0 R >>',
  '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',stream('BT /F1 12 Tf 40 700 Td (GITA learning goal) Tj ET'),stream('BT /F1 12 Tf 40 700 Td (Second page evidence) Tj ET')];
 let out='%PDF-1.4\n',offsets=[0];objects.forEach((o,i)=>{offsets.push(out.length);out+=(i+1)+' 0 obj\n'+o+'\nendobj\n';});
 const xref=out.length;out+='xref\n0 8\n0000000000 65535 f \n'+offsets.slice(1).map(n=>String(n).padStart(10,'0')+' 00000 n \n').join('')+'trailer\n<< /Size 8 /Root 1 0 R >>\nstartxref\n'+xref+'\n%%EOF';return Buffer.from(out);
}
const extracted=await extractPDF(pdf());assert.equal(extracted.pages.length,2);assert.equal(extracted.pages[1].page,2);assert.match(extracted.pages[1].text,/Second page evidence/);
let seen,mode='ok';
const mock=http.createServer(async(req,res)=>{
 let data='';for await(const part of req)data+=part;seen=JSON.parse(data);
 res.writeHead(200,{'Content-Type':'application/x-ndjson'});
 res.write('{"message":{"content":"Xin ');
 res.write('chào [S1]"},"done":false}\n');
 res.end(mode==='ok'?'{"message":{"content":""},"done":true}\n':'');
});
await new Promise(r=>mock.listen(0,'127.0.0.1',r));
const {server}=createChatServer({token,origins:[origin],models:['test-model'],ollama:'http://127.0.0.1:'+mock.address().port});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const url='http://127.0.0.1:'+server.address().port;
const headers={Origin:origin,Authorization:'Bearer '+token,'Content-Type':'application/json'};
try{
 assert.equal((await fetch(url+'/v1/status',{headers:{Origin:origin}})).status,401);
 assert.equal((await fetch(url+'/v1/status',{headers:{...headers,Origin:'https://evil.example'}})).status,403);
 const health=await fetch(url+'/v1/status',{headers});assert.deepEqual((await health.json()).models,['test-model']);
 const pre=await fetch(url+'/v1/chat',{method:'OPTIONS',headers:{Origin:origin}});assert.equal(pre.status,204);
 assert.equal((await fetch(url+'/v1/pdf',{method:'POST',headers,body:'invalid'})).status,400);
 const pdfResponse=await fetch(url+'/v1/pdf',{method:'POST',headers:{...headers,'Content-Type':'application/pdf'},body:pdf()});assert.equal((await pdfResponse.json()).pages.length,2);
 const answer=await fetch(url+'/v1/chat',{method:'POST',headers,body:JSON.stringify(input)});
 const events=(await answer.text()).trim().split('\n').map(JSON.parse);assert.equal(events[0].delta,'Xin chào [S1]');assert.equal(events.at(-1).done,true);
 assert.equal(seen.messages[0].role,'system');assert.match(seen.messages[0].content,/Sổ tay/);assert.equal(seen.tools,undefined);
 mode='incomplete';const broken=await fetch(url+'/v1/chat',{method:'POST',headers,body:JSON.stringify(input)});assert.match(await broken.text(),/trước khi hoàn tất/);
 const large=await fetch(url+'/v1/chat',{method:'POST',headers,body:'x'.repeat(140000)});assert.equal(large.status,413);
 console.log('Chat companion: PDF thực 2 trang, CORS/token, giới hạn, streaming, model allowlist và ngắt stream đạt.');
}finally{server.closeAllConnections();mock.closeAllConnections();await Promise.all([new Promise(r=>server.close(r)),new Promise(r=>mock.close(r))]);}
