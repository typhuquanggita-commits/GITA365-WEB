import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import {viecDieuPhoi} from '../may-chu/dieu-phoi.js';

const sqlite = new DatabaseSync(':memory:');
sqlite.exec(readFileSync(new URL('../may-chu/csdl.sql', import.meta.url), 'utf8'));
const db = {
  prepare(sql) {
    const statement = sqlite.prepare(sql);
    const methods = params => ({
        async first() { return statement.get(...params); },
        async all() { return {results:statement.all(...params)}; },
        async run() { return {meta:{changes:statement.run(...params).changes}}; }
      });
    return {...methods([]), bind(...params) { return methods(params); }};
  }
};
const admin = {uid:'1', u:'admin', role:'R01'};
const owner = {uid:'2', u:'coach', role:'R07'};
const outsider = {uid:'3', u:'guest', role:'R13'};
const other = {uid:'4', u:'other', role:'R08'};
const doors = ['docHomNay'];
const call = (body, who=owner, env={}) => viecDieuPhoi(body, env, db, who, doors);

assert.equal((await call({hanhDong:'tao', cua:'unknown', tieuDe:'X'})).code, 'KHONGCUA');
assert.equal((await call({hanhDong:'tao', cua:'docHomNay', tieuDe:'X'}, outsider)).code, 'NOPERM');
const made = await call({hanhDong:'tao', cua:'docHomNay', tieuDe:'Kiểm tra lịch', noiDung:'Đối chiếu lịch tuần'});
assert.equal(made.ok, true);
assert.equal((await call({hanhDong:'danhSach'}, other)).ds.length, 0);
assert.equal((await call({hanhDong:'danhSach'}, admin)).ds.length, 1);
assert.equal((await call({hanhDong:'ghiChu', id:made.id, noiDung:'Người khác không được ghi.'}, other)).code, 'KHONGTHAY');
assert.equal((await call({hanhDong:'ghiChu', id:made.id, noiDung:'   '})).code, 'DULIEU');
assert.equal((await call({hanhDong:'ghiChu', id:made.id, noiDung:'Đã bắt đầu rà soát.'})).ok, true);
assert.equal((await call({hanhDong:'capNhat', id:made.id, trangThai:'hoan_tat'})).code, 'TRANGTHAI');
assert.equal((await call({hanhDong:'capNhat', id:made.id, trangThai:'dang_lam'}, other)).code, 'KHONGTHAY');
assert.equal((await call({hanhDong:'capNhat', id:made.id, trangThai:'dang_lam'})).ok, true);
assert.equal((await call({hanhDong:'capNhat', id:made.id, trangThai:'cho_duyet'})).ok, true);
assert.equal((await call({hanhDong:'capNhat', id:made.id, trangThai:'hoan_tat', ketQua:'Đã soát'})).code, 'TRANGTHAI');
assert.equal((await call({hanhDong:'capNhat', id:made.id, trangThai:'hoan_tat', ketQua:'Đã soát'}, admin)).ok, true);
const listed = (await call({hanhDong:'danhSach'}, admin)).ds[0];
assert.equal(listed.ketQua, 'Đã soát');
assert.deepEqual(listed.suKien.map(x => x.loai), ['tao','ghi_chu','trang_thai','trang_thai','trang_thai']);
assert.match(listed.suKien.at(-1).noiDung, /Đã soát/);
assert.equal((await call({hanhDong:'danhSach'}, other)).ds.length, 0);

// Agent thật qua Workers AI: quyền AI11 tắt mặc định, cần đồng ý nội dung,
// lọc PII, chống chạy trùng; đầu ra chỉ vào trạng thái chờ người duyệt.
const taskAgent = await call({hanhDong:'tao', cua:'docHomNay', tieuDe:'Tóm tắt lịch tuần', noiDung:'Đề xuất các bước rà soát lịch tuần.'});
const reqAgent = {hanhDong:'chayAgent', id:taskAgent.id, xacNhanNoiDung:true};
const banNhapTot = '## Mục tiêu\nRà soát lịch tuần.\n## Các bước đề xuất\nĐối chiếu lịch.\n## Cách kiểm chứng\nSo sánh với lịch gốc.\n## Rủi ro và giới hạn\nNguồn lịch có thể cũ.';
const envAgent = {GITA_AGENT_MODEL:'@cf/google/gemma-4-26b-a4b-it', AI:{run:async () => ({response:banNhapTot})}};
assert.equal((await call(reqAgent)).code, 'CHUACAP');
assert.equal((await call({...reqAgent, xacNhanNoiDung:false}, owner, envAgent)).code, 'XACNHAN');
assert.equal((await db.prepare('SELECT trangThai FROM viecDieuPhoi WHERE id=?').bind(taskAgent.id).first()).trangThai, 'moi');
await db.prepare('INSERT INTO quyenAI (quyen,pham,bat,boiAi,luc,ghiChu) VALUES (?,?,?,?,?,?)')
  .bind('AI11','he',1,'admin',new Date().toISOString(),'Bật trong kiểm thử').run();
assert.equal((await call(reqAgent, owner)).code, 'AI_TAT');
const taskPii = await call({hanhDong:'tao', cua:'docHomNay', tieuDe:'Rà soát liên hệ', noiDung:'Gọi số 0912345678 để xác nhận.'});
assert.equal((await call({hanhDong:'chayAgent', id:taskPii.id, xacNhanNoiDung:true}, owner, envAgent)).code, 'DIEU13');
assert.equal((await db.prepare('SELECT trangThai FROM viecDieuPhoi WHERE id=?').bind(taskPii.id).first()).trangThai, 'moi');
assert.equal((await call({...reqAgent, hoSoGiong:'Liên hệ mẫu: phuhuynh@example.com'}, owner, envAgent)).code, 'DIEU13');
let modelCalls = 0;
const envDem = {...envAgent, AI:{run:async (model, input) => {
  modelCalls++;
  assert.equal(model, '@cf/google/gemma-4-26b-a4b-it');
  assert.equal(input.tools, undefined);
  if (/Bạn là critic/.test(input.messages[0].content)) {
    assert.match(input.messages[1].content, /Bản nháp cần rà soát/);
    assert.match(input.messages[1].content, /Giọng GITA ấm, cụ thể/);
    return {response:JSON.stringify({missingSections:[],unsupportedClaims:['Kiểm chứng lịch gốc'],safetyFlags:[],reviewNotes:['Đối chiếu nguồn trước khi duyệt']})};
  }
  assert.match(input.messages[0].content, /## Mục tiêu/);
  assert.match(input.messages[0].content, /không có công cụ/i);
  assert.match(input.messages[1].content, /Đề xuất các bước rà soát lịch tuần/);
  assert.match(input.messages[1].content, /Gợi ý phong cách/);
  assert.match(input.messages[1].content, /Giọng GITA ấm, cụ thể/);
  return {response:banNhapTot};
}}};
const draft = await call({...reqAgent, hoSoGiong:'Giọng GITA ấm, cụ thể.'}, owner, envDem);
assert.equal(draft.ok, true);
assert.equal(draft.trangThai, 'cho_duyet');
assert.equal(draft.canDuyet, true);
assert.equal(modelCalls, 2);
assert.equal((await call(reqAgent, owner, envDem)).code, 'KHONGSAN');
assert.equal(modelCalls, 2);
const agentListed = (await call({hanhDong:'danhSach'})).ds.find(v => v.id === taskAgent.id);
assert.equal(agentListed.trangThai, 'cho_duyet');
assert.match(agentListed.ketQua, /Mục tiêu/);
assert.match(agentListed.ketQua, /Đối chiếu nguồn trước khi duyệt/);
assert.match(agentListed.suKien.at(-1).noiDung, /đang chờ người có quyền duyệt/);
const taskCriticPii = await call({hanhDong:'tao', cua:'docHomNay', tieuDe:'Phản biện có dữ liệu nhận dạng', noiDung:'Đề xuất bước kiểm tra lịch.'});
let criticPiiCalls = 0;
const piiDraft = await call({hanhDong:'chayAgent', id:taskCriticPii.id, xacNhanNoiDung:true}, owner,
  {...envAgent, AI:{run:async () => { criticPiiCalls++; return {response:banNhapTot.replace('Rà soát lịch tuần.','Rà soát user@example.com.')}; }}});
assert.equal(piiDraft.ok, true);
assert.match(piiDraft.canhBaoPhanBien, /bộ lọc nhận dạng chặn/);
assert.equal(criticPiiCalls, 1);
const taskQuality = await call({hanhDong:'tao', cua:'docHomNay', tieuDe:'Đầu ra thiếu cấu trúc', noiDung:'Đề xuất cách xử lý.'});
const poor = await call({hanhDong:'chayAgent', id:taskQuality.id, xacNhanNoiDung:true}, owner,
  {...envAgent, AI:{run:async () => ({response:'Việc này có vẻ ổn. Hãy kiểm tra lại.'})}});
assert.equal(poor.code, 'CHATLUONG');
assert.equal((await db.prepare('SELECT trangThai FROM viecDieuPhoi WHERE id=?').bind(taskQuality.id).first()).trangThai, 'moi');
const taskFail = await call({hanhDong:'tao', cua:'docHomNay', tieuDe:'Thử lỗi provider', noiDung:'Bản nháp thử lỗi provider.'});
const failed = await call({hanhDong:'chayAgent', id:taskFail.id, xacNhanNoiDung:true}, owner,
  {...envAgent, AI:{run:async () => { throw new Error('provider offline'); }}});
assert.equal(failed.ok, false);
assert.equal(failed.code, 'AI_LOI');
assert.equal((await db.prepare('SELECT trangThai FROM viecDieuPhoi WHERE id=?').bind(taskFail.id).first()).trangThai, 'moi');

// Khôi phục an toàn chỉ cho quản trị viên và chỉ sau 10 phút im lặng.
const taskStale = await call({hanhDong:'tao', cua:'docHomNay', tieuDe:'Lượt bị treo', noiDung:'Kiểm tra khôi phục.'});
await call({hanhDong:'capNhat', id:taskStale.id, trangThai:'dang_lam'});
assert.equal((await call({hanhDong:'khoiPhuc', id:taskStale.id}, owner)).code, 'NOPERM');
assert.equal((await call({hanhDong:'khoiPhuc', id:taskStale.id}, admin)).code, 'CHUQUAHAN');
const staleAt = new Date(Date.now() - 11 * 60 * 1000).toISOString();
await db.prepare('UPDATE viecDieuPhoi SET ketQua=?,suaLuc=? WHERE id=?')
  .bind('Kết quả từ lượt cũ', staleAt, taskStale.id).run();
assert.equal((await call({hanhDong:'khoiPhuc', id:taskStale.id}, owner)).code, 'NOPERM');
const recovered = await call({hanhDong:'khoiPhuc', id:taskStale.id}, admin);
assert.equal(recovered.ok, true);
assert.equal(recovered.trangThai, 'moi');
const recoveredTask = (await call({hanhDong:'danhSach'}, admin)).ds.find(v => v.id === taskStale.id);
assert.equal(recoveredTask.trangThai, 'moi');
assert.equal(recoveredTask.ketQua, '');
assert.match(recoveredTask.suKien.at(-1).noiDung, /im lặng quá 10 phút/);

console.log('Sổ việc điều phối: phân quyền, lịch sử, AI hai lượt, duyệt và khôi phục stale đạt.');
