# GITA Studio — quy trình sản xuất video

## Tình trạng hiện tại

GITA Studio hiện có trình viết kịch bản theo cảnh, canvas xem thử 1080p, ghi âm micro, gắn ảnh/âm thanh trong bộ nhớ phiên, kiểm định lời đọc qua cửa GITA và nút dừng khẩn. Studio có 5 storyboard video hướng dẫn dùng đúng các luồng GITA365: bắt đầu an toàn, hành trình T1–T5, việc hôm nay, theo dõi tiến bộ, tài liệu và đồng hành. Mỗi storyboard có 5 cảnh/30 giây để biên tập tiếp, thu giọng người thật và gắn ảnh giao diện. Một thao tác trước đây gọi API `ghiDeBaiVideo` không tồn tại; đã đổi sang cửa `ghiHoChieuVideo`. Cửa này chỉ ghi metadata cùng các đèn do trình duyệt khai báo vào nhật ký. Nó không nhận media, không xác minh MP4 và không phải dịch vụ render.

Đã thêm `tools/video/dung-phim.mjs`: bộ dựng cục bộ tạo MP4 H.264/AAC, SRT và passport JSON từ JSON project. Ảnh tĩnh có chuyển động Ken Burns nhẹ; footage, voice-over, nhạc nền, phụ đề và render đều nằm trên máy người vận hành. Giới hạn mặc định: tối đa 120 cảnh, 30 phút/lượt, 4K, 24/25/30/50/60 fps. `imageFit` dùng `cover` để phủ đầy khung hoặc `contain` để giữ trọn hình trong nền tối — khung WebGL chụp từ bản đồ dùng `contain` để không mất các vòng ở tỉ lệ video dọc. Voice-over theo từng cảnh và nhạc nền được trộn. Có thể chèn phụ đề nếu FFmpeg được build với libass; nếu không, vẫn có MP4 và SRT rời.

Ngôi nhà có bản đồ WebGL 3D tại `src/hanh-trinh-3d.js`: năm vòng lấy mã, tên, câu hỏi và màu trực tiếp từ kho `G.TIERS`; 10 điểm bánh đà là ký hiệu minh họa, không hiển thị tiến độ cá nhân hoặc dữ liệu được bảo vệ. Kéo/chuột để xoay; các nút HTML vẫn truy cập được bằng bàn phím và mở bản đồ `con-duong`; hỗ trợ prefers-reduced-motion, dừng khi trang ẩn/offscreen, fallback 2D nếu WebGL không khởi động. Nút **Chụp khung 3D → Studio** chuyển PNG qua bộ nhớ của tab, rồi người biên tập tự gắn hình đó cho các cảnh. Đây là nâng cấp tăng cường trải nghiệm cho bản đồ hành trình, không thay thế quy trình đào tạo và cổng nội dung.

## Dựng video mẫu

Cần Node.js 20+ và FFmpeg có `libx264`; để chèn phụ đề vào hình, cài thêm bản FFmpeg có `libass`. Kiểm tra lệnh `ffmpeg -version` và `ffprobe -version`.

Từ thư mục gốc repo:

```bash
node tools/video/dung-phim.mjs tools/video/mau-gita.json --out ./video-output
```

Kết quả gồm `gita-mot-dieu-nho.mp4`, `gita-mot-dieu-nho.srt` và `gita-mot-dieu-nho.passport.json`. JSON mẫu dùng các nền màu, không tải nội dung từ bên ngoài. Thay `image`, `narration`, `music.path` bằng đường dẫn tương đối bên trong thư mục chứa project. Bộ dựng từ chối đường dẫn tuyệt đối và đường dẫn thoát khỏi thư mục project. Nó chạy chương trình `ffmpeg` bằng danh sách đối số, không qua shell.

### Render từ Studio web xuống máy cục bộ

Trong cửa sổ terminal khác, từ gốc repo chạy:

```bash
node tools/video/may-chu-cuc-bo.mjs
```

Giữ cửa sổ đó mở. Lệnh in ra một mã ngẫu nhiên dùng cho lần chạy này. Trong GITA Studio, nhập mã đó vào ô **Mã kết nối renderer cục bộ**, chọn cảnh/media rồi bấm **Dựng MP4 trên máy này**. Thành phẩm ghi vào `video-output/`; tệp upload trung gian được xóa khỏi thư mục tạm sau lượt dựng. Renderer mặc định chỉ nhận origin `https://gita.edu.vn` và localhost dev `http://localhost:4173`/`http://127.0.0.1:4173`. Nếu dùng Pages preview/custom domain khác, cho phép đúng origin bằng biến môi trường `GITA_VIDEO_ORIGINS` trước khi khởi động. Đổi token bằng cách khởi động lại với `GITA_VIDEO_TOKEN` mới. Đừng chia sẻ token hoặc mở port renderer ra Internet.

Bridge chỉ bind `127.0.0.1`, yêu cầu bearer token, giới hạn request 200 MB/40 tệp/tối đa một render cùng lúc và không có endpoint shell hay đọc đường dẫn tùy ý. Nếu trình duyệt chặn kết nối loopback, dựng trực tiếp bằng CLI ở trên; renderer không thay thế hệ thống render Cloudflare.

### Schema project tối thiểu

```json
{
  "schemaVersion": "gita.video.v1",
  "title": "Tên video",
  "width": 1080,
  "height": 1920,
  "fps": 30,
  "burnSubtitles": true,
  "music": { "path": "assets/nhac-nen.wav", "volume": 0.12 },
  "scenes": [
    { "seconds": 6, "image": "assets/canh-01.jpg", "imageFit": "cover", "narration": "voice/canh-01.wav", "caption": "Một câu phụ đề." },
    { "seconds": 5, "background": "#142b26", "caption": "Cảnh nền màu không cần ảnh." }
  ]
}
```

Ảnh được crop theo khung (portrait 9:16 hoặc landscape 16:9); lựa chọn framing/crop từng ảnh và footage video nhiều lớp chưa được hỗ trợ trong CLI này. Đầu ra passport ghi rõ hậu kỳ AI chưa chạy. Kiểm tra thời lượng/codec bằng `ffprobe` trước khi phát hành.

## Nghiên cứu repo và lựa chọn tích hợp

| Repo | Năng lực tham khảo | Trạng thái trong GITA365 |
|---|---|---|
| [Video2X](https://github.com/k4yt3x/video2x) | Tăng độ phân giải và nội suy khung hình (RIFE); yêu cầu máy tương thích Vulkan/AVX2 với các bản dựng hiện hành. | Hậu kỳ sau MP4 là adapter vận hành thủ công; chưa gọi binary, tải model hoặc khai báo GPU là sẵn sàng. Ghi trạng thái `not-run` vào passport. |
| [VideoLingo](https://github.com/Huanshere/VideoLingo) | Pipeline ASR theo từ, căn chỉnh, phân đoạn/dịch phụ đề, lồng tiếng; hỗ trợ tiến độ và tiếp tục tác vụ. | Bridge loopback gọi `/input` → `/run` → `/status` → `/files/trans.srt`. Dịch phụ đề hoạt động khi API local được bật; dubbing bị tắt ở bridge, tác vụ một lượt, không có hàng đợi/hủy từ Studio. |
| [cs-video-courses](https://github.com/Developer-Y/cs-video-courses) | Danh mục bài giảng khoa học máy tính theo chủ đề. Đây là kho liên kết học tập, không phải renderer hay thư viện media. | Dùng làm nguồn để lập danh sách đào tạo nội bộ; không tải lại hoặc đóng gói bài giảng. Thẩm tra giấy phép/điều khoản của từng khóa trước khi chia sẻ. |
| [Remotion](https://github.com/remotion-dev/remotion) | Video lập trình từ React, cấu phần/hoạt ảnh có thể tái sử dụng, preview và batch render. | Chưa nhúng runtime. Tổ chức cần rà soát giấy phép thương mại Remotion trước khi đưa vào sản phẩm/dịch vụ; bản GITA hiện dùng FFmpeg CLI mở, không sao chép mã repo. |
| [ClayGL](https://github.com/pissang/claygl) | Thư viện WebGL có scene graph, primitive, camera, vật liệu, shader, animation, glTF; upstream mô tả bundle tối thiểu 22 KB gzip và giấy phép BSD-2-Clause. | Bản đồ hiện viết bằng WebGL API thuần để hoạt động offline, không kéo một bundle ngoài vào ứng dụng. Cấu trúc vòng/mesh/shader lấy cảm hứng từ khả năng của ClayGL, không chứa mã ClayGL. Chưa nhúng glTF model hay asset nhân vật. |

### Bật adapter VideoLingo (tùy chọn)

Cài và cấu hình VideoLingo riêng theo hướng dẫn upstream, rồi chạy API tại loopback:

```bash
cd /duong-dan/VideoLingo
uv run start.py --api
```

Khởi động GITA companion với URL VideoLingo loopback:

```bash
GITA_VIDEOLINGO_URL=http://127.0.0.1:8000 node tools/video/may-chu-cuc-bo.mjs
```

Trên PowerShell, đặt `$env:GITA_VIDEOLINGO_URL='http://127.0.0.1:8000'` trước lệnh Node. Studio chỉ gửi đường dẫn MP4 nằm trong `video-output/` tới VideoLingo trên cùng máy. Bridge dùng `stage: all`, `dubbing: false`, poll trạng thái tối đa 30 phút và lưu `trans.srt` thành `<tên-video>.<ngôn-ngữ>.srt`. Upstream mô tả API local là không xác thực và chỉ một tác vụ một lúc; giữ nó trên loopback. Provider trong cấu hình VideoLingo có thể nhận nội dung khi xử lý, nên Studio hỏi xác nhận trước mỗi lượt. Muốn pause/resume/stop thì thao tác trong VideoLingo; bridge chưa có nút hủy hoặc lịch sử bền.

Các adapter chạy theo nhánh: dựng MP4 trước, rồi có thể phân nhánh sang phụ đề/dịch hoặc hậu kỳ GPU. Bản đồ 3D chụp thành ảnh PNG và ghép vào cảnh như một trong các nguồn hình; ảnh tĩnh có chuyển động zoom nhẹ trong MP4. Không gửi transcript, hình hay giọng của học sinh/phụ huynh ra nhà cung cấp bên ngoài nếu chưa có căn cứ và đồng ý phù hợp. Cửa Cloudflare chỉ ghi metadata; nó không điều phối file media hoặc tác vụ GPU.

## Kiểm thử

```bash
node --check tools/video/dung-phim.mjs
node tools/video/thu-dung-phim.mjs
node tools/video/thu-may-chu-cuc-bo.mjs
node --experimental-sqlite tools/video/thu-ho-chieu.mjs
node tools/video/thu-videolingo-bridge.mjs
node tools/video/thu-hanh-trinh-3d.mjs
```

Bài kiểm thử tạo asset tổng hợp tạm, dựng MP4 thật bằng FFmpeg, dùng ffprobe kiểm tra video/audio/thời lượng, xác minh SRT/passport và thử đường dẫn traversal. Kiểm thử bridge xác nhận CORS/token, upload multipart, xử lý WebP bằng ImageMagick và render qua loopback. Adapter VideoLingo được thử với API giả lập tại loopback, gồm trạng thái tác vụ và bàn giao SRT. Kiểm tra 3D xác nhận danh sách tầng/màu/mục tiêu lấy từ kho chương trình. Các bài không kiểm tra chất lượng hình ảnh chủ quan, WebGL trên GPU/thiết bị thật, Video2X hoặc Remotion.

## Giấy phép

Bộ dựng GITA mới là mã riêng trong repo GITA365 và gọi FFmpeg cài tại máy, không đóng gói nhị phân hay mã của bốn repo tham khảo. Video2X phát hành theo AGPL-3.0; VideoLingo theo Apache-2.0; Remotion có điều khoản giấy phép riêng và có trường hợp cần giấy phép công ty. Repo `cs-video-courses` là danh mục đường dẫn: quyền sử dụng từng video thuộc chủ sở hữu nguồn. Kiểm tra tệp giấy phép hiện hành và nghĩa vụ phân phối trước khi tích hợp sâu hoặc phát hành thương mại.
