# GITA Studio — quy trình sản xuất ảnh cục bộ

## Năng lực đã nối vào Studio

Trong mục **4a · Xưởng ảnh sắc nét**, chọn ảnh raster rồi chọn một khổ đầu ra. Studio gửi ảnh tới companion chỉ chạy trên `127.0.0.1`, dùng bearer token trong phiên, hỏi xác nhận trước khi gửi và trả ảnh để xem/tải. Tệp kết quả được giữ trong `image-output/`; file tạm nguồn bị xóa sau khi xử lý. Không có API ảnh tính phí hay dịch vụ lưu trữ bắt buộc.

| Khổ | Kích thước | Dùng cho |
|---|---:|---|
| Bài đăng vuông | 1080×1080 | Bài mạng xã hội, thẻ nội dung |
| Story | 1080×1920 | Story/reel/short làm ảnh bìa |
| Ngang | 1920×1080 | Thumbnail/slide/video ngang |
| Thumbnail | 1280×720 | Ảnh đại diện video ngang |
| In | 2400×3000 | Khổ dọc chất lượng cao |

ImageMagick tự căn EXIF, crop hoặc fit đúng tỉ lệ, chuyển về sRGB, áp dụng sharpen nhẹ và xóa EXIF/metadata trước khi xuất WebP. Thao tác thay đổi điểm ảnh; giữ bản gốc riêng nếu cần lưu hồ sơ. Studio giới hạn ảnh đầu vào 40 MB, 80 megapixel, một tác vụ ảnh tại một thời điểm và đầu ra xem trong web 15 MB. Preset `fit=contain` giữ toàn bộ ảnh nhưng thêm nền; luồng UI chọn `cover` cho ảnh chiến dịch. Ảnh chụp bản đồ WebGL được đánh dấu `contain` khi gắn vào video, tránh cắt mất nội dung ngang trong khung dọc.

## Chuẩn bị và chạy

Cài Node.js 20+, FFmpeg có libx264, và ImageMagick 6 hoặc 7 vào máy biên tập. Nếu lệnh cài đặt không nằm trong PATH, cấu hình `GITA_MAGICK` và `GITA_IDENTIFY`.

```bash
node tools/video/may-chu-cuc-bo.mjs
```

Giữ cửa sổ terminal mở, dán mã in ra vào GITA Studio. Với web build/local preview đã liệt kê trong `GITA_VIDEO_ORIGINS`, vào **Xưởng ảnh sắc nét**, chọn file/khổ rồi bấm **Tối ưu ảnh tại máy này**. Ảnh chỉ được gửi khi bấm nút và xác nhận. Thành phẩm nằm trong `image-output/` ở thư mục chạy companion.

Có thể chạy độc lập từ terminal:

```bash
node tools/image/xu-anh.mjs ./assets/anh-goc.jpg --preset story --out ./image-output
```

Tùy chọn `--fit contain|cover`, `--format webp|jpg|png`, `--magick` và `--identify`. CLI không ghi đè file đầu ra; nó tạo hậu tố `-v2`, `-v3` khi tên đã có. Các lệnh ảnh/video chỉ gọi chương trình tại máy, không gọi shell với nội dung người dùng.

## Vị trí phù hợp của sáu repo tham khảo

| Repo | Thế mạnh | Chọn dùng trong GITA365 |
|---|---|---|
| [ImageMagick](https://github.com/ImageMagick/ImageMagick) | Xử lý raster và batch qua CLI/API; phù hợp crop, chuẩn hóa, đổi định dạng, tối ưu và làm tự động. | Đã dùng làm engine cục bộ cho preset và xuất WebP/JPEG/PNG. Dùng với ImageMagick security policy phù hợp máy biên tập; không mở endpoint ra Internet. |
| [Intervention Image](https://github.com/Intervention/image) | API PHP nhất quán trên GD, Imagick và libvips; resize/compose/encode. | Tham khảo kiến trúc driver, nhưng GITA frontend/companion là Node và đã có ImageMagick cục bộ; không thêm PHP chỉ để chạy cùng một tác vụ. |
| [CycleGAN/pix2pix](https://github.com/junyanz/pytorch-CycleGAN-and-pix2pix) | Dịch ảnh có điều kiện hoặc không cặp qua model đã huấn luyện; cần PyTorch/model/dataset phù hợp. | Chưa nối vào luồng thương mại mặc định. Đây là biến đổi phong cách/miền ảnh, không phải công cụ sửa nét; có thể đổi ngữ nghĩa chi tiết nên cần preview và duyệt người thật. |
| [timm](https://github.com/huggingface/pytorch-image-models) | Encoder/classifier/backbone, huấn luyện/đánh giá và inference PyTorch. | Có thể làm bộ chấm chất lượng/bộ lọc ảnh khi GITA có bộ dữ liệu và tiêu chí riêng; không tự nó tạo hay upscale ảnh. Giấy phép từng bộ weights/dataset phải được kiểm tra. |
| [SDWebImage](https://github.com/SDWebImage/SDWebImage) | Tải, cache, giải mã ảnh bất đồng bộ cho UIKit/AppKit/SwiftUI trên nền tảng Apple. | Hữu ích nếu sau này làm ứng dụng iOS native; không cần cho trang web GITA hiện tại. |
| [ImageGlass](https://github.com/d2phap/ImageGlass) | Trình xem desktop đa định dạng, zoom, color management, slideshow. | Gợi ý quy trình duyệt ảnh sau xuất bằng viewer ngoài; không nhúng binary vào web và không dùng viewer thay editor. |

## Chất lượng, độ nét và chi phí

Preset ImageMagick là xử lý pixel CPU, vì vậy có thể chạy miễn phí trên phần cứng có sẵn và không cần tài khoản/key. Sharpen nhẹ giúp ảnh co/scale sắc hơn; nó không khôi phục chi tiết đã mất, không khử nhòe mạnh và không tạo độ phân giải nguồn mới. Ảnh đã rất nhỏ hoặc nén hỏng nên được thay bằng nguồn tốt hơn. Chạy upscaler neural đòi hỏi model, dung lượng đĩa và thường cần GPU/VRAM; phần cứng, điện, tải model và giấy phép/dữ liệu model vẫn có thể phát sinh chi phí hoặc điều kiện sử dụng.

CycleGAN/pix2pix và `timm` được giữ thành hướng mở rộng, không tự tải checkpoint xuống GITA365. Tài liệu upstream nói CycleGAN/pix2pix cần PyTorch và hỗ trợ CPU hoặc NVIDIA GPU; `timm` code theo Apache-2.0 nhưng pretrained weights có nguồn dữ liệu/điều khoản riêng, có thể không phù hợp thương mại. Không lấy bất kỳ checkpoint nào về dùng kinh doanh nếu chưa xác định quyền model và dataset. ImageGlass hiện có bản GPLv3 trong repo; không đóng gói hay liên kết mã của nó vào GITA365.

## License và ghi công

Intervention Image dùng MIT; SDWebImage dùng MIT; `timm` code dùng Apache-2.0; ImageGlass repository source nêu GPLv3; ImageMagick có giấy phép riêng dựa trên văn bản tương tự Apache-2.0 và yêu cầu ghi nhận sử dụng theo điều khoản upstream. Repo CycleGAN/pix2pix có LICENSE riêng — rà file LICENSE và các quyền của weights/datasets trước khi phân phối hoặc dùng thương mại. Viewer, mã thư viện, pretrained weights, datasets và ảnh đầu ra là các đối tượng quyền khác nhau; không suy ra giấy phép ảnh đầu ra từ license của code.

## Kiểm thử

```bash
node --check tools/image/xu-anh.mjs
node tools/image/thu-xu-anh.mjs
node tools/video/thu-may-chu-cuc-bo.mjs
```

Các test dùng ảnh tổng hợp, kiểm tra kích thước, định dạng WebP, metadata bị gỡ, token/origin cục bộ và đầu ra MP4 thật. Test không chứng minh độ sắc đẹp chủ quan trên ảnh sản phẩm thật hoặc tương thích mọi delegate/cấu hình ImageMagick.
