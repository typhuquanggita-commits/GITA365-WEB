# Cập nhật GITA365 V30 và khắc phục lỗi mở kho trên Cloudflare

## 1. Phân biệt hai phần cần triển khai

- **Cloudflare Pages**: phần web trong `_site/`, gồm index, JS/CSS, kho đã mã hóa và manifest phiên bản.
- **Cloudflare Worker**: API trong `may-chu/`, cơ sở dữ liệu D1, secret cấp khóa, tài khoản và phân quyền.

Cập nhật Pages không tự cập nhật Worker hoặc secret. Chọn vai để xem giao diện không phải đăng nhập thật máy chủ. Bản ZIP không chứa khóa giải mã hoặc mật khẩu của thầy.

## 2. Các thay đổi sửa lỗi trong mã

- Tải `kho/*.enc` bằng `cache: no-store` và tham số thời gian không chứa khóa. Cách này cũng tránh đường cache của service worker phiên bản cũ trong repo.
- Service worker mới bỏ qua toàn bộ đường `kho/`, chỉ xóa cache có tiền tố GITA và cập nhật với `updateViaCache: none`.
- Worker trả lỗi rõ khi bộ khóa thiếu gói được phép, thay vì trả bộ khóa rỗng nhưng báo thành công.
- Build tạo `_site/version.json` với dấu vân tay SHA-256 của tệp vỏ và kho mã hóa.
- Có trang `cap-nhat.html` độc lập và công cụ đối chiếu bản deploy với bản trên máy.

Đây là sửa các nguyên nhân tìm thấy trong mã. Chưa có phiên quản trị Cloudflare hoặc URL production xác nhận trong đợt này, nên chưa kết luận website đang chạy đã được sửa.

## 3. Chuẩn bị bản web

Giải nén ZIP. Mở terminal ở thư mục `GITA365-WEB` có `index.html`.

1. Giữ bản sao deployment cũ và bộ khóa tương ứng trong nơi riêng của quản trị viên.
2. Sửa `cau-hinh.js`, đặt `G.API_CAP_PHEP` thành URL Worker thật. Không dán token hoặc khóa vào đây. Nếu trước đây đã lưu URL trong màn Nối máy chủ, giá trị đó ưu tiên hơn tệp; kiểm tra lại trên thiết bị.
3. Nếu dùng domain API riêng, thêm đúng origin vào `connect-src` của `index.html`. Các Worker `*.workers.dev` đã được cho phép.
4. Chạy bằng Node.js 22 trở lên:

```sh
node tools/gop-src.js
node tools/gop-src.js --kiem
node tools/tao-site.mjs
```

Sau khi sửa cấu hình phải build lại để dấu vân tay và `_site` đúng. Không upload toàn bộ ZIP nguồn lên Pages; chỉ deploy **nội dung `_site/`**. Không đưa `kho/khoa.json`, `.env`, tệp secret hoặc bản sao D1 vào thư mục công khai.

## 4. Cập nhật Pages bằng GitHub

Trong Cloudflare Workers & Pages, chọn đúng Pages project, mở phần cấu hình build/deployment:

| Trường | Giá trị |
|---|---|
| Repository | Repo GITA365-WEB của thầy |
| Production branch | Nhánh thật đã chứa bản V30, ví dụ `main` sau khi merge |
| Framework preset | None |
| Root directory | Gốc repo; nếu upload cả thư mục bọc thì dùng đường dẫn tới nơi có index.html |
| Build command | `node tools/gop-src.js && node tools/tao-site.mjs` |
| Build output directory | `_site` |

Nếu thay đổi chỉ ở nhánh feature, Production không tự nhận cho đến khi merge hoặc chọn đúng nhánh. Kiểm tra commit và trạng thái deployment đã Success. Nhớ cập nhật **các file trong repo hiện có**, tránh tạo lồng thêm `GITA365-WEB/GITA365-WEB`.

## 5. Cách deploy trực tiếp khi không dùng Git integration

Nếu project cho phép Direct Upload, upload thư mục `_site` hoặc một ZIP chứa nội dung của `_site` ở ngay gốc.

Hoặc sử dụng Wrangler với tài khoản có quyền:

```sh
npx wrangler login
npx wrangler pages deploy _site --project-name TEN_PAGES_CUA_THAY
```

Thay `TEN_PAGES_CUA_THAY` bằng tên project thật. Kiểm tra deployment thuộc Production hay Preview; không chỉ nhìn URL preview rồi cho rằng domain chính đã đổi. Không tạo project mới nếu mục tiêu là cập nhật project hiện hữu.

## 6. Kiểm tra và nạp bộ khóa đúng bản

Bộ khóa phải là khóa đã dùng tạo chính những tệp `.enc` đang deploy. Không thể giải mã kho bằng một khóa ngẫu nhiên mới. Không chạy công cụ mã hóa lại khi chưa có nguồn và kế hoạch thay bộ khóa.

Kiểm tra ngoại tuyến bằng tệp khóa quản trị đang giữ:

```sh
node tools/kiem-khoa-kho.mjs /duong-dan-rieng/khoa.json _site/kho
```

Windows có thể dùng đường dẫn như `"C:\GITA-private\khoa.json"`. Công cụ chỉ báo KHỚP/KHÔNG KHỚP, không in khóa hay nội dung kho.

Nếu mọi gói KHỚP, vào thư mục máy chủ và nạp tệp đó làm secret:

```sh
cd may-chu
npx wrangler secret put GITA_KHOA_KHO
```

Dán nội dung JSON khi Wrangler yêu cầu (không dán vào GitHub hoặc chat). Kiểm tra `wrangler.toml` đang trỏ đúng Worker và D1 hiện hữu trước khi deploy:

```sh
npx wrangler deploy
```

Nếu dùng môi trường có tên, các lệnh phải dùng cùng `--env TEN_MOI_TRUONG`. Không tạo D1 mới hoặc chạy thao tác xóa dữ liệu để sửa lỗi cache. Cập nhật Pages và secret cùng một đợt bảo trì nếu thực sự thay bộ kho; rollback cũng cần đưa cả hai về cặp phù hợp.

## 7. Gỡ bản cũ trên thiết bị

1. Sau khi deploy, mở `https://TEN-MIEN-CUA-THAY/cap-nhat.html?fresh=V30`.
2. Bấm **Kiểm tra bản máy chủ**. So mã bản dựng với `_site/version.json` trong bản vừa build.
3. Lưu chat/dự án cần giữ, đóng các tab GITA khác; tích xác nhận rồi bấm **Gỡ cache GITA và bản chạy ngoại tuyến**.
4. Đóng trang khôi phục và toàn bộ tab/app PWA GITA. Mở lại website, đăng nhập tài khoản máy chủ thật rồi mở kho.
5. Trên iPhone nếu dùng icon màn hình chính, đóng hẳn phiên PWA cũ và kiểm tra trước trong Safari.

Không dùng xóa toàn bộ dữ liệu website như bước đầu tiên; cách đó có thể mất dữ liệu cục bộ chưa sao lưu.

## 8. Đối chiếu bản live

Tại gốc source sau khi build:

```sh
node tools/kiem-ban-live.mjs https://TEN-MIEN-CUA-THAY/
```

Công cụ tải manifest và đối chiếu từng SHA-256 với bản `_site` cục bộ. Chỉ báo ĐẠT nếu các tệp tương ứng khớp. Nó không đăng nhập, không đọc secret và không xác nhận quyền tài khoản.

Nếu domain riêng khác kết quả `*.pages.dev`, xem lại domain đang gắn project nào, Cloudflare Cache Rules/Worker route có ghi đè hay không. Tắt quy tắc cache ép cho `/version.json`, `/sw.js`, `/index.html`, `/cau-hinh.js`, `/gita-app.js`, `/gita-nghe.js`, `/kho/*` hoặc purge đúng các URL đó. `_headers` chỉ có tác dụng với tài nguyên tĩnh Pages; nếu một Worker/Function trả phản hồi thì cần thiết lập header ở chính nơi đó.

## 9. Bảng chẩn đoán

| Biểu hiện | Cách xử lý |
|---|---|
| Không có version.json / nhận HTML thay JSON | Sai output directory, deployment cũ hoặc route rewrite |
| Build ID không khớp | Sai nhánh, sai deployment, cache trung gian hoặc chưa build lại sau khi sửa |
| NOKEY | Secret chưa nạp/không đọc được trên đúng Worker environment |
| KEYSET_MISMATCH | Secret thiếu khóa cho một số gói; kiểm tra định dạng và bộ khóa |
| Giải mã thất bại | Kiểm ngoại tuyến; `.enc` và secret không cùng bộ hoặc tệp cũ vẫn được phục vụ |
| HTTP 404 tệp kho | Upload thiếu thư mục kho hoặc sai gốc |
| Không gọi được máy chủ | URL API, mạng, CSP, CORS, Worker lỗi; xem Network/Worker logs |
| Đăng nhập nhưng chưa đủ gói | Kiểm quyền tài khoản/phạm vi cấp phép, không vượt cổng phân quyền |

## Nguồn chính thức

- https://developers.cloudflare.com/pages/configuration/build-configuration/
- https://developers.cloudflare.com/pages/configuration/headers/

Các bước trên áp dụng cho kiến trúc Pages + Worker hiện có của repo; không phải xác nhận đã đăng nhập hoặc deploy vào tài khoản Cloudflare của thầy.

## 10. Chế độ build Production chặn thiếu URL máy chủ

Để tránh vô tình phát hành bản mẫu với API trống, trong Cloudflare đặt biến môi trường công khai `GITA_API_URL` bằng URL Worker thật (không chứa khóa/token). Đổi Build command thành:

```sh
node tools/gop-src.js && node tools/tao-site.mjs --production
```

Build sẽ thất bại rõ ràng nếu URL thiếu hoặc không phải HTTPS hợp lệ. URL được ghi vào bản `_site/cau-hinh.js` trước khi tạo dấu vân tay; source gốc không bị thay. Thiết lập URL lưu riêng trên trình duyệt vẫn ưu tiên, nên nếu máy người dùng từng kết nối Worker cũ thì vào Nối máy chủ để đổi hoặc bỏ cấu hình cũ.

Build mặc định không có `--production` vẫn tạo bản bàn giao có thể xem thử. Không coi bản mặc định là đã kết nối tới máy chủ của thầy.

## 11. Giấy phép mới khớp kho và thông báo cập nhật

Bản rà soát mới tự đóng dấu build vào ứng dụng và tên cache service worker. Khi người dùng quay lại tab hoặc sau 5 phút đang mở, app kiểm tra manifest máy chủ. Nếu khác bản, app hiện nút tải bản mới; không tự tải lại làm mất công việc chưa lưu. Cần triển khai bản này trước để các lần cập nhật tiếp theo có thông báo. Với app quá cũ hãy dùng trang cap-nhat.html.

Giấy phép riêng được cấp bằng bộ khóa GỐC khớp kho; không thể suy ra khóa từ tệp mã hóa. ZIP không chứa giấy phép mở toàn bộ kho vì môi trường bàn giao không có bộ khóa ấy. Trên máy quản trị, chạy ví dụ (thay đường dẫn, tên nhận và hạn thật):

```sh
node tools/cap-giay-phep.mjs "C:/GITA-private/khoa.json" "C:/GITA-private/giay-phep-v30.json" "Hoc vien GITA" "2027-09-28" "_site/kho"
```

Công cụ kiểm tra giải mã AES-GCM của từng gói trước khi ghi giấy phép, không ghi đè tệp cũ và từ chối lưu trong repo. Giấy phép chứa khóa bí mật: giữ riêng, không đưa vào ZIP công khai, GitHub hoặc Pages. Đây là tệp cấp khóa cục bộ theo định dạng của ứng dụng, không phải giấy phép thương mại/chữ ký số và không thay phân quyền máy chủ.

Khi nạp giấy phép mới, ứng dụng đối chiếu fingerprint kho trong manifest. Sai cặp sẽ báo trước khi nạp; ngày hết hạn không hợp lệ bị từ chối. Giấy phép cũ chưa có fingerprint vẫn được hỗ trợ và phải giải mã AES thành công.

Để mở kho thông qua máy chủ, tiếp tục nạp bộ khóa đã kiểm tra vào secret GITA_KHOA_KHO của đúng Worker. Việc cấp file riêng không tự thay secret. Bản web chỉ thay đổi giao diện/code không yêu cầu đổi khóa; chỉ thay khóa khi chính bộ kho mã hóa đổi.
