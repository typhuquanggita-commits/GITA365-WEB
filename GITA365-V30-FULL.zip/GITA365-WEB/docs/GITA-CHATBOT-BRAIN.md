# GITA Chatbot · Bộ não điều phối · Owncast

## Bản bàn giao 28/09/2026

### Đã triển khai

- Nhiều cuộc trò chuyện trong một tab: tạo, đổi tên, tìm kiếm, chuyển, xóa; giữ bản nháp riêng.
- 30 cuộc/tab, 240 tin/cuộc, câu hỏi tối đa 6.000 ký tự. Dữ liệu chỉ sống trong bộ nhớ tab; đăng xuất/đổi tài khoản dọn cả tài liệu và mã kết nối.
- Nhập TXT, MD, CSV, JSON trên trình duyệt; PDF qua companion cục bộ. Chia đoạn có độ chồng và xếp hạng BM25 theo từ khóa tiếng Việt không dấu.
- Trích dẫn có tên tệp, số trang PDF hoặc số đoạn; nội dung được escape trước khi hiển thị. Có thể mở từng nguồn để kiểm chứng.
- Đội ngũ R01–R12 có chế độ Ollama: chọn mô hình quản trị cho phép, nhận phản hồi từng phần, dừng, thử lại, báo lỗi/ngắt stream. Chế độ tra kho GITA là mặc định.
- Câu có dấu hiệu khẩn đi qua bộ chuyển người thật hiện có. Tài khoản gia đình dùng chế độ tra kho; mô hình cục bộ dành cho đội ngũ.
- Micro dừng giọng đọc trước khi nghe, bỏ sự kiện nhận dạng của phiên đã hủy; Enter tôn trọng quá trình gõ IME.
- Bản nháp giao việc từ chatbot: chọn agent trong roster thật, biên tập mục tiêu, đầu ra/tiêu chí hoàn thành và giới hạn; lưu qua `viecDieuPhoi` hiện có. Agent chạy, đánh giá và duyệt ở màn Điều phối theo quyền máy chủ.
- Owncast: mở player và chat lớp học bằng đường nhúng chính thức, mở tab riêng khi cần, soạn câu hỏi riêng cho trợ lý. Chỉ tải iframe khi bấm mở lớp.

## Chạy phần web

```bash
node tools/gop-src.js
node tools/tao-site.mjs
python3 -m http.server 4173 --directory _site
```

Mở `http://127.0.0.1:4173`. Đưa **nội dung** `_site/` lên nơi lưu trữ web như cách triển khai hiện có. Sổ việc thật cần cấu hình Worker và xác thực tài khoản trong `cau-hinh.js`.

## Bật mô hình cục bộ và PDF

Yêu cầu Node.js 22+, Ollama và Poppler (`pdftotext` trong PATH). Trên Ubuntu/Debian, gói Poppler là `poppler-utils`; trên macOS dùng `brew install poppler`. Windows có thể chạy companion trong WSL cùng Ollama có địa chỉ loopback truy cập được.

1. Cài Ollama, chọn và tải một mô hình phù hợp RAM/GPU của máy. Mã mặc định của companion là `qwen3:8b`; có thể dùng mã mô hình khác đã cài.
2. Khởi động Ollama tại `http://127.0.0.1:11434`.
3. Khởi động companion:

```bash
GITA_CHAT_MODELS='qwen3:8b' node tools/chat/may-chu-chat.mjs
```

4. Mở **Trợ lý GITA → Mô hình cục bộ**. Nhập mã kết nối do terminal cung cấp, bấm **Kết nối / làm mới**, chọn **Mô hình cục bộ**.
5. Thêm tài liệu rồi đặt câu hỏi có từ khóa cụ thể. Nguồn đính kèm chỉ thuộc cuộc trò chuyện hiện tại.

Companion nghe tại `127.0.0.1:8767`; mã kết nối sinh mới khi khởi động, hoặc đặt biến `GITA_CHAT_TOKEN` tối thiểu 32 ký tự. Browser dùng cố định cổng 8767. Biến `GITA_CHAT_PORT` chỉ hữu ích cho kiểm thử/triển khai có sửa endpoint tương ứng.

| Biến | Ý nghĩa |
|---|---|
| `GITA_CHAT_MODELS` | Các mã Ollama được phép, phân cách bằng dấu phẩy; phải tải trước trong Ollama |
| `GITA_OLLAMA_URL` | Loopback HTTP; mặc định `http://127.0.0.1:11434` |
| `GITA_CHAT_ORIGINS` | Origin web được phép; mặc định `https://gita.edu.vn,http://localhost:4173,http://127.0.0.1:4173` |
| `GITA_CHAT_TOKEN` | Mã kết nối tùy chọn; không đưa vào mã nguồn hoặc cấu hình web công khai |

`/v1/status` xác nhận companion và danh sách cho phép. Trạng thái này chưa khẳng định mô hình đã tải trong Ollama. Nếu Ollama lỗi, câu trả lời hiển thị lỗi và cho thử lại.

PDF: tối đa 10 MB, 100 trang đầu, 500.000 ký tự/tệp. PDF scan cần OCR trước; PDF có mật khẩu cần mở khóa bằng công cụ phù hợp. Văn bản tối đa 1 MB/tệp, 8 tài liệu và 1 triệu ký tự/cuộc. PDF tạm được xóa ở khối `finally` sau khi xử lý; quá trình bị hệ điều hành kill có thể để lại thư mục tạm `gita-chat-*` cần dọn.

Khi xóa một tài liệu, nó ngừng tham gia truy vấn mới. Trích dẫn đã xuất hiện trong câu trả lời cũ vẫn thuộc lịch sử; xóa cuộc trò chuyện để dọn cả những đoạn này.

Truy hồi hiện tại dùng từ khóa BM25; không có vector embeddings, OCR hay đồng bộ cloud. Mô hình có thể suy diễn sai; phần nguồn cho phép người dùng kiểm tra. Chế độ tra kho đưa trích đoạn tìm được, còn chế độ Ollama tổng hợp từ lịch sử và các nguồn.

## Giao việc cho bộ não

1. Đội ngũ đặt câu hỏi trong chatbot.
2. Bấm **Giao việc cho bộ não**, chọn agent/cửa phụ trách, sửa mục tiêu và tiêu chí hoàn thành.
3. Bấm **Lưu việc vào sổ điều phối** để gửi đúng phần đã biên tập lên Worker. Tài liệu và toàn bộ transcript không tự đính kèm vào công việc.
4. Mở **Sổ điều phối** để chạy agent, đọc bằng chứng, phản biện và duyệt qua luồng hiện có. Kết nối Ollama trong chatbot không tự bật quyền chạy agent trên Worker.

## Lớp trực tiếp Owncast

1. Triển khai một Owncast server theo hướng dẫn chính thức: https://owncast.online/quickstart/ . Dùng tên miền HTTPS, ví dụ `https://live.gita.edu.vn`.
2. Trong `cau-hinh.js`, đặt `G.OWNCAST_URL` bằng origin HTTPS của server (không kèm `/admin`, stream key, username hoặc password).
3. CSP của `index.html` đã cho iframe từ `https://*.gita.edu.vn`. Với tên miền khác, thêm **đúng origin** vào `frame-src`, dựng lại `_site/`.
4. Trong Owncast, cấu hình tên lớp, chat, người kiểm duyệt và quyền truy cập phù hợp. Owncast quản lý danh tính chat riêng; việc đăng nhập GITA không tự cấp hoặc hạn chế quyền xem Owncast.
5. Dùng OBS phát RTMP tới Owncast. File MP4 đã tạo bằng GITA Studio có thể dùng làm Media Source trong OBS. Stream key chỉ đặt trong OBS/Owncast admin.
6. Trong chatbot bấm **Mở lớp trực tiếp**. GITA tải `/embed/video?autoplay=off` và `/embed/chat/readwrite`. Người dùng tự nhập tin vào phòng chat; trợ lý không tự đăng câu trả lời vào phòng.

Nút **Soạn câu hỏi cho trợ lý GITA** đóng lớp và đặt câu mở đầu vào ô chat riêng để người dùng bổ sung. Đóng hộp thoại gỡ iframe và kết thúc việc phát tại đó.

## Các nguồn đã đối chiếu

| Repo / nguồn | Cách áp dụng trong GITA |
|---|---|
| https://github.com/vercel/chatbot | Phản hồi từng phần, vòng đời yêu cầu, lựa chọn mô hình |
| https://github.com/mckaywrigley/chatbot-ui | Nhiều hội thoại, tìm lịch sử, tài liệu theo cuộc |
| https://github.com/mayooear/ai-pdf-chatbot-langchain | Ingest → chia đoạn → truy hồi → trả lời có nguồn; repo đã archived, dùng làm tham khảo kiến trúc |
| https://github.com/78/xiaozhi-esp32 | Tách trạng thái nghe/nói/hủy; firmware ESP32 và gateway MCP cần một dự án tích hợp thiết bị riêng |
| https://github.com/owncast/owncast | Dùng dịch vụ Owncast tự lưu trữ với giao diện nhúng chính thức |
| https://owncast.online/docs/embed/ | Đường dẫn video và phòng chat nhúng |
| https://docs.ollama.com/api/chat | Giao thức chat NDJSON streaming |

Mã mới được triển khai trực tiếp bằng JavaScript/Node của GITA; không thêm framework Next.js, Supabase hoặc LangChain vào ứng dụng tĩnh. Mô hình và Owncast do người triển khai cung cấp riêng, theo giấy phép của phiên bản được chọn.

## Kiểm thử và giới hạn bàn giao

```bash
node tools/chat/thu-chat-server.mjs
node tools/chat/thu-chat-workspace.mjs
node tools/chat/thu-chat-input.mjs
node tools/thu-xuat-hoi-thoai.mjs
node tools/thu-micro.mjs
node tools/thu-giong-doc.mjs
node tools/thu-phien-trinh-duyet.mjs
node tools/thu-viec-dieu-phoi.mjs
node tools/gop-src.js --kiem
```

Bộ kiểm dùng PDF thực 2 trang và máy Ollama giả lập giao thức HTTP để kiểm tra streaming, ngắt giữa chừng, giới hạn, CORS, token và model allowlist. Bộ kiểm frontend chạy logic trong VM: cách ly cuộc trò chuyện, trích dẫn, XSS, giao việc, đổi phiên, hủy stream và chuyển tuyến khẩn.

Chưa có mô hình Ollama thực, Owncast server thực, thiết bị ESP32 hoặc browser binary trong môi trường bàn giao. Cần kiểm tra thêm giao diện mobile, quyền local-network/micro và live audio/video trên thiết bị triển khai. Không có phí API bên ngoài cho companion này; phần cứng, điện, băng thông và lưu trữ vẫn có chi phí tùy môi trường.


### Bản sửa ổn định hội thoại

- Giữ nguyên câu đang nhập khi mô hình bận, chưa kết nối hoặc câu vượt giới hạn.
- Nhánh khẩn vẫn đi tới người thật khi hội thoại đã dài hoặc câu hỏi vượt giới hạn thông thường.
- Giữ bộ lọc tìm hội thoại qua các lần cập nhật; khôi phục bản nháp đúng cuộc khi chuyển nhanh.
- Kiểm thử riêng việc xóa cuộc chat trong lúc nhập tệp để kết quả cũ không xuất hiện lại.
