# GITA365 V30 — bàn giao tích hợp

## Bản này làm được gì

Mở menu **V30 · Bàn sản xuất hợp nhất** bằng tài khoản nhân sự có quyền `qt_trang`.

1. Nhập brief: tên, đối tượng, mục tiêu, CTA. Nhập phong cách hoặc nạp từ Điều phối; khai báo cụm từ cần tránh.
2. Thêm dữ kiện với nguồn. Có tìm kiếm từ khóa, sửa tạo phiên bản thay thế, rút dữ kiện. Sửa/rút nguồn xóa đầu ra cũ để không dùng thông tin hết hiệu lực.
3. Bấm **Tạo toàn bộ bản nháp**: sinh ba bản Facebook/LinkedIn/YouTube theo khuôn, thiết kế SVG phối cảnh, storyboard có thời lượng. Đây là tự động hóa theo quy tắc, không phải một lời gọi mô hình AI.
4. **Biên tập bằng AI cục bộ** gọi mô hình đã kết nối trong chatbot, nhận ba bài và 3–5 cảnh theo JSON. Chỉ gửi ngữ cảnh dự án, không ghép tài liệu của chat khác. Máy kiểm cấu trúc, mã nguồn và cụm từ cấm trước khi thay bản nháp; lỗi thì giữ bản cũ. Có nút Dừng AI, hủy khi đổi phiên, và phải duyệt lại sau biên tập. Cần Ollama cùng companion chạy thật.

   **Đưa brief sang chatbot** tạo cuộc chat mới với yêu cầu chờ gửi. Chatbot giữ cơ chế tra kho hoặc Ollama cục bộ đã có. Prompt trên 6.000 ký tự cần tải TXT rồi nhập như tài liệu. Nội dung AI không tự duyệt.
5. **Giao việc vào sổ điều phối** tạo việc thực trên Worker cho agent chọn. Việc ở trạng thái chờ; dùng cơ chế chạy agent, kiểm định và duyệt của Điều phối. Không tạo tác vụ giả đã hoàn thành.
6. Tải SVG/PNG 1080 × 1350. Chuyển storyboard và PNG vào Studio; nếu Studio có kịch bản, ứng dụng hỏi trước khi thay. Thu giọng, kiểm tra và xuất MP4 bằng renderer hiện có. Cổng kiểm định Studio vẫn hoạt động.
7. Đọc đầu ra, kiểm nguồn và quyền sử dụng, ký duyệt đúng phiên bản; tải gói JSON phân phối. Bất kỳ chỉnh sửa liên quan nào đều hủy hiệu lực duyệt cũ.
8. Tải JSON dự án trước khi đóng. Nhập lại phục hồi nội dung nhưng không tin chữ ký, nhật ký hay trạng thái duyệt nhập từ tệp.

Dữ liệu V30 hiện ở RAM của tab, xóa khi đổi tài khoản/đăng xuất. Chỉ tác vụ được giao vào Điều phối mới lưu máy chủ. Đây chưa phải kho tri thức nhiều người đồng bộ thời gian thực. Nhật ký V30 là ghi nhận cục bộ, không phải log chống sửa đổi.

## Hợp nhất theo bảy lớp trong ảnh

| Lớp | Cơ chế trong bản bàn giao |
|---|---|
| Context | Brief, phong cách, dữ kiện có nguồn, sửa/rút và tra từ khóa |
| Tools | Tải SVG/PNG, chuyển Studio, chatbot, endpoint sổ việc có sẵn |
| Orchestration | Brief → nội dung/thiết kế/storyboard → kiểm tra → duyệt → xuất; giao việc máy chủ |
| Evaluation | 8 kiểm tra cấu trúc; không thay kiểm chứng sự thật và đánh giá sáng tạo |
| Security | Giới hạn nhập tệp, whitelist trường, escape HTML/SVG, phân quyền giao diện và Worker |
| Governance | Duyệt theo revision, hủy duyệt khi đổi, bản nhập cần duyệt lại |
| AgentOps | Đếm đầu ra thật, nhật ký trong phiên; theo dõi agent trong Điều phối |

## Phạm vi tham khảo

Không sao chép hoặc cài các skill bên ngoài để tự chạy lệnh trên tài khoản của chủ hệ.

- [AI Marketing Skills](https://github.com/ericosiu/ai-marketing-skills): tham khảo tổ chức luồng biên tập, kiểm định và duyệt đúng phiên bản. Không chuyển lời quảng bá điểm số của repo thành cam kết chất lượng GITA.
- [MultiPost Extension](https://github.com/leaperone/MultiPost-Extension): tham khảo phân phối đa kênh. Phần mở có Apache-2.0, module Agent trong bản chính thức không nằm trọn trong repo. GITA hiện xuất bản nháp để thao tác thủ công; JSON giao nhận **không** được quảng cáo là tương thích API MultiPost.
- [gbrain](https://github.com/garrytan/gbrain): tham khảo bộ nhớ có nguồn gốc và khả năng sửa/rút dữ kiện. GITA dùng kernel riêng; chưa nhúng Bun, semantic graph hay triển khai gbrain hosted.

## Giới hạn cần hiểu đúng

- Vector phối cảnh là minh họa 2D có chiều sâu; không phải sinh mô hình 3D, ảnh người thật hoặc ảnh diffusion. Bản đồ WebGL và các công cụ Studio/ảnh hiện có vẫn đi kèm.
- Chưa cấu hình dịch vụ thực thì không thể tuyên bố đã thử Ollama, Owncast, Workers AI hoặc render GPU trên máy khách. Các bài test HTTP dùng mô phỏng khi cần.
- Chưa có tích hợp tự đăng mạng xã hội hoặc bộ đo doanh thu. KPI là số đầu ra, trạng thái duyệt và giao nhận; không hứa 100% KPI hay tăng 10 lần.
- Phần tạo theo khuôn chạy miễn phí trên trình duyệt. Điện, thiết bị, GPU, lưu trữ, lưu lượng và dịch vụ AI có thể phát sinh chi phí.
- Không tự động thực hiện các hành động đối ngoại hoặc giao dịch từ nội dung trong bộ nhớ.

## Kiểm thử

`node tools/v30/thu-v30.mjs` — nguồn, revision, duyệt, nhập dữ liệu và SVG.

`node tools/v30/thu-workbench.mjs` — quyền, HTML, chuyển brief, giao việc và xóa phiên.

`node tools/thu-service-worker.mjs` — bỏ cache kho, giữ cache ứng dụng khác.

Bản tiếp theo đã bổ sung test biên tập AI cách ly ngữ cảnh, từ chối nguồn sai, thay dữ liệu nguyên tử và khôi phục dự án trống. Phản hồi AI trong test dùng HTTP mô phỏng, chưa phải đánh giá chất lượng mô hình thực.

Các bài test chatbot, phiên đăng nhập, sổ việc và so khớp bundle được chạy lại trong đợt bàn giao. Chưa kiểm thử giao diện bằng trình duyệt thật trong môi trường này.
