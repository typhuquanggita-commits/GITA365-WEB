# Giọng nói tiếng Việt

GITA365 có nút đọc câu trả lời của trợ lý cho nhân sự nội bộ. Mặc định ứng dụng dùng giọng tiếng Việt đã cài trên thiết bị (không gửi văn bản ra dịch vụ giọng nói bên ngoài). Tùy chọn Piper cho phép dùng tổng hợp tiếng Việt cục bộ qua một dịch vụ mà đơn vị tự vận hành.

## Lựa chọn engine

| Engine | Điểm phù hợp | Lưu ý |
|---|---|---|
| Piper | Tiếng Việt `vi_VN`, tổng hợp cục bộ nhanh; phù hợp làm engine neural tùy chọn cho GITA365 | Dự án `rhasspy/piper` cũ đã lưu trữ và phát triển tiếp ở `OHF-Voice/piper1-gpl`. Runtime hiện tại là GPLv3; từng voice có model card và giấy phép riêng. Hãy kiểm tra giấy phép đúng voice trước khi dùng/phân phối. |
| Coqui XTTS-v2 | Đa ngôn ngữ, có nhân bản/chuyển giọng từ mẫu | Danh sách ngôn ngữ chính thức không có tiếng Việt; model XTTS-v2 dùng CPML với điều khoản riêng, nên không đóng gói kèm. |
| OpenVoice V2 | MIT; chuyển giọng/điều khiển phong cách, có chất lượng đa ngôn ngữ tốt | Các ngôn ngữ hỗ trợ gốc được công bố không gồm tiếng Việt. |
| Coqui TTS | Framework huấn luyện/chạy nhiều TTS | Framework và model có giấy phép riêng; chất lượng/tiếng hỗ trợ phụ thuộc model cụ thể. |

Vì yêu cầu chính là giọng tiếng Việt dùng được với dữ liệu nội bộ, cấu hình này chọn giọng hệ thống `vi` làm dự phòng và Piper tự host làm tùy chọn neural. “Tốt nhất” còn phụ thuộc giọng Piper, phần cứng và giấy phép mà tổ chức chấp nhận; ứng dụng không tải model hoặc văn bản lên máy chủ công cộng.

## Chạy Piper cục bộ (tùy chọn)

Chạy trong môi trường Python riêng, trên máy có thể truy cập từ trình duyệt GITA365. Chọn một voice `vi_VN` từ danh mục Piper và đọc kỹ tệp `MODEL_CARD` của chính voice đó. Không đưa file voice hoặc runtime vào repository/ZIP nếu chưa được phép phân phối.

```bash
python -m venv .venv
. .venv/bin/activate
python -m pip install 'piper-tts[http]'
python -m piper.download_voices <VOICE_ID>
python -m piper.http_server -m <VOICE_ID> --host 127.0.0.1 --port 5000
```

Thay `<VOICE_ID>` bằng mã voice tiếng Việt chính xác trong danh mục mẫu/tải voice, rồi kiểm tra giấy phép `MODEL_CARD`. Lệnh HTTP server chính thức cho phiên bản Piper hiện hành lắng nghe cổng 5000; proxy GITA365 chỉ kết nối tới loopback này. API nhận `POST /synthesize` với JSON `{"text":"Xin chào"}` và trả âm thanh WAV.

Khởi động cầu nối an toàn đi kèm GITA365:

```bash
python3 tools/voice/piper-cors-proxy.py
```

Cầu nối chỉ bind `127.0.0.1:8765`, chỉ chuyển tiếp tới Piper ở `127.0.0.1:5000/synthesize`, giới hạn văn bản/kích thước WAV và chỉ chấp nhận Origin trong danh sách cho phép. Mặc định có `http://localhost:8099` để chạy máy phát triển. Với origin triển khai thật, đặt `GITA_ALLOWED_ORIGINS` thành origin chính xác, cách nhau bởi dấu phẩy, ví dụ:

```bash
GITA_VOICE_ORIGINS='https://your-site.example' python3 tools/voice/piper-cors-proxy.py
```

Trong `cau-hinh.js`, cấu hình endpoint cầu nối:

```js
G.GITA_PIPER_URL = 'http://127.0.0.1:8765/synthesize';
```

Trình duyệt cần truy cập được loopback của chính máy đang chạy ứng dụng. GITA365 kiểm tra URL chính xác, Origin, quyền đọc và loại nội dung trả về. Khi endpoint chưa cấu hình, ứng dụng chỉ tìm voice tiếng Việt cục bộ (`localService`) qua Web Speech API. Thiết bị không có voice phù hợp sẽ báo lỗi thay vì gửi giọng đọc sang dịch vụ từ xa.

## Quyền truy cập và riêng tư

- Khách hàng/khách truy cập không có nút đọc thành tiếng; thao tác bị từ chối lần nữa ở thời điểm phát.
- Cơ chế khóa sao chép của GITA365 tiếp tục chặn đọc nội dung được bảo vệ.
- Văn bản câu trả lời chỉ gửi tới Piper loopback nếu đơn vị chủ động cấu hình endpoint; cầu nối không ghi nội dung vào log.
- Nhập giọng nói dùng Web Speech API của trình duyệt/hệ điều hành; nhà cung cấp có thể gửi âm thanh tới dịch vụ nhận dạng bên ngoài. Lần đầu sử dụng trong mỗi phiên có thông báo xin đồng ý; micro tự dừng khi ẩn tab hoặc đăng xuất.
- Không nhập dữ liệu cá nhân nhạy cảm vào dịch vụ Piper dùng chung; quản trị viên đơn vị chịu trách nhiệm vận hành máy, model và giấy phép voice.

## Nguồn dự án và giấy phép

- [Coqui TTS](https://github.com/coqui-ai/TTS) và [tài liệu XTTS](https://docs.coqui.ai/en/latest/models/xtts.html).
- [XTTS-v2 model card và giấy phép](https://huggingface.co/coqui/XTTS-v2) — model dùng CPML; kiểm tra điều khoản/TOS hiện hành trước mọi mục đích sử dụng.
- [Piper cũ](https://github.com/rhasspy/piper), [Piper đang phát triển](https://github.com/OHF-Voice/piper1-gpl), [HTTP API](https://github.com/OHF-Voice/piper1-gpl/blob/main/docs/API_HTTP.md) và [danh sách giọng](https://github.com/OHF-Voice/piper1-gpl/blob/main/docs/VOICES.md).
- [OpenVoice](https://github.com/myshell-ai/OpenVoice).

Kiểm thử cục bộ: `node tools/thu-giong-doc.mjs` và `python3 tools/thu-piper-proxy.py`.
