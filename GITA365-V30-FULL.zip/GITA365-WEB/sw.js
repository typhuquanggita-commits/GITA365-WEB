/* ═══════════════════════════════════════════════════════════════
   GITA 365 · v7.0 — SERVICE WORKER
   Lưu phần vỏ và nội dung mẫu cho lúc mất mạng. Nội dung có cấp phép
   tuân theo Cache-Control của máy chủ, không hứa mở được khi ngoại tuyến.
   ═══════════════════════════════════════════════════════════════ */
const CACHE = 'gita365-v9-99-243';
/* Danh sách này phải khớp với thứ tự thẻ <script> trong index.html.
   Thiếu tệp thì lần cài đầu vẫn chạy — trình xử lý fetch bên dưới cache
   lại mọi thứ tải về — nhưng mất mạng ngay sau khi cài thì vỡ. */
const FILES = [
  './',
  './index.html',
  './manifest.webmanifest',
  './assets/style.css',
  /* Chỉ gói MẪU nằm trong danh sách tải sẵn.
     Bảy tệp kho/*.enc từng nằm ở đây — 12 MB tải ngay lúc cài, trước cả
     khi người dùng đăng nhập. Phụ huynh không bao giờ mở gói "nghe"
     (3,1 MB) mà vẫn phải tải; trên 3G là bốn phút và tiền 3G thật.
     Kho được mở theo quyền khi có kết nối; không tải sẵn bảy gói. */
  './kho/mau.json',
  './assets/fonts.css',
  './assets/fonts/bevietnampro-400-italic-latin.woff2',
  './assets/fonts/bevietnampro-400-italic-vietnamese.woff2',
  './assets/fonts/bevietnampro-400-normal-latin.woff2',
  './assets/fonts/bevietnampro-400-normal-vietnamese.woff2',
  './assets/fonts/bevietnampro-600-normal-latin.woff2',
  './assets/fonts/bevietnampro-600-normal-vietnamese.woff2',
  './assets/fonts/bevietnampro-700-normal-latin.woff2',
  './assets/fonts/bevietnampro-700-normal-vietnamese.woff2',
  './assets/fonts/bevietnampro-800-normal-latin.woff2',
  './assets/fonts/bevietnampro-800-normal-vietnamese.woff2',
  './assets/fonts/playfairdisplay-500-italic-latin.woff2',
  './assets/fonts/playfairdisplay-500-italic-vietnamese.woff2',
  './assets/fonts/playfairdisplay-600-normal-latin.woff2',
  './assets/fonts/playfairdisplay-600-normal-vietnamese.woff2',
  './assets/icons/icon-192.png',
  './assets/icons/icon-512.png',
  './assets/icons/maskable-512.png',
  './gita-app.js',
  './cau-hinh.js',
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE)
      .then(c => c.addAll(FILES))
      .then(() => self.skipWaiting())
      .catch(err => console.warn('[GITA] cache install:', err))
  );
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(ks => Promise.all(ks.filter(k => k.startsWith('gita365-') && k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

/* Ưu tiên bản trong máy, đồng thời làm mới ngầm ở nền */
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;   // font ngoài để trình duyệt tự lo
  const scope = new URL(self.registration.scope);
  if (!url.pathname.startsWith(scope.pathname)) return;
  const path = url.pathname.slice(scope.pathname.length);

  /* Chỉ giữ tài nguyên tĩnh. Một GET cùng tên miền có thể là API trả dữ
     liệu cá nhân; không được suy ra "cùng tên miền" nghĩa là an toàn để
     lưu ngoại tuyến. Query string cũng không được cache vì có thể mang
     token hoặc tham số hồ sơ. */
  const trang = /^(?:index|404|cau-hoi-thuong-gap|duong-vao|hanh-trinh-12-chang|mo-thuc-huan-luyen-gita|nam-tang-dong-hanh)\.html$/;
  const ma = /^(?:gita-app|gita-nghe|cau-hinh|sw)\.js$/;
  const asset = /^assets\/[\w./-]+\.(?:css|woff2|png|jpg|jpeg|webp|ico|svg)$/;
  const kho = /^kho\/[\w-]+\.(?:enc|json)$/;
  if (url.search || !(path === '' || trang.test(path) || ma.test(path) ||
      path === 'manifest.webmanifest' || asset.test(path) || kho.test(path))) return;

  // Licensed/encrypted payloads must never use stale Cache Storage entries.
  if (kho.test(path)) return;

  /* ── Tệp nặng và không đổi: lấy trong máy, KHÔNG hỏi lại mạng ──
     Kho mã hoá, phông chữ và biểu tượng chỉ đổi khi đổi số bản, mà đổi
     số bản là đổi tên CACHE và bản cũ bị xoá sạch ở 'activate'. Nên hỏi
     lại mạng cho chúng là tải lại thứ y hệt cái đang có.

     Trước bản này, mỗi lần một Coach đăng nhập là 11,6 MB kho được tải
     lại ngầm dù máy đã có đủ. Không ai thấy vì nó chạy ở nền — chỉ hoá
     đơn 3G thấy. */
  const nangVaKhongDoi = /\.(enc|woff2|png|jpg|jpeg|webp|ico|svg)$/i.test(path);

  if (nangVaKhongDoi) {
    e.respondWith(
      caches.match(req).then(hit => hit || fetch(req).then(res => {
        if (res && res.ok && res.type !== 'opaque' &&
            !/no-store|private/i.test(res.headers.get('Cache-Control') || '')) {
          const copy = res.clone();
          e.waitUntil(caches.open(CACHE).then(c => c.put(req, copy)));
        }
        return res;
      }))
    );
    return;
  }

  /* ── TRANG VÀ MÃ: MẠNG TRƯỚC, KHO SAU (9.99.226) ──
     Trước đây chỗ này trả bản trong kho TRƯỚC rồi mới làm mới ngầm
     (return hit || net). Hệ quả đúng thứ chủ hệ gặp: đẩy bản mới lên
     Cloudflare xong, mở ra vẫn thấy bản CŨ — vì service worker phục vụ
     bản đã cache, bản mới chỉ vào kho cho LẦN SAU. Người dùng tưởng bản
     vá chưa lên.

     Nay khi CÓ mạng thì lấy bản MỚI NHẤT từ mạng, cập nhật kho, và chỉ
     rơi về kho khi mất mạng. index.html · gita-app.js · gita-nghe.js ·
     cau-hinh.js · style.css luôn là bản vừa đẩy. Tệp nặng bất biến (.enc,
     phông, ảnh) vẫn lấy trong kho ở nhánh trên — chúng chỉ đổi khi đổi số
     bản, mà đổi số bản là đổi tên CACHE và xoá sạch bản cũ ở 'activate'. */
  e.respondWith(
    fetch(req).then(res => {
      if (res && res.ok && res.type !== 'opaque' &&
          !/no-store|private/i.test(res.headers.get('Cache-Control') || '')) {
        const copy = res.clone();
        e.waitUntil(caches.open(CACHE).then(c => c.put(req, copy)));
      }
      return res;
    }).catch(async () => (await caches.match(req)) ||
      new Response('Không có mạng và tài nguyên này chưa được lưu.',
        {status: 503, headers: {'Content-Type':'text/plain; charset=utf-8'}}))
  );
});
