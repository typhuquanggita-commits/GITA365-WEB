# GITA 365 · Bộ video hướng dẫn chuẩn nhận diện thương hiệu GITA

Mô-đun nhúng vào web app GITA 365. Mỗi màn hình có một video hướng dẫn riêng cho từng vai (Phụ huynh, Học sinh, Tư vấn viên, Coach, CSKH, Học thuật, Quản trị). Video gồm: lời chào theo họ tên người đăng nhập, sơ đồ tư duy, mô phỏng thao tác, quy trình, hội thoại nhập vai nhiều giọng, KPI, xử lý sự cố, cập nhật mới và tổng kết. Tất cả mang logo và màu thương hiệu GITA.

- Không phụ thuộc thư viện ngoài. Chạy trong **Shadow DOM** nên CSS của web app và của video không ảnh hưởng lẫn nhau.
- Giọng đọc thu sẵn (file `.mp4` âm thanh AAC), đồng bộ từng câu. Nghe được trên Chrome, Edge, **Cốc Cốc**, Safari và điện thoại. Video chưa có giọng thu sẵn sẽ dùng giọng đọc của trình duyệt, hoặc chỉ hiện phụ đề.
- Có sẵn 13 video chuẩn có giọng. Các màn còn lại tự dựng video từ dữ liệu vai và màn hình.

## Cấu trúc

```
gita365-video-guide/
├─ dist/                        bản đóng gói sẵn
│  ├─ gita-video-guide.esm.js   dùng với import (React, Vite, Next.js)
│  └─ gita-video-guide.js       dùng với thẻ <script> (biến toàn cục GitaVideoGuide)
├─ src/
│  ├─ index.js                  API công khai: mountGitaGuide, attachHelpButton
│  ├─ core.js                   bộ máy dựng cảnh, bút viết, sơ đồ, phụ đề, giọng đọc, trình phát
│  ├─ brand.js                  logo GITA, màu, phông chữ
│  ├─ data/app-data.js          vai trò, màn hình, quyền, KPI mẫu, nhật ký cập nhật
│  ├─ data/videos.js            kịch bản các video chuẩn
│  ├─ data/voices.js            danh mục giọng thu sẵn (file + mốc từng câu)
│  └─ ui/                       giao diện (CSS, khung HTML)
├─ react/GitaVideoGuide.jsx     thành phần React: <GitaVideoGuide/>, <GitaHelpButton/>
├─ public/gita-voice/           file giọng đọc (khoảng 18 MB) — chép vào thư mục public của web app
├─ demo/index.html              trang thử tích hợp
└─ tools/voice/tao_giong.py     công cụ tạo giọng cho video mới (chạy offline)
```

## Cài vào web app GITA 365 (React / Vite / Next.js)

1. Chép thư mục `gita365-video-guide` vào dự án, ví dụ `packages/gita365-video-guide`, hoặc để cạnh mã nguồn.
2. Chép `public/gita-voice/` vào thư mục `public/` của web app. Trên Vercel, file sẽ nằm ở `https://<tên-miền>/gita-voice/...`.
3. Dùng trong React:

```jsx
import GitaVideoGuide, { GitaHelpButton } from "./gita365-video-guide/react/GitaVideoGuide.jsx";

// Trang "Video hướng dẫn" đầy đủ (thư viện theo vai)
export function HuongDanPage({ currentUser }) {
  return <GitaVideoGuide user={{ name: currentUser.fullName, role: mapRole(currentUser.role) }} />;
}

// Nút nổi "Video hướng dẫn" trên từng màn hình
export function BaiTapPage({ currentUser }) {
  return (<>
    {/* ...nội dung màn Bài tập... */}
    <GitaHelpButton user={{ name: currentUser.fullName, role: mapRole(currentUser.role) }} screen="baitap" />
  </>);
}
```

Với **Next.js**, thành phần chạy phía trình duyệt. Hãy đặt `"use client"` ở đầu file, hoặc nạp bằng `dynamic(() => import(...), { ssr: false })`.

Nếu không dùng React:

```html
<div id="gita-guide"></div>
<script src="/js/gita-video-guide.js"></script>
<script>
  const guide = GitaVideoGuide.mountGitaGuide(document.getElementById("gita-guide"), {
    user: { name: "Nguyễn Minh Anh", role: "ph" }, screen: "tongquan", audioBase: "/gita-voice/"
  });
  GitaVideoGuide.attachHelpButton({ user: { name: "Nguyễn Minh Anh", role: "ph" }, screen: "baitap" });
</script>
```

## Ghép vai tài khoản với khoá vai của video

| Vai trong GITA 365 | Khoá `role` |
|---|---|
| Phụ huynh | `ph` |
| Học sinh | `hs` |
| Tư vấn viên | `tv` |
| Coach đồng hành | `coach` |
| Chăm sóc khách hàng | `cskh` |
| Chuyên môn học thuật | `hocthuat` |
| Quản trị vận hành | `quantri` (xem được kho video của mọi vai) |

```js
const mapRole = r => ({ PARENT: "ph", STUDENT: "hs", CONSULTANT: "tv", COACH: "coach", CS: "cskh", ACADEMIC: "hocthuat", ADMIN: "quantri" }[r]);
```

Khoá màn hình hiện có: `giadinh`, `taikhoan`, `tongquan`, `hanhtrinh`, `baihoc`, `baitap`, `coachai`, `hoso`, `hotro`, `baocao`, `capnhat`. Sửa tên và quyền trong `src/data/app-data.js` cho khớp web app thật.

## Tuỳ chọn `mountGitaGuide(host, options)`

| Tuỳ chọn | Ý nghĩa |
|---|---|
| `user` | `{ name, role, isAdmin, avatar }` — lấy từ tài khoản đăng nhập. Có `user` thì người xem không tự đổi vai được. |
| `screen` | Mở sẵn video của màn hình này. |
| `autoplay` | Tự phát khi mở (`false` mặc định). |
| `layout` | `"full"`: thư viện đầy đủ. `"player"`: chỉ khung phát. |
| `mode` | `"frame"` khung chuẩn, `"mini"` thu nhỏ góc màn hình, `"full"` phóng to. |
| `audioBase` | Nơi đặt file giọng, mặc định `"/gita-voice/"` (có thể là CDN). |
| `voices` | Bổ sung hoặc ghi đè danh mục giọng mà không cần build lại. |
| `extraVideos` | Mảng video bổ sung (cùng định dạng `src/data/videos.js`). |
| `logo`, `theme` | Đường dẫn logo khác; giao diện `"light"` hoặc `"dark"`. |
| `onEvent(e)` | Nhận sự kiện `play`, `pause`, `chapter`, `completed`, `mode` — dùng để ghi KPI đã xem. |

Hàm trả về đối tượng điều khiển:
- `open(role, screen, {autoplay, mode})`, `setUser(user)`, `play()`, `pause()`, `setMode(m)`
- `videos(role)`: danh sách video của vai
- `voicePack(role, screen)`, `scriptText(role, screen)`: xuất gói tạo giọng hoặc kịch bản lời đọc
- `state`, `destroy()`

Ví dụ ghi nhận hoàn thành video vào hệ thống:

```js
onEvent: e => { if (e.type === "completed") fetch("/api/kpi/video-watched", { method: "POST", body: JSON.stringify(e) }); }
```

## Thêm / sửa video

Mỗi video trong `src/data/videos.js` có khoá `"<vai>:<màn hình>"`. Các loại cảnh:

| Loại | Trường chính | Hiển thị |
|---|---|---|
| `intro` | `narration` | Logo GITA, bút viết lời chào theo họ tên (`{NAME}`) |
| `write` | `title, lines[≤5]` | Bút viết từng dòng |
| `mindmap` | `center, badge, branches[{label,note}] ≤6` | Sơ đồ tư duy |
| `mock` | `ui[4], cur, steps[{slot 0–3, text}]` | Mô phỏng màn hình, con trỏ bấm |
| `flow` | `title, steps[{label, detail}] ≤6` | Sơ đồ quy trình |
| `example` | `intro, dialog[{who, emo, text}] ≤6, lesson, outroLine` | Hội thoại nhập vai nhiều giọng |
| `practice` | `intro, steps[{name, parent, child, note, pemo, kemo}], outroLine` | Ba mẹ thực hành cùng con |
| `kpi` | `items[{label, target, value}], tips` | Vòng đo KPI |
| `issue` | `problem, steps, sla` | Xử lý sự cố |
| `update`, `outro` | `items` | Cập nhật mới, tổng kết |

Quy ước giọng đọc trong lời thoại:
- Thẻ cảm xúc đặt ở đầu câu: `[ấm] [vui] [cao] [trầm] [nhấn] [đồng cảm] [nghiêm] [lo] [mệt] [hỏi]`.
- Từ cần nhấn đặt giữa hai dấu sao: `*quan trọng nhất*`.
- `who` nhận các vai: Người dẫn, Coach, Coach AI, Tư vấn, Trainer, Ba mẹ / Phụ huynh, Con / Em, CSKH, Cộng tác viên, Học thuật, Quản trị.

Chuẩn xưng hô: khi nói với ba mẹ gọi học sinh là "con", khi nói với học sinh xưng "em", không dùng "bé" hay "cháu".

Sau khi sửa, chạy `npm install && npm run build` để tạo lại `dist/`.

## Tạo giọng cho video mới

1. Mở trang thư viện (hoặc `demo/index.html`), chọn video, vào tab **Giọng thuyết minh** và bấm **Tải gói tạo giọng chuẩn (.json)**.
2. Cài công cụ: `pip install sherpa-onnx numpy soundfile` và cài ffmpeg (nên dùng bản có rubberband).
3. Chạy lệnh:
   ```
   python tools/voice/tao_giong.py giong-ph_baocao.json
   ```
   Lần đầu, công cụ tự tải mô hình giọng tiếng Việt (khoảng 60 MB). Sau đó chạy offline.
4. Công cụ tạo file `public/gita-voice/ph-baocao.mp4` và tự thêm vào `src/data/voices.js`. Chạy `npm run build`, rồi triển khai.

Nếu muốn giọng biên tập viên thật:
- Bấm **Tải kịch bản lời đọc (.txt)** để lấy kịch bản gửi phát thanh viên.
- Mỗi chương thu một file.
- Khai báo trong `voices.js` theo dạng `{ nu: { chapters: ["thu-muc/ch01-nu.mp4", ...] } }`.

## Triển khai và lưu ý kỹ thuật

- **Máy chủ file giọng** nên hỗ trợ tải theo đoạn (HTTP Range). Vercel và CDN phổ biến đều hỗ trợ. Nếu máy chủ không hỗ trợ, trình phát tự tải cả file rồi tua đúng chương (chậm hơn khoảng 2–3 giây ở lần tua đầu).
- **Content-Security-Policy:** cần cho phép `media-src 'self' blob:` (và tên miền CDN nếu đặt giọng ở CDN), cùng `fonts.googleapis.com` và `fonts.gstatic.com` cho phông Be Vietnam Pro.
- Trình duyệt chặn tự phát âm thanh trước khi người dùng bấm. Nút **Phát** hoặc nút nổi **Video hướng dẫn** đã đủ để mở khoá.
- **Phím tắt** chỉ hoạt động khi đang bấm vào khung video:
  - Space: phát / dừng
  - ← →: chuyển chương
  - F: phóng to
  - M: thu nhỏ
  - Esc: trở về khung chuẩn
- Tiến độ đã xem và phân vai giọng được lưu trong `localStorage`, tiền tố `gita365.guide.`. Nên đồng bộ về máy chủ qua `onEvent`.

## Nội dung cần xác nhận trước khi phát hành

Các chi tiết sau là bản đề xuất, cần Học viện đối chiếu với web app và chính sách thật:
- Tên nút và bố cục màn hình trong cảnh mô phỏng.
- Thời hạn phản hồi (5 phút, 15 phút, 24 giờ…).
- KPI mẫu.
- Quy tắc chuyển phiếu.
- Nhật ký cập nhật.

Sửa tại `src/data/app-data.js` và `src/data/videos.js`.
