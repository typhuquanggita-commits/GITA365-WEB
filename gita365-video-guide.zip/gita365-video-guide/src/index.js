/*! GITA 365 · Video Guide — Học viện GITA. */
export { mountGitaGuide, ROLE_KEYS, SCREEN_KEYS, ROLES, SCREENS, FEATURED, VOICE_MANIFEST, BRAND } from "./core.js";
import { mountGitaGuide } from "./core.js";
import { LOGO_DATA } from "./brand.js";

/**
 * Nút nổi "Video hướng dẫn" cho từng màn hình của web app.
 * Bấm vào sẽ mở video đúng vai + đúng màn hình trong một cửa sổ nổi.
 * @param {object} o  { user, screen, audioBase, label, position:"right"|"left", onEvent, mode }
 * @returns {{open():void, close():void, update(o):void, remove():void}}
 */
export function attachHelpButton(o = {}) {
  let opts = Object.assign({ label: "Video hướng dẫn", position: "right" }, o);
  const host = document.createElement("div");
  host.setAttribute("data-gita-help", "");
  const sr = host.attachShadow({ mode: "open" });
  sr.innerHTML = `<style>
    :host{all:initial}
    .btn{position:fixed;bottom:calc(20px + env(safe-area-inset-bottom,0px));${opts.position === "left" ? "left" : "right"}:20px;z-index:2147483000;
      display:flex;align-items:center;gap:10px;padding:8px 16px 8px 8px;border-radius:40px;border:0;cursor:pointer;
      background:#1E5CAB;color:#fff;font:600 14px "Be Vietnam Pro",system-ui,sans-serif;box-shadow:0 10px 26px -10px rgba(21,40,58,.6)}
    .btn:hover{background:#174C90}.btn:focus-visible{outline:3px solid #E3262E;outline-offset:2px}
    .btn i{width:34px;height:34px;border-radius:50%;background:#fff;display:grid;place-items:center}
    .btn i svg{width:16px;height:16px}
    .ov{position:fixed;inset:0;z-index:2147483001;background:rgba(10,20,34,.6);display:none;align-items:center;justify-content:center;padding:16px}
    .ov.on{display:flex}
    .box{width:min(1100px,100%);max-height:100%;overflow:auto;background:#0E1B24;border-radius:16px;position:relative}
    .hd{display:flex;align-items:center;gap:12px;padding:10px 12px;background:#fff}
    .hd img{height:32px}.hd b{font:700 15px "Be Vietnam Pro",system-ui,sans-serif;color:#15283A;flex:1}
    .x{border:0;background:#E3EBF6;border-radius:20px;padding:6px 14px;font:600 13px "Be Vietnam Pro",system-ui,sans-serif;cursor:pointer}
  </style>
  <button class="btn" part="button"><i><svg viewBox="0 0 24 24" fill="#E3262E"><path d="M7 5v14l12-7z"/></svg></i><span></span></button>
  <div class="ov" role="dialog" aria-modal="true"><div class="box"><div class="hd"><img alt="GITA"><b></b><button class="x">Đóng</button></div><div class="mount"></div></div></div>`;
  const btn = sr.querySelector(".btn"), ov = sr.querySelector(".ov"), mountEl = sr.querySelector(".mount");
  sr.querySelector(".hd img").src = opts.logo || LOGO_DATA;
  sr.querySelector(".btn span").textContent = opts.label;
  let ctl = null;
  function open() {
    sr.querySelector(".hd b").textContent = opts.label;
    ov.classList.add("on");
    if (!ctl) ctl = mountGitaGuide(mountEl, { ...opts, layout: "player", autoplay: true });
    else ctl.open(opts.user && opts.user.role, opts.screen, { autoplay: true });
  }
  function close() { ov.classList.remove("on"); if (ctl) ctl.pause(); }
  btn.onclick = open;
  sr.querySelector(".x").onclick = close;
  ov.addEventListener("click", e => { if (e.target === ov) close(); });
  document.addEventListener("keydown", onEsc);
  function onEsc(e) { if (e.key === "Escape" && ov.classList.contains("on")) close(); }
  document.body.appendChild(host);
  return {
    open, close,
    update(n) { opts = Object.assign(opts, n); sr.querySelector(".btn span").textContent = opts.label;
      if (ctl && n.user) ctl.setUser(n.user); if (ctl && ov.classList.contains("on") && (n.screen || n.user)) ctl.open(opts.user && opts.user.role, opts.screen, { autoplay: true }); },
    remove() { document.removeEventListener("keydown", onEsc); if (ctl) ctl.destroy(); host.remove(); }
  };
}
