/*! GITA 365 · Video Guide — Học viện GITA. */
import {SLOTS,SCREENS,PERM_ORDER,ROLES,TRAIN,STAFF,UPDATES,CHAP} from "./data/app-data.js";
import {FEATURED} from "./data/videos.js";
import {VOICES as VOICE_MANIFEST} from "./data/voices.js";
import {LOGO_DATA,BRAND} from "./brand.js";
import {CSS} from "./ui/styles.js";
import {TEMPLATE} from "./ui/template.js";

export const ROLE_KEYS=Object.keys(ROLES);
export const SCREEN_KEYS=Object.keys(SCREENS);
export {ROLES,SCREENS,FEATURED,VOICE_MANIFEST,BRAND};

let FONT_DONE=false;
function ensureFont(href){if(FONT_DONE||typeof document==="undefined")return;FONT_DONE=true;if(document.querySelector('link[data-gita-font]'))return;
 const l=document.createElement("link");l.rel="stylesheet";l.href=href;l.setAttribute("data-gita-font","");document.head.appendChild(l)}

/**
 * Gắn bộ video hướng dẫn GITA vào một phần tử.
 * @param {HTMLElement} host  phần tử chứa (ví dụ <div id="gita-guide">)
 * @param {object} opts
 *   user:{name, role, isAdmin, avatar}  role ∈ ph|hs|tv|coach|cskh|hocthuat|quantri
 *   screen: khoá màn hình mở sẵn (ví dụ "tongquan"); autoplay: true|false
 *   layout: "full" (thư viện đầy đủ) | "player" (chỉ khung phát)
 *   mode: "frame"|"mini"|"full"; audioBase: "/gita-voice/"; voices: {...} bổ sung danh mục giọng
 *   extraVideos: [...] video bổ sung; logo: url logo; theme: "light"|"dark"
 *   allowRoleSwitch: cho phép tự đổi vai (mặc định: chỉ khi không truyền user)
 *   storagePrefix: tiền tố localStorage (mặc định "gita365.guide.")
 *   onEvent(e): e.type ∈ chapter|completed|mode|play|pause
 */
export function mountGitaGuide(host,opts={}){
if(!host)throw new Error("mountGitaGuide: thiếu phần tử chứa");
ensureFont(opts.fontHref||BRAND.fontHref);
const SR=host.shadowRoot||host.attachShadow({mode:"open"});
SR.innerHTML="<style>"+CSS+"</style>"+TEMPLATE;
const BODY=SR.querySelector(".gvg-body");
const PFX=opts.storagePrefix||"gita365.guide.";
let DEAD=false;
if(opts.theme)host.setAttribute("data-theme",opts.theme);
BODY.classList.add("layout-"+(opts.layout==="player"?"player":"full"));
function keyOk(e){return BODY.classList.contains("mode-full")||e.composedPath().includes(host)}
function scrollTopHost(){try{host.scrollIntoView({behavior:"smooth",block:"start"})}catch(e){}}
/* ============ STATE ============ */
const LS={get(k,d){try{const v=localStorage.getItem(PFX+k);return v==null?d:JSON.parse(v)}catch(e){return d}},set(k,v){try{localStorage.setItem(PFX+k,JSON.stringify(v))}catch(e){}}};
const me={name:"",role:"",avatar:"",isOwner:false,canEdit:false};
let aiVideos=(opts.extraVideos||[]).slice();
const $=s=>SR.querySelector(s);
const el=(t,c,txt)=>{const e=document.createElement(t);if(c)e.className=c;if(txt!=null)e.textContent=txt;return e};
function emit(type,detail){try{opts.onEvent&&opts.onEvent(Object.assign({type},detail||{}))}catch(e){console.error(e)}}

/* ============ LOGO ============ */
const LOGO_SRC=opts.logo||LOGO_DATA;
const logoUrl="";
function logoSVG(){return '<img src="'+LOGO_SRC+'" alt="Logo Học viện GITA" style="width:100%;height:100%;object-fit:contain;display:block">'}
function paintLogos(){SR.querySelectorAll("[data-logo]").forEach(n=>{n.innerHTML=logoSVG()})}

/* ============ VIDEO BUILD ============ */
function sName(){return me.name||"bạn"}
function buildVideo(roleKey,screenKey){
 if(FEATURED[roleKey+":"+screenKey])return FEATURED[roleKey+":"+screenKey]();
 const R=ROLES[roleKey],S=SCREENS[screenKey],perm=R.screens[screenKey]||"Xem";
 const staff=STAFF.has(roleKey);
 const steps=(S.steps[roleKey]||(staff&&S.steps.staff)||S.steps.default);
 const upd=UPDATES.filter(u=>u.s==="*"||u.s===screenKey).slice(0,4);
 const you=R.you, You=you.charAt(0).toUpperCase()+you.slice(1);
 return {id:roleKey+":"+screenKey,role:roleKey,screen:screenKey,ai:false,
  title:S.name+" — hướng dẫn cho "+R.name,
  scenes:[
   {type:"intro",narration:"Chào mừng "+R.hon+" "+"{NAME}"+" đến với GITA 365. Video này hướng dẫn "+you+" dùng màn "+S.name+" thật bài bản."},
   {type:"write",title:"Nhiệm vụ của "+you+" trên màn này",lines:[S.purpose].concat(R.mission.slice(0,3)),
    narration:S.purpose+" Với vai "+R.name+", việc chính của "+you+" là: "+R.mission.slice(0,3).join("; ")+"."},
   {type:"mindmap",center:S.name,badge:perm,branches:S.fn.map(f=>({label:f[0],note:f[1]})),
    narration:"Màn "+S.name+" có "+S.fn.length+" chức năng: "+S.fn.map(f=>f[0]).join(", ")+". Quyền của "+you+" ở đây là: "+perm+"."},
   {type:"mock",ui:S.ui,screensList:Object.keys(R.screens).map(k=>SCREENS[k].name),cur:S.name,steps:steps.map(s=>({slot:s[0],text:s[1]})),
    narration:"Cùng thao tác từng bước: "+steps.map(s=>s[1]).join(". ")+"."},
   {type:"flow",title:"Quy trình làm việc chuẩn",steps:steps.map((s,i)=>({label:["Mở","Kiểm tra","Thực hiện","Hoàn tất","Theo dõi"][i]||("Bước "+(i+1)),detail:s[1]})),
    narration:"Nhớ quy trình theo thứ tự này, mỗi lần làm đều giống nhau để không sót việc."},
   {type:"example",title:R.ex.title,dialog:R.ex.d.map(d=>({who:d[0],text:d[1]})),lesson:R.ex.lesson,
    narration:"Ví dụ minh họa: "+R.ex.title+". "+R.ex.lesson},
   ...(TRAIN[roleKey]?[{type:"example",chapter:"Đào tạo nội bộ",prefix:"",title:TRAIN[roleKey].title,intro:"[nghiêm] Phần đào tạo nội bộ: Trainer, "+R.name.toLowerCase()+" và cộng tác viên cùng diễn lại tình huống.",dialog:TRAIN[roleKey].d.map(d=>({who:d[0],text:d[1],emo:d[2]})),lesson:TRAIN[roleKey].lesson,narration:"Đào tạo nội bộ: "+TRAIN[roleKey].title}]:[]),
   {type:"kpi",items:R.kpi.map(k=>({label:k[0],target:k[1],value:k[2]})),tips:R.tips,
    narration:"Đây là các chỉ số "+you+" cần đạt để hoàn thành xuất sắc: "+R.kpi.map(k=>k[0]+", mục tiêu "+k[1]).join("; ")+". "+R.tips[0]},
   {type:"issue",problem:R.issue.p,steps:R.issue.s,sla:R.issue.sla,
    narration:"Khi gặp tình huống "+R.issue.p.toLowerCase()+", "+you+" xử lý theo 4 bước: "+R.issue.s.join("; ")+". Thời hạn: "+R.issue.sla+"."},
   {type:"update",items:upd,narration:"Những cập nhật mới liên quan đến màn này. "+You+" nhớ vào mục Cập nhật mới và xác nhận đã đọc."},
   {type:"outro",items:[S.fn[0][0],"Thao tác đủ "+steps.length+" bước",R.kpi[0][0]+": "+R.kpi[0][1],"Biết cách xử lý khi có vấn đề"],
    narration:"Tổng kết: "+you+" đã nắm nhiệm vụ, quyền hạn, cách dùng công cụ, KPI và cách xử lý vấn đề trên màn "+S.name+". Chúc "+you+" hoàn thành xuất sắc!"}
  ]};
}
function estDur(v){let s=0;v.scenes.forEach(sc=>{const n=sc.type==="example"?(sc.dialog||[]).map(d=>d.text).join(" ")+(sc.lesson||""):sc.type==="practice"?(sc.steps||[]).map(x=>x.parent+x.child+x.note).join(" "):(sc.narration||"");s+=Math.max(9,n.length*0.08)});return Math.round(s/60*10)/10}

/* ============ ENGINE ============ */
const stage=$("#stage"),layer=$("#layer"),pen=$("#pen"),cap=$("#cap");
let scale=1;
new ResizeObserver(()=>{scale=$("#frame").clientWidth/1280;stage.style.transform="scale("+scale+")"}).observe($("#frame"));
const P={video:null,idx:0,t:0,dur:1,playing:false,voice:true,music:false,speed:1,speechDone:true,ctx:null,last:0,penT:null};

function newCtx(){return{ticks:[],cues:[],fired:new Set(),lines:{}}}
function at(ctx,ms,fn){ctx.cues.push({ms,fn})}
function tick(ctx,fn){ctx.ticks.push(fn)}
function stageXY(node,right){const r=node.getBoundingClientRect(),s=stage.getBoundingClientRect();return{x:((right?r.right:r.left)-s.left)/scale,y:(r.bottom-s.top)/scale}}
function writer(ctx,node,text,start,cps,usePen){
 node.textContent="";const sp=[];
 for(const c of Array.from(String(text||""))){const s=el("span","ch",c);node.appendChild(s);sp.push(s)}
 const end=start+sp.length*1000/cps;let shown=0;
 tick(ctx,t=>{
  const n=Math.max(0,Math.min(sp.length,Math.floor((t-start)*cps/1000)));
  if(n>shown){for(let i=shown;i<n;i++)sp[i].classList.add("on");shown=n}
  if(usePen!==false&&t>=start&&t<end+250&&sp.length){const tgt=sp[Math.min(n,sp.length-1)];P.penT=stageXY(tgt,n>=sp.length)}
 });
 return end;
}
function mk(parent,cls,txt){const e=el("div",cls,txt);parent.appendChild(e);return e}
function onAt(ctx,ms,node,cls){at(ctx,ms,()=>node.classList.add(cls||"on"))}

const R_={
 intro(sc,L,ctx,v){
  const lg=mk(L,"intro-logo");lg.innerHTML=logoUrl?"":logoSVG();
  if(logoUrl){const i=new Image();i.src=logoUrl;i.alt="Logo GITA";i.style.cssText="width:100%;height:100%;object-fit:contain";lg.appendChild(i)}
  lg.style.transition="transform .9s cubic-bezier(.3,1.5,.5,1),opacity .6s";lg.style.transform="translateX(-50%) scale(.3) rotate(-12deg)";lg.style.opacity="0";
  at(ctx,100,()=>{lg.style.transform="translateX(-50%) scale(1) rotate(0)";lg.style.opacity="1"});
  const R=ROLES[v.role]||ROLES.ph;
  const hi=mk(L,"intro-hi","Chào mừng "+R.hon);onAt(ctx,900,hi);
  const nm=mk(L,"intro-name");const e1=writer(ctx,nm,me.name||R.name,1300,11);
  const sub=mk(L,"intro-sub",v.title);onAt(ctx,e1+300,sub);
  at(ctx,e1+400,()=>confetti(L));
  return e1+3200;
 },
 write(sc,L,ctx){
  const h=mk(L,"s-title");let t=writer(ctx,h,sc.title,300,24);
  const box=mk(L,"lines");
  (sc.lines||[]).slice(0,5).forEach(line=>{const r=mk(box,"line");mk(r,"dot");const tx=mk(r,"tx");onAt(ctx,t+200,r);t=writer(ctx,tx,line,t+400,30)});
  return t+1800;
 },
 mindmap(sc,L,ctx){
  const cx=640,cy=400,br=(sc.branches||[]).slice(0,6),n=br.length;
  const svg=document.createElementNS("http://www.w3.org/2000/svg","svg");svg.setAttribute("viewBox","0 0 1280 720");svg.style.cssText="position:absolute;inset:0;width:1280px;height:720px";L.appendChild(svg);
  const c=mk(L,"node center");mk(c,"l",sc.center);if(sc.badge){const b=mk(c,"bd","Quyền của bạn: "+sc.badge);b.style.background="#ED1E24";b.style.color="#15283A"}
  c.style.left=cx+"px";c.style.top=cy+"px";onAt(ctx,200,c);
  br.forEach((b,i)=>{
   const a=(-90+ (360/n)*i + (n%2?0:180/n)) *Math.PI/180;
   const x=cx+Math.cos(a)*440, y=cy+Math.sin(a)*215;
   const p=document.createElementNS("http://www.w3.org/2000/svg","path");
   const mx=(cx+x)/2+Math.sin(a)*40,my=(cy+y)/2-Math.cos(a)*40;
   p.setAttribute("d","M"+cx+" "+cy+" Q"+mx+" "+my+" "+x+" "+y);p.setAttribute("fill","none");p.setAttribute("stroke",["#5B8FD6","#ED1E24","#3C7DA6","#D9262C","#2B5FAB","#35505F"][i%6]);p.setAttribute("stroke-width","5");p.setAttribute("stroke-linecap","round");
   svg.appendChild(p);const len=p.getTotalLength();p.style.strokeDasharray=len;p.style.strokeDashoffset=len;
   const st=900+i*1100;
   tick(ctx,t=>{const k=Math.max(0,Math.min(1,(t-st)/700));p.style.strokeDashoffset=len*(1-k)});
   const nd=mk(L,"node");mk(nd,"l",b.label);if(b.note)mk(nd,"nt",b.note);
   nd.style.left=x+"px";nd.style.top=y+"px";nd.style.borderColor=p.getAttribute("stroke");onAt(ctx,st+650,nd);
  });
  return 900+n*1100+2500;
 },
 mock(sc,L,ctx,v){
  const m=mk(L,"mock");const bar=mk(m,"bar");bar.innerHTML="";const lg=el("span","",'GITA 365');bar.appendChild(lg);const cur=el("span","", "· "+(sc.cur||""));cur.style.fontWeight="500";cur.style.opacity=".8";bar.appendChild(cur);
  const side=mk(m,"side");(sc.screensList||[]).slice(0,9).forEach(n=>{const d=mk(side,n===sc.cur?"cur":"",n)});
  const ui=sc.ui||(SCREENS[v.screen]&&SCREENS[v.screen].ui)||["Nút chính","Danh sách","Khu làm việc","Bảng phụ"];
  const slots=SLOTS.map((r,i)=>{const s=mk(L,"slot",ui[i]||"");Object.assign(s.style,{left:r.x+"px",top:r.y+"px",width:r.w+"px",height:r.h+"px"});return s});
  const list=mk(L,"steps");const steps=(sc.steps||[]).slice(0,5);
  const rows=steps.map((s,i)=>{const r=mk(list,"st");const ic=el("i","",String(i+1));r.appendChild(ic);r.appendChild(el("span","",s.text));return r});
  const cur2=document.createElementNS("http://www.w3.org/2000/svg","svg");cur2.setAttribute("viewBox","0 0 24 24");cur2.setAttribute("class","cursor");cur2.innerHTML='<path d="M4 2l16 9-7 2-3 7z" fill="#15283A" stroke="#fff" stroke-width="1.5"/>';L.appendChild(cur2);
  const tip=mk(L,"tip");
  let px=1000,py=640;const T=3800,S0=700;
  const pts=steps.map(s=>{const r=SLOTS[Math.max(0,Math.min(3,+s.slot||0))];return{x:r.x+r.w*0.55,y:r.y+Math.min(r.h*0.5,60)}});
  tick(ctx,t=>{
   const i=Math.floor((t-S0)/T);let x=px,y=py;
   if(t<S0){x=px;y=py}else if(i<steps.length){const from=i===0?{x:px,y:py}:pts[i-1],to=pts[i];const k=Math.min(1,((t-S0)-i*T)/900),e=k<.5?2*k*k:1-Math.pow(-2*k+2,2)/2;x=from.x+(to.x-from.x)*e;y=from.y+(to.y-from.y)*e}else{const l=pts[pts.length-1]||{x:px,y:py};x=l.x;y=l.y}
   cur2.style.transform="translate("+x+"px,"+y+"px)";
  });
  steps.forEach((s,i)=>{
   const st=S0+i*T;const slot=slots[Math.max(0,Math.min(3,+s.slot||0))];
   at(ctx,st,()=>{rows[i].classList.add("on")});
   at(ctx,st+950,()=>{slots.forEach(z=>z.classList.remove("hi"));slot.classList.add("hi");const rp=mk(L,"ripple");rp.style.left=pts[i].x+"px";rp.style.top=pts[i].y+"px";setTimeout(()=>rp.remove(),800);
    tip.textContent=s.text;const r=SLOTS[+s.slot||0];let tx=r.x,ty=r.y+r.h+12;if(ty>560)ty=r.y-80;if(tx>560)tx=560;tip.style.left=tx+"px";tip.style.top=ty+"px";tip.classList.add("on")});
   at(ctx,st+T-200,()=>{rows[i].classList.add("done");rows[i].querySelector("i").textContent="✓"});
  });
  return S0+steps.length*T+1200;
 },
 flow(sc,L,ctx){
  const h=mk(L,"s-title");h.style.fontSize="40px";const t0=writer(ctx,h,sc.title||"Quy trình",200,26);
  const st=(sc.steps||[]).slice(0,6),n=st.length,gap=36,W=(1280-160-gap*(n-1))/n;
  const svg=document.createElementNS("http://www.w3.org/2000/svg","svg");svg.setAttribute("viewBox","0 0 1280 720");svg.style.cssText="position:absolute;inset:0;width:1280px;height:720px";L.appendChild(svg);
  const boxes=st.map((s,i)=>{const b=mk(L,"fbox");b.style.left=(80+i*(W+gap))+"px";b.style.width=W+"px";mk(b,"num",String(i+1));mk(b,"l",s.label);return b});
  const dets=st.map(s=>mk(L,"fdet"));
  let t=t0+300;const per=[];
  st.forEach((s,i)=>{
   const x1=80+i*(W+gap)+W,x2=x1+gap;
   if(i<n-1){const ln=document.createElementNS("http://www.w3.org/2000/svg","path");ln.setAttribute("d","M"+(x1+4)+" 305 L"+(x2-6)+" 305");ln.setAttribute("stroke","#2B5FAB");ln.setAttribute("stroke-width","4");ln.setAttribute("marker-end","url(#ah)");ln.style.opacity="0";svg.appendChild(ln);per.push(ln)}
   const s0=t;
   at(ctx,s0,()=>{boxes.forEach(b=>b.classList.remove("act"));boxes[i].classList.add("on","act");dets.forEach(d=>d.classList.remove("on"));dets[i].classList.add("on");if(i>0&&per[i-1])per[i-1].style.opacity="1"});
   t=writer(ctx,dets[i],s.detail||"",s0+300,30)+1400;
  });
  svg.innerHTML='<defs><marker id="ah" markerWidth="8" markerHeight="8" refX="6" refY="4" orient="auto"><path d="M0 0L8 4L0 8z" fill="#2B5FAB"/></marker></defs>'+svg.innerHTML;
  // re-bind connectors after innerHTML reset
  const paths=svg.querySelectorAll("path[stroke]");per.length=0;paths.forEach(p=>per.push(p));
  return t+600;
 },
 example(sc,L,ctx){
  const h=mk(L,"s-title");h.style.fontSize="40px";const t0=writer(ctx,h,(sc.prefix!=null?sc.prefix:"Ví dụ: ")+(sc.title||""),200,26);
  const dl=(sc.dialog||[]).slice(0,6);const first=(dl[0]||{}).who;const all=[];
  dl.forEach((d,i)=>{
   const b=mk(L,"bub "+(d.who===first?"l":"r"));b.style.top=(180+(i%3)*128)+"px";b.style.maxWidth="780px";
   const c=castOf(d.who);if(d.who!==first&&CASTCOL[c])b.style.background=CASTCOL[c];
   b.appendChild(el("span","w",d.who||""));const tx=el("span","");b.appendChild(tx);all.push(b);
   ctx.lines["d"+i]=()=>{if(i%3===0&&i>0)all.slice(i-3,i).forEach(p=>p.style.display="none");b.classList.add("on");writer(ctx,tx,d.text||"",P.t+80,34,false)};
  });
  const ls=mk(L,"lesson");ctx.lines["L"]=()=>writer(ctx,ls,"→ "+(sc.lesson||""),P.t+80,22);
  return t0+800;
 },
 practice(sc,L,ctx){
  const h=mk(L,"s-title");h.style.fontSize="40px";h.style.top="80px";const t0=writer(ctx,h,sc.title||"Thực hành cùng con",200,26);
  const PAR='<svg viewBox="0 0 200 300"><path d="M40 300 C40 200 70 170 100 170 C130 170 160 200 160 300Z" fill="#2B5FAB"/><circle cx="100" cy="100" r="54" fill="#F3D3B8"/><path d="M46 96 C46 50 80 36 104 38 C136 40 156 62 154 98 C140 74 110 66 84 70 C66 74 54 84 46 96Z" fill="#3B2A22"/><circle cx="80" cy="104" r="5" fill="#15283A"/><circle cx="120" cy="104" r="5" fill="#15283A"/><path d="M82 126 Q100 140 118 126" stroke="#15283A" stroke-width="4" fill="none" stroke-linecap="round"/></svg>';
  const KID='<svg viewBox="0 0 200 300"><path d="M58 300 C58 228 80 206 100 206 C120 206 142 228 142 300Z" fill="#ED1E24"/><circle cx="100" cy="148" r="46" fill="#F3D3B8"/><path d="M54 146 C52 108 78 94 100 94 C126 94 150 110 146 146 C136 124 118 118 100 118 C80 118 64 126 54 146Z" fill="#2A1E18"/><circle cx="84" cy="150" r="4.5" fill="#15283A"/><circle cx="116" cy="150" r="4.5" fill="#15283A"/><path d="M86 168 Q100 180 114 168" stroke="#15283A" stroke-width="4" fill="none" stroke-linecap="round"/><circle cx="72" cy="166" r="7" fill="#F2A7A0" opacity=".6"/><circle cx="128" cy="166" r="7" fill="#F2A7A0" opacity=".6"/></svg>';
  const ap=mk(L,"av");ap.style.left="60px";ap.innerHTML=PAR;ap.appendChild(el("div","","Ba mẹ"));
  const ak=mk(L,"av");ak.style.right="60px";ak.innerHTML=KID;ak.appendChild(el("div","","Con"));
  const tabs=mk(L,"ptabs");const steps=(sc.steps||[]).slice(0,4);
  const tb=steps.map((s,i)=>mk(tabs,"ptab","Bước "+(i+1)+" · "+s.name));
  let prev=[];
  steps.forEach((s,i)=>{
   const bp=mk(L,"bub l");bp.style.left="290px";bp.style.top="235px";bp.style.maxWidth="700px";bp.appendChild(el("span","w","Ba mẹ"));const tp=el("span","");bp.appendChild(tp);
   const bk=mk(L,"bub r");bk.style.right="290px";bk.style.top="385px";bk.style.maxWidth="560px";bk.style.background="#ED1E24";bk.appendChild(el("span","w","Con"));const tk=el("span","");bk.appendChild(tk);
   const nt=mk(L,"pnote");const mine=[bp,bk,nt];
   ctx.lines["s"+i]=()=>{prev.forEach(e=>e.style.display="none");prev=mine;ak.classList.remove("talk");ap.classList.remove("talk");tb.forEach((x,k)=>{x.classList.toggle("act",k===i);if(k<i)x.classList.add("done")})};
   ctx.lines["p"+i]=()=>{bp.classList.add("on");ap.classList.add("talk");ak.classList.remove("talk");writer(ctx,tp,s.parent||"",P.t+80,30,false)};
   ctx.lines["k"+i]=()=>{bk.classList.add("on");ak.classList.add("talk");ap.classList.remove("talk");writer(ctx,tk,s.child||"",P.t+80,30,false)};
   ctx.lines["n"+i]=()=>{ak.classList.remove("talk");writer(ctx,nt,"✎ "+(s.note||""),P.t+80,24)};
  });
  ctx.lines["end"]=()=>{ap.classList.remove("talk");ak.classList.remove("talk");tb.forEach(x=>{x.classList.remove("act");x.classList.add("done")})};
  return t0+800;
 },
 kpi(sc,L,ctx){
  const h=mk(L,"s-title");h.style.fontSize="40px";const t0=writer(ctx,h,"KPI để hoàn thành xuất sắc",200,26);
  mk(L,"knote","Vòng tròn là mức xuất sắc cần hướng tới. Chỉ tiêu cụ thể theo KPI được giao cho bạn.");
  const g=mk(L,"kpis");const items=(sc.items||[]).slice(0,4);g.style.gridTemplateColumns="repeat("+Math.max(1,items.length)+",1fr)";
  items.forEach((k,i)=>{
   const c=mk(g,"kc");const C=2*Math.PI*52;
   c.innerHTML='<svg viewBox="0 0 130 130"><circle cx="65" cy="65" r="52" fill="none" stroke="#E4ECF8" stroke-width="12"/><circle cx="65" cy="65" r="52" fill="none" stroke="'+(["#2B5FAB","#ED1E24","#3C7DA6","#5B8FD6"][i%4])+'" stroke-width="12" stroke-linecap="round" transform="rotate(-90 65 65)" stroke-dasharray="'+C+'" stroke-dashoffset="'+C+'"/></svg>';
   const ring=c.querySelectorAll("circle")[1];const v=mk(c,"v","0%");mk(c,"l",k.label);mk(c,"t","Mục tiêu: "+k.target);
   const st=t0+300+i*500;onAt(ctx,st,c);const val=Math.max(0,Math.min(100,+k.value||0));
   tick(ctx,t=>{const q=Math.max(0,Math.min(1,(t-st-200)/1400));const e=1-Math.pow(1-q,3);ring.setAttribute("stroke-dashoffset",C*(1-val/100*e));v.textContent=Math.round(val*e)+"%"});
  });
  const tp=mk(L,"ktips");const t1=writer(ctx,tp,(sc.tips||[]).slice(0,2).map(x=>"✎ "+x).join("\n"),t0+300+items.length*500+1600,24);
  return t1+2200;
 },
 issue(sc,L,ctx){
  const h=mk(L,"s-title");h.style.fontSize="36px";h.style.top="60px";h.style.left="70px";const t0=writer(ctx,h,"Xử lý vấn đề",200,24);
  const p=mk(L,"prob");mk(p,"k","Tình huống");mk(p,"p",sc.problem||"");if(sc.sla)mk(p,"sla","⏱ "+sc.sla);onAt(ctx,t0,p);
  const f=mk(L,"fix");let t=t0+1400;
  (sc.steps||[]).slice(0,5).forEach((s,i)=>{const r=mk(f,"fx");const ic=el("i","",String(i+1));r.appendChild(ic);const tx=el("span","");r.appendChild(tx);onAt(ctx,t,r);const e=writer(ctx,tx,s,t+200,32);at(ctx,e+500,()=>{r.classList.add("done");ic.textContent="✓"});t=e+900});
  return t+1600;
 },
 update(sc,L,ctx){
  const h=mk(L,"s-title");h.style.fontSize="40px";const t0=writer(ctx,h,"Cập nhật mới",200,24);
  const u=mk(L,"ups");(sc.items||[]).forEach((x,i)=>{const r=mk(u,"up");r.appendChild(el("b","","v"+x.v));r.appendChild(el("span","",x.t));const sm=el("small","",x.d);sm.style.marginLeft="auto";r.appendChild(sm);onAt(ctx,t0+300+i*900,r)});
  mk(L,"unote","Nhật ký mẫu — Quản trị thay bằng nhật ký cập nhật thật của web app.");
  return t0+300+(sc.items||[]).length*900+3000;
 },
 outro(sc,L,ctx){
  const d=mk(L,"done-big");const t0=writer(ctx,d,"Hoàn thành — sẵn sàng làm xuất sắc!",200,22,true);
  const c=mk(L,"chk");let t=t0+300;
  (sc.items||[]).slice(0,5).forEach(x=>{const r=mk(c,"ck");const ic=el("i","","");r.appendChild(ic);r.appendChild(el("span","",x));onAt(ctx,t,r);at(ctx,t+500,()=>{r.classList.add("done");ic.textContent="✓"});t+=900});
  at(ctx,t,()=>confetti(L));
  return t+3000;
 }
};
function confetti(L){if(matchMedia("(prefers-reduced-motion: reduce)").matches)return;const cs=["#ED1E24","#5B8FD6","#2B5FAB","#3C7DA6","#D9262C"];for(let i=0;i<40;i++){const s=el("div","spark");s.style.left=(200+Math.random()*880)+"px";s.style.top=(80+Math.random()*120)+"px";s.style.background=cs[i%5];s.style.animationDelay=(Math.random()*.5)+"s";L.appendChild(s);setTimeout(()=>s.remove(),2400)}}

/* ---- audio ---- */
let AC=null,musicTimer=null,master=null;
function ac(){if(!AC){try{AC=new (window.AudioContext||window.webkitAudioContext)();master=AC.createGain();master.gain.value=.5;master.connect(AC.destination)}catch(e){}}return AC}
function note(f,t0,dur,type,vol){const a=ac();if(!a)return;const o=a.createOscillator(),g=a.createGain();o.type=type||"sine";o.frequency.value=f;g.gain.setValueAtTime(0,t0);g.gain.linearRampToValueAtTime(vol,t0+.04);g.gain.exponentialRampToValueAtTime(.0001,t0+dur);o.connect(g);g.connect(master);o.start(t0);o.stop(t0+dur+.05)}
function chime(){const a=ac();if(!a||a.state!=="running")return;const t=a.currentTime;note(1046.5,t,.6,"sine",.05);note(1568,t+.08,.7,"sine",.035)}
const PENTA=[261.6,293.7,329.6,392,440,523.3,587.3,659.3];const CHORDS=[[130.8,196,261.6],[110,164.8,220],[146.8,220,293.7],[98,146.8,196]];
let mStep=0;
function musicLoop(){const a=ac();if(!a)return;const t=a.currentTime;
 if(mStep%8===0){CHORDS[(mStep/8|0)%4].forEach(f=>note(f,t,3.4,"sine",.018))}
 if(Math.random()<.7)note(PENTA[(Math.random()*PENTA.length)|0],t,.9,"triangle",.022);mStep++}
function setMusic(on){P.music=on;$("#bMusic").setAttribute("aria-pressed",on);clearInterval(musicTimer);if(on&&P.playing){const a=ac();a&&a.resume();musicTimer=setInterval(musicLoop,440)}}

/* ---- voice cast & emotion engine ---- */
let VOICES=[];const VP={gender:LS.get("gita.gender","nu")};
const EMO={binh:{p:1,r:1,v:1,l:"bình thường"},am:{p:.96,r:.92,v:.95,l:"ấm áp"},vui:{p:1.14,r:1.06,v:1,l:"vui tươi"},cao:{p:1.24,r:1.1,v:1,l:"hào hứng, tông cao"},
 tram:{p:.82,r:.86,v:.95,l:"trầm, sâu lắng"},nhan:{p:1.04,r:.9,v:1,l:"nhấn mạnh",pre:260},dongcam:{p:.92,r:.86,v:.85,l:"đồng cảm, nhẹ nhàng"},
 nghiem:{p:.9,r:.92,v:1,l:"nghiêm túc"},lo:{p:1.1,r:1.1,v:.95,l:"lo lắng"},met:{p:.88,r:.8,v:.8,l:"mệt, chán"},hoi:{p:1.08,r:1,v:1,l:"băn khoăn, hỏi"}};
const TAGS={"vui":"vui","ấm":"am","am":"am","trầm":"tram","tram":"tram","cao":"cao","nhấn":"nhan","nhan":"nhan","đồng cảm":"dongcam","nghiêm":"nghiem","lo":"lo","mệt":"met","hỏi":"hoi","bình":"binh"};
const CAST_DEF={
 dan:{name:"Người dẫn",g:"nu",p:1,r:.94,emo:"am",sample:"Kính chào Quý phụ huynh. Chào mừng ba mẹ đến với Học viện GITA."},
 trainer:{name:"Trainer",g:"nam",p:.9,r:.93,emo:"nghiem",sample:"Hôm nay chúng ta cùng luyện kỹ năng tư vấn theo đúng quy trình GITA."},
 coach:{name:"Coach",g:"nu",p:1.05,r:.95,emo:"am",sample:"Ba mẹ cứ kiên nhẫn chờ vài giây nhé, con đang suy nghĩ đấy."},
 coachai:{name:"Coach AI",g:"nu",p:1.1,r:1.02,emo:"binh",sample:"Em đọc lại đề và gạch chân dữ kiện chính nhé."},
 tuvan:{name:"Tư vấn viên",g:"nu",p:1.12,r:1,emo:"vui",sample:"Dạ, anh chị cho em hỏi mong muốn lớn nhất của gia đình mình ạ."},
 ctv:{name:"Cộng tác viên",g:"nam",p:1.08,r:1.02,emo:"vui",sample:"Em chào anh chị, em là cộng tác viên của Học viện GITA."},
 cskh:{name:"Chăm sóc khách hàng",g:"nu",p:1.08,r:.98,emo:"am",sample:"Dạ em xin lỗi anh chị, em kiểm tra ngay cho nhà mình ạ."},
 hocthuat:{name:"Học thuật",g:"nam",p:.95,r:.95,emo:"nghiem",sample:"Câu này đang ghép hai ý, mình tách ra cho dễ hiểu nhé."},
 quantri:{name:"Quản trị",g:"nam",p:.92,r:.95,emo:"nghiem",sample:"Từ thứ Hai, cả đội áp dụng quy trình mới."},
 phuhuynh:{name:"Phụ huynh",g:"nam",p:1,r:.95,emo:"binh",sample:"Tôi hay hỏi con học xong chưa, con toàn trả lời qua loa."},
 con:{name:"Học sinh",g:"nu",p:1.42,r:1.06,emo:"vui",sample:"Con chọn ôn Toán ạ!"}
};
const CASTCOL={coach:"#2B5FAB",coachai:"#4277BB",tuvan:"#2B5FAB",trainer:"#1F3A68",ctv:"#4277BB",cskh:"#2B5FAB",hocthuat:"#1F3A68",quantri:"#15283A",phuhuynh:"#4277BB",con:"#ED1E24"};
let CASTO=LS.get("gita.cast",{});
function cast(id){const d=CAST_DEF[id]||CAST_DEF.dan,o=CASTO[id]||{};return{name:d.name,g:id==="dan"?(VP.gender==="nam"?"nam":"nu"):(o.g||d.g),p:+o.p||d.p,r:+o.r||d.r,emo:d.emo,voice:o.voice||"",sample:d.sample}}
function castOf(who){const w=String(who||"").toLowerCase().trim();
 if(/coach ai/.test(w))return"coachai";if(/coach/.test(w))return"coach";if(/tư vấn/.test(w))return"tuvan";if(/trainer|giảng viên/.test(w))return"trainer";
 if(/cộng tác|ctv/.test(w))return"ctv";if(/cskh|chăm sóc/.test(w))return"cskh";if(/học thuật/.test(w))return"hocthuat";if(/quản trị/.test(w))return"quantri";
 if(/ba mẹ|phụ huynh|^bố|^mẹ|^ba$/.test(w))return"phuhuynh";if(/^(con|em)$|học sinh/.test(w))return"con";return"dan"}
function vGender(v){const n=v.name.replace(/Vietnam(ese)?/ig,"");if(/NamMinh|Nam Minh|\bAn\b|\bmale\b/i.test(n))return "nam";if(/HoaiMy|Hoài My|Linh|Google|female/i.test(n))return "nu";return "?"}
function vNatural(v){return /natural|online|neural|wavenet|premium|enhanced/i.test(v.name)}
function vScore(v){return (vNatural(v)?10:0)+(/HoaiMy|NamMinh/i.test(v.name)?5:0)+(/Google/i.test(v.name)?3:0)}
function loadVoices(){if(!("speechSynthesis" in window))return;VOICES=speechSynthesis.getVoices().filter(v=>/^vi/i.test(v.lang)).sort((a,b)=>vScore(b)-vScore(a));renderVoiceUI();voiceStatus()}
if("speechSynthesis" in window){setTimeout(loadVoices,0);speechSynthesis.onvoiceschanged=loadVoices;setTimeout(loadVoices,600);setTimeout(loadVoices,2000)}
function voiceFor(id){const c=cast(id);if(!VOICES.length)return null;
 if(c.voice){const v=VOICES.find(x=>x.name===c.voice);if(v)return{v,adj:1}}
 const same=VOICES.find(v=>vGender(v)===c.g);if(same)return{v:same,adj:1};
 const any=VOICES[0];const ag=vGender(any);return{v:any,adj:c.g==="nam"&&ag!=="nam"?.74:c.g==="nu"&&ag==="nam"?1.25:1}}
function autoEmo(t,def){t=t.trim();if(/^(kính chào|chào mừng)/i.test(t))return"am";if(/quan trọng nhất|mấu chốt|lưu ý|bắt buộc/i.test(t))return"nhan";
 if(/chúc|tuyệt vời|chúc mừng|xuất sắc|đúng rồi/i.test(t))return"vui";if(/đừng lo|mệt|chưa hợp tác|khó khăn|xin lỗi|hiểu/i.test(t))return"dongcam";if(/\?\s*$/.test(t))return"hoi";if(/!\s*$/.test(t))return"vui";return def}
function mkLine(who,text,emo,cue){
 let t=String(text||"").replace(/\{NAME\}/g,me.name||"").replace(/\s+/g," ").trim();let e=emo&&EMO[emo]?emo:"";
 const m=t.match(/^\[([^\]]{2,12})\]\s*/);if(m){const k=TAGS[m[1].toLowerCase()];if(k&&!e)e=k;t=t.slice(m[0].length)}
 const id=castOf(who);if(!e)e=autoEmo(t.replace(/\*/g,""),cast(id).emo);
 const raw=[];t.split(/(\*[^*]+\*)/).forEach(x=>{if(!x)return;if(/^\*.*\*$/.test(x))raw.push({t:x.slice(1,-1),emph:true});else raw.push({t:x,emph:false})});
 if(raw.filter(g=>g.emph).length>1)raw.forEach(g=>g.emph=false);
 const segs=[];raw.forEach(g=>{const last=segs[segs.length-1];if(!/[\p{L}\d]/u.test(g.t)){if(last)last.t+=g.t.trim()?g.t:"";return}if(last&&!last.emph&&!g.emph){last.t+=g.t;return}segs.push(g)});
 return{who:who||"Người dẫn",cast:id,emo:e,clean:t.replace(/\*/g,""),segs:segs.length?segs:[{t:t,emph:false}],cue:cue||""}}
function buildTrack(sc){
 if(Array.isArray(sc.track))return sc.track.map(l=>mkLine(l.who,l.text,l.emo,l.cue));
 const L=[];
 if(sc.type==="example"){
  L.push(mkLine("Người dẫn",sc.intro||("Ví dụ minh họa: "+(sc.title||"")+"."),sc.introEmo||"",""));
  (sc.dialog||[]).slice(0,6).forEach((d,i)=>L.push(mkLine(d.who,d.text,d.emo,"d"+i)));
  L.push(mkLine("Người dẫn",sc.outroLine||sc.lesson||"",sc.outroEmo||"nhan","L"));return L.filter(l=>l.clean||l.cue)}
 if(sc.type==="practice"){
  if(sc.intro)L.push(mkLine("Người dẫn",sc.intro,"",""));
  (sc.steps||[]).slice(0,4).forEach((s,i)=>{L.push(mkLine("Người dẫn","Bước "+["một","hai","ba","bốn"][i]+", "+String(s.name||"").toLowerCase()+".","nhan","s"+i));
   L.push(mkLine("Ba mẹ",s.parent,s.pemo||"am","p"+i));L.push(mkLine("Con",s.child,s.kemo||"vui","k"+i));L.push(mkLine("Người dẫn",s.note,"am","n"+i))});
  L.push(mkLine("Người dẫn",sc.outroLine||"",sc.outroEmo||"",'end'));return L.filter(l=>l.clean||l.cue)}
 chunk(String(sc.narration||"")).forEach(c=>{if(c.trim())L.push(mkLine("Người dẫn",c,"",""))});return L}
function lineEst(l){return Math.max(1400,l.clean.length*66)}
function clamp(x,a,b){return Math.max(a,Math.min(b,x))}
let REC={};const audio=new Audio();audio.preload="auto";
const AUDIO_BASE=String(opts.audioBase||"/gita-voice/").replace(/\/?$/,"/");
const VMAN=Object.assign({},VOICE_MANIFEST,opts.voices||{});
function manFor(){const m=P.video&&VMAN[P.video.id];if(!m)return null;return m[VP.gender]||m.nu||m.nam||null}
function recInfo(i){if(VP.gender==="off")return null;const m=manFor();if(!m)return null;
 if(m.full&&m.ch&&m.ch[i])return{src:AUDIO_BASE+m.full,off:m.ch[i][0],dur:m.ch[i][1],starts:m.ch[i][2]};
 if(m.chapters&&m.chapters[i])return{src:AUDIO_BASE+m.chapters[i],off:null,dur:null,starts:null};return null}
function recFor(i){const r=recInfo(i);return r?r.src:""}

const T={lines:[],i:-1,st:"idle",el:0,need:0,gap:0,tok:0,fired:new Set(),done:true,scale:1};
const KEEP=[];let AUDIO_OK=null,UNLOCKED=false;
function ttsReady(){return VP.gender!=="off"&&"speechSynthesis" in window&&VOICES.length>0&&AUDIO_OK!==false}
function trackStart(lines){T.tok++;try{if("speechSynthesis" in window)speechSynthesis.cancel()}catch(e){}T.lines=lines;T.i=-1;T.fired=new Set();T.done=!lines.length;T.st="gap";T.gap=400;T.scale=1}
function showLineCap(l){cap.textContent="";if(!l||!l.clean)return;if(l.cast!=="dan"){const b=el("b","",l.who+": ");b.style.color="#FFB4B6";cap.appendChild(b)}cap.appendChild(document.createTextNode(l.clean))}
function beginLine(i){T.i=i;const l=T.lines[i];T.el=0;
 if(!T.fired.has(i)){T.fired.add(i);const fn=l.cue&&P.ctx&&P.ctx.lines[l.cue];if(fn)try{fn()}catch(e){console.error(e)}}
 showLineCap(l);duck(true);
 if(!l.clean){T.st="gap";T.gap=200;return}
 if(P.recSrc){T.st="timer";T.need=lineEst(l)*T.scale;return}
 if(ttsReady()){T.st="speaking";T.need=lineEst(l)*2.4+6000;speakLine(l,T.tok)}else{T.st="timer";T.need=lineEst(l)}}
function speakLine(l,tok){
 const vc=voiceFor(l.cast);if(!vc){T.st="timer";T.need=lineEst(l);return}
 const c=cast(l.cast),e=EMO[l.emo]||EMO.binh;let k=0;
 const next=()=>{if(tok!==T.tok)return;if(k>=l.segs.length){T.st="gap";T.gap=l.cast==="dan"?480:380;return}
  const sg=l.segs[k++];const u=new SpeechSynthesisUtterance(sg.t);u.voice=vc.v;u.lang=vc.v.lang||"vi-VN";
  let p=c.p*e.p*vc.adj,r=c.r*e.r*P.speed;if(sg.emph){p*=1.05;r*=.94}
  u.pitch=clamp(p,.1,1.65);u.rate=clamp(r,.5,2);u.volume=clamp(e.v,0,1);
  u.onstart=()=>{AUDIO_OK=true};
  let ended=false;u.onend=()=>{if(ended||tok!==T.tok)return;ended=true;const pause=(sg.emph||(l.segs[k]&&l.segs[k].emph))?170:0;pause?setTimeout(next,pause):next()};
  u.onerror=ev=>{if(ev&&(ev.error==="interrupted"||ev.error==="canceled"))return;u.onend()};
  KEEP.push(u);if(KEEP.length>30)KEEP.shift();speechSynthesis.speak(u)};
 if(e.pre)setTimeout(next,e.pre);else next();
}
let BLOBTRY=false;
function seekCheck(){const rel=recRel();if(rel>-1500&&rel<P.recSeg.dur+1500){P.seekBad=0;return}
 P.seekBad=(P.seekBad||0)+1;if(P.seekBad<2)return;
 if(!P.reseeked){P.reseeked=true;P.seekBad=0;try{audio.currentTime=P.recSeg.off/1000}catch(e){}return}
 if(BLOBTRY)return;BLOBTRY=true;const src=P.recSrc;
 fetch(src).then(r=>{if(!r.ok)throw 0;return r.blob()}).then(bl=>{const u=URL.createObjectURL(bl);audio.src=u;audio.setAttribute("data-src",src);if(P.recSeg)P.recSeekTo=P.recSeg.off;if(P.playing)audio.play().catch(()=>{})}).catch(()=>{})}
function recRel(){return audio.currentTime*1000-P.recSeg.off}
function trackTick(dt){if(T.done)return;
 if(P.recSeg&&P.recSeg.map&&P.recSrc){if(P.recSeekTo!=null)return;const rel=recRel(),M=P.recSeg.map;let k=T.i;while(k+1<M.length&&M[k+1]<=rel)k++;for(let j=T.i+1;j<=k;j++)beginLine(j);
  if(P.recEnded||rel>=P.recSeg.dur-40){for(let j=T.i+1;j<T.lines.length;j++)beginLine(j);T.done=true;T.st="idle";duck(false)}return}T.el+=dt*P.speed;
 if(T.st==="timer"&&T.el>=T.need){T.st="gap";T.gap=380}
 else if(T.st==="speaking"&&T.el>T.need){T.tok++;try{speechSynthesis.cancel()}catch(e){}T.st="gap";T.gap=200}
 if(T.st==="gap"){T.gap-=dt;if(T.gap<=0){if(T.i+1<T.lines.length)beginLine(T.i+1);else{T.done=true;T.st="idle";duck(false)}}}}
function trackPause(){if(T.st==="speaking"){T.tok++;try{speechSynthesis.cancel()}catch(e){}T.st="resume"}if(P.recSrc)audio.pause()}
function trackResume(){if(T.st==="resume"){const l=T.lines[T.i];T.st="speaking";T.el=0;if(ttsReady())speakLine(l,T.tok);else{T.st="timer";T.need=lineEst(l)}}
 if(P.recSrc&&!P.recEnded)startRec()}
function startRec(){audio.playbackRate=P.speed;if(audio.getAttribute("data-src")!==P.recSrc){audio.src=P.recSrc;audio.setAttribute("data-src",P.recSrc);P.recEnded=false}
 if(P.recSeg&&P.recSeek){P.recSeek=false;if(audio.readyState>=1){try{audio.currentTime=P.recSeg.off/1000}catch(e){}}else P.recSeekTo=P.recSeg.off}
 audio.play().catch(()=>{P.recEnded=true;if(P.recSeg){P.recSeg=null;P.recSrc="";voiceStatus()}})}
audio.onloadedmetadata=()=>{if(P.recSeg){if(P.recSeekTo!=null){try{audio.currentTime=P.recSeekTo/1000}catch(e){}P.recSeekTo=null}return}const tot=T.lines.reduce((a,l)=>a+lineEst(l),0)||1;if(audio.duration>0)T.scale=audio.duration*1000/tot};
audio.onended=()=>{P.recEnded=true};
function unlockSpeech(){if(UNLOCKED||!("speechSynthesis" in window))return;UNLOCKED=true;try{const u=new SpeechSynthesisUtterance(" ");u.volume=0;speechSynthesis.speak(u)}catch(e){}}
function duck(on){if(master&&AC)try{master.gain.setTargetAtTime(on?.22:.5,AC.currentTime,.3)}catch(e){}}
function voiceStatus(){
 const st=$("#vstat");if(!st)return;
 if(VP.gender==="off"){st.textContent="Đang tắt giọng — chỉ hiện phụ đề.";return}
 if(P.recSrc){st.textContent="Chương này phát giọng đọc thu sẵn — nghe được trên mọi trình duyệt, kể cả Cốc Cốc.";return}
 if(!("speechSynthesis" in window)){st.textContent="Trình duyệt này không hỗ trợ đọc giọng. Mở trang bằng Microsoft Edge hoặc Chrome trên máy tính.";return}
 if(!VOICES.length&&/coc_coc|coccoc/i.test(navigator.userAgent)){st.textContent="Cốc Cốc chưa có giọng đọc tiếng Việt cho các video chưa thu âm. Trên Windows: Cài đặt > Thời gian và ngôn ngữ > Giọng nói > Thêm giọng > Tiếng Việt, rồi mở lại Cốc Cốc.";return}
 if(!VOICES.length){st.textContent="Máy này chưa có giọng tiếng Việt nên chưa phát được tiếng. Mở trang bằng Microsoft Edge (có HoaiMy nữ và NamMinh nam), rồi bấm “Thử tiếng”.";return}
 if(AUDIO_OK===false){st.textContent="Trình duyệt chưa phát được tiếng. Kiểm tra âm lượng, tắt chế độ im lặng, rồi bấm “Thử tiếng”.";return}
 const nat=VOICES.filter(vNatural),hasM=VOICES.some(v=>vGender(v)==="nam"),hasF=VOICES.some(v=>vGender(v)==="nu");
 const vd=voiceFor("dan");let msg="Người dẫn: "+vd.v.name.replace(/\s*-\s*Vietnamese.*$/i,"").replace(/^Microsoft\s*/,"")+" · "+(nat.length?nat.length+" giọng tự nhiên":"giọng cơ bản");
 if(!hasM||!hasF)msg+=" · Máy chỉ có giọng "+(hasM?"nam":"nữ")+", các vai còn lại được đổi tông. Mở bằng Microsoft Edge để có đủ giọng nam và nữ.";
 st.textContent=msg}
function setGender(g){VP.gender=g;LS.set("gita.gender",g);$("#sGender").value=g;if(P.video)goto(P.idx);voiceStatus();renderVoiceUI()}
$("#sGender").value=VP.gender;$("#sGender").onchange=e=>setGender(e.target.value);
$("#bTest").onclick=()=>{const st=$("#vstat");
 if(!("speechSynthesis" in window)){st.textContent="Trình duyệt này không hỗ trợ đọc giọng. Mở trang bằng Microsoft Edge hoặc Chrome trên máy tính.";return}
 loadVoices();if(!VOICES.length){voiceStatus();return}
 const vc=voiceFor("dan");let started=false;try{speechSynthesis.cancel()}catch(e){}
 const u=new SpeechSynthesisUtterance("Xin chào, đây là giọng thuyết minh của Học viện GITA.");u.voice=vc.v;u.lang=vc.v.lang;u.rate=.94;
 u.onstart=()=>{started=true;AUDIO_OK=true;st.textContent="Âm thanh hoạt động — đang đọc bằng "+vc.v.name.replace(/\s*-\s*Vietnamese.*$/i,"")+". Nếu vẫn không nghe, hãy tăng âm lượng thiết bị."};
 KEEP.push(u);speechSynthesis.speak(u);UNLOCKED=true;
 setTimeout(()=>{if(!started){AUDIO_OK=false;voiceStatus()}},3500)};
function renderVoiceUI(){
 const t=$("#castTbl");if(!t)return;t.innerHTML="";
 $("#vHint").textContent=VOICES.length?"Mỗi vai có giọng, tông và tốc độ riêng. Giọng có chữ Natural/Online là giọng AI chất lượng cao; máy có "+VOICES.length+" giọng tiếng Việt.":"Máy này chưa có giọng tiếng Việt. Microsoft Edge có sẵn hai giọng tự nhiên: HoaiMy (nữ) và NamMinh (nam). Video vẫn chạy với phụ đề.";
 const hr=el("tr");["Vai","Giọng","Tông","Tốc độ",""].forEach(x=>hr.appendChild(el("th","",x)));t.appendChild(hr);
 Object.keys(CAST_DEF).forEach(id=>{const c=cast(id);const r=el("tr");const n=el("td");n.appendChild(el("div","",c.name));n.appendChild(el("div","small","Cảm xúc nền: "+EMO[c.emo].l));r.appendChild(n);
  const td=el("td");const sel=el("select");sel.style.cssText="max-width:230px;padding:5px;border-radius:8px;border:1px solid var(--line);background:var(--surface)";
  const o0=el("option","",id==="dan"?"Theo nút Dẫn (nữ/nam)":"Tự động — giọng "+(c.g==="nam"?"nam":"nữ"));o0.value="";sel.appendChild(o0);
  if(id!=="dan")["nu","nam"].forEach(g=>{const o=el("option","","Tự động — giọng "+(g==="nam"?"nam":"nữ"));o.value="@"+g;sel.appendChild(o)});
  VOICES.forEach(v=>{const o=el("option","",v.name.replace(/\s*-\s*Vietnamese.*$/i,""));o.value=v.name;sel.appendChild(o)});
  const cur=CASTO[id]||{};sel.value=cur.voice||(cur.g&&id!=="dan"?"@"+cur.g:"");
  sel.onchange=()=>{const o=CASTO[id]=CASTO[id]||{};if(sel.value.startsWith("@")){o.g=sel.value.slice(1);o.voice=""}else{o.voice=sel.value;if(!sel.value)delete o.g}LS.set("gita.cast",CASTO);voiceStatus()};
  td.appendChild(sel);r.appendChild(td);
  [["p",.5,1.6,.02],["r",.7,1.3,.02]].forEach(([k,mn,mx,st])=>{const tdd=el("td");const inp=el("input");inp.type="range";inp.min=mn;inp.max=mx;inp.step=st;inp.value=c[k];inp.style.width="110px";inp.setAttribute("aria-label",(k==="p"?"Tông giọng ":"Tốc độ ")+c.name);
   const lab=el("span","small"," "+(+c[k]).toFixed(2));inp.oninput=()=>{(CASTO[id]=CASTO[id]||{})[k]=+inp.value;lab.textContent=" "+(+inp.value).toFixed(2);LS.set("gita.cast",CASTO)};tdd.appendChild(inp);tdd.appendChild(lab);r.appendChild(tdd)});
  const tb=el("td");const b=el("button","btn ghost","Nghe thử");b.style.padding="6px 12px";b.onclick=()=>{if(!VOICES.length){voiceStatus();return}const l=mkLine(c.name,c.sample,"","");const was=P.playing;if(was)pause();T.tok++;try{speechSynthesis.cancel()}catch(e){}const tok=T.tok;UNLOCKED=true;speakLine(l,tok)};
  tb.appendChild(b);r.appendChild(tb);t.appendChild(r)});
}
function scriptText(v){
 const L=["GITA 365 — KỊCH BẢN LỜI ĐỌC NHIỀU VAI","Video: "+v.title,"Chuẩn giọng: biên tập viên, giọng Bắc chuẩn, ấm, truyền cảm; 140–160 từ/phút; nghỉ 0,5 giây giữa các câu.","Mỗi chương thu một file MP3 riêng (ghép đủ các vai), đặt tên theo số chương. [Vai · cảm xúc] là chỉ dẫn diễn xuất, không đọc thành tiếng; *từ* là từ cần nhấn.",""];
 const nm=me.name;me.name="";
 v.scenes.forEach((s,i)=>{L.push("CHƯƠNG "+(i+1)+" — "+(s.chapter||CHAP[s.type]||""));buildTrack(s).forEach(l=>{if(!l.clean)return;L.push("["+(l.cast==="dan"?"Người dẫn":l.who)+" · "+EMO[l.emo].l+"] "+l.segs.map(x=>x.emph?"*"+x.t.trim()+"*":x.t).join("").trim())});L.push("")});
 me.name=nm;return L.join("\n");
}
function vid(id){return String(id).replace(/[^A-Za-z0-9_-]/g,"_").slice(0,150)}
function spokenTxt(t){return String(t).replace(/[—–]/g,",").replace(/[✎→“”"«»]/g,"").replace(/…/g,",").replace(/·/g,",").replace(/≥\s*/g,"từ ").replace(/≤\s*/g,"không quá ").replace(/(\d)\s*%/g,"$1 phần trăm").replace(/\s*×\s*/g," nhân ").replace(/\s{2,}/g," ").replace(/^[,:;.\s]+/,"").trim()}
function voicePack(v){const nm=me.name;me.name="";const cst={};Object.keys(CAST_DEF).forEach(k=>{const c=cast(k);cst[k]={name:c.name,g:k==="dan"?"auto":c.g,p:c.p,r:c.r}});
 const pk={app:"GITA 365 Studio",version:1,id:v.id,file:vid(v.id),title:v.title,cast:cst,emo:EMO,
  chapters:v.scenes.map((sc,i)=>({n:i+1,chapter:sc.chapter||CHAP[sc.type]||"",lines:buildTrack(sc).filter(l=>l.clean).map(l=>({cast:l.cast,who:l.cast==="dan"?"Người dẫn":l.who,emo:l.emo,segs:l.segs.map(g=>({t:spokenTxt(g.t),emph:!!g.emph})).filter(g=>g.t)}))}))};
 me.name=nm;return pk}
function dl(name,text,type){try{const bl=new Blob([text],{type:type||"text/plain;charset=utf-8"});const u=URL.createObjectURL(bl);const a=el("a");a.href=u;a.download=name;SR.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(u);a.remove()},1000);return true}catch(e){return false}}
function subscribeRec(){renderRecTable()}
function renderRecTable(){
 const t=$("#recTbl");if(!t||!P.video)return;t.innerHTML="";const v=P.video;
 const hr=el("tr");["Chương","Lời đọc","Giọng thu sẵn"].forEach(x=>hr.appendChild(el("th","",x)));t.appendChild(hr);
 const m=VMAN[v.id];
 v.scenes.forEach((s,i)=>{const r=el("tr");r.appendChild(el("td","",(i+1)+". "+(s.chapter||CHAP[s.type]||"")));r.appendChild(el("td","nr",buildTrack(s).filter(l=>l.clean).map(l=>(l.cast==="dan"?"":l.who+": ")+l.clean).join(" ")));
  const has=m&&Object.keys(m).filter(g=>{const x=m[g];return x&&((x.full&&x.ch&&x.ch[i])||(x.chapters&&x.chapters[i]))});
  r.appendChild(el("td",has&&has.length?"ok2":"small",has&&has.length?"Có ("+has.map(g=>g==="nam"?"nam":"nữ").join(", ")+")":"Chưa có"));t.appendChild(r)});
 $("#scriptBox").value=scriptText(v);
}
$("#bPack").onclick=()=>{const m=$("#scriptMsg");if(!P.video)return;m.textContent=dl("giong-"+vid(P.video.id)+".json",JSON.stringify(voicePack(P.video),null,1),"application/json")?"Đã tải gói tạo giọng. Chạy tools/voice/tao_giong.py với file này để tạo file giọng chuẩn.":"Chưa tải được gói tạo giọng."};
$("#bScript").onclick=()=>{const m=$("#scriptMsg");if(!P.video)return;m.textContent=dl("kich-ban-loi-doc-"+vid(P.video.id)+".txt",scriptText(P.video))?"Đã tải file kịch bản.":"Chưa tải được — hãy sao chép kịch bản trong khung bên dưới."};

/* ---- player ---- */
function nar(sc){return buildTrack(sc).map(l=>l.clean).join(" ")}
function loadVideo(v,autoplay){
 P.video=v;P.idx=0;$("#vtitle").textContent=v.title;
 $("#vmeta").textContent=(ROLES[v.role]?ROLES[v.role].name:"")+" · "+(SCREENS[v.screen]?SCREENS[v.screen].name:"")+" · khoảng "+estDur(v)+" phút"+(v.ai?" · sản xuất bằng AI":"");
 const sg=$("#segs");sg.innerHTML="";v.scenes.forEach((s,i)=>{const b=el("button","seg");b.setAttribute("aria-label","Tới chương "+(i+1));b.appendChild(el("span"));b.onclick=()=>goto(i);sg.appendChild(b)});
 const ch=$("#chaps");ch.innerHTML="";v.scenes.forEach((s,i)=>{const b=el("button","",(i+1)+". "+(s.chapter||CHAP[s.type]||s.type));b.onclick=()=>goto(i);ch.appendChild(b)});
 renderPlaylist();subscribeRec();goto(0);if(autoplay)play();else pause();
}
function goto(i){
 const v=P.video;if(!v)return;P.idx=Math.max(0,Math.min(v.scenes.length-1,i));emit("chapter",{videoId:v.id,index:P.idx,chapter:v.scenes[P.idx].chapter||CHAP[v.scenes[P.idx].type]||""});
 const sc=v.scenes[P.idx];layer.innerHTML="";pen.style.opacity=0;
 P.ctx=newCtx();let d=6000;
 try{d=(R_[sc.type]||R_.write)(sc,layer,P.ctx,v)}catch(e){console.error(e);layer.innerHTML="";const m=mk(layer,"s-title","Cảnh này chưa hiển thị được.");d=3000}
 P.dur=Math.max(4000,d);P.t=0;
 $("#chap").innerHTML="";const b=el("b","",(P.idx+1)+"/"+v.scenes.length);$("#chap").appendChild(b);$("#chap").appendChild(el("span","",sc.chapter||CHAP[sc.type]||""));
 const ri=recInfo(P.idx);const ns=ri?ri.src:"";P.recSeg=ri&&ri.off!=null?ri:null;P.recSrc=ns;P.recEnded=!ns;audio.pause();if(!P.recSeg||audio.getAttribute("data-src")!==ns)audio.removeAttribute("data-src");P.recSeek=!!P.recSeg;P.reseeked=false;P.seekBad=0;
 trackStart(buildTrack(sc));
 if(P.recSeg){const st=P.recSeg.starts||[];const nClean=T.lines.filter(l=>l.clean).length;
  if(st.length===nClean){let j=0;const M=T.lines.map(l=>l.clean?st[j++]:null);for(let k=M.length-1,nx=P.recSeg.dur;k>=0;k--){if(M[k]==null)M[k]=nx;else nx=M[k]}P.recSeg.map=M}
  else{P.recSeg.map=null;const tot=T.lines.reduce((a,l)=>a+lineEst(l),0)||1;T.scale=P.recSeg.dur/tot}}
 voiceStatus();
 SR.querySelectorAll("#chaps button").forEach((b,k)=>b.classList.toggle("cur",k===P.idx));
 SR.querySelectorAll("#segs .seg span").forEach((s,k)=>s.style.width=k<P.idx?"100%":"0");
 runTicks();
 cap.textContent="";if(P.playing){if(P.recSrc)startRec();chime()}
 voiceStatus();
}
function chunk(t){const parts=t.split(/(?<=[.!?;])\s+/).filter(Boolean);const out=[];parts.forEach(p=>{if(out.length&&(out[out.length-1]+" "+p).length<=90)out[out.length-1]+=" "+p;else if(p.length>120){const w=p.split(" ");let cur="";w.forEach(x=>{if((cur+" "+x).trim().length>95){out.push(cur.trim());cur=x}else cur+=" "+x});if(cur.trim())out.push(cur.trim())}else out.push(p)});return out.length?out:[""]}
function runTicks(){const c=P.ctx;if(!c)return;P.penT=null;c.cues.forEach((q,k)=>{if(!c.fired.has(k)&&P.t>=q.ms){c.fired.add(k);try{q.fn()}catch(e){}}});c.ticks.forEach(f=>{try{f(P.t)}catch(e){}});
 if(P.penT){pen.style.opacity=1;pen.style.transform="translate("+(P.penT.x-8)+"px,"+(P.penT.y-62)+"px)"}else pen.style.opacity=0}
function loop(now){
 if(DEAD)return;
 const dt=P.last?Math.min(100,now-P.last):0;P.last=now;
 if(P.playing&&P.video){P.t+=dt*P.speed;runTicks();
  const seg=SR.querySelectorAll("#segs .seg span")[P.idx];if(seg)seg.style.width=Math.min(100,P.t/P.dur*100)+"%";
  if(P.recSeg&&P.recSrc&&!P.recEnded&&!audio.paused&&P.recSeekTo==null&&recRel()>=P.recSeg.dur){audio.pause();P.recEnded=true}
  if(P.recSeg&&!audio.paused&&P.recSeekTo==null&&now-(P.lastSeekChk||0)>900){P.lastSeekChk=now;seekCheck()}
  trackTick(dt);
  if(P.t>=P.dur&&T.done&&(P.recEnded||P.t>P.dur+180000)){
   if(P.idx<P.video.scenes.length-1)goto(P.idx+1);else{finish()}
  }}
 requestAnimationFrame(loop);
}
requestAnimationFrame(loop);
function finish(){pause();emit("completed",{videoId:P.video.id,role:P.video.role,screen:P.video.screen});const w=LS.get("gita.watched",{});w[P.video.id]=1;LS.set("gita.watched",w);renderPlaylist();renderLib()}
function play(){if(!P.video)return;emit("play",{videoId:P.video.id,index:P.idx});if(P.idx===P.video.scenes.length-1&&P.t>=P.dur)goto(0);P.playing=true;stage.classList.remove("paused");
 const a=ac();a&&a.resume();unlockSpeech();
 trackResume();
 setMusic(P.music);updPlay()}
function pause(){if(P.playing&&P.video)emit("pause",{videoId:P.video.id,index:P.idx});P.playing=false;stage.classList.add("paused");trackPause();clearInterval(musicTimer);updPlay()}
function updPlay(){$("#lPlay").textContent=P.playing?"Tạm dừng":"Phát";$("#icPlay").innerHTML=P.playing?'<path d="M6 5h4v14H6zM14 5h4v14h-4z"/>':'<path d="M7 5v14l12-7z"/>'}
$("#bPlay").onclick=()=>P.playing?pause():play();
$("#bPrev").onclick=()=>goto(P.idx-1);
$("#bNext").onclick=()=>goto(P.idx+1);
$("#bMusic").onclick=()=>{const a=ac();a&&a.resume();setMusic(!P.music)};
$("#bCap").onclick=function(){const on=this.getAttribute("aria-pressed")!=="true";this.setAttribute("aria-pressed",on);stage.classList.toggle("nocap",!on)};
$("#sSpeed").onchange=e=>{P.speed=+e.target.value;audio.playbackRate=P.speed};
function setMode(m){BODY.classList.remove("mode-frame","mode-mini","mode-full");BODY.classList.add("mode-"+m);emit("mode",{mode:m});["Mini","Frame","Full"].forEach(k=>$("#b"+k).setAttribute("aria-pressed",k.toLowerCase()===m))}
$("#bMini").onclick=()=>setMode("mini");$("#bFrame").onclick=()=>setMode("frame");$("#bFull").onclick=()=>setMode("full");
const onKey=e=>{if(DEAD||!keyOk(e))return;const tg=e.composedPath()[0]||e.target;if(/INPUT|TEXTAREA|SELECT/.test(tg.tagName||""))return;
 if(e.key===" "){e.preventDefault();P.playing?pause():play()}else if(e.key==="ArrowRight")goto(P.idx+1);else if(e.key==="ArrowLeft")goto(P.idx-1);else if(e.key==="Escape")setMode("frame");else if(e.key==="f")setMode("full");else if(e.key==="m")setMode("mini")};
document.addEventListener("keydown",onKey);

/* ============ LIBRARY ============ */
function videosFor(role){const R=ROLES[role];const b=Object.keys(R.screens).map(s=>buildVideo(role,s));return b.concat(aiVideos.filter(v=>v.role===role))}
function renderPlaylist(){
 const pl=$("#pl");pl.innerHTML="";if(!me.role)return;
 $("#plTitle").textContent="Video cho vai "+ROLES[me.role].name;
 const w=LS.get("gita.watched",{});
 videosFor(me.role).forEach(v=>{
  const b=el("button","pi"+(P.video&&P.video.id===v.id?" cur":""));const th=el("div","th",v.ai?"AI":"GITA");b.appendChild(th);
  const tx=el("div");tx.appendChild(el("div","t",SCREENS[v.screen]?SCREENS[v.screen].name:v.title));
  const m=el("div","m",(v.ai?(v.title+" · "):"")+"≈ "+estDur(v)+" phút · ");const pm=el("span","perm",ROLES[v.role].screens[v.screen]||"Xem");m.appendChild(pm);tx.appendChild(m);b.appendChild(tx);
  if(w[v.id])b.appendChild(el("span","ok","✓"));b.onclick=()=>loadVideo(v,true);pl.appendChild(b)});
}
let libRole=null;
function renderLib(){
 const rc=$("#roleChips");rc.innerHTML="";const admin=me.role==="quantri";if(!libRole)libRole=me.role||"ph";
 Object.keys(ROLES).forEach(k=>{const b=el("button","",ROLES[k].name);b.setAttribute("aria-pressed",k===libRole);b.disabled=!admin&&k!==me.role;b.onclick=()=>{libRole=k;renderLib()};rc.appendChild(b)});
 const lib=$("#lib");lib.innerHTML="";const w=LS.get("gita.watched",{});
 videosFor(libRole).forEach(v=>{const c=el("button","card");c.appendChild(el("div","k",(SCREENS[v.screen]?SCREENS[v.screen].name:"")+" · "+ROLES[v.role].name));c.appendChild(el("div","t",v.title));
  c.appendChild(el("div","d",v.ai?(v.focus||"Video do AI sản xuất theo yêu cầu"):(SCREENS[v.screen].purpose)));
  const ft=el("div","ft");ft.appendChild(el("span","tag"+(v.ai?" ai":""),v.ai?"AI sản xuất":"Chuẩn"));ft.appendChild(el("span","",v.scenes.length+" chương · ≈ "+estDur(v)+" phút"));if(w[v.id])ft.appendChild(el("span","tag","Đã xem"));c.appendChild(ft);
  c.onclick=()=>{loadVideo(v,true);scrollTopHost()};lib.appendChild(c)});
}
function renderMatrix(){
 const t=el("table");const hr=el("tr");hr.appendChild(el("th","","Màn hình"));Object.keys(ROLES).forEach(k=>hr.appendChild(el("th","",ROLES[k].name)));t.appendChild(hr);
 Object.keys(SCREENS).forEach(s=>{const r=el("tr");r.appendChild(el("td","",SCREENS[s].name));Object.keys(ROLES).forEach(k=>{const td=el("td");const p=ROLES[k].screens[s];
  if(p){const b=el("button","perm",p+" ▸");b.style.border="0";b.title="Xem video";b.disabled=me.role!=="quantri"&&k!==me.role;b.onclick=()=>{loadVideo(buildVideo(k,s),true);scrollTopHost()};td.appendChild(b)}else td.textContent="—";r.appendChild(td)});t.appendChild(r)});
 const m=$("#mat");m.innerHTML="";m.appendChild(t);
}

/* tabs */
SR.querySelectorAll(".tabs button").forEach(b=>b.onclick=()=>{SR.querySelectorAll(".tabs button").forEach(x=>x.setAttribute("aria-selected",x===b));SR.querySelectorAll(".tp").forEach(p=>p.classList.toggle("on",p.id==="tp-"+b.dataset.tab))});

/* ============ ROLE / WELCOME ============ */
let pick=null;
function openRole(){
 const ov=$("#ov");$("#ovName").value=me.name||"";pick=me.role||(me.isOwner?"quantri":null);
 const box=$("#ovRoles");box.innerHTML="";
 Object.keys(ROLES).forEach(k=>{const b=el("button");b.appendChild(el("b","",ROLES[k].name));b.appendChild(el("span","",Object.keys(ROLES[k].screens).length+" video màn hình"));b.setAttribute("aria-pressed",k===pick);b.onclick=()=>{pick=k;box.querySelectorAll("button").forEach(x=>x.setAttribute("aria-pressed",x===b))};box.appendChild(b)});
 ov.classList.add("on");setTimeout(()=>$("#ovName").focus(),50);
}
$("#ovGo").onclick=()=>{if(!pick){$("#ovRoles").style.outline="2px solid var(--coral)";return}
 me.name=$("#ovName").value.trim()||me.name;me.role=pick;LS.set("demo.name",me.name);LS.set("demo.role",pick);$("#ov").classList.remove("on");applyRole()};
$("#btnRole").onclick=openRole;
function applyRole(){
 $("#whoName").textContent=me.name||"Khách";$("#whoRole").textContent=me.role?ROLES[me.role].name:"Chưa chọn vai";
 if(me.avatar)$("#whoAv").src=me.avatar;else $("#whoAv").style.display="none";
 libRole=me.role;renderLib();renderMatrix();
 if(me.role){const first=Object.keys(ROLES[me.role].screens)[0];loadVideo(buildVideo(me.role,first),false)}
}


/* ============ KHỞI ĐỘNG & API ============ */
function applyUser(u){if(!u)return;if(u.name!=null)me.name=String(u.name);if(u.role&&ROLES[u.role])me.role=u.role;me.isOwner=!!u.isAdmin;me.canEdit=!!u.isAdmin;me.avatar=u.avatar||"";
 if(!me.avatar){const i=$("#whoAv");if(i)i.style.display="none"}}
const hasUser=!!(opts.user&&opts.user.role&&ROLES[opts.user.role]);
if(hasUser)applyUser(opts.user);else{me.name=LS.get("demo.name","");me.role=LS.get("demo.role","")}
if(hasUser&&!opts.allowRoleSwitch)BODY.classList.add("no-role-switch");
paintLogos();
if(me.role){applyRole();if(opts.screen&&SCREENS[opts.screen]){loadVideo(buildVideo(me.role,opts.screen),!!opts.autoplay)}}
else{renderLib();renderMatrix();openRole()}
if(opts.mode)setMode(opts.mode);
const ctl={
 open(role,screen,o={}){role=role||me.role;if(!ROLES[role]||!SCREENS[screen])return null;if(role!==me.role){me.role=role;applyRole()}
  const v=buildVideo(role,screen);loadVideo(v,o.autoplay!==false);if(o.mode)setMode(o.mode);return v.id},
 setUser(u){applyUser(u);applyRole()},
 play(){play()},pause(){pause()},setMode(m){setMode(m)},
 videos(role){return videosFor(role||me.role).map(v=>({id:v.id,role:v.role,screen:v.screen,title:v.title,chapters:v.scenes.length,minutes:estDur(v)}))},
 voicePack(role,screen){return voicePack(buildVideo(role,screen))},
 scriptText(role,screen){return scriptText(buildVideo(role,screen))},
 get state(){return{videoId:P.video&&P.video.id,chapter:P.idx,playing:P.playing,user:{name:me.name,role:me.role}}},
 destroy(){DEAD=true;try{pause()}catch(e){}try{audio.pause();audio.removeAttribute("src")}catch(e){}try{speechSynthesis.cancel()}catch(e){}
  clearInterval(musicTimer);document.removeEventListener("keydown",onKey);SR.innerHTML=""}
};
return ctl;
}
