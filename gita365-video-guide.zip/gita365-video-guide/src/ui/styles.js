/*! GITA 365 · Video Guide — Học viện GITA. */
export const CSS=`
:host{display:block;
  --paper:#F4F7FC; --surface:#FFFFFF; --ink:#15283A; --muted:#5B6B78; --line:#D6DFEC;
  --green:#2B5FAB; --leaf:#5B8FD6; --sun:#ED1E24; --coral:#D9262C; --sky:#3C7DA6;
  --chip:#E4ECF8;
  --ui:"Be Vietnam Pro", "Segoe UI", system-ui, -apple-system, sans-serif;
  --hand:"Dancing Script", "Segoe Script", cursive;
  box-sizing:border-box;
  padding-top:env(safe-area-inset-top,0px); padding-bottom:env(safe-area-inset-bottom,0px);
}
@media (prefers-color-scheme:dark){
  :host(:not([data-theme="light"])){
    --paper:#0D1522; --surface:#152033; --ink:#E8EEF7; --muted:#A3B1C6; --line:#26344A; --chip:#1C2A40;
  }
}
:host([data-theme="dark"]){--paper:#0D1522; --surface:#152033; --ink:#E8EEF7; --muted:#A3B1C6; --line:#26344A; --chip:#1C2A40;}
*,*::before,*::after{box-sizing:border-box}
.gvg-body{margin:0;background:var(--paper);color:var(--ink);font-family:var(--ui);font-size:15px;line-height:1.55}
button,select,input,textarea{font:inherit;color:inherit}
button{cursor:pointer}
:focus-visible{outline:3px solid var(--sun);outline-offset:2px}
.wrap{max-width:1320px;margin:0 auto;padding:18px 20px 60px}

/* header */
.top{display:flex;align-items:center;gap:16px;flex-wrap:wrap;margin-bottom:18px}
.brand{display:flex;align-items:center;gap:12px}
.brand .logo-slot{width:96px;height:48px}
.brand h1{font-size:19px;margin:0;font-weight:700;letter-spacing:-.01em}
.brand p{margin:0;color:var(--muted);font-size:13px}
.who{margin-left:auto;display:flex;align-items:center;gap:10px;background:var(--surface);border:1px solid var(--line);border-radius:40px;padding:5px 6px 5px 5px}
.who img{width:34px;height:34px;border-radius:50%}
.who .n{font-weight:600;font-size:14px;line-height:1.2}
.who .r{font-size:12px;color:var(--muted)}
.who button{border:0;background:var(--chip);border-radius:30px;padding:6px 12px;font-size:13px}

/* layout */
.grid{display:grid;grid-template-columns:minmax(0,1fr) 320px;gap:18px;align-items:start}
@media (max-width:980px){.grid{grid-template-columns:1fr}}

/* player dock */
.dock{background:#0E1B24;border-radius:14px;overflow:hidden;box-shadow:0 18px 40px -24px rgba(21,40,58,.6)}
.frame{position:relative;width:100%;aspect-ratio:16/9;overflow:hidden;background:#F4F7FC}
.stage{position:absolute;left:0;top:0;width:1280px;height:720px;transform-origin:0 0;overflow:hidden;
  background:
   radial-gradient(circle at 1px 1px, rgba(43,95,171,.13) 1.2px, transparent 1.3px) 0 0/32px 32px,
   linear-gradient(160deg,#F8FAFE 0%,#E9EFF9 100%);
  color:#15283A;font-family:var(--ui)}
.stage.paused *{animation-play-state:paused!important}
.layer{position:absolute;inset:0}
.wm{position:absolute;right:28px;top:22px;display:flex;align-items:center;gap:10px;opacity:.9;z-index:5}
.wm .logo-slot{width:104px;height:52px}
.wm span{font-weight:800;font-size:18px;letter-spacing:.02em;color:#2B5FAB}
.chap{position:absolute;left:40px;top:28px;z-index:5;font-size:17px;font-weight:600;color:#2B5FAB;display:flex;gap:10px;align-items:center}
.chap b{background:#2B5FAB;color:#fff;border-radius:6px;padding:2px 9px;font-size:15px}
.cap{position:absolute;left:50%;bottom:20px;transform:translateX(-50%);width:max-content;max-width:940px;z-index:6;
  background:rgba(14,27,36,.86);color:#fff;font-size:21px;line-height:1.4;padding:8px 18px;border-radius:10px;text-align:center}
.cap:empty{display:none}
.nocap .cap{display:none}
.pen{position:absolute;left:0;top:0;width:70px;height:70px;z-index:20;pointer-events:none;opacity:0;transition:opacity .25s;will-change:transform}
.ch{opacity:0}
.ch.on{opacity:1}

/* scene pieces */
.s-title{position:absolute;left:80px;top:96px;right:220px;font-size:46px;font-weight:800;letter-spacing:-.01em;line-height:1.15;white-space:pre-wrap}
.hand{font-family:var(--hand);font-weight:700}
.lines{position:absolute;left:80px;top:200px;right:120px;display:flex;flex-direction:column;gap:22px}
.line{display:flex;gap:18px;align-items:flex-start;font-size:30px;line-height:1.35}
.line .dot{flex:0 0 18px;height:18px;margin-top:12px;border-radius:50%;background:#5B8FD6;transform:scale(0);transition:transform .35s cubic-bezier(.3,1.6,.5,1)}
.line.on .dot{transform:scale(1)}
.line .tx{white-space:pre-wrap}
.node{position:absolute;transform:translate(-50%,-50%) scale(0);transition:transform .45s cubic-bezier(.3,1.5,.5,1);background:#fff;border:3px solid #2B5FAB;border-radius:16px;padding:12px 18px;text-align:center;box-shadow:0 10px 24px -14px rgba(21,40,58,.5);max-width:300px}
.node.on{transform:translate(-50%,-50%) scale(1)}
.node .l{font-weight:700;font-size:24px;line-height:1.2}
.node .nt{font-size:17px;color:#5B6B78;margin-top:4px;line-height:1.3}
.node .bd{display:inline-block;margin-top:6px;font-size:14px;font-weight:700;border-radius:20px;padding:2px 10px;background:#E4ECF8;color:#1F4E9E}
.node.center{background:#2B5FAB;color:#fff;border-color:#2B5FAB;padding:22px 30px}
.node.center .l{font-size:32px}
.fbox{position:absolute;top:230px;height:150px;border-radius:16px;background:#fff;border:3px solid #CBD8EC;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;padding:10px 12px;transition:all .4s;opacity:.35;transform:translateY(16px)}
.fbox.on{opacity:1;transform:none}
.fbox.act{border-color:#ED1E24;box-shadow:0 0 0 6px rgba(237,30,36,.25);background:#FFF3F3}
.fbox .num{width:40px;height:40px;border-radius:50%;background:#2B5FAB;color:#fff;font-weight:800;font-size:20px;display:grid;place-items:center;margin-bottom:8px}
.fbox .l{font-weight:700;font-size:22px;line-height:1.2}
.fdet{position:absolute;left:100px;right:100px;top:440px;min-height:120px;background:#fff;border-left:8px solid #ED1E24;border-radius:12px;padding:20px 28px;font-size:29px;line-height:1.4;white-space:pre-wrap;opacity:0;transition:opacity .3s}
.fdet.on{opacity:1}
.mock{position:absolute;left:60px;top:110px;width:820px;height:510px;background:#fff;border-radius:16px;border:2px solid #CBD8EC;overflow:hidden;box-shadow:0 20px 40px -26px rgba(21,40,58,.5)}
.mock .bar{height:48px;background:#15283A;color:#fff;display:flex;align-items:center;padding:0 18px;gap:12px;font-weight:700}
.mock .side{position:absolute;left:0;top:48px;bottom:0;width:180px;background:#EAF0F9;padding:12px 10px;font-size:15px}
.mock .side div{padding:7px 10px;border-radius:8px;margin-bottom:3px;color:#35505F}
.mock .side .cur{background:#2B5FAB;color:#fff;font-weight:600}
.slot{position:absolute;border:2px dashed #B9C9E2;border-radius:12px;background:#F6F9FD;display:flex;align-items:center;justify-content:center;text-align:center;padding:6px 8px;font-size:16px;line-height:1.2;font-weight:600;color:#35505F;transition:all .3s}
.slot.hi{border:3px solid #ED1E24;background:#FFF1F1;box-shadow:0 0 0 8px rgba(237,30,36,.22);color:#15283A}
.cursor{position:absolute;left:0;top:0;width:34px;height:34px;z-index:15;pointer-events:none}
.ripple{position:absolute;width:20px;height:20px;border-radius:50%;border:3px solid #D9262C;transform:translate(-50%,-50%);animation:rip .7s ease-out forwards;z-index:14}
@keyframes rip{to{width:90px;height:90px;opacity:0}}
.tip{position:absolute;z-index:16;background:#15283A;color:#fff;font-size:20px;line-height:1.35;padding:10px 16px;border-radius:10px;max-width:330px;opacity:0;transition:opacity .3s}
.tip.on{opacity:1}
.steps{position:absolute;left:910px;top:120px;width:320px;display:flex;flex-direction:column;gap:12px}
.st{display:flex;gap:12px;align-items:flex-start;font-size:19px;line-height:1.35;opacity:.35;transition:opacity .3s}
.st.on{opacity:1}
.st i{flex:0 0 30px;height:30px;border-radius:50%;border:3px solid #2B5FAB;display:grid;place-items:center;font-style:normal;font-weight:800;font-size:15px;color:#2B5FAB}
.st.done i{background:#2B5FAB;color:#fff}
.bub{position:absolute;max-width:640px;padding:16px 22px;border-radius:20px;font-size:26px;line-height:1.4;opacity:0;transform:translateY(12px);transition:all .35s;white-space:pre-wrap}
.bub.on{opacity:1;transform:none}
.bub .w{display:block;font-size:16px;font-weight:700;margin-bottom:4px;opacity:.75}
.bub.l{left:90px;background:#fff;border:2px solid #CBD8EC;border-bottom-left-radius:4px}
.bub.r{right:90px;background:#2B5FAB;color:#fff;border-bottom-right-radius:4px}
.lesson{position:absolute;left:90px;right:90px;bottom:90px;font-size:38px;color:#2B5FAB;white-space:pre-wrap;line-height:1.3}
.kpis{position:absolute;left:80px;right:80px;top:190px;display:grid;grid-template-columns:repeat(4,1fr);gap:22px}
.kc{background:#fff;border-radius:16px;padding:18px;text-align:center;border:2px solid #D9E3F2;opacity:0;transform:translateY(14px);transition:all .4s}
.kc.on{opacity:1;transform:none}
.kc svg{width:130px;height:130px}
.kc .v{font-size:30px;font-weight:800}
.kc .l{font-weight:700;font-size:20px;line-height:1.25;margin-top:6px}
.kc .t{font-size:16px;color:#5B6B78;margin-top:6px}
.knote{position:absolute;left:80px;top:150px;font-size:16px;color:#5B6B78}
.ktips{position:absolute;left:80px;right:80px;top:480px;font-size:27px;line-height:1.4;white-space:pre-wrap}
.prob{position:absolute;left:70px;top:130px;width:430px;background:#fff;border-radius:18px;border:3px solid #D9262C;padding:26px;opacity:0;transform:translateX(-20px);transition:all .45s}
.prob.on{opacity:1;transform:none}
.prob .k{font-size:17px;font-weight:700;color:#D9262C}
.prob .p{font-size:30px;font-weight:700;line-height:1.3;margin-top:8px}
.prob .sla{margin-top:18px;display:inline-block;background:#E4ECF8;color:#1F4E9E;border-radius:20px;padding:5px 14px;font-weight:700;font-size:17px}
.fix{position:absolute;left:560px;right:70px;top:130px;display:flex;flex-direction:column;gap:16px}
.fx{display:flex;gap:14px;align-items:flex-start;font-size:25px;line-height:1.35;opacity:0;transform:translateY(10px);transition:all .35s}
.fx.on{opacity:1;transform:none}
.fx i{flex:0 0 38px;height:38px;border-radius:50%;background:#E4ECF8;display:grid;place-items:center;font-style:normal;font-weight:800;color:#2B5FAB;transition:all .3s}
.fx.done i{background:#2B5FAB;color:#fff}
.ups{position:absolute;left:80px;right:80px;top:190px;display:flex;flex-direction:column;gap:16px}
.up{display:flex;gap:18px;align-items:center;background:#fff;border-radius:14px;padding:16px 22px;border:2px solid #D9E3F2;font-size:25px;opacity:0;transform:translateX(30px);transition:all .4s}
.up.on{opacity:1;transform:none}
.up b{background:#3C7DA6;color:#fff;border-radius:8px;padding:3px 10px;font-size:17px;white-space:nowrap}
.up small{font-size:16px;color:#5B6B78;white-space:nowrap}
.unote{position:absolute;left:80px;bottom:90px;font-size:16px;color:#5B6B78}
.intro-logo{position:absolute;left:50%;top:95px;transform:translateX(-50%);width:440px;height:222px}
.intro-hi{position:absolute;left:0;right:0;top:350px;text-align:center;font-size:34px;font-weight:600;color:#35505F;opacity:0;transition:opacity .5s}
.intro-hi.on{opacity:1}
.intro-name{position:absolute;left:0;right:0;top:395px;text-align:center;font-family:var(--hand);font-weight:700;font-size:82px;color:#2B5FAB;white-space:pre;line-height:1.2}
.intro-sub{position:absolute;left:0;right:0;top:520px;text-align:center;font-size:27px;font-weight:600;opacity:0;transform:translateY(10px);transition:all .5s}
.intro-sub.on{opacity:1;transform:none}
.draw{stroke-dasharray:var(--len);stroke-dashoffset:var(--len)}
.done-big{position:absolute;left:0;right:0;top:118px;text-align:center;font-size:52px;font-weight:800;color:#2B5FAB}
.chk{position:absolute;left:330px;right:200px;top:220px;display:flex;flex-direction:column;gap:16px}
.ck{display:flex;gap:16px;align-items:center;font-size:28px;opacity:0;transition:opacity .3s}
.ck.on{opacity:1}
.ck i{flex:0 0 40px;height:40px;border-radius:10px;border:3px solid #2B5FAB;display:grid;place-items:center;font-style:normal;color:#fff;font-weight:800;transition:background .3s}
.ck.done i{background:#2B5FAB}
.spark{position:absolute;width:10px;height:10px;border-radius:2px;z-index:12;animation:fall 1.6s ease-in forwards}
@keyframes fall{to{transform:translateY(420px) rotate(540deg);opacity:0}}
.fadein{animation:fi .5s ease both}
@keyframes fi{from{opacity:0}to{opacity:1}}

/* controls */
.ctl{display:flex;align-items:center;gap:6px;padding:8px 10px;color:#E8EEF7;flex-wrap:wrap}
.ctl button,.ctl select{background:transparent;border:0;color:#E8EEF7;border-radius:8px;padding:6px 9px;font-size:14px;display:inline-flex;align-items:center;gap:6px}
.ctl button:hover{background:rgba(255,255,255,.1)}
.ctl button[aria-pressed="true"]{background:rgba(237,30,36,.22);color:#FFD77A}
.ctl select{background:#1B2B36}
.ctl .sp{flex:1}
.ctl svg{width:20px;height:20px}
.bar2{display:flex;gap:3px;padding:0 10px 10px}
.seg{flex:1;height:7px;background:rgba(255,255,255,.14);border-radius:4px;overflow:hidden;cursor:pointer;border:0;padding:0}
.seg span{display:block;height:100%;width:0;background:#ED1E24}
.chaps{display:flex;gap:6px;padding:0 10px 12px;overflow-x:auto}
.chaps button{flex:0 0 auto;background:#1B2B36;border:0;color:#BFD0C6;border-radius:20px;padding:4px 11px;font-size:12.5px}
.chaps button.cur{background:#ED1E24;color:#15283A;font-weight:700}
.vtitle{padding:12px 14px 4px;color:#fff;font-weight:700;font-size:16px}
.vmeta{padding:0 14px 6px;color:#A3B1C6;font-size:13px}

/* modes */
.gvg-body.mode-full .dock{position:fixed;inset:0;z-index:100;border-radius:0;display:flex;flex-direction:column;justify-content:center;background:#060D12;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}
.gvg-body.mode-full .frame{max-width:calc((100vh - 150px) * 16 / 9);margin:0 auto}
.gvg-body.mode-mini .dock{position:fixed;right:16px;bottom:calc(16px + env(safe-area-inset-bottom,0px));width:min(380px,calc(100vw - 32px));z-index:100}
.gvg-body.mode-mini .chaps,.gvg-body.mode-mini .vmeta,.gvg-body.mode-mini .ext{display:none}
.gvg-body.mode-mini .dockph{display:block}
.dockph{display:none;border:2px dashed var(--line);border-radius:14px;aspect-ratio:16/9;display:none;align-items:center;justify-content:center;color:var(--muted);text-align:center;padding:20px}
.gvg-body.mode-mini .dockph{display:flex}

/* playlist */
.panel{background:var(--surface);border:1px solid var(--line);border-radius:14px;padding:14px}
.panel h2{font-size:15px;margin:0 0 10px}
.pl{display:flex;flex-direction:column;gap:6px;max-height:560px;overflow:auto}
.pi{display:flex;gap:10px;align-items:center;text-align:left;background:transparent;border:1px solid transparent;border-radius:10px;padding:8px}
.pi:hover{background:var(--chip)}
.pi.cur{border-color:var(--green);background:var(--chip)}
.pi .th{flex:0 0 58px;height:36px;border-radius:6px;background:linear-gradient(135deg,var(--green),var(--leaf));display:grid;place-items:center;color:#fff;font-weight:800;font-size:12px}
.pi .t{font-weight:600;font-size:14px;line-height:1.3}
.pi .m{font-size:12px;color:var(--muted)}
.pi .ok{margin-left:auto;color:var(--green);font-weight:800}
.perm{font-size:11.5px;border-radius:12px;padding:1px 7px;background:var(--chip);color:var(--muted);font-weight:600}

/* tabs */
.tabs{display:flex;gap:4px;margin:26px 0 14px;border-bottom:1px solid var(--line);overflow-x:auto}
.tabs button{background:none;border:0;border-bottom:3px solid transparent;padding:10px 14px;font-weight:600;color:var(--muted);white-space:nowrap}
.tabs button[aria-selected="true"]{color:var(--ink);border-color:var(--green)}
.tp{display:none}.tp.on{display:block}
.chips{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px}
.chips button{border:1px solid var(--line);background:var(--surface);border-radius:20px;padding:5px 12px;font-size:13px}
.chips button[aria-pressed="true"]{background:var(--green);color:#fff;border-color:var(--green)}
.chips button:disabled{opacity:.4;cursor:not-allowed}
.lib{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:12px}
.card{background:var(--surface);border:1px solid var(--line);border-radius:12px;padding:14px;display:flex;flex-direction:column;gap:6px;text-align:left}
.card:hover{border-color:var(--green)}
.card .k{font-size:12px;color:var(--muted)}
.card .t{font-weight:700;font-size:15px;line-height:1.3}
.card .d{font-size:13px;color:var(--muted);line-height:1.45}
.card .ft{display:flex;gap:6px;align-items:center;margin-top:auto;padding-top:6px;font-size:12px;color:var(--muted)}
.tag{border-radius:10px;padding:1px 8px;font-weight:600;font-size:11.5px;background:var(--chip)}
.tag.ai{background:#E4ECF8;color:#1F4E9E}
.form{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin-bottom:12px}
.form label{display:flex;flex-direction:column;gap:5px;font-size:13px;font-weight:600}
.form select,.form textarea,.form input{background:var(--surface);border:1px solid var(--line);border-radius:10px;padding:9px 11px;font-weight:400}
.form textarea{min-height:80px;resize:vertical}
.full{grid-column:1/-1}
.btn{background:var(--green);color:#fff;border:0;border-radius:10px;padding:10px 18px;font-weight:700}
.btn:disabled{opacity:.5;cursor:not-allowed}
.btn.ghost{background:var(--chip);color:var(--ink)}
.pipe{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;margin:16px 0}
.pp{border:1px solid var(--line);border-radius:12px;padding:12px;background:var(--surface);font-size:13px}
.pp b{display:block;font-size:14px;margin-bottom:3px}
.pp .s{margin-top:6px;font-weight:700;color:var(--muted)}
.pp.run{border-color:var(--sun)}.pp.run .s{color:#B3161C}
.pp.ok{border-color:var(--green)}.pp.ok .s{color:var(--green)}
.pp.err{border-color:var(--coral)}.pp.err .s{color:var(--coral)}
.msg{font-size:14px;color:var(--muted);margin-top:8px}
.team{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:12px}
.tm{background:var(--surface);border:1px solid var(--line);border-radius:12px;padding:16px}
.tm .ic{width:42px;height:42px;border-radius:12px;display:grid;place-items:center;color:#fff;font-weight:800;margin-bottom:10px}
.tm h3{margin:0 0 6px;font-size:15px}
.tm p{margin:0;font-size:13.5px;color:var(--muted)}
.mat{overflow-x:auto;border:1px solid var(--line);border-radius:12px;background:var(--surface)}
.mat table{border-collapse:collapse;width:100%;font-size:13px;min-width:760px}
.mat th,.mat td{padding:8px 10px;border-bottom:1px solid var(--line);text-align:left}
.mat th{font-weight:700;background:var(--chip)}
.brandbox{display:flex;gap:14px;align-items:center;flex-wrap:wrap;margin-top:16px}
.brandbox .logo-slot{width:128px;height:64px}

/* role overlay */
.ov{position:fixed;inset:0;z-index:200;background:rgba(10,20,16,.55);display:none;align-items:center;justify-content:center;padding:20px}
.ov.on{display:flex}
.ovb{background:var(--surface);border-radius:18px;max-width:560px;width:100%;padding:24px;max-height:90vh;overflow:auto}
.ovb h2{margin:0 0 4px;font-size:21px}
.ovb p{margin:0 0 14px;color:var(--muted);font-size:14px}
.roles{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px;margin:12px 0 16px}
.roles button{border:2px solid var(--line);background:var(--paper);border-radius:12px;padding:10px;text-align:left;font-size:13px}
.roles button b{display:block;font-size:14.5px}
.roles button[aria-pressed="true"]{border-color:var(--green);background:var(--chip)}
.ptabs{position:absolute;left:290px;right:290px;top:160px;display:flex;gap:10px}
.ptab{flex:1;padding:9px 10px;border-radius:10px;background:#E4ECF8;font-size:19px;font-weight:600;text-align:center;color:#35505F;transition:all .3s}
.ptab.act{background:#2B5FAB;color:#fff}
.ptab.done{background:#C9DAF3;color:#2B5FAB}
.av{position:absolute;bottom:88px;width:200px;text-align:center;font-weight:700;font-size:20px;color:#2B5FAB}
.av svg{width:200px;height:300px;display:block;transition:transform .3s}
.av.talk svg{animation:talk .5s ease-in-out infinite alternate}
@keyframes talk{to{transform:translateY(-6px) scale(1.02)}}
.pnote{position:absolute;left:290px;right:290px;top:540px;font-size:25px;line-height:1.35;color:#2B5FAB;font-style:italic;white-space:pre-wrap}
.vstat{padding:0 14px 8px;color:#FFD77A;font-size:13px}
.vstat:empty{display:none}
.vtbl{width:100%;border-collapse:collapse;font-size:13.5px}
.vtbl th,.vtbl td{padding:8px 10px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
.vtbl th{background:var(--chip)}
.vtbl .nr{color:var(--muted);font-size:12.5px;max-width:520px}
.ok2{color:var(--green);font-weight:700}
.vlist{display:flex;flex-direction:column;gap:8px;margin:10px 0 18px}
.vrow{display:flex;gap:10px;align-items:center;flex-wrap:wrap;background:var(--surface);border:1px solid var(--line);border-radius:10px;padding:10px 12px}
.vrow .nm{font-weight:600;flex:1;min-width:200px}
.small{font-size:12.5px;color:var(--muted)}
.script{width:100%;min-height:220px;background:var(--surface);border:1px solid var(--line);border-radius:10px;padding:12px;font-size:13.5px;line-height:1.5}
.sec{margin:22px 0 8px;font-size:16px}
.sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)}
@media (prefers-reduced-motion:reduce){.spark{display:none}}

/* ---- nhúng vào web app ---- */
.gvg-body{position:relative;min-height:0}
.gvg-body .wrap{padding:14px 16px 40px}
.layout-player .top,.layout-player .panel,.layout-player .tabs,.layout-player .tp{display:none!important}
.layout-player .grid{grid-template-columns:1fr}
.layout-player .wrap{padding:0;max-width:none}
.layout-player .dock{box-shadow:none}
.no-role-switch #btnRole{display:none}
`;
