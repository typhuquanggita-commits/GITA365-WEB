/*! GITA 365 · Video Guide — Học viện GITA. */
export const TEMPLATE=`<div class="gvg-body mode-frame">
<div class="wrap">
  <header class="top">
    <div class="brand">
      <div class="logo-slot" data-logo></div>
      <div><h1>GITA 365 · Video hướng dẫn</h1><p>Mỗi màn hình một video — đúng vai, đúng việc, đúng KPI</p></div>
    </div>
    <div class="who" id="who">
      <img id="whoAv" alt="">
      <div><div class="n" id="whoName">Khách</div><div class="r" id="whoRole">Chưa chọn vai</div></div>
      <button id="btnRole">Đổi vai</button>
    </div>
  </header>

  <div class="grid">
    <div>
      <div class="dockph">Video đang phát ở khung thu nhỏ góc màn hình. <br>Bấm “Khung chuẩn” để đưa về đây.</div>
      <section class="dock" id="dock" aria-label="Trình phát video hướng dẫn">
        <div class="frame" id="frame">
          <div class="stage" id="stage">
            <div class="chap" id="chap"></div>
            <div class="wm"><div class="logo-slot" data-logo></div></div>
            <div class="layer" id="layer"></div>
            <svg class="pen" id="pen" viewBox="0 0 70 70" aria-hidden="true">
              <g transform="rotate(-45 35 35)">
                <rect x="29" y="-6" width="12" height="46" rx="4" fill="#15283A"/>
                <rect x="29" y="8" width="12" height="5" fill="#ED1E24"/>
                <path d="M29 40 L41 40 L35 58 Z" fill="#ED1E24"/>
                <path d="M33.4 50 L36.6 50 L35 58 Z" fill="#15283A"/>
              </g>
            </svg>
            <div class="cap" id="cap" aria-live="polite"></div>
          </div>
        </div>
        <div class="vtitle" id="vtitle">—</div>
        <div class="vmeta" id="vmeta"></div>
        <div class="vstat" id="vstat"></div>
        <div class="bar2" id="segs"></div>
        <div class="ctl">
          <button id="bPrev" aria-label="Chương trước"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M6 5h2v14H6zM20 5v14L9 12z"/></svg></button>
          <button id="bPlay" aria-label="Phát"><svg viewBox="0 0 24 24" fill="currentColor" id="icPlay"><path d="M7 5v14l12-7z"/></svg><span id="lPlay">Phát</span></button>
          <button id="bNext" aria-label="Chương sau"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M16 5h2v14h-2zM4 5v14l11-7z"/></svg></button>
          <select id="sGender" aria-label="Giọng người dẫn"><option value="nu">Dẫn: giọng nữ</option><option value="nam">Dẫn: giọng nam</option><option value="off">Tắt giọng</option></select>
          <button id="bTest" title="Kiểm tra loa và giọng đọc">Thử tiếng</button>
          <button id="bMusic" aria-pressed="false" title="Giai điệu nền">Giai điệu</button>
          <button id="bCap" aria-pressed="true">Phụ đề</button>
          <select id="sSpeed" aria-label="Tốc độ"><option value="0.75">0.75×</option><option value="1" selected>1×</option><option value="1.25">1.25×</option><option value="1.5">1.5×</option></select>
          <span class="sp"></span>
          <button id="bMini" aria-pressed="false">Thu nhỏ</button>
          <button id="bFrame" aria-pressed="true">Khung chuẩn</button>
          <button id="bFull" aria-pressed="false">Phóng to</button>
        </div>
        <div class="chaps ext" id="chaps"></div>
      </section>
    </div>
    <aside class="panel">
      <h2 id="plTitle">Video của bạn</h2>
      <div class="pl" id="pl"></div>
    </aside>
  </div>

  <nav class="tabs" role="tablist">
    <button role="tab" aria-selected="true" data-tab="lib">Kho video</button>
    <button role="tab" aria-selected="false" data-tab="voice">Giọng thuyết minh</button>
    <button role="tab" aria-selected="false" data-tab="perm">Vai trò & quyền hạn</button>
  </nav>

  <section class="tp on" id="tp-lib">
    <div class="chips" id="roleChips"></div>
    <div class="lib" id="lib"></div>
  </section>

  <section class="tp" id="tp-voice">
    <h3 class="sec" style="margin-top:0">Dàn diễn viên giọng đọc</h3>
    <p class="small" id="vHint"></p>
    <div class="mat" style="margin:10px 0 8px"><table class="vtbl" id="castTbl"></table></div>
    <p class="small">Cảm xúc tự điều chỉnh theo lời thoại. Người soạn kịch bản có thể chủ động đánh dấu: đặt <b>[vui]</b>, <b>[ấm]</b>, <b>[trầm]</b>, <b>[cao]</b>, <b>[nhấn]</b>, <b>[đồng cảm]</b>, <b>[nghiêm]</b>, <b>[lo]</b>, <b>[mệt]</b>, <b>[hỏi]</b> ở đầu câu; đặt từ cần nhấn giữa hai dấu sao, ví dụ *quan trọng nhất*.</p>
    <h3 class="sec">Giọng thu âm chuyên nghiệp cho video đang mở</h3>
    <p class="small">Để có chất giọng biên tập viên đúng nghĩa: gửi kịch bản dưới đây cho phát thanh viên thu âm, hoặc đưa vào dịch vụ giọng đọc AI tiếng Việt. Mỗi chương một file MP3, đọc khoảng 140–160 từ mỗi phút, nghỉ nửa giây giữa các câu. Sau khi có file giọng, khai báo trong src/data/voices.js — video tự phát giọng thu âm cho mọi người xem; chương chưa có file sẽ dùng giọng đọc của máy.</p>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin:10px 0">
      <button class="btn" id="bScript">Tải kịch bản lời đọc (.txt)</button>
      <button class="btn" id="bPack">Tải gói tạo giọng chuẩn (.json)</button>
      
      <span class="msg" id="scriptMsg" style="margin:0;align-self:center"></span>
    </div>
    <div class="mat" style="margin-bottom:12px"><table class="vtbl" id="recTbl"></table></div>
    <textarea class="script" id="scriptBox" readonly aria-label="Kịch bản lời đọc"></textarea>
  </section>

  <section class="tp" id="tp-perm">
    <p class="msg" style="margin-top:0">Bảng quyền trên từng màn hình. Mỗi ô có video hướng dẫn riêng — bấm để xem.</p>
    <div class="mat" id="mat"></div>
  </section>
</div>

<div class="ov" id="ov" role="dialog" aria-modal="true" aria-labelledby="ovT">
  <div class="ovb">
    <h2 id="ovT">Chào mừng đến GITA 365</h2>
    <p>Chọn vai đăng nhập để nhận đúng bộ video hướng dẫn cho công việc của bạn.</p>
    <div class="form" style="margin:0"><label class="full">Họ và tên<input id="ovName" autocomplete="name" placeholder="Nhập họ tên"></label></div>
    <div class="roles" id="ovRoles"></div>
    <p style="font-size:12.5px">Chế độ thử: chọn vai tại đây. Trong web app GITA 365, vai và họ tên lấy trực tiếp từ tài khoản đăng nhập (options.user).</p>
    <button class="btn" id="ovGo">Vào xem video</button>
  </div>
</div>
</div>
`;
