#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GITA 365 — TẠO GIỌNG THUYẾT MINH CHO VIDEO HƯỚNG DẪN (chạy offline trên máy của anh/chị)

Đầu vào : gói kịch bản giọng .json (lấy trong trang thử / thư viện: tab "Giọng thuyết minh" → "Tải gói tạo giọng chuẩn")
Đầu ra  : 1 file âm thanh .mp4 (AAC) cho cả video, đồng bộ từng câu, đặt vào public/gita-voice/
          và tự cập nhật danh mục src/data/voices.js (vị trí chương + mốc từng câu).

Giọng   : mô hình tiếng Việt mã nguồn mở VAIS1000 (giọng nữ miền Bắc) chạy bằng sherpa-onnx, không cần mạng
          sau lần tải mô hình đầu tiên. Các vai (Ba mẹ, Con, Coach, Tư vấn, Trainer…) được tạo bằng đổi tông.

Cài đặt : Python 3.9+, ffmpeg (bản có rubberband càng tốt)
          pip install sherpa-onnx numpy soundfile
Chạy    : python tools/voice/tao_giong.py giong-ph_tongquan.json [giong-hs_baihoc.json ...]
Tuỳ chọn: --toc-do 0.88   (nhỏ hơn = đọc chậm hơn)    --khong-cap-nhat  (không sửa src/data/voices.js)
"""
import argparse, json, os, re, shutil, subprocess, sys, tarfile, tempfile, urllib.request

try:
    import numpy as np, soundfile as sf, sherpa_onnx
except ImportError:
    sys.exit("Thiếu thư viện. Chạy: pip install sherpa-onnx numpy soundfile")

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
MODEL_NAME = "vi_VN-vais1000-medium"
MODEL_DIR = os.path.join(os.path.dirname(__file__), "models", "vits-piper-" + MODEL_NAME)
MODEL_URL = "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-" + MODEL_NAME + ".tar.bz2"
SR = 22050

# Tông giọng gốc của từng vai (1.0 = giọng người dẫn)
PITCH = {"dan": 1.0, "coach": 1.05, "coachai": 1.08, "tuvan": 1.07, "cskh": 1.06, "con": 1.2,
         "phuhuynh": 0.8, "trainer": 0.76, "ctv": 0.82, "hocthuat": 0.79, "quantri": 0.77}
# Cách đọc các từ tiếng Anh / viết tắt
REPL = [(r"\bCoach AI\b", "Cốt Ây Ai"), (r"\bCoach\b", "Cốt"), (r"\bGITA\b", "Gi ta"), (r"\bKPI\b", "Ca Pê I"),
        (r"\bTrainer\b", "Trên nơ"), (r"\bcheck-in\b", "chéc in"), (r"\bCSKH\b", "chăm sóc khách hàng"),
        (r"\bAI\b", "Ây Ai"), (r"\bA4\b", "A bốn"), (r"\bWOW\b", "quao"), (r"\bWi-Fi\b", "oai phai"),
        (r"\bvideo\b", "vi đê ô"), (r"\bVideo\b", "Vi đê ô")]
DIG = ["không", "một", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín"]


def n2v(n):
    n = int(n)
    if n < 10: return DIG[n]
    if n < 100:
        t, u = divmod(n, 10); s = "mười" if t == 1 else DIG[t] + " mươi"
        if u == 0: return s
        if u == 1 and t > 1: return s + " mốt"
        if u == 5: return s + " lăm"
        if u == 4 and t > 1: return s + " tư"
        return s + " " + DIG[u]
    if n < 1000:
        h, r = divmod(n, 100); s = DIG[h] + " trăm"
        if r == 0: return s
        if r < 10: return s + " linh " + DIG[r]
        return s + " " + n2v(r)
    return " ".join(DIG[int(c)] for c in str(n))


def norm(t):
    for a, b in REPL: t = re.sub(a, b, t)
    t = re.sub(r"(\d+)\s*[–-]\s*(\d+)", lambda m: n2v(m.group(1)) + " đến " + n2v(m.group(2)), t)
    t = re.sub(r"\d+", lambda m: n2v(m.group(0)), t)
    for a, b in [("×", " nhân "), ("%", " phần trăm"), ("/", " trên "), ("…", ","), ("“", ""), ("”", ""), ('"', "")]:
        t = t.replace(a, b)
    return re.sub(r"\s{2,}", " ", t).strip(" ,")


def ensure_model():
    if os.path.exists(os.path.join(MODEL_DIR, MODEL_NAME + ".onnx")): return
    os.makedirs(os.path.dirname(MODEL_DIR), exist_ok=True)
    print("Đang tải mô hình giọng tiếng Việt (một lần, khoảng 60 MB)…", flush=True)
    tmp = os.path.join(os.path.dirname(MODEL_DIR), "model.tar.bz2")
    urllib.request.urlretrieve(MODEL_URL, tmp)
    with tarfile.open(tmp) as tf: tf.extractall(os.path.dirname(MODEL_DIR))
    os.remove(tmp)


def load_tts():
    ensure_model()
    d = MODEL_DIR
    cfg = sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(
        vits=sherpa_onnx.OfflineTtsVitsModelConfig(model=f"{d}/{MODEL_NAME}.onnx", tokens=f"{d}/tokens.txt",
                                                   data_dir=f"{d}/espeak-ng-data"), num_threads=4), max_num_sentences=1)
    return sherpa_onnx.OfflineTts(cfg)


def has_rubberband():
    try:
        out = subprocess.run(["ffmpeg", "-hide_banner", "-filters"], capture_output=True, text=True).stdout
        return " rubberband " in out
    except FileNotFoundError:
        sys.exit("Chưa cài ffmpeg. Tải tại https://ffmpeg.org/download.html và thêm vào PATH.")


def sil(ms): return np.zeros(int(SR * ms / 1000), dtype=np.float32)


class Voice:
    def __init__(self, speed):
        self.tts = load_tts(); self.speed = speed; self.rb = has_rubberband()
        if not self.rb: print("Lưu ý: ffmpeg không có rubberband — đổi tông bằng cách thay tần số lấy mẫu (chất lượng thấp hơn).")

    def synth(self, text, speed):
        a = self.tts.generate(text, sid=0, speed=float(speed)); x = np.array(a.samples, dtype=np.float32)
        idx = np.where(np.abs(x) > 0.01)[0]
        if len(idx): x = x[max(0, idx[0] - 300):min(len(x), idx[-1] + 900)]
        return x

    def shift(self, x, p):
        if abs(p - 1) < 0.01: return x
        af = (f"rubberband=pitch={p:.3f}:formant=shifted:transients=smooth" if self.rb
              else f"asetrate={int(SR * p)},aresample={SR},atempo={1 / p:.4f}")
        with tempfile.TemporaryDirectory() as d:
            i, o = os.path.join(d, "i.wav"), os.path.join(d, "o.wav"); sf.write(i, x, SR)
            subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", i, "-af", af, o], check=True)
            return sf.read(o, dtype="float32")[0]

    def chapter(self, ch, pack):
        cast, emo = pack["cast"], pack["emo"]; out = [sil(350)]; pos = len(out[0]); prev = None; starts = []
        for L in ch["lines"]:
            cid = L["cast"]; C = cast.get(cid, cast["dan"]); E = emo.get(L["emo"], {})
            gap = []
            if prev is not None: gap.append(sil(700 if cid != prev else 480))
            if E.get("pre"): gap.append(sil(E["pre"]))
            for g in gap: out.append(g); pos += len(g)
            starts.append(int(pos * 1000 / SR))
            base = PITCH.get(cid, 1.0); ep = E.get("p", 1) ** 0.5; vol = E.get("v", 1)
            spd = max(0.7, min(1.25, self.speed * C.get("r", 1) * E.get("r", 1) / 0.94))
            for k, sg in enumerate(L["segs"]):
                t = norm(sg["t"])
                if not t: continue
                if k: out.append(sil(110)); pos += len(out[-1])
                x = self.synth(t, spd * (0.93 if sg.get("emph") else 1))
                x = (self.shift(x, base * ep * (1.03 if sg.get("emph") else 1)) * vol).astype(np.float32)
                out.append(x); pos += len(x)
            prev = cid
        out.append(sil(600))
        return np.concatenate(out), starts


def main():
    ap = argparse.ArgumentParser(description="Tạo giọng thuyết minh cho video hướng dẫn GITA 365")
    ap.add_argument("packs", nargs="+", help="các file giong-*.json")
    ap.add_argument("--toc-do", type=float, default=0.88, help="tốc độ đọc (mặc định 0.88)")
    ap.add_argument("--gioi", choices=["nu", "nam"], default="nu", help="khoá giọng người dẫn trong danh mục")
    ap.add_argument("--ra", default=os.path.join(ROOT, "public", "gita-voice"), help="thư mục lưu file giọng")
    ap.add_argument("--khong-cap-nhat", action="store_true", help="không sửa src/data/voices.js")
    a = ap.parse_args()
    os.makedirs(a.ra, exist_ok=True)
    v = Voice(a.toc_do); entries = {}
    for path in a.packs:
        pk = json.load(open(path, encoding="utf-8"))
        key = pk["id"]; fn = key.replace(":", "-") + ".mp4"
        print(f"▶ {pk.get('title', key)} — {len(pk['chapters'])} chương", flush=True)
        parts, chs, off = [], [], 0
        for ch in pk["chapters"]:
            x, st = v.chapter(ch, pk); d = int(len(x) * 1000 / SR)
            chs.append([int(round(off)), d, st]); parts.append(x); off += len(x) * 1000 / SR
            print(f"   chương {ch['n']:>2}: {d / 1000:5.1f} giây", flush=True)
        full = np.concatenate(parts)
        with tempfile.TemporaryDirectory() as d:
            w = os.path.join(d, "a.wav"); sf.write(w, full, SR)
            subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", w, "-af",
                            "highpass=f=70,acompressor=threshold=-20dB:ratio=2.5:attack=8:release=120,loudnorm=I=-16:TP=-1.5:LRA=9",
                            "-ar", "44100", "-ac", "1", "-c:a", "aac", "-b:a", "80k", "-movflags", "+faststart",
                            os.path.join(a.ra, fn)], check=True)
        entries[key] = {a.gioi: {"full": fn, "ch": chs}}
        print(f"   ✓ {fn} — {len(full) / SR / 60:.1f} phút", flush=True)
    if not a.khong_cap_nhat: update_manifest_merge(entries)
    else: print(json.dumps(entries, ensure_ascii=False))


def update_manifest_merge(entries):
    p = os.path.join(ROOT, "src", "data", "voices.js")
    s = open(p, encoding="utf-8").read(); head, body = s.split("export const VOICES=", 1)
    data = json.loads(body.strip().rstrip(";"))
    for k, val in entries.items(): data.setdefault(k, {}).update(val)
    js = json.dumps(data, ensure_ascii=False, separators=(",", ":")).replace('},"', '},\n"')
    open(p, "w", encoding="utf-8").write(head + "export const VOICES=\n" + js + ";\n")
    print("Đã cập nhật", os.path.relpath(p, ROOT), "— chạy lại `npm run build` để đóng gói.")


if __name__ == "__main__":
    main()
