/*! GITA 365 · Video Guide — thành phần React. */
import { useEffect, useRef } from "react";
import { mountGitaGuide, attachHelpButton } from "../src/index.js";

/**
 * Thư viện / khung phát video hướng dẫn GITA.
 * <GitaVideoGuide user={{name:"Nguyễn Minh Anh", role:"ph"}} screen="tongquan" layout="full" />
 */
export default function GitaVideoGuide({ user, screen, layout = "full", mode, audioBase = "/gita-voice/",
  autoplay = false, theme, onEvent, className, style }) {
  const ref = useRef(null);
  const ctl = useRef(null);
  const evt = useRef(onEvent);
  evt.current = onEvent;

  useEffect(() => {
    ctl.current = mountGitaGuide(ref.current, {
      user, screen, layout, mode, audioBase, autoplay, theme,
      onEvent: e => evt.current && evt.current(e)
    });
    return () => { ctl.current && ctl.current.destroy(); ctl.current = null; };
    // gắn lại khi đổi bố cục hoặc nơi lưu giọng
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [layout, audioBase, theme]);

  useEffect(() => { if (ctl.current && user) ctl.current.setUser(user); }, [user && user.name, user && user.role]);
  useEffect(() => { if (ctl.current && screen) ctl.current.open(user && user.role, screen, { autoplay }); },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [screen]);

  return <div ref={ref} className={className} style={style} />;
}

/**
 * Nút nổi "Video hướng dẫn" gắn vào mỗi màn hình.
 * <GitaHelpButton user={user} screen="baitap" />
 */
export function GitaHelpButton({ user, screen, label = "Video hướng dẫn", audioBase = "/gita-voice/", position = "right", onEvent }) {
  const h = useRef(null);
  useEffect(() => {
    h.current = attachHelpButton({ user, screen, label, audioBase, position, onEvent });
    return () => { h.current && h.current.remove(); h.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [audioBase, position]);
  useEffect(() => { h.current && h.current.update({ user, screen, label }); },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [user && user.name, user && user.role, screen, label]);
  return null;
}
